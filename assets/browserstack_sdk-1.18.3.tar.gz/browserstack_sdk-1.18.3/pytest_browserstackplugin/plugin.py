# coding: UTF-8
import sys
bstack111llll_opy_ = sys.version_info [0] == 2
bstack1llllll_opy_ = 2048
bstack11ll1l_opy_ = 7
def bstack11l11ll_opy_ (bstack1l1ll11_opy_):
    global bstack1l11l_opy_
    bstack1l11ll_opy_ = ord (bstack1l1ll11_opy_ [-1])
    bstack111ll1_opy_ = bstack1l1ll11_opy_ [:-1]
    bstack1lllll_opy_ = bstack1l11ll_opy_ % len (bstack111ll1_opy_)
    bstack11l1l1l_opy_ = bstack111ll1_opy_ [:bstack1lllll_opy_] + bstack111ll1_opy_ [bstack1lllll_opy_:]
    if bstack111llll_opy_:
        bstack1ll1l_opy_ = unicode () .join ([unichr (ord (char) - bstack1llllll_opy_ - (bstack1l11l1_opy_ + bstack1l11ll_opy_) % bstack11ll1l_opy_) for bstack1l11l1_opy_, char in enumerate (bstack11l1l1l_opy_)])
    else:
        bstack1ll1l_opy_ = str () .join ([chr (ord (char) - bstack1llllll_opy_ - (bstack1l11l1_opy_ + bstack1l11ll_opy_) % bstack11ll1l_opy_) for bstack1l11l1_opy_, char in enumerate (bstack11l1l1l_opy_)])
    return eval (bstack1ll1l_opy_)
import atexit
import datetime
import inspect
import logging
import os
import sys
import threading
from uuid import uuid4
import pytest
from packaging import version
from browserstack_sdk.__init__ import (bstack111l111l_opy_, bstack1l1llllll_opy_, update, bstack11lll11l_opy_,
                                       bstack1lll1ll1l1_opy_, bstack111lllll1_opy_, bstack11l1llll1_opy_, bstack11111l11l_opy_,
                                       bstack111ll1l1l_opy_, bstack111lll1ll_opy_, bstack1ll1l11l11_opy_, bstack111ll11l1_opy_,
                                       bstack1111l1ll1_opy_, getAccessibilityResults, getAccessibilityResultsSummary)
from browserstack_sdk._version import __version__
from bstack_utils.capture import bstack1l111l11l1_opy_
from bstack_utils.constants import bstack1ll1111ll_opy_, bstack11l111ll1_opy_, bstack1111l1ll_opy_, bstack111111ll_opy_, \
    bstack1ll1l1l1_opy_
from bstack_utils.helper import bstack1ll1llll1l_opy_, bstack1lll11l1l1_opy_, bstack11lll1lll1_opy_, bstack11ll1llll_opy_, bstack1l111111ll_opy_, \
    bstack11llll111l_opy_, bstack1ll1l1lll_opy_, bstack1ll1l111l1_opy_, bstack1l1111111l_opy_, bstack1llll1111_opy_, Notset, \
    bstack1l1ll1l1l_opy_, bstack11llll1lll_opy_, bstack11llllll1l_opy_, Result, bstack1l11111l1l_opy_, bstack11lllllll1_opy_, bstack1l1l11l1ll_opy_
from bstack_utils.bstack1l1ll11l11_opy_ import bstack1l1ll1l111_opy_
from bstack_utils.messages import bstack1111lllll_opy_, bstack11ll1l1l1_opy_, bstack1llll11ll_opy_, bstack1lll111ll_opy_, bstack1ll11l11_opy_, \
    bstack1l1l1l11_opy_, bstack1111111ll_opy_, bstack1l11l11l1_opy_, bstack1l1ll1ll1_opy_, bstack1lll111111_opy_, \
    bstack1ll111111_opy_, bstack1ll1l1ll1l_opy_
from bstack_utils.proxy import bstack1lllll1ll1_opy_, bstack111l1lll_opy_
from bstack_utils.bstack11111llll_opy_ import bstack1l11l111l1_opy_, bstack1l111ll11l_opy_, bstack1l111lllll_opy_, bstack1l11l1111l_opy_, \
    bstack1l11l11111_opy_, bstack1l111ll1l1_opy_, bstack1l111l1lll_opy_, bstack1lll1l1l1l_opy_, bstack1l111ll1ll_opy_
from bstack_utils.bstack1l1l1ll11l_opy_ import bstack1l1l1ll111_opy_
from bstack_utils.bstack1ll11111ll_opy_ import bstack11ll11lll_opy_, bstack1lllll1l1_opy_, bstack11llll11l_opy_
from bstack_utils.bstack1l11ll11l1_opy_ import bstack11ll1l111l_opy_
from bstack_utils.bstack1lllll1111_opy_ import bstack1ll1lll1ll_opy_
import bstack_utils.bstack1ll1lllll_opy_ as bstack11lllll1l_opy_
bstack1llll1llll_opy_ = None
bstack1lll1llll1_opy_ = None
bstack1llll1l1l_opy_ = None
bstack1ll1l1l11_opy_ = None
bstack1lllll111_opy_ = None
bstack1ll1l111ll_opy_ = None
bstack1ll11ll1l_opy_ = None
bstack1111ll11_opy_ = None
bstack1llll11l1l_opy_ = None
bstack11llll1ll_opy_ = None
bstack11lll111l_opy_ = None
bstack1llll1ll11_opy_ = None
bstack1llll11111_opy_ = None
bstack11lllll11_opy_ = bstack11l11ll_opy_ (u"ࠫࠬፒ")
CONFIG = {}
bstack11lll11l1_opy_ = False
bstack1111l111_opy_ = bstack11l11ll_opy_ (u"ࠬ࠭ፓ")
bstack1ll11llll1_opy_ = bstack11l11ll_opy_ (u"࠭ࠧፔ")
bstack1ll1ll1ll_opy_ = False
bstack11lll111_opy_ = []
bstack11llll11_opy_ = bstack11l111ll1_opy_
bstack111lllllll_opy_ = bstack11l11ll_opy_ (u"ࠧࡱࡻࡷࡩࡸࡺࠧፕ")
bstack111ll1ll1l_opy_ = False
logger = logging.getLogger(__name__)
logging.basicConfig(level=bstack11llll11_opy_,
                    format=bstack11l11ll_opy_ (u"ࠨ࡞ࡱࠩ࠭ࡧࡳࡤࡶ࡬ࡱࡪ࠯ࡳࠡ࡝ࠨࠬࡳࡧ࡭ࡦࠫࡶࡡࡠࠫࠨ࡭ࡧࡹࡩࡱࡴࡡ࡮ࡧࠬࡷࡢࠦ࠭ࠡࠧࠫࡱࡪࡹࡳࡢࡩࡨ࠭ࡸ࠭ፖ"),
                    datefmt=bstack11l11ll_opy_ (u"ࠩࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠫፗ"),
                    stream=sys.stdout)
store = {
    bstack11l11ll_opy_ (u"ࠪࡧࡺࡸࡲࡦࡰࡷࡣ࡭ࡵ࡯࡬ࡡࡸࡹ࡮ࡪࠧፘ"): []
}
def bstack1ll11l1111_opy_():
    global CONFIG
    global bstack11llll11_opy_
    if bstack11l11ll_opy_ (u"ࠫࡱࡵࡧࡍࡧࡹࡩࡱ࠭ፙ") in CONFIG:
        bstack11llll11_opy_ = bstack1ll1111ll_opy_[CONFIG[bstack11l11ll_opy_ (u"ࠬࡲ࡯ࡨࡎࡨࡺࡪࡲࠧፚ")]]
        logging.getLogger().setLevel(bstack11llll11_opy_)
try:
    from playwright.sync_api import (
        BrowserContext,
        Page
    )
except:
    pass
import json
_11l1111l1l_opy_ = {}
current_test_uuid = None
def bstack1l1lllll1_opy_(page, bstack111ll111l_opy_):
    try:
        page.evaluate(bstack11l11ll_opy_ (u"ࠨ࡟ࠡ࠿ࡁࠤࢀࢃࠢ፛"),
                      bstack11l11ll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡥࡥࡹࡧࡦࡹࡹࡵࡲ࠻ࠢࡾࠦࡦࡩࡴࡪࡱࡱࠦ࠿ࠦࠢࡴࡧࡷࡗࡪࡹࡳࡪࡱࡱࡒࡦࡳࡥࠣ࠮ࠣࠦࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠢ࠻ࠢࡾࠦࡳࡧ࡭ࡦࠤ࠽ࠫ፜") + json.dumps(
                          bstack111ll111l_opy_) + bstack11l11ll_opy_ (u"ࠣࡿࢀࠦ፝"))
    except Exception as e:
        print(bstack11l11ll_opy_ (u"ࠤࡨࡼࡨ࡫ࡰࡵ࡫ࡲࡲࠥ࡯࡮ࠡࡲ࡯ࡥࡾࡽࡲࡪࡩ࡫ࡸࠥࡹࡥࡴࡵ࡬ࡳࡳࠦ࡮ࡢ࡯ࡨࠤࢀࢃࠢ፞"), e)
def bstack1lll111l1_opy_(page, message, level):
    try:
        page.evaluate(bstack11l11ll_opy_ (u"ࠥࡣࠥࡃ࠾ࠡࡽࢀࠦ፟"), bstack11l11ll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡢࡩࡽ࡫ࡣࡶࡶࡲࡶ࠿ࠦࡻࠣࡣࡦࡸ࡮ࡵ࡮ࠣ࠼ࠣࠦࡦࡴ࡮ࡰࡶࡤࡸࡪࠨࠬࠡࠤࡤࡶ࡬ࡻ࡭ࡦࡰࡷࡷࠧࡀࠠࡼࠤࡧࡥࡹࡧࠢ࠻ࠩ፠") + json.dumps(
            message) + bstack11l11ll_opy_ (u"ࠬ࠲ࠢ࡭ࡧࡹࡩࡱࠨ࠺ࠨ፡") + json.dumps(level) + bstack11l11ll_opy_ (u"࠭ࡽࡾࠩ።"))
    except Exception as e:
        print(bstack11l11ll_opy_ (u"ࠢࡦࡺࡦࡩࡵࡺࡩࡰࡰࠣ࡭ࡳࠦࡰ࡭ࡣࡼࡻࡷ࡯ࡧࡩࡶࠣࡥࡳࡴ࡯ࡵࡣࡷ࡭ࡴࡴࠠࡼࡿࠥ፣"), e)
def bstack1l11lll1_opy_(page, status, message=bstack11l11ll_opy_ (u"ࠣࠤ፤")):
    try:
        if (status == bstack11l11ll_opy_ (u"ࠤࡩࡥ࡮ࡲࡥࡥࠤ፥")):
            page.evaluate(bstack11l11ll_opy_ (u"ࠥࡣࠥࡃ࠾ࠡࡽࢀࠦ፦"),
                          bstack11l11ll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡢࡩࡽ࡫ࡣࡶࡶࡲࡶ࠿ࠦࡻࠣࡣࡦࡸ࡮ࡵ࡮ࠣ࠼ࠣࠦࡸ࡫ࡴࡔࡧࡶࡷ࡮ࡵ࡮ࡔࡶࡤࡸࡺࡹࠢ࠭ࠢࠥࡥࡷ࡭ࡵ࡮ࡧࡱࡸࡸࠨ࠺ࠡࡽࠥࡶࡪࡧࡳࡰࡰࠥ࠾ࠬ፧") + json.dumps(
                              bstack11l11ll_opy_ (u"࡙ࠧࡣࡦࡰࡤࡶ࡮ࡵࠠࡧࡣ࡬ࡰࡪࡪࠠࡸ࡫ࡷ࡬࠿ࠦࠢ፨") + str(message)) + bstack11l11ll_opy_ (u"࠭ࠬࠣࡵࡷࡥࡹࡻࡳࠣ࠼ࠪ፩") + json.dumps(status) + bstack11l11ll_opy_ (u"ࠢࡾࡿࠥ፪"))
        else:
            page.evaluate(bstack11l11ll_opy_ (u"ࠣࡡࠣࡁࡃࠦࡻࡾࠤ፫"),
                          bstack11l11ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡠࡧࡻࡩࡨࡻࡴࡰࡴ࠽ࠤࢀࠨࡡࡤࡶ࡬ࡳࡳࠨ࠺ࠡࠤࡶࡩࡹ࡙ࡥࡴࡵ࡬ࡳࡳ࡙ࡴࡢࡶࡸࡷࠧ࠲ࠠࠣࡣࡵ࡫ࡺࡳࡥ࡯ࡶࡶࠦ࠿ࠦࡻࠣࡵࡷࡥࡹࡻࡳࠣ࠼ࠪ፬") + json.dumps(
                              status) + bstack11l11ll_opy_ (u"ࠥࢁࢂࠨ፭"))
    except Exception as e:
        print(bstack11l11ll_opy_ (u"ࠦࡪࡾࡣࡦࡲࡷ࡭ࡴࡴࠠࡪࡰࠣࡴࡱࡧࡹࡸࡴ࡬࡫࡭ࡺࠠࡴࡧࡷࠤࡸ࡫ࡳࡴ࡫ࡲࡲࠥࡹࡴࡢࡶࡸࡷࠥࢁࡽࠣ፮"), e)
def pytest_configure(config):
    config.args = bstack1ll1lll1ll_opy_.bstack1l1l1l1l1l_opy_(config.args)
@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    bstack111ll11ll1_opy_ = item.config.getoption(bstack11l11ll_opy_ (u"ࠬࡹ࡫ࡪࡲࡖࡩࡸࡹࡩࡰࡰࡑࡥࡲ࡫ࠧ፯"))
    plugins = item.config.getoption(bstack11l11ll_opy_ (u"ࠨࡰ࡭ࡷࡪ࡭ࡳࡹࠢ፰"))
    report = outcome.get_result()
    bstack111lllll11_opy_(item, call, report)
    if bstack11l11ll_opy_ (u"ࠢࡱࡻࡷࡩࡸࡺ࡟ࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡶ࡬ࡶࡩ࡬ࡲࠧ፱") not in plugins or bstack1llll1111_opy_():
        return
    summary = []
    driver = getattr(item, bstack11l11ll_opy_ (u"ࠣࡡࡧࡶ࡮ࡼࡥࡳࠤ፲"), None)
    page = getattr(item, bstack11l11ll_opy_ (u"ࠤࡢࡴࡦ࡭ࡥࠣ፳"), None)
    try:
        if (driver == None):
            driver = threading.current_thread().bstackSessionDriver
    except:
        pass
    item._driver = driver
    if (driver is not None):
        bstack111lll1l1l_opy_(item, report, summary, bstack111ll11ll1_opy_)
    if (page is not None):
        bstack111ll1ll11_opy_(item, report, summary, bstack111ll11ll1_opy_)
def bstack111lll1l1l_opy_(item, report, summary, bstack111ll11ll1_opy_):
    if report.when in [bstack11l11ll_opy_ (u"ࠥࡷࡪࡺࡵࡱࠤ፴"), bstack11l11ll_opy_ (u"ࠦࡹ࡫ࡡࡳࡦࡲࡻࡳࠨ፵")]:
        return
    if not bstack11lll1lll1_opy_():
        return
    try:
        if (str(bstack111ll11ll1_opy_).lower() != bstack11l11ll_opy_ (u"ࠬࡺࡲࡶࡧࠪ፶")):
            item._driver.execute_script(
                bstack11l11ll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡤ࡫ࡸࡦࡥࡸࡸࡴࡸ࠺ࠡࡽࠥࡥࡨࡺࡩࡰࡰࠥ࠾ࠥࠨࡳࡦࡶࡖࡩࡸࡹࡩࡰࡰࡑࡥࡲ࡫ࠢ࠭ࠢࠥࡥࡷ࡭ࡵ࡮ࡧࡱࡸࡸࠨ࠺ࠡࡽࠥࡲࡦࡳࡥࠣ࠼ࠣࠫ፷") + json.dumps(
                    report.nodeid) + bstack11l11ll_opy_ (u"ࠧࡾࡿࠪ፸"))
    except Exception as e:
        summary.append(
            bstack11l11ll_opy_ (u"࡙ࠣࡄࡖࡓࡏࡎࡈ࠼ࠣࡊࡦ࡯࡬ࡦࡦࠣࡸࡴࠦ࡭ࡢࡴ࡮ࠤࡸ࡫ࡳࡴ࡫ࡲࡲࠥࡴࡡ࡮ࡧ࠽ࠤࢀ࠶ࡽࠣ፹").format(e)
        )
    passed = report.passed or report.skipped or (report.failed and hasattr(report, bstack11l11ll_opy_ (u"ࠤࡺࡥࡸࡾࡦࡢ࡫࡯ࠦ፺")))
    bstack111ll11l_opy_ = bstack11l11ll_opy_ (u"ࠥࠦ፻")
    bstack1l111ll1ll_opy_(report)
    if not passed:
        try:
            bstack111ll11l_opy_ = report.longrepr.reprcrash
        except Exception as e:
            summary.append(
                bstack11l11ll_opy_ (u"ࠦ࡜ࡇࡒࡏࡋࡑࡋ࠿ࠦࡆࡢ࡫࡯ࡩࡩࠦࡴࡰࠢࡧࡩࡹ࡫ࡲ࡮࡫ࡱࡩࠥ࡬ࡡࡪ࡮ࡸࡶࡪࠦࡲࡦࡣࡶࡳࡳࡀࠠࡼ࠲ࢀࠦ፼").format(e)
            )
        try:
            if (threading.current_thread().bstackTestErrorMessages == None):
                threading.current_thread().bstackTestErrorMessages = []
        except Exception as e:
            threading.current_thread().bstackTestErrorMessages = []
        threading.current_thread().bstackTestErrorMessages.append(str(bstack111ll11l_opy_))
    if not report.skipped:
        passed = report.passed or (report.failed and hasattr(report, bstack11l11ll_opy_ (u"ࠧࡽࡡࡴࡺࡩࡥ࡮ࡲࠢ፽")))
        bstack111ll11l_opy_ = bstack11l11ll_opy_ (u"ࠨࠢ፾")
        if not passed:
            try:
                bstack111ll11l_opy_ = report.longrepr.reprcrash
            except Exception as e:
                summary.append(
                    bstack11l11ll_opy_ (u"ࠢࡘࡃࡕࡒࡎࡔࡇ࠻ࠢࡉࡥ࡮ࡲࡥࡥࠢࡷࡳࠥࡪࡥࡵࡧࡵࡱ࡮ࡴࡥࠡࡨࡤ࡭ࡱࡻࡲࡦࠢࡵࡩࡦࡹ࡯࡯࠼ࠣࡿ࠵ࢃࠢ፿").format(e)
                )
            try:
                if (threading.current_thread().bstackTestErrorMessages == None):
                    threading.current_thread().bstackTestErrorMessages = []
            except Exception as e:
                threading.current_thread().bstackTestErrorMessages = []
            threading.current_thread().bstackTestErrorMessages.append(str(bstack111ll11l_opy_))
        try:
            if passed:
                item._driver.execute_script(
                    bstack11l11ll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࡟ࡦࡺࡨࡧࡺࡺ࡯ࡳ࠼ࠣࡿࡡࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠢࡢࡥࡷ࡭ࡴࡴࠢ࠻ࠢࠥࡥࡳࡴ࡯ࡵࡣࡷࡩࠧ࠲ࠠ࡝ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠥࡥࡷ࡭ࡵ࡮ࡧࡱࡸࡸࠨ࠺ࠡࡽ࡟ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠤ࡯ࡩࡻ࡫࡬ࠣ࠼ࠣࠦ࡮ࡴࡦࡰࠤ࠯ࠤࡡࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠦࡩࡧࡴࡢࠤ࠽ࠤࠬᎀ")
                    + json.dumps(bstack11l11ll_opy_ (u"ࠤࡳࡥࡸࡹࡥࡥࠣࠥᎁ"))
                    + bstack11l11ll_opy_ (u"ࠥࡠࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࢃ࡜ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࢂࠨᎂ")
                )
            else:
                item._driver.execute_script(
                    bstack11l11ll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡢࡩࡽ࡫ࡣࡶࡶࡲࡶ࠿ࠦࡻ࡝ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠥࡥࡨࡺࡩࡰࡰࠥ࠾ࠥࠨࡡ࡯ࡰࡲࡸࡦࡺࡥࠣ࠮ࠣࡠࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠨࡡࡳࡩࡸࡱࡪࡴࡴࡴࠤ࠽ࠤࢀࡢࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠧࡲࡥࡷࡧ࡯ࠦ࠿ࠦࠢࡦࡴࡵࡳࡷࠨࠬࠡ࡞ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠣࡦࡤࡸࡦࠨ࠺ࠡࠩᎃ")
                    + json.dumps(str(bstack111ll11l_opy_))
                    + bstack11l11ll_opy_ (u"ࠧࡢࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࡾ࡞ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡽࠣᎄ")
                )
        except Exception as e:
            summary.append(bstack11l11ll_opy_ (u"ࠨࡗࡂࡔࡑࡍࡓࡍ࠺ࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡶࡲࠤࡦࡴ࡮ࡰࡶࡤࡸࡪࡀࠠࡼ࠲ࢀࠦᎅ").format(e))
def bstack111ll1ll11_opy_(item, report, summary, bstack111ll11ll1_opy_):
    if report.when in [bstack11l11ll_opy_ (u"ࠢࡴࡧࡷࡹࡵࠨᎆ"), bstack11l11ll_opy_ (u"ࠣࡶࡨࡥࡷࡪ࡯ࡸࡰࠥᎇ")]:
        return
    if (str(bstack111ll11ll1_opy_).lower() != bstack11l11ll_opy_ (u"ࠩࡷࡶࡺ࡫ࠧᎈ")):
        bstack1l1lllll1_opy_(item._page, report.nodeid)
    passed = report.passed or report.skipped or (report.failed and hasattr(report, bstack11l11ll_opy_ (u"ࠥࡻࡦࡹࡸࡧࡣ࡬ࡰࠧᎉ")))
    bstack111ll11l_opy_ = bstack11l11ll_opy_ (u"ࠦࠧᎊ")
    bstack1l111ll1ll_opy_(report)
    if not report.skipped:
        if not passed:
            try:
                bstack111ll11l_opy_ = report.longrepr.reprcrash
            except Exception as e:
                summary.append(
                    bstack11l11ll_opy_ (u"ࠧ࡝ࡁࡓࡐࡌࡒࡌࡀࠠࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡨࡪࡺࡥࡳ࡯࡬ࡲࡪࠦࡦࡢ࡫࡯ࡹࡷ࡫ࠠࡳࡧࡤࡷࡴࡴ࠺ࠡࡽ࠳ࢁࠧᎋ").format(e)
                )
        try:
            if passed:
                bstack1l11lll1_opy_(item._page, bstack11l11ll_opy_ (u"ࠨࡰࡢࡵࡶࡩࡩࠨᎌ"))
            else:
                if bstack111ll11l_opy_:
                    bstack1lll111l1_opy_(item._page, str(bstack111ll11l_opy_), bstack11l11ll_opy_ (u"ࠢࡦࡴࡵࡳࡷࠨᎍ"))
                    bstack1l11lll1_opy_(item._page, bstack11l11ll_opy_ (u"ࠣࡨࡤ࡭ࡱ࡫ࡤࠣᎎ"), str(bstack111ll11l_opy_))
                else:
                    bstack1l11lll1_opy_(item._page, bstack11l11ll_opy_ (u"ࠤࡩࡥ࡮ࡲࡥࡥࠤᎏ"))
        except Exception as e:
            summary.append(bstack11l11ll_opy_ (u"࡛ࠥࡆࡘࡎࡊࡐࡊ࠾ࠥࡌࡡࡪ࡮ࡨࡨࠥࡺ࡯ࠡࡷࡳࡨࡦࡺࡥࠡࡵࡨࡷࡸ࡯࡯࡯ࠢࡶࡸࡦࡺࡵࡴ࠼ࠣࡿ࠵ࢃࠢ᎐").format(e))
try:
    from typing import Generator
    import pytest_playwright.pytest_playwright as p
    @pytest.fixture
    def page(context: BrowserContext, request: pytest.FixtureRequest) -> Generator[Page, None, None]:
        page = context.new_page()
        request.node._page = page
        yield page
except:
    pass
def pytest_addoption(parser):
    parser.addoption(bstack11l11ll_opy_ (u"ࠦ࠲࠳ࡳ࡬࡫ࡳࡗࡪࡹࡳࡪࡱࡱࡒࡦࡳࡥࠣ᎑"), default=bstack11l11ll_opy_ (u"ࠧࡌࡡ࡭ࡵࡨࠦ᎒"), help=bstack11l11ll_opy_ (u"ࠨࡁࡶࡶࡲࡱࡦࡺࡩࡤࠢࡶࡩࡹࠦࡳࡦࡵࡶ࡭ࡴࡴࠠ࡯ࡣࡰࡩࠧ᎓"))
    try:
        import pytest_selenium.pytest_selenium
    except:
        parser.addoption(bstack11l11ll_opy_ (u"ࠢ࠮࠯ࡧࡶ࡮ࡼࡥࡳࠤ᎔"), action=bstack11l11ll_opy_ (u"ࠣࡵࡷࡳࡷ࡫ࠢ᎕"), default=bstack11l11ll_opy_ (u"ࠤࡦ࡬ࡷࡵ࡭ࡦࠤ᎖"),
                         help=bstack11l11ll_opy_ (u"ࠥࡈࡷ࡯ࡶࡦࡴࠣࡸࡴࠦࡲࡶࡰࠣࡸࡪࡹࡴࡴࠤ᎗"))
def bstack111ll1l11l_opy_(log):
    if not (log[bstack11l11ll_opy_ (u"ࠫࡲ࡫ࡳࡴࡣࡪࡩࠬ᎘")] and log[bstack11l11ll_opy_ (u"ࠬࡳࡥࡴࡵࡤ࡫ࡪ࠭᎙")].strip()):
        return
    active = bstack11l1111111_opy_()
    log = {
        bstack11l11ll_opy_ (u"࠭࡬ࡦࡸࡨࡰࠬ᎚"): log[bstack11l11ll_opy_ (u"ࠧ࡭ࡧࡹࡩࡱ࠭᎛")],
        bstack11l11ll_opy_ (u"ࠨࡶ࡬ࡱࡪࡹࡴࡢ࡯ࡳࠫ᎜"): datetime.datetime.utcnow().isoformat() + bstack11l11ll_opy_ (u"ࠩ࡝ࠫ᎝"),
        bstack11l11ll_opy_ (u"ࠪࡱࡪࡹࡳࡢࡩࡨࠫ᎞"): log[bstack11l11ll_opy_ (u"ࠫࡲ࡫ࡳࡴࡣࡪࡩࠬ᎟")],
    }
    if active:
        if active[bstack11l11ll_opy_ (u"ࠬࡺࡹࡱࡧࠪᎠ")] == bstack11l11ll_opy_ (u"࠭ࡨࡰࡱ࡮ࠫᎡ"):
            log[bstack11l11ll_opy_ (u"ࠧࡩࡱࡲ࡯ࡤࡸࡵ࡯ࡡࡸࡹ࡮ࡪࠧᎢ")] = active[bstack11l11ll_opy_ (u"ࠨࡪࡲࡳࡰࡥࡲࡶࡰࡢࡹࡺ࡯ࡤࠨᎣ")]
        elif active[bstack11l11ll_opy_ (u"ࠩࡷࡽࡵ࡫ࠧᎤ")] == bstack11l11ll_opy_ (u"ࠪࡸࡪࡹࡴࠨᎥ"):
            log[bstack11l11ll_opy_ (u"ࠫࡹ࡫ࡳࡵࡡࡵࡹࡳࡥࡵࡶ࡫ࡧࠫᎦ")] = active[bstack11l11ll_opy_ (u"ࠬࡺࡥࡴࡶࡢࡶࡺࡴ࡟ࡶࡷ࡬ࡨࠬᎧ")]
    bstack1ll1lll1ll_opy_.bstack1l1l11llll_opy_([log])
def bstack11l1111111_opy_():
    if len(store[bstack11l11ll_opy_ (u"࠭ࡣࡶࡴࡵࡩࡳࡺ࡟ࡩࡱࡲ࡯ࡤࡻࡵࡪࡦࠪᎨ")]) > 0 and store[bstack11l11ll_opy_ (u"ࠧࡤࡷࡵࡶࡪࡴࡴࡠࡪࡲࡳࡰࡥࡵࡶ࡫ࡧࠫᎩ")][-1]:
        return {
            bstack11l11ll_opy_ (u"ࠨࡶࡼࡴࡪ࠭Ꭺ"): bstack11l11ll_opy_ (u"ࠩ࡫ࡳࡴࡱࠧᎫ"),
            bstack11l11ll_opy_ (u"ࠪ࡬ࡴࡵ࡫ࡠࡴࡸࡲࡤࡻࡵࡪࡦࠪᎬ"): store[bstack11l11ll_opy_ (u"ࠫࡨࡻࡲࡳࡧࡱࡸࡤ࡮࡯ࡰ࡭ࡢࡹࡺ࡯ࡤࠨᎭ")][-1]
        }
    if store.get(bstack11l11ll_opy_ (u"ࠬࡩࡵࡳࡴࡨࡲࡹࡥࡴࡦࡵࡷࡣࡺࡻࡩࡥࠩᎮ"), None):
        return {
            bstack11l11ll_opy_ (u"࠭ࡴࡺࡲࡨࠫᎯ"): bstack11l11ll_opy_ (u"ࠧࡵࡧࡶࡸࠬᎰ"),
            bstack11l11ll_opy_ (u"ࠨࡶࡨࡷࡹࡥࡲࡶࡰࡢࡹࡺ࡯ࡤࠨᎱ"): store[bstack11l11ll_opy_ (u"ࠩࡦࡹࡷࡸࡥ࡯ࡶࡢࡸࡪࡹࡴࡠࡷࡸ࡭ࡩ࠭Ꮂ")]
        }
    return None
bstack111ll1l1l1_opy_ = bstack1l111l11l1_opy_(bstack111ll1l11l_opy_)
def pytest_runtest_call(item):
    try:
        global CONFIG
        global bstack111ll1ll1l_opy_
        if bstack111ll1ll1l_opy_:
            driver = getattr(item, bstack11l11ll_opy_ (u"ࠪࡣࡩࡸࡩࡷࡧࡵࠫᎳ"), None)
            bstack111ll11lll_opy_ = bstack11lllll1l_opy_.bstack11l11l1l1l_opy_(CONFIG, bstack11llll111l_opy_(item.own_markers))
            item._a11y_started = bstack11lllll1l_opy_.bstack11l111l111_opy_(driver, bstack111ll11lll_opy_)
        if not bstack1ll1lll1ll_opy_.on() or bstack111lllllll_opy_ != bstack11l11ll_opy_ (u"ࠫࡵࡿࡴࡦࡵࡷࠫᎴ"):
            return
        global current_test_uuid, bstack111ll1l1l1_opy_
        bstack111ll1l1l1_opy_.start()
        bstack111ll1l1ll_opy_ = {
            bstack11l11ll_opy_ (u"ࠬࡻࡵࡪࡦࠪᎵ"): uuid4().__str__(),
            bstack11l11ll_opy_ (u"࠭ࡳࡵࡣࡵࡸࡪࡪ࡟ࡢࡶࠪᎶ"): datetime.datetime.utcnow().isoformat() + bstack11l11ll_opy_ (u"࡛ࠧࠩᎷ")
        }
        current_test_uuid = bstack111ll1l1ll_opy_[bstack11l11ll_opy_ (u"ࠨࡷࡸ࡭ࡩ࠭Ꮈ")]
        store[bstack11l11ll_opy_ (u"ࠩࡦࡹࡷࡸࡥ࡯ࡶࡢࡸࡪࡹࡴࡠࡷࡸ࡭ࡩ࠭Ꮉ")] = bstack111ll1l1ll_opy_[bstack11l11ll_opy_ (u"ࠪࡹࡺ࡯ࡤࠨᎺ")]
        threading.current_thread().current_test_uuid = current_test_uuid
        _11l1111l1l_opy_[item.nodeid] = {**_11l1111l1l_opy_[item.nodeid], **bstack111ll1l1ll_opy_}
        bstack111lll1ll1_opy_(item, _11l1111l1l_opy_[item.nodeid], bstack11l11ll_opy_ (u"࡙ࠫ࡫ࡳࡵࡔࡸࡲࡘࡺࡡࡳࡶࡨࡨࠬᎻ"))
    except Exception as err:
        print(bstack11l11ll_opy_ (u"ࠬࡋࡸࡤࡧࡳࡸ࡮ࡵ࡮ࠡ࡫ࡱࠤࡵࡿࡴࡦࡵࡷࡣࡷࡻ࡮ࡵࡧࡶࡸࡤࡩࡡ࡭࡮࠽ࠤࢀࢃࠧᎼ"), str(err))
def pytest_runtest_setup(item):
    if bstack1l1111111l_opy_():
        atexit.register(bstack11l111ll_opy_)
        try:
            item.config.hook.pytest_selenium_runtest_makereport = bstack1l11l111l1_opy_
        except Exception as err:
            threading.current_thread().testStatus = bstack11l11ll_opy_ (u"࠭ࡰࡢࡵࡶࡩࡩ࠭Ꮍ")
    try:
        if not bstack1ll1lll1ll_opy_.on():
            return
        bstack111ll1l1l1_opy_.start()
        uuid = uuid4().__str__()
        bstack111ll1l1ll_opy_ = {
            bstack11l11ll_opy_ (u"ࠧࡶࡷ࡬ࡨࠬᎾ"): uuid,
            bstack11l11ll_opy_ (u"ࠨࡵࡷࡥࡷࡺࡥࡥࡡࡤࡸࠬᎿ"): datetime.datetime.utcnow().isoformat() + bstack11l11ll_opy_ (u"ࠩ࡝ࠫᏀ"),
            bstack11l11ll_opy_ (u"ࠪࡸࡾࡶࡥࠨᏁ"): bstack11l11ll_opy_ (u"ࠫ࡭ࡵ࡯࡬ࠩᏂ"),
            bstack11l11ll_opy_ (u"ࠬ࡮࡯ࡰ࡭ࡢࡸࡾࡶࡥࠨᏃ"): bstack11l11ll_opy_ (u"࠭ࡂࡆࡈࡒࡖࡊࡥࡅࡂࡅࡋࠫᏄ"),
            bstack11l11ll_opy_ (u"ࠧࡩࡱࡲ࡯ࡤࡴࡡ࡮ࡧࠪᏅ"): bstack11l11ll_opy_ (u"ࠨࡵࡨࡸࡺࡶࠧᏆ")
        }
        threading.current_thread().bstack111lll11ll_opy_ = uuid
        store[bstack11l11ll_opy_ (u"ࠩࡦࡹࡷࡸࡥ࡯ࡶࡢࡸࡪࡹࡴࡠ࡫ࡷࡩࡲ࠭Ꮗ")] = item
        store[bstack11l11ll_opy_ (u"ࠪࡧࡺࡸࡲࡦࡰࡷࡣ࡭ࡵ࡯࡬ࡡࡸࡹ࡮ࡪࠧᏈ")] = [uuid]
        if not _11l1111l1l_opy_.get(item.nodeid, None):
            _11l1111l1l_opy_[item.nodeid] = {bstack11l11ll_opy_ (u"ࠫ࡭ࡵ࡯࡬ࡵࠪᏉ"): [], bstack11l11ll_opy_ (u"ࠬ࡬ࡩࡹࡶࡸࡶࡪࡹࠧᏊ"): []}
        _11l1111l1l_opy_[item.nodeid][bstack11l11ll_opy_ (u"࠭ࡨࡰࡱ࡮ࡷࠬᏋ")].append(bstack111ll1l1ll_opy_[bstack11l11ll_opy_ (u"ࠧࡶࡷ࡬ࡨࠬᏌ")])
        _11l1111l1l_opy_[item.nodeid + bstack11l11ll_opy_ (u"ࠨ࠯ࡶࡩࡹࡻࡰࠨᏍ")] = bstack111ll1l1ll_opy_
        bstack11l1111l11_opy_(item, bstack111ll1l1ll_opy_, bstack11l11ll_opy_ (u"ࠩࡋࡳࡴࡱࡒࡶࡰࡖࡸࡦࡸࡴࡦࡦࠪᏎ"))
    except Exception as err:
        print(bstack11l11ll_opy_ (u"ࠪࡉࡽࡩࡥࡱࡶ࡬ࡳࡳࠦࡩ࡯ࠢࡳࡽࡹ࡫ࡳࡵࡡࡵࡹࡳࡺࡥࡴࡶࡢࡷࡪࡺࡵࡱ࠼ࠣࡿࢂ࠭Ꮟ"), str(err))
def pytest_runtest_teardown(item):
    try:
        if getattr(item, bstack11l11ll_opy_ (u"ࠫࡤࡧ࠱࠲ࡻࡢࡷࡹࡧࡲࡵࡧࡧࠫᏐ"), False):
            logger.info(bstack11l11ll_opy_ (u"ࠧࡇࡵࡵࡱࡰࡥࡹ࡫ࠠࡵࡧࡶࡸࠥࡩࡡࡴࡧࠣࡩࡽ࡫ࡣࡶࡶ࡬ࡳࡳࠦࡨࡢࡵࠣࡩࡳࡪࡥࡥ࠰ࠣࡔࡷࡵࡣࡦࡵࡶ࡭ࡳ࡭ࠠࡧࡱࡵࠤࡦࡩࡣࡦࡵࡶ࡭ࡧ࡯࡬ࡪࡶࡼࠤࡹ࡫ࡳࡵ࡫ࡱ࡫ࠥ࡯ࡳࠡࡷࡱࡨࡪࡸࡷࡢࡻ࠱ࠤࠧᏑ"))
            driver = getattr(item, bstack11l11ll_opy_ (u"࠭࡟ࡥࡴ࡬ࡺࡪࡸࠧᏒ"), None)
            bstack11lllll1l_opy_.bstack11l111l1ll_opy_(driver, item)
        if not bstack1ll1lll1ll_opy_.on():
            return
        bstack111ll1l1ll_opy_ = {
            bstack11l11ll_opy_ (u"ࠧࡶࡷ࡬ࡨࠬᏓ"): uuid4().__str__(),
            bstack11l11ll_opy_ (u"ࠨࡵࡷࡥࡷࡺࡥࡥࡡࡤࡸࠬᏔ"): datetime.datetime.utcnow().isoformat() + bstack11l11ll_opy_ (u"ࠩ࡝ࠫᏕ"),
            bstack11l11ll_opy_ (u"ࠪࡸࡾࡶࡥࠨᏖ"): bstack11l11ll_opy_ (u"ࠫ࡭ࡵ࡯࡬ࠩᏗ"),
            bstack11l11ll_opy_ (u"ࠬ࡮࡯ࡰ࡭ࡢࡸࡾࡶࡥࠨᏘ"): bstack11l11ll_opy_ (u"࠭ࡁࡇࡖࡈࡖࡤࡋࡁࡄࡊࠪᏙ"),
            bstack11l11ll_opy_ (u"ࠧࡩࡱࡲ࡯ࡤࡴࡡ࡮ࡧࠪᏚ"): bstack11l11ll_opy_ (u"ࠨࡶࡨࡥࡷࡪ࡯ࡸࡰࠪᏛ")
        }
        _11l1111l1l_opy_[item.nodeid + bstack11l11ll_opy_ (u"ࠩ࠰ࡸࡪࡧࡲࡥࡱࡺࡲࠬᏜ")] = bstack111ll1l1ll_opy_
        bstack11l1111l11_opy_(item, bstack111ll1l1ll_opy_, bstack11l11ll_opy_ (u"ࠪࡌࡴࡵ࡫ࡓࡷࡱࡗࡹࡧࡲࡵࡧࡧࠫᏝ"))
    except Exception as err:
        print(bstack11l11ll_opy_ (u"ࠫࡊࡾࡣࡦࡲࡷ࡭ࡴࡴࠠࡪࡰࠣࡴࡾࡺࡥࡴࡶࡢࡶࡺࡴࡴࡦࡵࡷࡣࡹ࡫ࡡࡳࡦࡲࡻࡳࡀࠠࡼࡿࠪᏞ"), str(err))
@pytest.hookimpl(hookwrapper=True)
def pytest_fixture_setup(fixturedef, request):
    if not bstack1ll1lll1ll_opy_.on():
        yield
        return
    start_time = datetime.datetime.now()
    if bstack1l11l1111l_opy_(fixturedef.argname):
        store[bstack11l11ll_opy_ (u"ࠬࡩࡵࡳࡴࡨࡲࡹࡥ࡭ࡰࡦࡸࡰࡪࡥࡩࡵࡧࡰࠫᏟ")] = request.node
    elif bstack1l11l11111_opy_(fixturedef.argname):
        store[bstack11l11ll_opy_ (u"࠭ࡣࡶࡴࡵࡩࡳࡺ࡟ࡤ࡮ࡤࡷࡸࡥࡩࡵࡧࡰࠫᏠ")] = request.node
    outcome = yield
    try:
        fixture = {
            bstack11l11ll_opy_ (u"ࠧ࡯ࡣࡰࡩࠬᏡ"): fixturedef.argname,
            bstack11l11ll_opy_ (u"ࠨࡴࡨࡷࡺࡲࡴࠨᏢ"): bstack1l111111ll_opy_(outcome),
            bstack11l11ll_opy_ (u"ࠩࡧࡹࡷࡧࡴࡪࡱࡱࠫᏣ"): (datetime.datetime.now() - start_time).total_seconds() * 1000
        }
        bstack111ll1l111_opy_ = store[bstack11l11ll_opy_ (u"ࠪࡧࡺࡸࡲࡦࡰࡷࡣࡹ࡫ࡳࡵࡡ࡬ࡸࡪࡳࠧᏤ")]
        if not _11l1111l1l_opy_.get(bstack111ll1l111_opy_.nodeid, None):
            _11l1111l1l_opy_[bstack111ll1l111_opy_.nodeid] = {bstack11l11ll_opy_ (u"ࠫ࡫࡯ࡸࡵࡷࡵࡩࡸ࠭Ꮵ"): []}
        _11l1111l1l_opy_[bstack111ll1l111_opy_.nodeid][bstack11l11ll_opy_ (u"ࠬ࡬ࡩࡹࡶࡸࡶࡪࡹࠧᏦ")].append(fixture)
    except Exception as err:
        logger.debug(bstack11l11ll_opy_ (u"࠭ࡅࡹࡥࡨࡴࡹ࡯࡯࡯ࠢ࡬ࡲࠥࡶࡹࡵࡧࡶࡸࡤ࡬ࡩࡹࡶࡸࡶࡪࡥࡳࡦࡶࡸࡴ࠿ࠦࡻࡾࠩᏧ"), str(err))
if bstack1llll1111_opy_() and bstack1ll1lll1ll_opy_.on():
    def pytest_bdd_before_step(request, step):
        try:
            _11l1111l1l_opy_[request.node.nodeid][bstack11l11ll_opy_ (u"ࠧࡵࡧࡶࡸࡤࡪࡡࡵࡣࠪᏨ")].bstack11ll1llll1_opy_(id(step))
        except Exception as err:
            print(bstack11l11ll_opy_ (u"ࠨࡇࡻࡧࡪࡶࡴࡪࡱࡱࠤ࡮ࡴࠠࡱࡻࡷࡩࡸࡺ࡟ࡣࡦࡧࡣࡧ࡫ࡦࡰࡴࡨࡣࡸࡺࡥࡱ࠼ࠣࡿࢂ࠭Ꮹ"), str(err))
    def pytest_bdd_step_error(request, step, exception):
        try:
            _11l1111l1l_opy_[request.node.nodeid][bstack11l11ll_opy_ (u"ࠩࡷࡩࡸࡺ࡟ࡥࡣࡷࡥࠬᏪ")].bstack11ll1ll111_opy_(id(step), Result.failed(exception=exception))
        except Exception as err:
            print(bstack11l11ll_opy_ (u"ࠪࡉࡽࡩࡥࡱࡶ࡬ࡳࡳࠦࡩ࡯ࠢࡳࡽࡹ࡫ࡳࡵࡡࡥࡨࡩࡥࡳࡵࡧࡳࡣࡪࡸࡲࡰࡴ࠽ࠤࢀࢃࠧᏫ"), str(err))
    def pytest_bdd_after_step(request, step):
        try:
            bstack1l11ll11l1_opy_: bstack11ll1l111l_opy_ = _11l1111l1l_opy_[request.node.nodeid][bstack11l11ll_opy_ (u"ࠫࡹ࡫ࡳࡵࡡࡧࡥࡹࡧࠧᏬ")]
            bstack1l11ll11l1_opy_.bstack11ll1ll111_opy_(id(step), Result.passed())
        except Exception as err:
            print(bstack11l11ll_opy_ (u"ࠬࡋࡸࡤࡧࡳࡸ࡮ࡵ࡮ࠡ࡫ࡱࠤࡵࡿࡴࡦࡵࡷࡣࡧࡪࡤࡠࡵࡷࡩࡵࡥࡥࡳࡴࡲࡶ࠿ࠦࡻࡾࠩᏭ"), str(err))
    def pytest_bdd_before_scenario(request, feature, scenario):
        global bstack111lllllll_opy_
        try:
            if not bstack1ll1lll1ll_opy_.on() or bstack111lllllll_opy_ != bstack11l11ll_opy_ (u"࠭ࡰࡺࡶࡨࡷࡹ࠳ࡢࡥࡦࠪᏮ"):
                return
            global bstack111ll1l1l1_opy_
            bstack111ll1l1l1_opy_.start()
            if not _11l1111l1l_opy_.get(request.node.nodeid, None):
                _11l1111l1l_opy_[request.node.nodeid] = {}
            bstack1l11ll11l1_opy_ = bstack11ll1l111l_opy_.bstack11ll1ll1ll_opy_(
                scenario, feature, request.node,
                name=bstack1l111ll1l1_opy_(request.node, scenario),
                bstack11ll1lllll_opy_=bstack11ll1llll_opy_(),
                file_path=feature.filename,
                scope=[feature.name],
                framework=bstack11l11ll_opy_ (u"ࠧࡑࡻࡷࡩࡸࡺ࠭ࡤࡷࡦࡹࡲࡨࡥࡳࠩᏯ"),
                tags=bstack1l111l1lll_opy_(feature, scenario)
            )
            _11l1111l1l_opy_[request.node.nodeid][bstack11l11ll_opy_ (u"ࠨࡶࡨࡷࡹࡥࡤࡢࡶࡤࠫᏰ")] = bstack1l11ll11l1_opy_
            bstack111ll1llll_opy_(bstack1l11ll11l1_opy_.uuid)
            bstack1ll1lll1ll_opy_.bstack1l1l1111l1_opy_(bstack11l11ll_opy_ (u"ࠩࡗࡩࡸࡺࡒࡶࡰࡖࡸࡦࡸࡴࡦࡦࠪᏱ"), bstack1l11ll11l1_opy_)
        except Exception as err:
            print(bstack11l11ll_opy_ (u"ࠪࡉࡽࡩࡥࡱࡶ࡬ࡳࡳࠦࡩ࡯ࠢࡳࡽࡹ࡫ࡳࡵࡡࡥࡨࡩࡥࡢࡦࡨࡲࡶࡪࡥࡳࡤࡧࡱࡥࡷ࡯࡯࠻ࠢࡾࢁࠬᏲ"), str(err))
def bstack111ll11l1l_opy_(bstack111ll111l1_opy_):
    if bstack111ll111l1_opy_ in store[bstack11l11ll_opy_ (u"ࠫࡨࡻࡲࡳࡧࡱࡸࡤ࡮࡯ࡰ࡭ࡢࡹࡺ࡯ࡤࠨᏳ")]:
        store[bstack11l11ll_opy_ (u"ࠬࡩࡵࡳࡴࡨࡲࡹࡥࡨࡰࡱ࡮ࡣࡺࡻࡩࡥࠩᏴ")].remove(bstack111ll111l1_opy_)
def bstack111ll1llll_opy_(bstack111ll1lll1_opy_):
    store[bstack11l11ll_opy_ (u"࠭ࡣࡶࡴࡵࡩࡳࡺ࡟ࡵࡧࡶࡸࡤࡻࡵࡪࡦࠪᏵ")] = bstack111ll1lll1_opy_
    threading.current_thread().current_test_uuid = bstack111ll1lll1_opy_
@bstack1ll1lll1ll_opy_.bstack1l11l1ll1l_opy_
def bstack111lllll11_opy_(item, call, report):
    global bstack111lllllll_opy_
    try:
        if report.when == bstack11l11ll_opy_ (u"ࠧࡤࡣ࡯ࡰࠬ᏶"):
            bstack111ll1l1l1_opy_.reset()
        if report.when == bstack11l11ll_opy_ (u"ࠨࡥࡤࡰࡱ࠭᏷"):
            if bstack111lllllll_opy_ == bstack11l11ll_opy_ (u"ࠩࡳࡽࡹ࡫ࡳࡵࠩᏸ"):
                _11l1111l1l_opy_[item.nodeid][bstack11l11ll_opy_ (u"ࠪࡪ࡮ࡴࡩࡴࡪࡨࡨࡤࡧࡴࠨᏹ")] = bstack1l11111l1l_opy_(report.stop)
                bstack111lll1ll1_opy_(item, _11l1111l1l_opy_[item.nodeid], bstack11l11ll_opy_ (u"࡙ࠫ࡫ࡳࡵࡔࡸࡲࡋ࡯࡮ࡪࡵ࡫ࡩࡩ࠭ᏺ"), report, call)
                store[bstack11l11ll_opy_ (u"ࠬࡩࡵࡳࡴࡨࡲࡹࡥࡴࡦࡵࡷࡣࡺࡻࡩࡥࠩᏻ")] = None
            elif bstack111lllllll_opy_ == bstack11l11ll_opy_ (u"ࠨࡰࡺࡶࡨࡷࡹ࠳ࡢࡥࡦࠥᏼ"):
                bstack1l11ll11l1_opy_ = _11l1111l1l_opy_[item.nodeid][bstack11l11ll_opy_ (u"ࠧࡵࡧࡶࡸࡤࡪࡡࡵࡣࠪᏽ")]
                bstack1l11ll11l1_opy_.set(hooks=_11l1111l1l_opy_[item.nodeid].get(bstack11l11ll_opy_ (u"ࠨࡪࡲࡳࡰࡹࠧ᏾"), []))
                exception, bstack11llllll11_opy_ = None, None
                if call.excinfo:
                    exception = call.excinfo.value
                    bstack11llllll11_opy_ = [call.excinfo.exconly(), report.longreprtext]
                bstack1l11ll11l1_opy_.stop(time=bstack1l11111l1l_opy_(report.stop), result=Result(result=report.outcome, exception=exception, bstack11llllll11_opy_=bstack11llllll11_opy_))
                bstack1ll1lll1ll_opy_.bstack1l1l1111l1_opy_(bstack11l11ll_opy_ (u"ࠩࡗࡩࡸࡺࡒࡶࡰࡉ࡭ࡳ࡯ࡳࡩࡧࡧࠫ᏿"), _11l1111l1l_opy_[item.nodeid][bstack11l11ll_opy_ (u"ࠪࡸࡪࡹࡴࡠࡦࡤࡸࡦ࠭᐀")])
        elif report.when in [bstack11l11ll_opy_ (u"ࠫࡸ࡫ࡴࡶࡲࠪᐁ"), bstack11l11ll_opy_ (u"ࠬࡺࡥࡢࡴࡧࡳࡼࡴࠧᐂ")]:
            bstack111lll1lll_opy_ = item.nodeid + bstack11l11ll_opy_ (u"࠭࠭ࠨᐃ") + report.when
            if report.skipped:
                hook_type = bstack11l11ll_opy_ (u"ࠧࡃࡇࡉࡓࡗࡋ࡟ࡆࡃࡆࡌࠬᐄ") if report.when == bstack11l11ll_opy_ (u"ࠨࡵࡨࡸࡺࡶࠧᐅ") else bstack11l11ll_opy_ (u"ࠩࡄࡊ࡙ࡋࡒࡠࡇࡄࡇࡍ࠭ᐆ")
                _11l1111l1l_opy_[bstack111lll1lll_opy_] = {
                    bstack11l11ll_opy_ (u"ࠪࡹࡺ࡯ࡤࠨᐇ"): uuid4().__str__(),
                    bstack11l11ll_opy_ (u"ࠫࡸࡺࡡࡳࡶࡨࡨࡤࡧࡴࠨᐈ"): datetime.datetime.utcfromtimestamp(report.start).isoformat() + bstack11l11ll_opy_ (u"ࠬࡠࠧᐉ"),
                    bstack11l11ll_opy_ (u"࠭ࡨࡰࡱ࡮ࡣࡹࡿࡰࡦࠩᐊ"): hook_type
                }
            _11l1111l1l_opy_[bstack111lll1lll_opy_][bstack11l11ll_opy_ (u"ࠧࡧ࡫ࡱ࡭ࡸ࡮ࡥࡥࡡࡤࡸࠬᐋ")] = datetime.datetime.utcfromtimestamp(report.stop).isoformat() + bstack11l11ll_opy_ (u"ࠨ࡜ࠪᐌ")
            bstack111ll11l1l_opy_(_11l1111l1l_opy_[bstack111lll1lll_opy_][bstack11l11ll_opy_ (u"ࠩࡸࡹ࡮ࡪࠧᐍ")])
            bstack11l1111l11_opy_(item, _11l1111l1l_opy_[bstack111lll1lll_opy_], bstack11l11ll_opy_ (u"ࠪࡌࡴࡵ࡫ࡓࡷࡱࡊ࡮ࡴࡩࡴࡪࡨࡨࠬᐎ"), report, call)
            if report.when == bstack11l11ll_opy_ (u"ࠫࡸ࡫ࡴࡶࡲࠪᐏ"):
                if report.outcome == bstack11l11ll_opy_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬᐐ"):
                    bstack111ll1l1ll_opy_ = {
                        bstack11l11ll_opy_ (u"࠭ࡵࡶ࡫ࡧࠫᐑ"): uuid4().__str__(),
                        bstack11l11ll_opy_ (u"ࠧࡴࡶࡤࡶࡹ࡫ࡤࡠࡣࡷࠫᐒ"): bstack11ll1llll_opy_(),
                        bstack11l11ll_opy_ (u"ࠨࡨ࡬ࡲ࡮ࡹࡨࡦࡦࡢࡥࡹ࠭ᐓ"): bstack11ll1llll_opy_()
                    }
                    _11l1111l1l_opy_[item.nodeid] = {**_11l1111l1l_opy_[item.nodeid], **bstack111ll1l1ll_opy_}
                    bstack111lll1ll1_opy_(item, _11l1111l1l_opy_[item.nodeid], bstack11l11ll_opy_ (u"ࠩࡗࡩࡸࡺࡒࡶࡰࡖࡸࡦࡸࡴࡦࡦࠪᐔ"))
                    bstack111lll1ll1_opy_(item, _11l1111l1l_opy_[item.nodeid], bstack11l11ll_opy_ (u"ࠪࡘࡪࡹࡴࡓࡷࡱࡊ࡮ࡴࡩࡴࡪࡨࡨࠬᐕ"), report, call)
    except Exception as err:
        print(bstack11l11ll_opy_ (u"ࠫࡊࡾࡣࡦࡲࡷ࡭ࡴࡴࠠࡪࡰࠣ࡬ࡦࡴࡤ࡭ࡧࡢࡳ࠶࠷ࡹࡠࡶࡨࡷࡹࡥࡥࡷࡧࡱࡸ࠿ࠦࡻࡾࠩᐖ"), str(err))
def bstack11l11111l1_opy_(test, bstack111ll1l1ll_opy_, result=None, call=None, bstack1l11llll1_opy_=None, outcome=None):
    file_path = os.path.relpath(test.fspath.strpath, start=os.getcwd())
    bstack1l11ll11l1_opy_ = {
        bstack11l11ll_opy_ (u"ࠬࡻࡵࡪࡦࠪᐗ"): bstack111ll1l1ll_opy_[bstack11l11ll_opy_ (u"࠭ࡵࡶ࡫ࡧࠫᐘ")],
        bstack11l11ll_opy_ (u"ࠧࡵࡻࡳࡩࠬᐙ"): bstack11l11ll_opy_ (u"ࠨࡶࡨࡷࡹ࠭ᐚ"),
        bstack11l11ll_opy_ (u"ࠩࡱࡥࡲ࡫ࠧᐛ"): test.name,
        bstack11l11ll_opy_ (u"ࠪࡦࡴࡪࡹࠨᐜ"): {
            bstack11l11ll_opy_ (u"ࠫࡱࡧ࡮ࡨࠩᐝ"): bstack11l11ll_opy_ (u"ࠬࡶࡹࡵࡪࡲࡲࠬᐞ"),
            bstack11l11ll_opy_ (u"࠭ࡣࡰࡦࡨࠫᐟ"): inspect.getsource(test.obj)
        },
        bstack11l11ll_opy_ (u"ࠧࡪࡦࡨࡲࡹ࡯ࡦࡪࡧࡵࠫᐠ"): test.name,
        bstack11l11ll_opy_ (u"ࠨࡵࡦࡳࡵ࡫ࠧᐡ"): test.name,
        bstack11l11ll_opy_ (u"ࠩࡶࡧࡴࡶࡥࡴࠩᐢ"): bstack1ll1lll1ll_opy_.bstack1l11ll11ll_opy_(test),
        bstack11l11ll_opy_ (u"ࠪࡪ࡮ࡲࡥࡠࡰࡤࡱࡪ࠭ᐣ"): file_path,
        bstack11l11ll_opy_ (u"ࠫࡱࡵࡣࡢࡶ࡬ࡳࡳ࠭ᐤ"): file_path,
        bstack11l11ll_opy_ (u"ࠬࡸࡥࡴࡷ࡯ࡸࠬᐥ"): bstack11l11ll_opy_ (u"࠭ࡰࡦࡰࡧ࡭ࡳ࡭ࠧᐦ"),
        bstack11l11ll_opy_ (u"ࠧࡷࡥࡢࡪ࡮ࡲࡥࡱࡣࡷ࡬ࠬᐧ"): file_path,
        bstack11l11ll_opy_ (u"ࠨࡵࡷࡥࡷࡺࡥࡥࡡࡤࡸࠬᐨ"): bstack111ll1l1ll_opy_[bstack11l11ll_opy_ (u"ࠩࡶࡸࡦࡸࡴࡦࡦࡢࡥࡹ࠭ᐩ")],
        bstack11l11ll_opy_ (u"ࠪࡪࡷࡧ࡭ࡦࡹࡲࡶࡰ࠭ᐪ"): bstack11l11ll_opy_ (u"ࠫࡕࡿࡴࡦࡵࡷࠫᐫ"),
        bstack11l11ll_opy_ (u"ࠬࡩࡵࡴࡶࡲࡱࡗ࡫ࡲࡶࡰࡓࡥࡷࡧ࡭ࠨᐬ"): {
            bstack11l11ll_opy_ (u"࠭ࡲࡦࡴࡸࡲࡤࡴࡡ࡮ࡧࠪᐭ"): test.nodeid
        },
        bstack11l11ll_opy_ (u"ࠧࡵࡣࡪࡷࠬᐮ"): bstack11llll111l_opy_(test.own_markers)
    }
    if bstack1l11llll1_opy_ in [bstack11l11ll_opy_ (u"ࠨࡖࡨࡷࡹࡘࡵ࡯ࡕ࡮࡭ࡵࡶࡥࡥࠩᐯ"), bstack11l11ll_opy_ (u"ࠩࡗࡩࡸࡺࡒࡶࡰࡉ࡭ࡳ࡯ࡳࡩࡧࡧࠫᐰ")]:
        bstack1l11ll11l1_opy_[bstack11l11ll_opy_ (u"ࠪࡱࡪࡺࡡࠨᐱ")] = {
            bstack11l11ll_opy_ (u"ࠫ࡫࡯ࡸࡵࡷࡵࡩࡸ࠭ᐲ"): bstack111ll1l1ll_opy_.get(bstack11l11ll_opy_ (u"ࠬ࡬ࡩࡹࡶࡸࡶࡪࡹࠧᐳ"), [])
        }
    if bstack1l11llll1_opy_ == bstack11l11ll_opy_ (u"࠭ࡔࡦࡵࡷࡖࡺࡴࡓ࡬࡫ࡳࡴࡪࡪࠧᐴ"):
        bstack1l11ll11l1_opy_[bstack11l11ll_opy_ (u"ࠧࡳࡧࡶࡹࡱࡺࠧᐵ")] = bstack11l11ll_opy_ (u"ࠨࡵ࡮࡭ࡵࡶࡥࡥࠩᐶ")
        bstack1l11ll11l1_opy_[bstack11l11ll_opy_ (u"ࠩ࡫ࡳࡴࡱࡳࠨᐷ")] = bstack111ll1l1ll_opy_[bstack11l11ll_opy_ (u"ࠪ࡬ࡴࡵ࡫ࡴࠩᐸ")]
        bstack1l11ll11l1_opy_[bstack11l11ll_opy_ (u"ࠫ࡫࡯࡮ࡪࡵ࡫ࡩࡩࡥࡡࡵࠩᐹ")] = bstack111ll1l1ll_opy_[bstack11l11ll_opy_ (u"ࠬ࡬ࡩ࡯࡫ࡶ࡬ࡪࡪ࡟ࡢࡶࠪᐺ")]
    if result:
        bstack1l11ll11l1_opy_[bstack11l11ll_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭ᐻ")] = result.outcome
        bstack1l11ll11l1_opy_[bstack11l11ll_opy_ (u"ࠧࡥࡷࡵࡥࡹ࡯࡯࡯ࡡ࡬ࡲࡤࡳࡳࠨᐼ")] = result.duration * 1000
        bstack1l11ll11l1_opy_[bstack11l11ll_opy_ (u"ࠨࡨ࡬ࡲ࡮ࡹࡨࡦࡦࡢࡥࡹ࠭ᐽ")] = bstack111ll1l1ll_opy_[bstack11l11ll_opy_ (u"ࠩࡩ࡭ࡳ࡯ࡳࡩࡧࡧࡣࡦࡺࠧᐾ")]
        if result.failed:
            bstack1l11ll11l1_opy_[bstack11l11ll_opy_ (u"ࠪࡪࡦ࡯࡬ࡶࡴࡨࡣࡹࡿࡰࡦࠩᐿ")] = bstack1ll1lll1ll_opy_.bstack1l11l1l111_opy_(call.excinfo.typename)
            bstack1l11ll11l1_opy_[bstack11l11ll_opy_ (u"ࠫ࡫ࡧࡩ࡭ࡷࡵࡩࠬᑀ")] = bstack1ll1lll1ll_opy_.bstack1l11lll11l_opy_(call.excinfo, result)
        bstack1l11ll11l1_opy_[bstack11l11ll_opy_ (u"ࠬ࡮࡯ࡰ࡭ࡶࠫᑁ")] = bstack111ll1l1ll_opy_[bstack11l11ll_opy_ (u"࠭ࡨࡰࡱ࡮ࡷࠬᑂ")]
    if outcome:
        bstack1l11ll11l1_opy_[bstack11l11ll_opy_ (u"ࠧࡳࡧࡶࡹࡱࡺࠧᑃ")] = bstack1l111111ll_opy_(outcome)
        bstack1l11ll11l1_opy_[bstack11l11ll_opy_ (u"ࠨࡦࡸࡶࡦࡺࡩࡰࡰࡢ࡭ࡳࡥ࡭ࡴࠩᑄ")] = 0
        bstack1l11ll11l1_opy_[bstack11l11ll_opy_ (u"ࠩࡩ࡭ࡳ࡯ࡳࡩࡧࡧࡣࡦࡺࠧᑅ")] = bstack111ll1l1ll_opy_[bstack11l11ll_opy_ (u"ࠪࡪ࡮ࡴࡩࡴࡪࡨࡨࡤࡧࡴࠨᑆ")]
        if bstack1l11ll11l1_opy_[bstack11l11ll_opy_ (u"ࠫࡷ࡫ࡳࡶ࡮ࡷࠫᑇ")] == bstack11l11ll_opy_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬᑈ"):
            bstack1l11ll11l1_opy_[bstack11l11ll_opy_ (u"࠭ࡦࡢ࡫࡯ࡹࡷ࡫࡟ࡵࡻࡳࡩࠬᑉ")] = bstack11l11ll_opy_ (u"ࠧࡖࡰ࡫ࡥࡳࡪ࡬ࡦࡦࡈࡶࡷࡵࡲࠨᑊ")  # bstack111ll11l11_opy_
            bstack1l11ll11l1_opy_[bstack11l11ll_opy_ (u"ࠨࡨࡤ࡭ࡱࡻࡲࡦࠩᑋ")] = [{bstack11l11ll_opy_ (u"ࠩࡥࡥࡨࡱࡴࡳࡣࡦࡩࠬᑌ"): [bstack11l11ll_opy_ (u"ࠪࡷࡴࡳࡥࠡࡧࡵࡶࡴࡸࠧᑍ")]}]
        bstack1l11ll11l1_opy_[bstack11l11ll_opy_ (u"ࠫ࡭ࡵ࡯࡬ࡵࠪᑎ")] = bstack111ll1l1ll_opy_[bstack11l11ll_opy_ (u"ࠬ࡮࡯ࡰ࡭ࡶࠫᑏ")]
    return bstack1l11ll11l1_opy_
def bstack111ll111ll_opy_(test, bstack111ll1111l_opy_, bstack1l11llll1_opy_, result, call, outcome, bstack111llll1l1_opy_):
    file_path = os.path.relpath(test.fspath.strpath, start=os.getcwd())
    hook_type = bstack111ll1111l_opy_[bstack11l11ll_opy_ (u"࠭ࡨࡰࡱ࡮ࡣࡹࡿࡰࡦࠩᑐ")]
    hook_name = bstack111ll1111l_opy_[bstack11l11ll_opy_ (u"ࠧࡩࡱࡲ࡯ࡤࡴࡡ࡮ࡧࠪᑑ")]
    hook_data = {
        bstack11l11ll_opy_ (u"ࠨࡷࡸ࡭ࡩ࠭ᑒ"): bstack111ll1111l_opy_[bstack11l11ll_opy_ (u"ࠩࡸࡹ࡮ࡪࠧᑓ")],
        bstack11l11ll_opy_ (u"ࠪࡸࡾࡶࡥࠨᑔ"): bstack11l11ll_opy_ (u"ࠫ࡭ࡵ࡯࡬ࠩᑕ"),
        bstack11l11ll_opy_ (u"ࠬࡴࡡ࡮ࡧࠪᑖ"): bstack11l11ll_opy_ (u"࠭ࡻࡾࠩᑗ").format(bstack1l111ll11l_opy_(hook_name)),
        bstack11l11ll_opy_ (u"ࠧࡣࡱࡧࡽࠬᑘ"): {
            bstack11l11ll_opy_ (u"ࠨ࡮ࡤࡲ࡬࠭ᑙ"): bstack11l11ll_opy_ (u"ࠩࡳࡽࡹ࡮࡯࡯ࠩᑚ"),
            bstack11l11ll_opy_ (u"ࠪࡧࡴࡪࡥࠨᑛ"): None
        },
        bstack11l11ll_opy_ (u"ࠫࡸࡩ࡯ࡱࡧࠪᑜ"): test.name,
        bstack11l11ll_opy_ (u"ࠬࡹࡣࡰࡲࡨࡷࠬᑝ"): bstack1ll1lll1ll_opy_.bstack1l11ll11ll_opy_(test, hook_name),
        bstack11l11ll_opy_ (u"࠭ࡦࡪ࡮ࡨࡣࡳࡧ࡭ࡦࠩᑞ"): file_path,
        bstack11l11ll_opy_ (u"ࠧ࡭ࡱࡦࡥࡹ࡯࡯࡯ࠩᑟ"): file_path,
        bstack11l11ll_opy_ (u"ࠨࡴࡨࡷࡺࡲࡴࠨᑠ"): bstack11l11ll_opy_ (u"ࠩࡳࡩࡳࡪࡩ࡯ࡩࠪᑡ"),
        bstack11l11ll_opy_ (u"ࠪࡺࡨࡥࡦࡪ࡮ࡨࡴࡦࡺࡨࠨᑢ"): file_path,
        bstack11l11ll_opy_ (u"ࠫࡸࡺࡡࡳࡶࡨࡨࡤࡧࡴࠨᑣ"): bstack111ll1111l_opy_[bstack11l11ll_opy_ (u"ࠬࡹࡴࡢࡴࡷࡩࡩࡥࡡࡵࠩᑤ")],
        bstack11l11ll_opy_ (u"࠭ࡦࡳࡣࡰࡩࡼࡵࡲ࡬ࠩᑥ"): bstack11l11ll_opy_ (u"ࠧࡑࡻࡷࡩࡸࡺ࠭ࡤࡷࡦࡹࡲࡨࡥࡳࠩᑦ") if bstack111lllllll_opy_ == bstack11l11ll_opy_ (u"ࠨࡲࡼࡸࡪࡹࡴ࠮ࡤࡧࡨࠬᑧ") else bstack11l11ll_opy_ (u"ࠩࡓࡽࡹ࡫ࡳࡵࠩᑨ"),
        bstack11l11ll_opy_ (u"ࠪ࡬ࡴࡵ࡫ࡠࡶࡼࡴࡪ࠭ᑩ"): hook_type
    }
    bstack111lll11l1_opy_ = bstack111llll111_opy_(_11l1111l1l_opy_.get(test.nodeid, None))
    if bstack111lll11l1_opy_:
        hook_data[bstack11l11ll_opy_ (u"ࠫࡹ࡫ࡳࡵࡡࡵࡹࡳࡥࡩࡥࠩᑪ")] = bstack111lll11l1_opy_
    if result:
        hook_data[bstack11l11ll_opy_ (u"ࠬࡸࡥࡴࡷ࡯ࡸࠬᑫ")] = result.outcome
        hook_data[bstack11l11ll_opy_ (u"࠭ࡤࡶࡴࡤࡸ࡮ࡵ࡮ࡠ࡫ࡱࡣࡲࡹࠧᑬ")] = result.duration * 1000
        hook_data[bstack11l11ll_opy_ (u"ࠧࡧ࡫ࡱ࡭ࡸ࡮ࡥࡥࡡࡤࡸࠬᑭ")] = bstack111ll1111l_opy_[bstack11l11ll_opy_ (u"ࠨࡨ࡬ࡲ࡮ࡹࡨࡦࡦࡢࡥࡹ࠭ᑮ")]
        if result.failed:
            hook_data[bstack11l11ll_opy_ (u"ࠩࡩࡥ࡮ࡲࡵࡳࡧࡢࡸࡾࡶࡥࠨᑯ")] = bstack1ll1lll1ll_opy_.bstack1l11l1l111_opy_(call.excinfo.typename)
            hook_data[bstack11l11ll_opy_ (u"ࠪࡪࡦ࡯࡬ࡶࡴࡨࠫᑰ")] = bstack1ll1lll1ll_opy_.bstack1l11lll11l_opy_(call.excinfo, result)
    if outcome:
        hook_data[bstack11l11ll_opy_ (u"ࠫࡷ࡫ࡳࡶ࡮ࡷࠫᑱ")] = bstack1l111111ll_opy_(outcome)
        hook_data[bstack11l11ll_opy_ (u"ࠬࡪࡵࡳࡣࡷ࡭ࡴࡴ࡟ࡪࡰࡢࡱࡸ࠭ᑲ")] = 100
        hook_data[bstack11l11ll_opy_ (u"࠭ࡦࡪࡰ࡬ࡷ࡭࡫ࡤࡠࡣࡷࠫᑳ")] = bstack111ll1111l_opy_[bstack11l11ll_opy_ (u"ࠧࡧ࡫ࡱ࡭ࡸ࡮ࡥࡥࡡࡤࡸࠬᑴ")]
        if hook_data[bstack11l11ll_opy_ (u"ࠨࡴࡨࡷࡺࡲࡴࠨᑵ")] == bstack11l11ll_opy_ (u"ࠩࡩࡥ࡮ࡲࡥࡥࠩᑶ"):
            hook_data[bstack11l11ll_opy_ (u"ࠪࡪࡦ࡯࡬ࡶࡴࡨࡣࡹࡿࡰࡦࠩᑷ")] = bstack11l11ll_opy_ (u"࡚ࠫࡴࡨࡢࡰࡧࡰࡪࡪࡅࡳࡴࡲࡶࠬᑸ")  # bstack111ll11l11_opy_
            hook_data[bstack11l11ll_opy_ (u"ࠬ࡬ࡡࡪ࡮ࡸࡶࡪ࠭ᑹ")] = [{bstack11l11ll_opy_ (u"࠭ࡢࡢࡥ࡮ࡸࡷࡧࡣࡦࠩᑺ"): [bstack11l11ll_opy_ (u"ࠧࡴࡱࡰࡩࠥ࡫ࡲࡳࡱࡵࠫᑻ")]}]
    if bstack111llll1l1_opy_:
        hook_data[bstack11l11ll_opy_ (u"ࠨࡴࡨࡷࡺࡲࡴࠨᑼ")] = bstack111llll1l1_opy_.result
        hook_data[bstack11l11ll_opy_ (u"ࠩࡧࡹࡷࡧࡴࡪࡱࡱࡣ࡮ࡴ࡟࡮ࡵࠪᑽ")] = bstack11llll1lll_opy_(bstack111ll1111l_opy_[bstack11l11ll_opy_ (u"ࠪࡷࡹࡧࡲࡵࡧࡧࡣࡦࡺࠧᑾ")], bstack111ll1111l_opy_[bstack11l11ll_opy_ (u"ࠫ࡫࡯࡮ࡪࡵ࡫ࡩࡩࡥࡡࡵࠩᑿ")])
        hook_data[bstack11l11ll_opy_ (u"ࠬ࡬ࡩ࡯࡫ࡶ࡬ࡪࡪ࡟ࡢࡶࠪᒀ")] = bstack111ll1111l_opy_[bstack11l11ll_opy_ (u"࠭ࡦࡪࡰ࡬ࡷ࡭࡫ࡤࡠࡣࡷࠫᒁ")]
        if hook_data[bstack11l11ll_opy_ (u"ࠧࡳࡧࡶࡹࡱࡺࠧᒂ")] == bstack11l11ll_opy_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨᒃ"):
            hook_data[bstack11l11ll_opy_ (u"ࠩࡩࡥ࡮ࡲࡵࡳࡧࡢࡸࡾࡶࡥࠨᒄ")] = bstack1ll1lll1ll_opy_.bstack1l11l1l111_opy_(bstack111llll1l1_opy_.exception_type)
            hook_data[bstack11l11ll_opy_ (u"ࠪࡪࡦ࡯࡬ࡶࡴࡨࠫᒅ")] = [{bstack11l11ll_opy_ (u"ࠫࡧࡧࡣ࡬ࡶࡵࡥࡨ࡫ࠧᒆ"): bstack11llllll1l_opy_(bstack111llll1l1_opy_.exception)}]
    return hook_data
def bstack111lll1ll1_opy_(test, bstack111ll1l1ll_opy_, bstack1l11llll1_opy_, result=None, call=None, outcome=None):
    bstack1l11ll11l1_opy_ = bstack11l11111l1_opy_(test, bstack111ll1l1ll_opy_, result, call, bstack1l11llll1_opy_, outcome)
    driver = getattr(test, bstack11l11ll_opy_ (u"ࠬࡥࡤࡳ࡫ࡹࡩࡷ࠭ᒇ"), None)
    if bstack1l11llll1_opy_ == bstack11l11ll_opy_ (u"࠭ࡔࡦࡵࡷࡖࡺࡴࡓࡵࡣࡵࡸࡪࡪࠧᒈ") and driver:
        bstack1l11ll11l1_opy_[bstack11l11ll_opy_ (u"ࠧࡪࡰࡷࡩ࡬ࡸࡡࡵ࡫ࡲࡲࡸ࠭ᒉ")] = bstack1ll1lll1ll_opy_.bstack1l1l111l1l_opy_(driver)
    if bstack1l11llll1_opy_ == bstack11l11ll_opy_ (u"ࠨࡖࡨࡷࡹࡘࡵ࡯ࡕ࡮࡭ࡵࡶࡥࡥࠩᒊ"):
        bstack1l11llll1_opy_ = bstack11l11ll_opy_ (u"ࠩࡗࡩࡸࡺࡒࡶࡰࡉ࡭ࡳ࡯ࡳࡩࡧࡧࠫᒋ")
    bstack1l1l111lll_opy_ = {
        bstack11l11ll_opy_ (u"ࠪࡩࡻ࡫࡮ࡵࡡࡷࡽࡵ࡫ࠧᒌ"): bstack1l11llll1_opy_,
        bstack11l11ll_opy_ (u"ࠫࡹ࡫ࡳࡵࡡࡵࡹࡳ࠭ᒍ"): bstack1l11ll11l1_opy_
    }
    bstack1ll1lll1ll_opy_.bstack1l1l1l1l11_opy_(bstack1l1l111lll_opy_)
def bstack11l1111l11_opy_(test, bstack111ll1l1ll_opy_, bstack1l11llll1_opy_, result=None, call=None, outcome=None, bstack111llll1l1_opy_=None):
    hook_data = bstack111ll111ll_opy_(test, bstack111ll1l1ll_opy_, bstack1l11llll1_opy_, result, call, outcome, bstack111llll1l1_opy_)
    bstack1l1l111lll_opy_ = {
        bstack11l11ll_opy_ (u"ࠬ࡫ࡶࡦࡰࡷࡣࡹࡿࡰࡦࠩᒎ"): bstack1l11llll1_opy_,
        bstack11l11ll_opy_ (u"࠭ࡨࡰࡱ࡮ࡣࡷࡻ࡮ࠨᒏ"): hook_data
    }
    bstack1ll1lll1ll_opy_.bstack1l1l1l1l11_opy_(bstack1l1l111lll_opy_)
def bstack111llll111_opy_(bstack111ll1l1ll_opy_):
    if not bstack111ll1l1ll_opy_:
        return None
    if bstack111ll1l1ll_opy_.get(bstack11l11ll_opy_ (u"ࠧࡵࡧࡶࡸࡤࡪࡡࡵࡣࠪᒐ"), None):
        return getattr(bstack111ll1l1ll_opy_[bstack11l11ll_opy_ (u"ࠨࡶࡨࡷࡹࡥࡤࡢࡶࡤࠫᒑ")], bstack11l11ll_opy_ (u"ࠩࡸࡹ࡮ࡪࠧᒒ"), None)
    return bstack111ll1l1ll_opy_.get(bstack11l11ll_opy_ (u"ࠪࡹࡺ࡯ࡤࠨᒓ"), None)
@pytest.fixture(autouse=True)
def second_fixture(caplog, request):
    yield
    try:
        if not bstack1ll1lll1ll_opy_.on():
            return
        places = [bstack11l11ll_opy_ (u"ࠫࡸ࡫ࡴࡶࡲࠪᒔ"), bstack11l11ll_opy_ (u"ࠬࡩࡡ࡭࡮ࠪᒕ"), bstack11l11ll_opy_ (u"࠭ࡴࡦࡣࡵࡨࡴࡽ࡮ࠨᒖ")]
        bstack1l1l111l11_opy_ = []
        for bstack111ll11111_opy_ in places:
            records = caplog.get_records(bstack111ll11111_opy_)
            bstack111lll1111_opy_ = bstack11l11ll_opy_ (u"ࠧࡵࡧࡶࡸࡤࡸࡵ࡯ࡡࡸࡹ࡮ࡪࠧᒗ") if bstack111ll11111_opy_ == bstack11l11ll_opy_ (u"ࠨࡥࡤࡰࡱ࠭ᒘ") else bstack11l11ll_opy_ (u"ࠩ࡫ࡳࡴࡱ࡟ࡳࡷࡱࡣࡺࡻࡩࡥࠩᒙ")
            bstack111lll1l11_opy_ = request.node.nodeid + (bstack11l11ll_opy_ (u"ࠪࠫᒚ") if bstack111ll11111_opy_ == bstack11l11ll_opy_ (u"ࠫࡨࡧ࡬࡭ࠩᒛ") else bstack11l11ll_opy_ (u"ࠬ࠳ࠧᒜ") + bstack111ll11111_opy_)
            bstack111ll1lll1_opy_ = bstack111llll111_opy_(_11l1111l1l_opy_.get(bstack111lll1l11_opy_, None))
            if not bstack111ll1lll1_opy_:
                continue
            for record in records:
                if bstack11lllllll1_opy_(record.message):
                    continue
                bstack1l1l111l11_opy_.append({
                    bstack11l11ll_opy_ (u"࠭ࡴࡪ࡯ࡨࡷࡹࡧ࡭ࡱࠩᒝ"): datetime.datetime.utcfromtimestamp(record.created).isoformat() + bstack11l11ll_opy_ (u"࡛ࠧࠩᒞ"),
                    bstack11l11ll_opy_ (u"ࠨ࡮ࡨࡺࡪࡲࠧᒟ"): record.levelname,
                    bstack11l11ll_opy_ (u"ࠩࡰࡩࡸࡹࡡࡨࡧࠪᒠ"): record.message,
                    bstack111lll1111_opy_: bstack111ll1lll1_opy_
                })
        if len(bstack1l1l111l11_opy_) > 0:
            bstack1ll1lll1ll_opy_.bstack1l1l11llll_opy_(bstack1l1l111l11_opy_)
    except Exception as err:
        print(bstack11l11ll_opy_ (u"ࠪࡉࡽࡩࡥࡱࡶ࡬ࡳࡳࠦࡩ࡯ࠢࡶࡩࡨࡵ࡮ࡥࡡࡩ࡭ࡽࡺࡵࡳࡧ࠽ࠤࢀࢃࠧᒡ"), str(err))
def bstack111lll111l_opy_(driver_command, response):
    if driver_command == bstack11l11ll_opy_ (u"ࠫࡸࡩࡲࡦࡧࡱࡷ࡭ࡵࡴࠨᒢ"):
        bstack1ll1lll1ll_opy_.bstack1l11l1lll1_opy_({
            bstack11l11ll_opy_ (u"ࠬ࡯࡭ࡢࡩࡨࠫᒣ"): response[bstack11l11ll_opy_ (u"࠭ࡶࡢ࡮ࡸࡩࠬᒤ")],
            bstack11l11ll_opy_ (u"ࠧࡵࡧࡶࡸࡤࡸࡵ࡯ࡡࡸࡹ࡮ࡪࠧᒥ"): store[bstack11l11ll_opy_ (u"ࠨࡥࡸࡶࡷ࡫࡮ࡵࡡࡷࡩࡸࡺ࡟ࡶࡷ࡬ࡨࠬᒦ")]
        })
def bstack11l111ll_opy_():
    global bstack11lll111_opy_
    bstack1ll1lll1ll_opy_.bstack1l11ll1l11_opy_()
    for driver in bstack11lll111_opy_:
        try:
            driver.quit()
        except Exception as e:
            pass
def bstack1ll11lll1l_opy_(self, *args, **kwargs):
    bstack11l11l11l_opy_ = bstack1llll1llll_opy_(self, *args, **kwargs)
    bstack1ll1lll1ll_opy_.bstack11111111l_opy_(self)
    return bstack11l11l11l_opy_
def bstack1lll1ll1l_opy_(framework_name):
    global bstack11lllll11_opy_
    global bstack1ll1ll11ll_opy_
    bstack11lllll11_opy_ = framework_name
    logger.info(bstack1ll1l1ll1l_opy_.format(bstack11lllll11_opy_.split(bstack11l11ll_opy_ (u"ࠩ࠰ࠫᒧ"))[0]))
    try:
        from selenium import webdriver
        from selenium.webdriver.common.service import Service
        from selenium.webdriver.remote.webdriver import WebDriver
        if bstack11lll1lll1_opy_():
            Service.start = bstack11l1llll1_opy_
            Service.stop = bstack11111l11l_opy_
            webdriver.Remote.__init__ = bstack1ll11l1lll_opy_
            webdriver.Remote.get = bstack1l1lll11l_opy_
            if not isinstance(os.getenv(bstack11l11ll_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡓ࡝࡙ࡋࡓࡕࡡࡓࡅࡗࡇࡌࡍࡇࡏࠫᒨ")), str):
                return
            WebDriver.close = bstack111ll1l1l_opy_
            WebDriver.quit = bstack1l1l1l111_opy_
            WebDriver.getAccessibilityResults = getAccessibilityResults
            WebDriver.getAccessibilityResultsSummary = getAccessibilityResultsSummary
        if not bstack11lll1lll1_opy_() and bstack1ll1lll1ll_opy_.on():
            webdriver.Remote.__init__ = bstack1ll11lll1l_opy_
        bstack1ll1ll11ll_opy_ = True
    except Exception as e:
        pass
    bstack1ll11ll111_opy_()
    if os.environ.get(bstack11l11ll_opy_ (u"ࠫࡘࡋࡌࡆࡐࡌ࡙ࡒࡥࡏࡓࡡࡓࡐࡆ࡟ࡗࡓࡋࡊࡌ࡙ࡥࡉࡏࡕࡗࡅࡑࡒࡅࡅࠩᒩ")):
        bstack1ll1ll11ll_opy_ = eval(os.environ.get(bstack11l11ll_opy_ (u"࡙ࠬࡅࡍࡇࡑࡍ࡚ࡓ࡟ࡐࡔࡢࡔࡑࡇ࡙ࡘࡔࡌࡋࡍ࡚࡟ࡊࡐࡖࡘࡆࡒࡌࡆࡆࠪᒪ")))
    if not bstack1ll1ll11ll_opy_:
        bstack1ll1l11l11_opy_(bstack11l11ll_opy_ (u"ࠨࡐࡢࡥ࡮ࡥ࡬࡫ࡳࠡࡰࡲࡸࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࠣᒫ"), bstack1ll111111_opy_)
    if bstack1ll1l1lll1_opy_():
        try:
            from selenium.webdriver.remote.remote_connection import RemoteConnection
            RemoteConnection._get_proxy_url = bstack1l1lll1l_opy_
        except Exception as e:
            logger.error(bstack1l1l1l11_opy_.format(str(e)))
    if bstack11l11ll_opy_ (u"ࠧࡱࡻࡷࡩࡸࡺࠧᒬ") in str(framework_name).lower():
        if not bstack11lll1lll1_opy_():
            return
        try:
            from pytest_selenium import pytest_selenium
            from _pytest.config import Config
            pytest_selenium.pytest_report_header = bstack1lll1ll1l1_opy_
            from pytest_selenium.drivers import browserstack
            browserstack.pytest_selenium_runtest_makereport = bstack111lllll1_opy_
            Config.getoption = bstack1llll111ll_opy_
        except Exception as e:
            pass
        try:
            from pytest_bdd import reporting
            reporting.runtest_makereport = bstack1ll1llll1_opy_
        except Exception as e:
            pass
def bstack1l1l1l111_opy_(self):
    global bstack11lllll11_opy_
    global bstack11111l111_opy_
    global bstack1lll1llll1_opy_
    try:
        if bstack11l11ll_opy_ (u"ࠨࡲࡼࡸࡪࡹࡴࠨᒭ") in bstack11lllll11_opy_ and self.session_id != None and bstack1ll1llll1l_opy_(threading.current_thread(), bstack11l11ll_opy_ (u"ࠩࡷࡩࡸࡺࡓࡵࡣࡷࡹࡸ࠭ᒮ"), bstack11l11ll_opy_ (u"ࠪࠫᒯ")) != bstack11l11ll_opy_ (u"ࠫࡸࡱࡩࡱࡲࡨࡨࠬᒰ"):
            bstack1l11l11l_opy_ = bstack11l11ll_opy_ (u"ࠬࡶࡡࡴࡵࡨࡨࠬᒱ") if len(threading.current_thread().bstackTestErrorMessages) == 0 else bstack11l11ll_opy_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭ᒲ")
            bstack1lllll1l1l_opy_ = bstack11ll11lll_opy_(bstack11l11ll_opy_ (u"ࠧࡴࡧࡷࡗࡪࡹࡳࡪࡱࡱࡗࡹࡧࡴࡶࡵࠪᒳ"), bstack11l11ll_opy_ (u"ࠨࠩᒴ"), bstack1l11l11l_opy_, bstack11l11ll_opy_ (u"ࠩ࠯ࠤࠬᒵ").join(
                threading.current_thread().bstackTestErrorMessages), bstack11l11ll_opy_ (u"ࠪࠫᒶ"), bstack11l11ll_opy_ (u"ࠫࠬᒷ"))
            if self != None:
                self.execute_script(bstack1lllll1l1l_opy_)
    except Exception as e:
        logger.debug(bstack11l11ll_opy_ (u"ࠧࡋࡲࡳࡱࡵࠤࡼ࡮ࡩ࡭ࡧࠣࡱࡦࡸ࡫ࡪࡰࡪࠤࡸࡺࡡࡵࡷࡶ࠾ࠥࠨᒸ") + str(e))
    bstack1lll1llll1_opy_(self)
    self.session_id = None
def bstack1ll11l1lll_opy_(self, command_executor,
             desired_capabilities=None, browser_profile=None, proxy=None,
             keep_alive=True, file_detector=None, options=None):
    global CONFIG
    global bstack11111l111_opy_
    global bstack1ll1l1l11l_opy_
    global bstack1ll1ll1ll_opy_
    global bstack11lllll11_opy_
    global bstack1llll1llll_opy_
    global bstack11lll111_opy_
    global bstack1111l111_opy_
    global bstack1ll11llll1_opy_
    global bstack111ll1ll1l_opy_
    CONFIG[bstack11l11ll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡘࡊࡋࠨᒹ")] = str(bstack11lllll11_opy_) + str(__version__)
    command_executor = bstack1ll1l111l1_opy_(bstack1111l111_opy_)
    logger.debug(bstack1lll111ll_opy_.format(command_executor))
    proxy = bstack1111l1ll1_opy_(CONFIG, proxy)
    bstack11lllllll_opy_ = 0
    try:
        if bstack1ll1ll1ll_opy_ is True:
            bstack11lllllll_opy_ = int(os.environ.get(bstack11l11ll_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡐࡍࡃࡗࡊࡔࡘࡍࡠࡋࡑࡈࡊ࡞ࠧᒺ")))
    except:
        bstack11lllllll_opy_ = 0
    bstack1l11l111_opy_ = bstack111l111l_opy_(CONFIG, bstack11lllllll_opy_)
    logger.debug(bstack1l11l11l1_opy_.format(str(bstack1l11l111_opy_)))
    if bstack11l11ll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࡌࡰࡥࡤࡰࠬᒻ") in CONFIG and CONFIG[bstack11l11ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡍࡱࡦࡥࡱ࠭ᒼ")]:
        bstack11llll11l_opy_(bstack1l11l111_opy_, bstack1ll11llll1_opy_)
    if desired_capabilities:
        bstack1llll1lll1_opy_ = bstack1l1llllll_opy_(desired_capabilities)
        bstack1llll1lll1_opy_[bstack11l11ll_opy_ (u"ࠪࡹࡸ࡫ࡗ࠴ࡅࠪᒽ")] = bstack1l1ll1l1l_opy_(CONFIG)
        bstack1111llll1_opy_ = bstack111l111l_opy_(bstack1llll1lll1_opy_)
        if bstack1111llll1_opy_:
            bstack1l11l111_opy_ = update(bstack1111llll1_opy_, bstack1l11l111_opy_)
        desired_capabilities = None
    if options:
        bstack111lll1ll_opy_(options, bstack1l11l111_opy_)
    if not options:
        options = bstack11lll11l_opy_(bstack1l11l111_opy_)
    if bstack11lllll1l_opy_.bstack1lllll11l1_opy_(CONFIG, bstack11lllllll_opy_) and bstack11lllll1l_opy_.bstack11l11lll1_opy_(bstack1l11l111_opy_, options):
        bstack111ll1ll1l_opy_ = True
        bstack11lllll1l_opy_.set_capabilities(bstack1l11l111_opy_, CONFIG)
    if proxy and bstack1ll1l1lll_opy_() >= version.parse(bstack11l11ll_opy_ (u"ࠫ࠹࠴࠱࠱࠰࠳ࠫᒾ")):
        options.proxy(proxy)
    if options and bstack1ll1l1lll_opy_() >= version.parse(bstack11l11ll_opy_ (u"ࠬ࠹࠮࠹࠰࠳ࠫᒿ")):
        desired_capabilities = None
    if (
            not options and not desired_capabilities
    ) or (
            bstack1ll1l1lll_opy_() < version.parse(bstack11l11ll_opy_ (u"࠭࠳࠯࠺࠱࠴ࠬᓀ")) and not desired_capabilities
    ):
        desired_capabilities = {}
        desired_capabilities.update(bstack1l11l111_opy_)
    logger.info(bstack1llll11ll_opy_)
    if bstack1ll1l1lll_opy_() >= version.parse(bstack11l11ll_opy_ (u"ࠧ࠵࠰࠴࠴࠳࠶ࠧᓁ")):
        bstack1llll1llll_opy_(self, command_executor=command_executor,
                  options=options, keep_alive=keep_alive, file_detector=file_detector)
    elif bstack1ll1l1lll_opy_() >= version.parse(bstack11l11ll_opy_ (u"ࠨ࠵࠱࠼࠳࠶ࠧᓂ")):
        bstack1llll1llll_opy_(self, command_executor=command_executor,
                  desired_capabilities=desired_capabilities, options=options,
                  browser_profile=browser_profile, proxy=proxy,
                  keep_alive=keep_alive, file_detector=file_detector)
    elif bstack1ll1l1lll_opy_() >= version.parse(bstack11l11ll_opy_ (u"ࠩ࠵࠲࠺࠹࠮࠱ࠩᓃ")):
        bstack1llll1llll_opy_(self, command_executor=command_executor,
                  desired_capabilities=desired_capabilities,
                  browser_profile=browser_profile, proxy=proxy,
                  keep_alive=keep_alive, file_detector=file_detector)
    else:
        bstack1llll1llll_opy_(self, command_executor=command_executor,
                  desired_capabilities=desired_capabilities,
                  browser_profile=browser_profile, proxy=proxy,
                  keep_alive=keep_alive)
    try:
        bstack1ll111ll1_opy_ = bstack11l11ll_opy_ (u"ࠪࠫᓄ")
        if bstack1ll1l1lll_opy_() >= version.parse(bstack11l11ll_opy_ (u"ࠫ࠹࠴࠰࠯࠲ࡥ࠵ࠬᓅ")):
            bstack1ll111ll1_opy_ = self.caps.get(bstack11l11ll_opy_ (u"ࠧࡵࡰࡵ࡫ࡰࡥࡱࡎࡵࡣࡗࡵࡰࠧᓆ"))
        else:
            bstack1ll111ll1_opy_ = self.capabilities.get(bstack11l11ll_opy_ (u"ࠨ࡯ࡱࡶ࡬ࡱࡦࡲࡈࡶࡤࡘࡶࡱࠨᓇ"))
        if bstack1ll111ll1_opy_:
            if bstack1ll1l1lll_opy_() <= version.parse(bstack11l11ll_opy_ (u"ࠧ࠴࠰࠴࠷࠳࠶ࠧᓈ")):
                self.command_executor._url = bstack11l11ll_opy_ (u"ࠣࡪࡷࡸࡵࡀ࠯࠰ࠤᓉ") + bstack1111l111_opy_ + bstack11l11ll_opy_ (u"ࠤ࠽࠼࠵࠵ࡷࡥ࠱࡫ࡹࡧࠨᓊ")
            else:
                self.command_executor._url = bstack11l11ll_opy_ (u"ࠥ࡬ࡹࡺࡰࡴ࠼࠲࠳ࠧᓋ") + bstack1ll111ll1_opy_ + bstack11l11ll_opy_ (u"ࠦ࠴ࡽࡤ࠰ࡪࡸࡦࠧᓌ")
            logger.debug(bstack11ll1l1l1_opy_.format(bstack1ll111ll1_opy_))
        else:
            logger.debug(bstack1111lllll_opy_.format(bstack11l11ll_opy_ (u"ࠧࡕࡰࡵ࡫ࡰࡥࡱࠦࡈࡶࡤࠣࡲࡴࡺࠠࡧࡱࡸࡲࡩࠨᓍ")))
    except Exception as e:
        logger.debug(bstack1111lllll_opy_.format(e))
    bstack11111l111_opy_ = self.session_id
    if bstack11l11ll_opy_ (u"࠭ࡰࡺࡶࡨࡷࡹ࠭ᓎ") in bstack11lllll11_opy_:
        threading.current_thread().bstack11l11l1ll_opy_ = self.session_id
        threading.current_thread().bstackSessionDriver = self
        threading.current_thread().bstackTestErrorMessages = []
        bstack1ll1lll1ll_opy_.bstack11111111l_opy_(self)
    bstack11lll111_opy_.append(self)
    if bstack11l11ll_opy_ (u"ࠧࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡵࠪᓏ") in CONFIG and bstack11l11ll_opy_ (u"ࠨࡵࡨࡷࡸ࡯࡯࡯ࡐࡤࡱࡪ࠭ᓐ") in CONFIG[bstack11l11ll_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࡷࠬᓑ")][bstack11lllllll_opy_]:
        bstack1ll1l1l11l_opy_ = CONFIG[bstack11l11ll_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱࡸ࠭ᓒ")][bstack11lllllll_opy_][bstack11l11ll_opy_ (u"ࠫࡸ࡫ࡳࡴ࡫ࡲࡲࡓࡧ࡭ࡦࠩᓓ")]
    logger.debug(bstack1lll111111_opy_.format(bstack11111l111_opy_))
def bstack1l1lll11l_opy_(self, url):
    global bstack1llll11l1l_opy_
    global CONFIG
    try:
        bstack1lllll1l1_opy_(url, CONFIG, logger)
    except Exception as err:
        logger.debug(bstack1l1ll1ll1_opy_.format(str(err)))
    try:
        bstack1llll11l1l_opy_(self, url)
    except Exception as e:
        try:
            bstack111l111l1_opy_ = str(e)
            if any(err_msg in bstack111l111l1_opy_ for err_msg in bstack111111ll_opy_):
                bstack1lllll1l1_opy_(url, CONFIG, logger, True)
        except Exception as err:
            logger.debug(bstack1l1ll1ll1_opy_.format(str(err)))
        raise e
def bstack1lll1l111_opy_(item, when):
    global bstack1llll1ll11_opy_
    try:
        bstack1llll1ll11_opy_(item, when)
    except Exception as e:
        pass
def bstack1ll1llll1_opy_(item, call, rep):
    global bstack1llll11111_opy_
    global bstack11lll111_opy_
    name = bstack11l11ll_opy_ (u"ࠬ࠭ᓔ")
    try:
        if rep.when == bstack11l11ll_opy_ (u"࠭ࡣࡢ࡮࡯ࠫᓕ"):
            bstack11111l111_opy_ = threading.current_thread().bstack11l11l1ll_opy_
            bstack111ll11ll1_opy_ = item.config.getoption(bstack11l11ll_opy_ (u"ࠧࡴ࡭࡬ࡴࡘ࡫ࡳࡴ࡫ࡲࡲࡓࡧ࡭ࡦࠩᓖ"))
            try:
                if (str(bstack111ll11ll1_opy_).lower() != bstack11l11ll_opy_ (u"ࠨࡶࡵࡹࡪ࠭ᓗ")):
                    name = str(rep.nodeid)
                    bstack1lllll1l1l_opy_ = bstack11ll11lll_opy_(bstack11l11ll_opy_ (u"ࠩࡶࡩࡹ࡙ࡥࡴࡵ࡬ࡳࡳࡔࡡ࡮ࡧࠪᓘ"), name, bstack11l11ll_opy_ (u"ࠪࠫᓙ"), bstack11l11ll_opy_ (u"ࠫࠬᓚ"), bstack11l11ll_opy_ (u"ࠬ࠭ᓛ"), bstack11l11ll_opy_ (u"࠭ࠧᓜ"))
                    for driver in bstack11lll111_opy_:
                        if bstack11111l111_opy_ == driver.session_id:
                            driver.execute_script(bstack1lllll1l1l_opy_)
            except Exception as e:
                logger.debug(bstack11l11ll_opy_ (u"ࠧࡆࡴࡵࡳࡷࠦࡩ࡯ࠢࡶࡩࡹࡺࡩ࡯ࡩࠣࡷࡪࡹࡳࡪࡱࡱࡒࡦࡳࡥࠡࡨࡲࡶࠥࡶࡹࡵࡧࡶࡸ࠲ࡨࡤࡥࠢࡶࡩࡸࡹࡩࡰࡰ࠽ࠤࢀࢃࠧᓝ").format(str(e)))
            try:
                bstack1lll1l1l1l_opy_(rep.outcome.lower())
                if rep.outcome.lower() != bstack11l11ll_opy_ (u"ࠨࡵ࡮࡭ࡵࡶࡥࡥࠩᓞ"):
                    status = bstack11l11ll_opy_ (u"ࠩࡩࡥ࡮ࡲࡥࡥࠩᓟ") if rep.outcome.lower() == bstack11l11ll_opy_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪᓠ") else bstack11l11ll_opy_ (u"ࠫࡵࡧࡳࡴࡧࡧࠫᓡ")
                    reason = bstack11l11ll_opy_ (u"ࠬ࠭ᓢ")
                    if status == bstack11l11ll_opy_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭ᓣ"):
                        reason = rep.longrepr.reprcrash.message
                        if (not threading.current_thread().bstackTestErrorMessages):
                            threading.current_thread().bstackTestErrorMessages = []
                        threading.current_thread().bstackTestErrorMessages.append(reason)
                    level = bstack11l11ll_opy_ (u"ࠧࡪࡰࡩࡳࠬᓤ") if status == bstack11l11ll_opy_ (u"ࠨࡲࡤࡷࡸ࡫ࡤࠨᓥ") else bstack11l11ll_opy_ (u"ࠩࡨࡶࡷࡵࡲࠨᓦ")
                    data = name + bstack11l11ll_opy_ (u"ࠪࠤࡵࡧࡳࡴࡧࡧࠥࠬᓧ") if status == bstack11l11ll_opy_ (u"ࠫࡵࡧࡳࡴࡧࡧࠫᓨ") else name + bstack11l11ll_opy_ (u"ࠬࠦࡦࡢ࡫࡯ࡩࡩࠧࠠࠨᓩ") + reason
                    bstack1ll1l11111_opy_ = bstack11ll11lll_opy_(bstack11l11ll_opy_ (u"࠭ࡡ࡯ࡰࡲࡸࡦࡺࡥࠨᓪ"), bstack11l11ll_opy_ (u"ࠧࠨᓫ"), bstack11l11ll_opy_ (u"ࠨࠩᓬ"), bstack11l11ll_opy_ (u"ࠩࠪᓭ"), level, data)
                    for driver in bstack11lll111_opy_:
                        if bstack11111l111_opy_ == driver.session_id:
                            driver.execute_script(bstack1ll1l11111_opy_)
            except Exception as e:
                logger.debug(bstack11l11ll_opy_ (u"ࠪࡉࡷࡸ࡯ࡳࠢ࡬ࡲࠥࡹࡥࡵࡶ࡬ࡲ࡬ࠦࡳࡦࡵࡶ࡭ࡴࡴࠠࡤࡱࡱࡸࡪࡾࡴࠡࡨࡲࡶࠥࡶࡹࡵࡧࡶࡸ࠲ࡨࡤࡥࠢࡶࡩࡸࡹࡩࡰࡰ࠽ࠤࢀࢃࠧᓮ").format(str(e)))
    except Exception as e:
        logger.debug(bstack11l11ll_opy_ (u"ࠫࡊࡸࡲࡰࡴࠣ࡭ࡳࠦࡧࡦࡶࡷ࡭ࡳ࡭ࠠࡴࡶࡤࡸࡪࠦࡩ࡯ࠢࡳࡽࡹ࡫ࡳࡵ࠯ࡥࡨࡩࠦࡴࡦࡵࡷࠤࡸࡺࡡࡵࡷࡶ࠾ࠥࢁࡽࠨᓯ").format(str(e)))
    bstack1llll11111_opy_(item, call, rep)
notset = Notset()
def bstack1llll111ll_opy_(self, name: str, default=notset, skip: bool = False):
    global bstack11lll111l_opy_
    if str(name).lower() == bstack11l11ll_opy_ (u"ࠬࡪࡲࡪࡸࡨࡶࠬᓰ"):
        return bstack11l11ll_opy_ (u"ࠨࡂࡳࡱࡺࡷࡪࡸࡓࡵࡣࡦ࡯ࠧᓱ")
    else:
        return bstack11lll111l_opy_(self, name, default, skip)
def bstack1l1lll1l_opy_(self):
    global CONFIG
    global bstack1ll11ll1l_opy_
    try:
        proxy = bstack1lllll1ll1_opy_(CONFIG)
        if proxy:
            if proxy.endswith(bstack11l11ll_opy_ (u"ࠧ࠯ࡲࡤࡧࠬᓲ")):
                proxies = bstack111l1lll_opy_(proxy, bstack1ll1l111l1_opy_())
                if len(proxies) > 0:
                    protocol, bstack1ll1ll11l1_opy_ = proxies.popitem()
                    if bstack11l11ll_opy_ (u"ࠣ࠼࠲࠳ࠧᓳ") in bstack1ll1ll11l1_opy_:
                        return bstack1ll1ll11l1_opy_
                    else:
                        return bstack11l11ll_opy_ (u"ࠤ࡫ࡸࡹࡶ࠺࠰࠱ࠥᓴ") + bstack1ll1ll11l1_opy_
            else:
                return proxy
    except Exception as e:
        logger.error(bstack11l11ll_opy_ (u"ࠥࡉࡷࡸ࡯ࡳࠢ࡬ࡲࠥࡹࡥࡵࡶ࡬ࡲ࡬ࠦࡰࡳࡱࡻࡽࠥࡻࡲ࡭ࠢ࠽ࠤࢀࢃࠢᓵ").format(str(e)))
    return bstack1ll11ll1l_opy_(self)
def bstack1ll1l1lll1_opy_():
    return (bstack11l11ll_opy_ (u"ࠫ࡭ࡺࡴࡱࡒࡵࡳࡽࡿࠧᓶ") in CONFIG or bstack11l11ll_opy_ (u"ࠬ࡮ࡴࡵࡲࡶࡔࡷࡵࡸࡺࠩᓷ") in CONFIG) and bstack1lll11l1l1_opy_() and bstack1ll1l1lll_opy_() >= version.parse(
        bstack1111l1ll_opy_)
def bstack1lll11l1ll_opy_(self,
               executablePath=None,
               channel=None,
               args=None,
               ignoreDefaultArgs=None,
               handleSIGINT=None,
               handleSIGTERM=None,
               handleSIGHUP=None,
               timeout=None,
               env=None,
               headless=None,
               devtools=None,
               proxy=None,
               downloadsPath=None,
               slowMo=None,
               tracesDir=None,
               chromiumSandbox=None,
               firefoxUserPrefs=None
               ):
    global CONFIG
    global bstack1ll1l1l11l_opy_
    global bstack1ll1ll1ll_opy_
    global bstack11lllll11_opy_
    CONFIG[bstack11l11ll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡘࡊࡋࠨᓸ")] = str(bstack11lllll11_opy_) + str(__version__)
    bstack11lllllll_opy_ = 0
    try:
        if bstack1ll1ll1ll_opy_ is True:
            bstack11lllllll_opy_ = int(os.environ.get(bstack11l11ll_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡐࡍࡃࡗࡊࡔࡘࡍࡠࡋࡑࡈࡊ࡞ࠧᓹ")))
    except:
        bstack11lllllll_opy_ = 0
    CONFIG[bstack11l11ll_opy_ (u"ࠣ࡫ࡶࡔࡱࡧࡹࡸࡴ࡬࡫࡭ࡺࠢᓺ")] = True
    bstack1l11l111_opy_ = bstack111l111l_opy_(CONFIG, bstack11lllllll_opy_)
    logger.debug(bstack1l11l11l1_opy_.format(str(bstack1l11l111_opy_)))
    if CONFIG.get(bstack11l11ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡍࡱࡦࡥࡱ࠭ᓻ")):
        bstack11llll11l_opy_(bstack1l11l111_opy_, bstack1ll11llll1_opy_)
    if bstack11l11ll_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱࡸ࠭ᓼ") in CONFIG and bstack11l11ll_opy_ (u"ࠫࡸ࡫ࡳࡴ࡫ࡲࡲࡓࡧ࡭ࡦࠩᓽ") in CONFIG[bstack11l11ll_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡳࠨᓾ")][bstack11lllllll_opy_]:
        bstack1ll1l1l11l_opy_ = CONFIG[bstack11l11ll_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩᓿ")][bstack11lllllll_opy_][bstack11l11ll_opy_ (u"ࠧࡴࡧࡶࡷ࡮ࡵ࡮ࡏࡣࡰࡩࠬᔀ")]
    import urllib
    import json
    bstack11ll1111_opy_ = bstack11l11ll_opy_ (u"ࠨࡹࡶࡷ࠿࠵࠯ࡤࡦࡳ࠲ࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭࠱ࡧࡴࡳ࠯ࡱ࡮ࡤࡽࡼࡸࡩࡨࡪࡷࡃࡨࡧࡰࡴ࠿ࠪᔁ") + urllib.parse.quote(json.dumps(bstack1l11l111_opy_))
    browser = self.connect(bstack11ll1111_opy_)
    return browser
def bstack1ll11ll111_opy_():
    global bstack1ll1ll11ll_opy_
    try:
        from playwright._impl._browser_type import BrowserType
        BrowserType.launch = bstack1lll11l1ll_opy_
        bstack1ll1ll11ll_opy_ = True
    except Exception as e:
        pass
def bstack111llll1ll_opy_():
    global CONFIG
    global bstack11lll11l1_opy_
    global bstack1111l111_opy_
    global bstack1ll11llll1_opy_
    global bstack1ll1ll1ll_opy_
    CONFIG = json.loads(os.environ.get(bstack11l11ll_opy_ (u"ࠩࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡅࡒࡒࡋࡏࡇࠨᔂ")))
    bstack11lll11l1_opy_ = eval(os.environ.get(bstack11l11ll_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡌࡗࡤࡇࡐࡑࡡࡄ࡙࡙ࡕࡍࡂࡖࡈࠫᔃ")))
    bstack1111l111_opy_ = os.environ.get(bstack11l11ll_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡌ࡚ࡈ࡟ࡖࡔࡏࠫᔄ"))
    bstack111ll11l1_opy_(CONFIG, bstack11lll11l1_opy_)
    bstack1ll11l1111_opy_()
    global bstack1llll1llll_opy_
    global bstack1lll1llll1_opy_
    global bstack1llll1l1l_opy_
    global bstack1ll1l1l11_opy_
    global bstack1lllll111_opy_
    global bstack1ll1l111ll_opy_
    global bstack1111ll11_opy_
    global bstack1llll11l1l_opy_
    global bstack1ll11ll1l_opy_
    global bstack11lll111l_opy_
    global bstack1llll1ll11_opy_
    global bstack1llll11111_opy_
    try:
        from selenium import webdriver
        from selenium.webdriver.remote.webdriver import WebDriver
        bstack1llll1llll_opy_ = webdriver.Remote.__init__
        bstack1lll1llll1_opy_ = WebDriver.quit
        bstack1111ll11_opy_ = WebDriver.close
        bstack1llll11l1l_opy_ = WebDriver.get
    except Exception as e:
        pass
    if (bstack11l11ll_opy_ (u"ࠬ࡮ࡴࡵࡲࡓࡶࡴࡾࡹࠨᔅ") in CONFIG or bstack11l11ll_opy_ (u"࠭ࡨࡵࡶࡳࡷࡕࡸ࡯ࡹࡻࠪᔆ") in CONFIG) and bstack1lll11l1l1_opy_():
        if bstack1ll1l1lll_opy_() < version.parse(bstack1111l1ll_opy_):
            logger.error(bstack1111111ll_opy_.format(bstack1ll1l1lll_opy_()))
        else:
            try:
                from selenium.webdriver.remote.remote_connection import RemoteConnection
                bstack1ll11ll1l_opy_ = RemoteConnection._get_proxy_url
            except Exception as e:
                logger.error(bstack1l1l1l11_opy_.format(str(e)))
    try:
        from _pytest.config import Config
        bstack11lll111l_opy_ = Config.getoption
        from _pytest import runner
        bstack1llll1ll11_opy_ = runner._update_current_test_var
    except Exception as e:
        logger.warn(e, bstack1ll11l11_opy_)
    try:
        from pytest_bdd import reporting
        bstack1llll11111_opy_ = reporting.runtest_makereport
    except Exception as e:
        logger.debug(bstack11l11ll_opy_ (u"ࠧࡑ࡮ࡨࡥࡸ࡫ࠠࡪࡰࡶࡸࡦࡲ࡬ࠡࡲࡼࡸࡪࡹࡴ࠮ࡤࡧࡨࠥࡺ࡯ࠡࡴࡸࡲࠥࡶࡹࡵࡧࡶࡸ࠲ࡨࡤࡥࠢࡷࡩࡸࡺࡳࠨᔇ"))
    bstack1ll11llll1_opy_ = CONFIG.get(bstack11l11ll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡕࡷࡥࡨࡱࡌࡰࡥࡤࡰࡔࡶࡴࡪࡱࡱࡷࠬᔈ"), {}).get(bstack11l11ll_opy_ (u"ࠩ࡯ࡳࡨࡧ࡬ࡊࡦࡨࡲࡹ࡯ࡦࡪࡧࡵࠫᔉ"))
    bstack1ll1ll1ll_opy_ = True
    bstack1lll1ll1l_opy_(bstack1ll1l1l1_opy_)
if (bstack1l1111111l_opy_()):
    bstack111llll1ll_opy_()
@bstack1l1l11l1ll_opy_(class_method=False)
def bstack111lllll1l_opy_(hook_name, event, bstack111llllll1_opy_=None):
    if hook_name not in [bstack11l11ll_opy_ (u"ࠪࡷࡪࡺࡵࡱࡡࡩࡹࡳࡩࡴࡪࡱࡱࠫᔊ"), bstack11l11ll_opy_ (u"ࠫࡹ࡫ࡡࡳࡦࡲࡻࡳࡥࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨᔋ"), bstack11l11ll_opy_ (u"ࠬࡹࡥࡵࡷࡳࡣࡲࡵࡤࡶ࡮ࡨࠫᔌ"), bstack11l11ll_opy_ (u"࠭ࡴࡦࡣࡵࡨࡴࡽ࡮ࡠ࡯ࡲࡨࡺࡲࡥࠨᔍ"), bstack11l11ll_opy_ (u"ࠧࡴࡧࡷࡹࡵࡥࡣ࡭ࡣࡶࡷࠬᔎ"), bstack11l11ll_opy_ (u"ࠨࡶࡨࡥࡷࡪ࡯ࡸࡰࡢࡧࡱࡧࡳࡴࠩᔏ"), bstack11l11ll_opy_ (u"ࠩࡶࡩࡹࡻࡰࡠ࡯ࡨࡸ࡭ࡵࡤࠨᔐ"), bstack11l11ll_opy_ (u"ࠪࡸࡪࡧࡲࡥࡱࡺࡲࡤࡳࡥࡵࡪࡲࡨࠬᔑ")]:
        return
    node = store[bstack11l11ll_opy_ (u"ࠫࡨࡻࡲࡳࡧࡱࡸࡤࡺࡥࡴࡶࡢ࡭ࡹ࡫࡭ࠨᔒ")]
    if hook_name in [bstack11l11ll_opy_ (u"ࠬࡹࡥࡵࡷࡳࡣࡲࡵࡤࡶ࡮ࡨࠫᔓ"), bstack11l11ll_opy_ (u"࠭ࡴࡦࡣࡵࡨࡴࡽ࡮ࡠ࡯ࡲࡨࡺࡲࡥࠨᔔ")]:
        node = store[bstack11l11ll_opy_ (u"ࠧࡤࡷࡵࡶࡪࡴࡴࡠ࡯ࡲࡨࡺࡲࡥࡠ࡫ࡷࡩࡲ࠭ᔕ")]
    elif hook_name in [bstack11l11ll_opy_ (u"ࠨࡵࡨࡸࡺࡶ࡟ࡤ࡮ࡤࡷࡸ࠭ᔖ"), bstack11l11ll_opy_ (u"ࠩࡷࡩࡦࡸࡤࡰࡹࡱࡣࡨࡲࡡࡴࡵࠪᔗ")]:
        node = store[bstack11l11ll_opy_ (u"ࠪࡧࡺࡸࡲࡦࡰࡷࡣࡨࡲࡡࡴࡵࡢ࡭ࡹ࡫࡭ࠨᔘ")]
    if event == bstack11l11ll_opy_ (u"ࠫࡧ࡫ࡦࡰࡴࡨࠫᔙ"):
        hook_type = bstack1l111lllll_opy_(hook_name)
        uuid = uuid4().__str__()
        bstack111ll1111l_opy_ = {
            bstack11l11ll_opy_ (u"ࠬࡻࡵࡪࡦࠪᔚ"): uuid,
            bstack11l11ll_opy_ (u"࠭ࡳࡵࡣࡵࡸࡪࡪ࡟ࡢࡶࠪᔛ"): bstack11ll1llll_opy_(),
            bstack11l11ll_opy_ (u"ࠧࡵࡻࡳࡩࠬᔜ"): bstack11l11ll_opy_ (u"ࠨࡪࡲࡳࡰ࠭ᔝ"),
            bstack11l11ll_opy_ (u"ࠩ࡫ࡳࡴࡱ࡟ࡵࡻࡳࡩࠬᔞ"): hook_type,
            bstack11l11ll_opy_ (u"ࠪ࡬ࡴࡵ࡫ࡠࡰࡤࡱࡪ࠭ᔟ"): hook_name
        }
        store[bstack11l11ll_opy_ (u"ࠫࡨࡻࡲࡳࡧࡱࡸࡤ࡮࡯ࡰ࡭ࡢࡹࡺ࡯ࡤࠨᔠ")].append(uuid)
        bstack11l111111l_opy_ = node.nodeid
        if hook_type == bstack11l11ll_opy_ (u"ࠬࡈࡅࡇࡑࡕࡉࡤࡋࡁࡄࡊࠪᔡ"):
            if not _11l1111l1l_opy_.get(bstack11l111111l_opy_, None):
                _11l1111l1l_opy_[bstack11l111111l_opy_] = {bstack11l11ll_opy_ (u"࠭ࡨࡰࡱ࡮ࡷࠬᔢ"): []}
            _11l1111l1l_opy_[bstack11l111111l_opy_][bstack11l11ll_opy_ (u"ࠧࡩࡱࡲ࡯ࡸ࠭ᔣ")].append(bstack111ll1111l_opy_[bstack11l11ll_opy_ (u"ࠨࡷࡸ࡭ࡩ࠭ᔤ")])
        _11l1111l1l_opy_[bstack11l111111l_opy_ + bstack11l11ll_opy_ (u"ࠩ࠰ࠫᔥ") + hook_name] = bstack111ll1111l_opy_
        bstack11l1111l11_opy_(node, bstack111ll1111l_opy_, bstack11l11ll_opy_ (u"ࠪࡌࡴࡵ࡫ࡓࡷࡱࡗࡹࡧࡲࡵࡧࡧࠫᔦ"))
    elif event == bstack11l11ll_opy_ (u"ࠫࡦ࡬ࡴࡦࡴࠪᔧ"):
        bstack111lll1lll_opy_ = node.nodeid + bstack11l11ll_opy_ (u"ࠬ࠳ࠧᔨ") + hook_name
        _11l1111l1l_opy_[bstack111lll1lll_opy_][bstack11l11ll_opy_ (u"࠭ࡦࡪࡰ࡬ࡷ࡭࡫ࡤࡠࡣࡷࠫᔩ")] = bstack11ll1llll_opy_()
        bstack111ll11l1l_opy_(_11l1111l1l_opy_[bstack111lll1lll_opy_][bstack11l11ll_opy_ (u"ࠧࡶࡷ࡬ࡨࠬᔪ")])
        bstack11l1111l11_opy_(node, _11l1111l1l_opy_[bstack111lll1lll_opy_], bstack11l11ll_opy_ (u"ࠨࡊࡲࡳࡰࡘࡵ࡯ࡈ࡬ࡲ࡮ࡹࡨࡦࡦࠪᔫ"), bstack111llll1l1_opy_=bstack111llllll1_opy_)
def bstack111llll11l_opy_():
    global bstack111lllllll_opy_
    if bstack1llll1111_opy_():
        bstack111lllllll_opy_ = bstack11l11ll_opy_ (u"ࠩࡳࡽࡹ࡫ࡳࡵ࠯ࡥࡨࡩ࠭ᔬ")
    else:
        bstack111lllllll_opy_ = bstack11l11ll_opy_ (u"ࠪࡴࡾࡺࡥࡴࡶࠪᔭ")
@bstack1ll1lll1ll_opy_.bstack1l11l1ll1l_opy_
def bstack11l11111ll_opy_():
    bstack111llll11l_opy_()
    if bstack1lll11l1l1_opy_():
        bstack1l1l1ll111_opy_(bstack111lll111l_opy_)
    bstack1l1ll11l11_opy_ = bstack1l1ll1l111_opy_(bstack111lllll1l_opy_)
bstack11l11111ll_opy_()