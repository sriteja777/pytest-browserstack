# coding: UTF-8
import sys
bstack111llll_opy_ = sys.version_info [0] == 2
bstack1llllll_opy_ = 2048
bstack11ll1l_opy_ = 7
def bstack11l11ll_opy_ (bstack1l1ll11_opy_):
    global bstack1l11l_opy_
    bstack1l11ll_opy_ = ord (bstack1l1ll11_opy_ [-1])
    bstack111ll1_opy_ = bstack1l1ll11_opy_ [:-1]
    bstack1lllll_opy_ = bstack1l11ll_opy_ % len (bstack111ll1_opy_)
    bstack11l1l1l_opy_ = bstack111ll1_opy_ [:bstack1lllll_opy_] + bstack111ll1_opy_ [bstack1lllll_opy_:]
    if bstack111llll_opy_:
        bstack1ll1l_opy_ = unicode () .join ([unichr (ord (char) - bstack1llllll_opy_ - (bstack1l11l1_opy_ + bstack1l11ll_opy_) % bstack11ll1l_opy_) for bstack1l11l1_opy_, char in enumerate (bstack11l1l1l_opy_)])
    else:
        bstack1ll1l_opy_ = str () .join ([chr (ord (char) - bstack1llllll_opy_ - (bstack1l11l1_opy_ + bstack1l11ll_opy_) % bstack11ll1l_opy_) for bstack1l11l1_opy_, char in enumerate (bstack11l1l1l_opy_)])
    return eval (bstack1ll1l_opy_)
import threading
class bstack11ll11l11_opy_(threading.Thread):
    def run(self):
        self.exc = None
        try:
            self.ret = self._target(*self._args, **self._kwargs)
        except Exception as e:
            self.exc = e
    def join(self, timeout=None):
        super(bstack11ll11l11_opy_, self).join(timeout)
        if self.exc:
            raise self.exc
        return self.ret