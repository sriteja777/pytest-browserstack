# coding: UTF-8
import sys
bstack111llll_opy_ = sys.version_info [0] == 2
bstack1llllll_opy_ = 2048
bstack11ll1l_opy_ = 7
def bstack11l11ll_opy_ (bstack1l1ll11_opy_):
    global bstack1l11l_opy_
    bstack1l11ll_opy_ = ord (bstack1l1ll11_opy_ [-1])
    bstack111ll1_opy_ = bstack1l1ll11_opy_ [:-1]
    bstack1lllll_opy_ = bstack1l11ll_opy_ % len (bstack111ll1_opy_)
    bstack11l1l1l_opy_ = bstack111ll1_opy_ [:bstack1lllll_opy_] + bstack111ll1_opy_ [bstack1lllll_opy_:]
    if bstack111llll_opy_:
        bstack1ll1l_opy_ = unicode () .join ([unichr (ord (char) - bstack1llllll_opy_ - (bstack1l11l1_opy_ + bstack1l11ll_opy_) % bstack11ll1l_opy_) for bstack1l11l1_opy_, char in enumerate (bstack11l1l1l_opy_)])
    else:
        bstack1ll1l_opy_ = str () .join ([chr (ord (char) - bstack1llllll_opy_ - (bstack1l11l1_opy_ + bstack1l11ll_opy_) % bstack11ll1l_opy_) for bstack1l11l1_opy_, char in enumerate (bstack11l1l1l_opy_)])
    return eval (bstack1ll1l_opy_)
import multiprocessing
import os
from browserstack_sdk.bstack1lll111l_opy_ import *
from bstack_utils.helper import bstack1ll111l1_opy_
from bstack_utils.messages import bstack1ll11l11_opy_
from bstack_utils.constants import bstack1ll1l1l1_opy_
class bstack1lll1ll1_opy_:
    def __init__(self, args, logger, bstack1ll1111l_opy_, bstack1ll11lll_opy_):
        self.args = args
        self.logger = logger
        self.bstack1ll1111l_opy_ = bstack1ll1111l_opy_
        self.bstack1ll11lll_opy_ = bstack1ll11lll_opy_
        self._prepareconfig = None
        self.Config = None
        self.runner = None
        self.bstack1ll1llll_opy_ = []
        self.bstack1ll1l111_opy_ = None
        self.bstack1ll1lll1_opy_ = []
        self.bstack1llll1ll_opy_ = self.bstack1llll111_opy_()
        self.bstack1ll1ll11_opy_ = -1
    def bstack1ll111ll_opy_(self, bstack1lll1l1l_opy_):
        self.parse_args()
        self.bstack1lll1l11_opy_()
        self.bstack1lll1lll_opy_(bstack1lll1l1l_opy_)
    @staticmethod
    def version():
        import pytest
        return pytest.__version__
    def bstack1lllll11_opy_(self, arg):
        if arg in self.args:
            i = self.args.index(arg)
            self.args.pop(i + 1)
            self.args.pop(i)
    def parse_args(self):
        self.bstack1ll1ll11_opy_ = -1
        if bstack11l11ll_opy_ (u"ࠩࡳࡥࡷࡧ࡬࡭ࡧ࡯ࡷࡕ࡫ࡲࡑ࡮ࡤࡸ࡫ࡵࡲ࡮ࠩࡵ") in self.bstack1ll1111l_opy_:
            self.bstack1ll1ll11_opy_ = self.bstack1ll1111l_opy_[bstack11l11ll_opy_ (u"ࠪࡴࡦࡸࡡ࡭࡮ࡨࡰࡸࡖࡥࡳࡒ࡯ࡥࡹ࡬࡯ࡳ࡯ࠪࡶ")]
        try:
            bstack1lll11ll_opy_ = [bstack11l11ll_opy_ (u"ࠫ࠲࠳ࡤࡳ࡫ࡹࡩࡷ࠭ࡷ"), bstack11l11ll_opy_ (u"ࠬ࠳࠭ࡱ࡮ࡸ࡫࡮ࡴࡳࠨࡸ"), bstack11l11ll_opy_ (u"࠭࠭ࡱࠩࡹ")]
            if self.bstack1ll1ll11_opy_ >= 0:
                bstack1lll11ll_opy_.extend([bstack11l11ll_opy_ (u"ࠧ࠮࠯ࡱࡹࡲࡶࡲࡰࡥࡨࡷࡸ࡫ࡳࠨࡺ"), bstack11l11ll_opy_ (u"ࠨ࠯ࡱࠫࡻ")])
            for arg in bstack1lll11ll_opy_:
                self.bstack1lllll11_opy_(arg)
        except Exception as exc:
            self.logger.error(str(exc))
    def get_args(self):
        return self.args
    def bstack1lll1l11_opy_(self):
        bstack1ll1l111_opy_ = [os.path.normpath(item) for item in self.args]
        self.bstack1ll1l111_opy_ = bstack1ll1l111_opy_
        return bstack1ll1l111_opy_
    def bstack1ll1l11l_opy_(self):
        try:
            from _pytest.config import _prepareconfig
            from _pytest.config import Config
            from _pytest import runner
            import importlib
            bstack1lll1111_opy_ = importlib.find_loader(bstack11l11ll_opy_ (u"ࠩࡳࡽࡹ࡫ࡳࡵࡡࡶࡩࡱ࡫࡮ࡪࡷࡰࠫࡼ"))
            self._prepareconfig = _prepareconfig
            self.Config = Config
            self.runner = runner
        except Exception as e:
            self.logger.warn(e, bstack1ll11l11_opy_)
    def bstack1lll1lll_opy_(self, bstack1lll1l1l_opy_):
        if bstack1lll1l1l_opy_:
            self.bstack1ll1l111_opy_.append(bstack11l11ll_opy_ (u"ࠪ࠱࠲ࡹ࡫ࡪࡲࡖࡩࡸࡹࡩࡰࡰࡑࡥࡲ࡫ࠧࡽ"))
            self.bstack1ll1l111_opy_.append(bstack11l11ll_opy_ (u"࡙ࠫࡸࡵࡦࠩࡾ"))
        self.bstack1ll1l111_opy_.append(bstack11l11ll_opy_ (u"ࠬ࠳ࡰࠨࡿ"))
        self.bstack1ll1l111_opy_.append(bstack11l11ll_opy_ (u"࠭ࡰࡺࡶࡨࡷࡹࡥࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡵࡲࡵࡨ࡫ࡱࠫࢀ"))
        self.bstack1ll1l111_opy_.append(bstack11l11ll_opy_ (u"ࠧ࠮࠯ࡧࡶ࡮ࡼࡥࡳࠩࢁ"))
        self.bstack1ll1l111_opy_.append(bstack11l11ll_opy_ (u"ࠨࡥ࡫ࡶࡴࡳࡥࠨࢂ"))
        if self.bstack1ll1ll11_opy_ > 1:
            self.bstack1ll1l111_opy_.append(bstack11l11ll_opy_ (u"ࠩ࠰ࡲࠬࢃ"))
            self.bstack1ll1l111_opy_.append(str(self.bstack1ll1ll11_opy_))
    def bstack1ll11l1l_opy_(self):
        bstack1ll1lll1_opy_ = []
        for spec in self.bstack1ll1llll_opy_:
            bstack1llll11l_opy_ = [spec]
            bstack1llll11l_opy_ += self.bstack1ll1l111_opy_
            bstack1ll1lll1_opy_.append(bstack1llll11l_opy_)
        self.bstack1ll1lll1_opy_ = bstack1ll1lll1_opy_
        return bstack1ll1lll1_opy_
    def bstack1llll111_opy_(self):
        try:
            from pytest_bdd import reporting
            self.bstack1llll1ll_opy_ = True
            return True
        except Exception as e:
            self.bstack1llll1ll_opy_ = False
        return self.bstack1llll1ll_opy_
    def bstack1ll1l1ll_opy_(self, bstack1ll11ll1_opy_, bstack1ll111ll_opy_):
        bstack1ll111ll_opy_[bstack11l11ll_opy_ (u"ࠪࡇࡔࡔࡆࡊࡉࠪࢄ")] = self.bstack1ll1111l_opy_
        multiprocessing.set_start_method(bstack11l11ll_opy_ (u"ࠫࡸࡶࡡࡸࡰࠪࢅ"))
        if bstack11l11ll_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡳࠨࢆ") in self.bstack1ll1111l_opy_:
            bstack1lll11l1_opy_ = []
            manager = multiprocessing.Manager()
            bstack1llll1l1_opy_ = manager.list()
            for index, platform in enumerate(self.bstack1ll1111l_opy_[bstack11l11ll_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩࢇ")]):
                bstack1lll11l1_opy_.append(multiprocessing.Process(name=str(index),
                                                           target=bstack1ll11ll1_opy_,
                                                           args=(self.bstack1ll1l111_opy_, bstack1ll111ll_opy_)))
            i = 0
            for t in bstack1lll11l1_opy_:
                os.environ[bstack11l11ll_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡐࡍࡃࡗࡊࡔࡘࡍࡠࡋࡑࡈࡊ࡞ࠧ࢈")] = str(i)
                i += 1
                t.start()
            for t in bstack1lll11l1_opy_:
                t.join()
            return bstack1llll1l1_opy_