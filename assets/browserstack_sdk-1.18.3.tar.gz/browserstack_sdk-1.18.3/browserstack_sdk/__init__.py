# coding: UTF-8
import sys
bstack111llll_opy_ = sys.version_info [0] == 2
bstack1llllll_opy_ = 2048
bstack11ll1l_opy_ = 7
def bstack11l11ll_opy_ (bstack1l1ll11_opy_):
    global bstack1l11l_opy_
    bstack1l11ll_opy_ = ord (bstack1l1ll11_opy_ [-1])
    bstack111ll1_opy_ = bstack1l1ll11_opy_ [:-1]
    bstack1lllll_opy_ = bstack1l11ll_opy_ % len (bstack111ll1_opy_)
    bstack11l1l1l_opy_ = bstack111ll1_opy_ [:bstack1lllll_opy_] + bstack111ll1_opy_ [bstack1lllll_opy_:]
    if bstack111llll_opy_:
        bstack1ll1l_opy_ = unicode () .join ([unichr (ord (char) - bstack1llllll_opy_ - (bstack1l11l1_opy_ + bstack1l11ll_opy_) % bstack11ll1l_opy_) for bstack1l11l1_opy_, char in enumerate (bstack11l1l1l_opy_)])
    else:
        bstack1ll1l_opy_ = str () .join ([chr (ord (char) - bstack1llllll_opy_ - (bstack1l11l1_opy_ + bstack1l11ll_opy_) % bstack11ll1l_opy_) for bstack1l11l1_opy_, char in enumerate (bstack11l1l1l_opy_)])
    return eval (bstack1ll1l_opy_)
import atexit
import os
import signal
import sys
import yaml
import requests
import logging
import threading
import socket
import datetime
import string
import random
import json
import collections.abc
import re
import multiprocessing
import traceback
import copy
from packaging import version
from browserstack.local import Local
from urllib.parse import urlparse
from bstack_utils.constants import *
from bstack_utils.percy import *
import time
import requests
def bstack1l1l1l1l_opy_():
  global CONFIG
  headers = {
        bstack11l11ll_opy_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡷࡽࡵ࡫ࠧࢉ"): bstack11l11ll_opy_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯࡫ࡵࡲࡲࠬࢊ"),
      }
  proxies = bstack111l11ll_opy_(CONFIG, bstack1l111ll1_opy_)
  try:
    response = requests.get(bstack1l111ll1_opy_, headers=headers, proxies=proxies, timeout=5)
    if response.json():
      bstack11lll1lll_opy_ = response.json()[bstack11l11ll_opy_ (u"ࠪ࡬ࡺࡨࡳࠨࢋ")]
      logger.debug(bstack1l1ll111l_opy_.format(response.json()))
      return bstack11lll1lll_opy_
    else:
      logger.debug(bstack11111l11_opy_.format(bstack11l11ll_opy_ (u"ࠦࡗ࡫ࡳࡱࡱࡱࡷࡪࠦࡊࡔࡑࡑࠤࡵࡧࡲࡴࡧࠣࡩࡷࡸ࡯ࡳࠢࠥࢌ")))
  except Exception as e:
    logger.debug(bstack11111l11_opy_.format(e))
def bstack1lll1l1ll1_opy_(hub_url):
  global CONFIG
  url = bstack11l11ll_opy_ (u"ࠧ࡮ࡴࡵࡲࡶ࠾࠴࠵ࠢࢍ")+  hub_url + bstack11l11ll_opy_ (u"ࠨ࠯ࡤࡪࡨࡧࡰࠨࢎ")
  headers = {
        bstack11l11ll_opy_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡶࡼࡴࡪ࠭࢏"): bstack11l11ll_opy_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡪࡴࡱࡱࠫ࢐"),
      }
  proxies = bstack111l11ll_opy_(CONFIG, url)
  try:
    start_time = time.perf_counter()
    requests.get(url, headers=headers, proxies=proxies, timeout=5)
    latency = time.perf_counter() - start_time
    logger.debug(bstack1ll1l1111_opy_.format(hub_url, latency))
    return dict(hub_url=hub_url, latency=latency)
  except Exception as e:
    logger.debug(bstack1l1l11l11_opy_.format(hub_url, e))
def bstack1lll1ll1ll_opy_():
  try:
    global bstack1111l111_opy_
    bstack11lll1lll_opy_ = bstack1l1l1l1l_opy_()
    bstack11ll11111_opy_ = []
    results = []
    for bstack1l1lll11_opy_ in bstack11lll1lll_opy_:
      bstack11ll11111_opy_.append(bstack11ll11l11_opy_(target=bstack1lll1l1ll1_opy_,args=(bstack1l1lll11_opy_,)))
    for t in bstack11ll11111_opy_:
      t.start()
    for t in bstack11ll11111_opy_:
      results.append(t.join())
    bstack1l1l1ll11_opy_ = {}
    for item in results:
      hub_url = item[bstack11l11ll_opy_ (u"ࠩ࡫ࡹࡧࡥࡵࡳ࡮ࠪ࢑")]
      latency = item[bstack11l11ll_opy_ (u"ࠪࡰࡦࡺࡥ࡯ࡥࡼࠫ࢒")]
      bstack1l1l1ll11_opy_[hub_url] = latency
    bstack11l11ll1l_opy_ = min(bstack1l1l1ll11_opy_, key= lambda x: bstack1l1l1ll11_opy_[x])
    bstack1111l111_opy_ = bstack11l11ll1l_opy_
    logger.debug(bstack111l1l1l1_opy_.format(bstack11l11ll1l_opy_))
  except Exception as e:
    logger.debug(bstack1111l1l11_opy_.format(e))
from bstack_utils.messages import *
from bstack_utils.config import Config
from bstack_utils.helper import bstack1l11l1l11_opy_, bstack1llll11lll_opy_, bstack1ll1llll1l_opy_, bstack11llllll1_opy_, Notset, bstack1l1ll1l1l_opy_, \
  bstack1ll1llll11_opy_, bstack1ll1ll1l11_opy_, bstack11lll1111_opy_, bstack1lll11ll1l_opy_, bstack1llll1111_opy_, bstack1lll11l1l1_opy_, bstack111l11lll_opy_, \
  bstack1lllllll1l_opy_
from bstack_utils.bstack1lllll1111_opy_ import bstack1ll1lll1ll_opy_
from bstack_utils.proxy import bstack111l1lll_opy_, bstack111l11ll_opy_, bstack1lllll1ll1_opy_, bstack11ll1ll1_opy_
import bstack_utils.bstack1ll1lllll_opy_ as bstack11lllll1l_opy_
from browserstack_sdk.bstack1ll1ll1l_opy_ import *
from browserstack_sdk.bstack1lll111l_opy_ import *
from bstack_utils.bstack11111llll_opy_ import bstack1lll1l1l1l_opy_
bstack1lllllll11_opy_ = bstack11l11ll_opy_ (u"ࠫࠥࠦ࠯ࠫࠢࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࠦࠪ࠰࡞ࡱࠤࠥ࡯ࡦࠩࡲࡤ࡫ࡪࠦ࠽࠾࠿ࠣࡺࡴ࡯ࡤࠡ࠲ࠬࠤࢀࡢ࡮ࠡࠢࠣࡸࡷࡿࡻ࡝ࡰࠣࡧࡴࡴࡳࡵࠢࡩࡷࠥࡃࠠࡳࡧࡴࡹ࡮ࡸࡥࠩ࡞ࠪࡪࡸࡢࠧࠪ࠽࡟ࡲࠥࠦࠠࠡࠢࡩࡷ࠳ࡧࡰࡱࡧࡱࡨࡋ࡯࡬ࡦࡕࡼࡲࡨ࠮ࡢࡴࡶࡤࡧࡰࡥࡰࡢࡶ࡫࠰ࠥࡐࡓࡐࡐ࠱ࡷࡹࡸࡩ࡯ࡩ࡬ࡪࡾ࠮ࡰࡠ࡫ࡱࡨࡪࡾࠩࠡ࠭ࠣࠦ࠿ࠨࠠࠬࠢࡍࡗࡔࡔ࠮ࡴࡶࡵ࡭ࡳ࡭ࡩࡧࡻࠫࡎࡘࡕࡎ࠯ࡲࡤࡶࡸ࡫ࠨࠩࡣࡺࡥ࡮ࡺࠠ࡯ࡧࡺࡔࡦ࡭ࡥ࠳࠰ࡨࡺࡦࡲࡵࡢࡶࡨࠬࠧ࠮ࠩࠡ࠿ࡁࠤࢀࢃࠢ࠭ࠢ࡟ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡢࡩࡽ࡫ࡣࡶࡶࡲࡶ࠿ࠦࡻࠣࡣࡦࡸ࡮ࡵ࡮ࠣ࠼ࠣࠦ࡬࡫ࡴࡔࡧࡶࡷ࡮ࡵ࡮ࡅࡧࡷࡥ࡮ࡲࡳࠣࡿ࡟ࠫ࠮࠯ࠩ࡜ࠤ࡫ࡥࡸ࡮ࡥࡥࡡ࡬ࡨࠧࡣࠩࠡ࠭ࠣࠦ࠱ࡢ࡜࡯ࠤࠬࡠࡳࠦࠠࠡࠢࢀࡧࡦࡺࡣࡩࠪࡨࡼ࠮ࢁ࡜࡯ࠢࠣࠤࠥࢃ࡜࡯ࠢࠣࢁࡡࡴࠠࠡ࠱࠭ࠤࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽ࠡࠬ࠲ࠫ࢓")
bstack1l1ll1l11_opy_ = bstack11l11ll_opy_ (u"ࠬࡢ࡮࠰ࠬࠣࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃࠠࠫ࠱࡟ࡲࡨࡵ࡮ࡴࡶࠣࡦࡸࡺࡡࡤ࡭ࡢࡴࡦࡺࡨࠡ࠿ࠣࡴࡷࡵࡣࡦࡵࡶ࠲ࡦࡸࡧࡷ࡝ࡳࡶࡴࡩࡥࡴࡵ࠱ࡥࡷ࡭ࡶ࠯࡮ࡨࡲ࡬ࡺࡨࠡ࠯ࠣ࠷ࡢࡢ࡮ࡤࡱࡱࡷࡹࠦࡢࡴࡶࡤࡧࡰࡥࡣࡢࡲࡶࠤࡂࠦࡰࡳࡱࡦࡩࡸࡹ࠮ࡢࡴࡪࡺࡠࡶࡲࡰࡥࡨࡷࡸ࠴ࡡࡳࡩࡹ࠲ࡱ࡫࡮ࡨࡶ࡫ࠤ࠲ࠦ࠱࡞࡞ࡱࡧࡴࡴࡳࡵࠢࡳࡣ࡮ࡴࡤࡦࡺࠣࡁࠥࡶࡲࡰࡥࡨࡷࡸ࠴ࡡࡳࡩࡹ࡟ࡵࡸ࡯ࡤࡧࡶࡷ࠳ࡧࡲࡨࡸ࠱ࡰࡪࡴࡧࡵࡪࠣ࠱ࠥ࠸࡝࡝ࡰࡳࡶࡴࡩࡥࡴࡵ࠱ࡥࡷ࡭ࡶࠡ࠿ࠣࡴࡷࡵࡣࡦࡵࡶ࠲ࡦࡸࡧࡷ࠰ࡶࡰ࡮ࡩࡥࠩ࠲࠯ࠤࡵࡸ࡯ࡤࡧࡶࡷ࠳ࡧࡲࡨࡸ࠱ࡰࡪࡴࡧࡵࡪࠣ࠱ࠥ࠹ࠩ࡝ࡰࡦࡳࡳࡹࡴࠡ࡫ࡰࡴࡴࡸࡴࡠࡲ࡯ࡥࡾࡽࡲࡪࡩ࡫ࡸ࠹ࡥࡢࡴࡶࡤࡧࡰࠦ࠽ࠡࡴࡨࡵࡺ࡯ࡲࡦࠪࠥࡴࡱࡧࡹࡸࡴ࡬࡫࡭ࡺࠢࠪ࠽࡟ࡲ࡮ࡳࡰࡰࡴࡷࡣࡵࡲࡡࡺࡹࡵ࡭࡬࡮ࡴ࠵ࡡࡥࡷࡹࡧࡣ࡬࠰ࡦ࡬ࡷࡵ࡭ࡪࡷࡰ࠲ࡱࡧࡵ࡯ࡥ࡫ࠤࡂࠦࡡࡴࡻࡱࡧࠥ࠮࡬ࡢࡷࡱࡧ࡭ࡕࡰࡵ࡫ࡲࡲࡸ࠯ࠠ࠾ࡀࠣࡿࡡࡴ࡬ࡦࡶࠣࡧࡦࡶࡳ࠼࡞ࡱࡸࡷࡿࠠࡼ࡞ࡱࡧࡦࡶࡳࠡ࠿ࠣࡎࡘࡕࡎ࠯ࡲࡤࡶࡸ࡫ࠨࡣࡵࡷࡥࡨࡱ࡟ࡤࡣࡳࡷ࠮ࡢ࡮ࠡࠢࢀࠤࡨࡧࡴࡤࡪࠫࡩࡽ࠯ࠠࡼ࡞ࡱࠤࠥࠦࠠࡾ࡞ࡱࠤࠥࡸࡥࡵࡷࡵࡲࠥࡧࡷࡢ࡫ࡷࠤ࡮ࡳࡰࡰࡴࡷࡣࡵࡲࡡࡺࡹࡵ࡭࡬࡮ࡴ࠵ࡡࡥࡷࡹࡧࡣ࡬࠰ࡦ࡬ࡷࡵ࡭ࡪࡷࡰ࠲ࡨࡵ࡮࡯ࡧࡦࡸ࠭ࢁ࡜࡯ࠢࠣࠤࠥࡽࡳࡆࡰࡧࡴࡴ࡯࡮ࡵ࠼ࠣࡤࡼࡹࡳ࠻࠱࠲ࡧࡩࡶ࠮ࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠴ࡣࡰ࡯࠲ࡴࡱࡧࡹࡸࡴ࡬࡫࡭ࡺ࠿ࡤࡣࡳࡷࡂࠪࡻࡦࡰࡦࡳࡩ࡫ࡕࡓࡋࡆࡳࡲࡶ࡯࡯ࡧࡱࡸ࠭ࡐࡓࡐࡐ࠱ࡷࡹࡸࡩ࡯ࡩ࡬ࡪࡾ࠮ࡣࡢࡲࡶ࠭࠮ࢃࡠ࠭࡞ࡱࠤࠥࠦࠠ࠯࠰࠱ࡰࡦࡻ࡮ࡤࡪࡒࡴࡹ࡯࡯࡯ࡵ࡟ࡲࠥࠦࡽࠪ࡞ࡱࢁࡡࡴ࠯ࠫࠢࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࠦࠪ࠰࡞ࡱࠫ࢔")
from ._version import __version__
bstack1l11ll11_opy_ = None
CONFIG = {}
bstack11ll11l1_opy_ = {}
bstack1ll11ll11l_opy_ = {}
bstack11111l111_opy_ = None
bstack111l1l11_opy_ = None
bstack1ll1l1l11l_opy_ = None
bstack111l11l1_opy_ = -1
bstack11llll11_opy_ = bstack11l111ll1_opy_
bstack1lll11llll_opy_ = 1
bstack1ll1ll1ll_opy_ = False
bstack11ll1l11_opy_ = False
bstack11lllll11_opy_ = bstack11l11ll_opy_ (u"࠭ࠧ࢕")
bstack1ll11llll1_opy_ = bstack11l11ll_opy_ (u"ࠧࠨ࢖")
bstack11lll11l1_opy_ = False
bstack1l11ll11l_opy_ = True
bstack11ll1lll_opy_ = bstack11l11ll_opy_ (u"ࠨࠩࢗ")
bstack11lll111_opy_ = []
bstack1111l111_opy_ = bstack11l11ll_opy_ (u"ࠩࠪ࢘")
bstack1ll1ll11ll_opy_ = False
bstack1ll111llll_opy_ = None
bstack1ll1lllll1_opy_ = None
bstack1l1111l1l_opy_ = -1
bstack111lll11l_opy_ = os.path.join(os.path.expanduser(bstack11l11ll_opy_ (u"ࠪࢂ࢙ࠬ")), bstack11l11ll_opy_ (u"ࠫ࠳ࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮࢚ࠫ"), bstack11l11ll_opy_ (u"ࠬ࠴ࡲࡰࡤࡲࡸ࠲ࡸࡥࡱࡱࡵࡸ࠲࡮ࡥ࡭ࡲࡨࡶ࠳ࡰࡳࡰࡰ࢛ࠪ"))
bstack11ll11ll1_opy_ = []
bstack111l111ll_opy_ = []
bstack1llll11l1_opy_ = False
bstack11l11l1l_opy_ = False
bstack1llll1llll_opy_ = None
bstack1lll1llll1_opy_ = None
bstack111ll1l1_opy_ = None
bstack1ll11l11l_opy_ = None
bstack1ll11l1ll1_opy_ = None
bstack1llll1l1l_opy_ = None
bstack1ll1l1l11_opy_ = None
bstack111111111_opy_ = None
bstack1lllll111_opy_ = None
bstack1ll1l111ll_opy_ = None
bstack1ll11ll1l_opy_ = None
bstack1111ll11_opy_ = None
bstack1llll11l1l_opy_ = None
bstack11llll1ll_opy_ = None
bstack11lll111l_opy_ = None
bstack1llll1ll11_opy_ = None
bstack1lll11ll11_opy_ = None
bstack1llll11111_opy_ = None
bstack11l1l1111_opy_ = bstack11l11ll_opy_ (u"ࠨࠢ࢜")
logger = logging.getLogger(__name__)
logging.basicConfig(level=bstack11llll11_opy_,
                    format=bstack11l11ll_opy_ (u"ࠧ࡝ࡰࠨࠬࡦࡹࡣࡵ࡫ࡰࡩ࠮ࡹࠠ࡜ࠧࠫࡲࡦࡳࡥࠪࡵࡠ࡟ࠪ࠮࡬ࡦࡸࡨࡰࡳࡧ࡭ࡦࠫࡶࡡࠥ࠳ࠠࠦࠪࡰࡩࡸࡹࡡࡨࡧࠬࡷࠬ࢝"),
                    datefmt=bstack11l11ll_opy_ (u"ࠨࠧࡋ࠾ࠪࡓ࠺ࠦࡕࠪ࢞"),
                    stream=sys.stdout)
bstack11l1111l_opy_ = Config.get_instance()
percy = bstack1llll11l11_opy_()
def bstack1ll11l1111_opy_():
  global CONFIG
  global bstack11llll11_opy_
  if bstack11l11ll_opy_ (u"ࠩ࡯ࡳ࡬ࡒࡥࡷࡧ࡯ࠫ࢟") in CONFIG:
    bstack11llll11_opy_ = bstack1ll1111ll_opy_[CONFIG[bstack11l11ll_opy_ (u"ࠪࡰࡴ࡭ࡌࡦࡸࡨࡰࠬࢠ")]]
    logging.getLogger().setLevel(bstack11llll11_opy_)
def bstack1l11l111l_opy_():
  global CONFIG
  global bstack1llll11l1_opy_
  bstack1lll1l11l_opy_ = bstack11111l1l1_opy_(CONFIG)
  if (bstack11l11ll_opy_ (u"ࠫࡸࡱࡩࡱࡕࡨࡷࡸ࡯࡯࡯ࡐࡤࡱࡪ࠭ࢡ") in bstack1lll1l11l_opy_ and str(bstack1lll1l11l_opy_[bstack11l11ll_opy_ (u"ࠬࡹ࡫ࡪࡲࡖࡩࡸࡹࡩࡰࡰࡑࡥࡲ࡫ࠧࢢ")]).lower() == bstack11l11ll_opy_ (u"࠭ࡴࡳࡷࡨࠫࢣ")):
    bstack1llll11l1_opy_ = True
def bstack1l1l1llll_opy_():
  from appium.version import version as appium_version
  return version.parse(appium_version)
def bstack1ll1l1lll_opy_():
  from selenium import webdriver
  return version.parse(webdriver.__version__)
def bstack1l1ll11l_opy_():
  args = sys.argv
  for i in range(len(args)):
    if bstack11l11ll_opy_ (u"ࠢ࠮࠯ࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡤࡱࡱࡪ࡮࡭ࡦࡪ࡮ࡨࠦࢤ") == args[i].lower() or bstack11l11ll_opy_ (u"ࠣ࠯࠰ࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬࠰ࡦࡳࡳ࡬ࡩࡨࠤࢥ") == args[i].lower():
      path = args[i + 1]
      sys.argv.remove(args[i])
      sys.argv.remove(path)
      global bstack11ll1lll_opy_
      bstack11ll1lll_opy_ += bstack11l11ll_opy_ (u"ࠩ࠰࠱ࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡆࡳࡳ࡬ࡩࡨࡈ࡬ࡰࡪࠦࠧࢦ") + path
      return path
  return None
bstack11111lll1_opy_ = re.compile(bstack11l11ll_opy_ (u"ࡵࠦ࠳࠰࠿࡝ࠦࡾࠬ࠳࠰࠿ࠪࡿ࠱࠮ࡄࠨࢧ"))
def bstack1ll11111l_opy_(loader, node):
  value = loader.construct_scalar(node)
  for group in bstack11111lll1_opy_.findall(value):
    if group is not None and os.environ.get(group) is not None:
      value = value.replace(bstack11l11ll_opy_ (u"ࠦࠩࢁࠢࢨ") + group + bstack11l11ll_opy_ (u"ࠧࢃࠢࢩ"), os.environ.get(group))
  return value
def bstack111l1llll_opy_():
  bstack1lll1ll11_opy_ = bstack1l1ll11l_opy_()
  if bstack1lll1ll11_opy_ and os.path.exists(os.path.abspath(bstack1lll1ll11_opy_)):
    fileName = bstack1lll1ll11_opy_
  if bstack11l11ll_opy_ (u"࠭ࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤࡉࡏࡏࡈࡌࡋࡤࡌࡉࡍࡇࠪࢪ") in os.environ and os.path.exists(
          os.path.abspath(os.environ[bstack11l11ll_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡃࡐࡐࡉࡍࡌࡥࡆࡊࡎࡈࠫࢫ")])) and not bstack11l11ll_opy_ (u"ࠨࡨ࡬ࡰࡪࡔࡡ࡮ࡧࠪࢬ") in locals():
    fileName = os.environ[bstack11l11ll_opy_ (u"ࠩࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡅࡒࡒࡋࡏࡇࡠࡈࡌࡐࡊ࠭ࢭ")]
  if bstack11l11ll_opy_ (u"ࠪࡪ࡮ࡲࡥࡏࡣࡰࡩࠬࢮ") in locals():
    bstack11l1l11_opy_ = os.path.abspath(fileName)
  else:
    bstack11l1l11_opy_ = bstack11l11ll_opy_ (u"ࠫࠬࢯ")
  bstack11ll1l1ll_opy_ = os.getcwd()
  bstack1111111l1_opy_ = bstack11l11ll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮࠲ࡾࡳ࡬ࠨࢰ")
  bstack1ll111lll_opy_ = bstack11l11ll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯࠳ࡿࡡ࡮࡮ࠪࢱ")
  while (not os.path.exists(bstack11l1l11_opy_)) and bstack11ll1l1ll_opy_ != bstack11l11ll_opy_ (u"ࠢࠣࢲ"):
    bstack11l1l11_opy_ = os.path.join(bstack11ll1l1ll_opy_, bstack1111111l1_opy_)
    if not os.path.exists(bstack11l1l11_opy_):
      bstack11l1l11_opy_ = os.path.join(bstack11ll1l1ll_opy_, bstack1ll111lll_opy_)
    if bstack11ll1l1ll_opy_ != os.path.dirname(bstack11ll1l1ll_opy_):
      bstack11ll1l1ll_opy_ = os.path.dirname(bstack11ll1l1ll_opy_)
    else:
      bstack11ll1l1ll_opy_ = bstack11l11ll_opy_ (u"ࠣࠤࢳ")
  if not os.path.exists(bstack11l1l11_opy_):
    bstack1l1ll1ll_opy_(
      bstack11l1ll11l_opy_.format(os.getcwd()))
  try:
    with open(bstack11l1l11_opy_, bstack11l11ll_opy_ (u"ࠩࡵࠫࢴ")) as stream:
      yaml.add_implicit_resolver(bstack11l11ll_opy_ (u"ࠥࠥࡵࡧࡴࡩࡧࡻࠦࢵ"), bstack11111lll1_opy_)
      yaml.add_constructor(bstack11l11ll_opy_ (u"ࠦࠦࡶࡡࡵࡪࡨࡼࠧࢶ"), bstack1ll11111l_opy_)
      config = yaml.load(stream, yaml.FullLoader)
      return config
  except:
    with open(bstack11l1l11_opy_, bstack11l11ll_opy_ (u"ࠬࡸࠧࢷ")) as stream:
      try:
        config = yaml.safe_load(stream)
        return config
      except yaml.YAMLError as exc:
        bstack1l1ll1ll_opy_(bstack1ll1l1ll1_opy_.format(str(exc)))
def bstack11l111l1_opy_(config):
  bstack11l11lll_opy_ = bstack1llll111l_opy_(config)
  for option in list(bstack11l11lll_opy_):
    if option.lower() in bstack1111ll1l_opy_ and option != bstack1111ll1l_opy_[option.lower()]:
      bstack11l11lll_opy_[bstack1111ll1l_opy_[option.lower()]] = bstack11l11lll_opy_[option]
      del bstack11l11lll_opy_[option]
  return config
def bstack1lll1l11ll_opy_():
  global bstack1ll11ll11l_opy_
  for key, bstack1ll1111l1_opy_ in bstack1llllll1ll_opy_.items():
    if isinstance(bstack1ll1111l1_opy_, list):
      for var in bstack1ll1111l1_opy_:
        if var in os.environ and os.environ[var] and str(os.environ[var]).strip():
          bstack1ll11ll11l_opy_[key] = os.environ[var]
          break
    elif bstack1ll1111l1_opy_ in os.environ and os.environ[bstack1ll1111l1_opy_] and str(os.environ[bstack1ll1111l1_opy_]).strip():
      bstack1ll11ll11l_opy_[key] = os.environ[bstack1ll1111l1_opy_]
  if bstack11l11ll_opy_ (u"࠭ࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤࡒࡏࡄࡃࡏࡣࡎࡊࡅࡏࡖࡌࡊࡎࡋࡒࠨࢸ") in os.environ:
    bstack1ll11ll11l_opy_[bstack11l11ll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡔࡶࡤࡧࡰࡒ࡯ࡤࡣ࡯ࡓࡵࡺࡩࡰࡰࡶࠫࢹ")] = {}
    bstack1ll11ll11l_opy_[bstack11l11ll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡕࡷࡥࡨࡱࡌࡰࡥࡤࡰࡔࡶࡴࡪࡱࡱࡷࠬࢺ")][bstack11l11ll_opy_ (u"ࠩ࡯ࡳࡨࡧ࡬ࡊࡦࡨࡲࡹ࡯ࡦࡪࡧࡵࠫࢻ")] = os.environ[bstack11l11ll_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡏࡓࡈࡇࡌࡠࡋࡇࡉࡓ࡚ࡉࡇࡋࡈࡖࠬࢼ")]
def bstack1ll111ll11_opy_():
  global bstack11ll11l1_opy_
  global bstack11ll1lll_opy_
  for idx, val in enumerate(sys.argv):
    if idx < len(sys.argv) and bstack11l11ll_opy_ (u"ࠫ࠲࠳ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯࠳ࡲ࡯ࡤࡣ࡯ࡍࡩ࡫࡮ࡵ࡫ࡩ࡭ࡪࡸࠧࢽ").lower() == val.lower():
      bstack11ll11l1_opy_[bstack11l11ll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷ࡙ࡴࡢࡥ࡮ࡐࡴࡩࡡ࡭ࡑࡳࡸ࡮ࡵ࡮ࡴࠩࢾ")] = {}
      bstack11ll11l1_opy_[bstack11l11ll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡓࡵࡣࡦ࡯ࡑࡵࡣࡢ࡮ࡒࡴࡹ࡯࡯࡯ࡵࠪࢿ")][bstack11l11ll_opy_ (u"ࠧ࡭ࡱࡦࡥࡱࡏࡤࡦࡰࡷ࡭࡫࡯ࡥࡳࠩࣀ")] = sys.argv[idx + 1]
      del sys.argv[idx:idx + 2]
      break
  for key, bstack1l1l111ll_opy_ in bstack111lll1l1_opy_.items():
    if isinstance(bstack1l1l111ll_opy_, list):
      for idx, val in enumerate(sys.argv):
        for var in bstack1l1l111ll_opy_:
          if idx < len(sys.argv) and bstack11l11ll_opy_ (u"ࠨ࠯࠰ࠫࣁ") + var.lower() == val.lower() and not key in bstack11ll11l1_opy_:
            bstack11ll11l1_opy_[key] = sys.argv[idx + 1]
            bstack11ll1lll_opy_ += bstack11l11ll_opy_ (u"ࠩࠣ࠱࠲࠭ࣂ") + var + bstack11l11ll_opy_ (u"ࠪࠤࠬࣃ") + sys.argv[idx + 1]
            del sys.argv[idx:idx + 2]
            break
    else:
      for idx, val in enumerate(sys.argv):
        if idx < len(sys.argv) and bstack11l11ll_opy_ (u"ࠫ࠲࠳ࠧࣄ") + bstack1l1l111ll_opy_.lower() == val.lower() and not key in bstack11ll11l1_opy_:
          bstack11ll11l1_opy_[key] = sys.argv[idx + 1]
          bstack11ll1lll_opy_ += bstack11l11ll_opy_ (u"ࠬࠦ࠭࠮ࠩࣅ") + bstack1l1l111ll_opy_ + bstack11l11ll_opy_ (u"࠭ࠠࠨࣆ") + sys.argv[idx + 1]
          del sys.argv[idx:idx + 2]
def bstack1l1llllll_opy_(config):
  bstack1111ll1ll_opy_ = config.keys()
  for bstack1lll1l111l_opy_, bstack11111l1l_opy_ in bstack11111111_opy_.items():
    if bstack11111l1l_opy_ in bstack1111ll1ll_opy_:
      config[bstack1lll1l111l_opy_] = config[bstack11111l1l_opy_]
      del config[bstack11111l1l_opy_]
  for bstack1lll1l111l_opy_, bstack11111l1l_opy_ in bstack111l11111_opy_.items():
    if isinstance(bstack11111l1l_opy_, list):
      for bstack1l1l11111_opy_ in bstack11111l1l_opy_:
        if bstack1l1l11111_opy_ in bstack1111ll1ll_opy_:
          config[bstack1lll1l111l_opy_] = config[bstack1l1l11111_opy_]
          del config[bstack1l1l11111_opy_]
          break
    elif bstack11111l1l_opy_ in bstack1111ll1ll_opy_:
      config[bstack1lll1l111l_opy_] = config[bstack11111l1l_opy_]
      del config[bstack11111l1l_opy_]
  for bstack1l1l11111_opy_ in list(config):
    for bstack1lll11l111_opy_ in bstack11lll1l1_opy_:
      if bstack1l1l11111_opy_.lower() == bstack1lll11l111_opy_.lower() and bstack1l1l11111_opy_ != bstack1lll11l111_opy_:
        config[bstack1lll11l111_opy_] = config[bstack1l1l11111_opy_]
        del config[bstack1l1l11111_opy_]
  bstack111llll1_opy_ = []
  if bstack11l11ll_opy_ (u"ࠧࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡵࠪࣇ") in config:
    bstack111llll1_opy_ = config[bstack11l11ll_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠫࣈ")]
  for platform in bstack111llll1_opy_:
    for bstack1l1l11111_opy_ in list(platform):
      for bstack1lll11l111_opy_ in bstack11lll1l1_opy_:
        if bstack1l1l11111_opy_.lower() == bstack1lll11l111_opy_.lower() and bstack1l1l11111_opy_ != bstack1lll11l111_opy_:
          platform[bstack1lll11l111_opy_] = platform[bstack1l1l11111_opy_]
          del platform[bstack1l1l11111_opy_]
  for bstack1lll1l111l_opy_, bstack11111l1l_opy_ in bstack111l11111_opy_.items():
    for platform in bstack111llll1_opy_:
      if isinstance(bstack11111l1l_opy_, list):
        for bstack1l1l11111_opy_ in bstack11111l1l_opy_:
          if bstack1l1l11111_opy_ in platform:
            platform[bstack1lll1l111l_opy_] = platform[bstack1l1l11111_opy_]
            del platform[bstack1l1l11111_opy_]
            break
      elif bstack11111l1l_opy_ in platform:
        platform[bstack1lll1l111l_opy_] = platform[bstack11111l1l_opy_]
        del platform[bstack11111l1l_opy_]
  for bstack1ll1l11ll1_opy_ in bstack1ll1lll111_opy_:
    if bstack1ll1l11ll1_opy_ in config:
      if not bstack1ll1lll111_opy_[bstack1ll1l11ll1_opy_] in config:
        config[bstack1ll1lll111_opy_[bstack1ll1l11ll1_opy_]] = {}
      config[bstack1ll1lll111_opy_[bstack1ll1l11ll1_opy_]].update(config[bstack1ll1l11ll1_opy_])
      del config[bstack1ll1l11ll1_opy_]
  for platform in bstack111llll1_opy_:
    for bstack1ll1l11ll1_opy_ in bstack1ll1lll111_opy_:
      if bstack1ll1l11ll1_opy_ in list(platform):
        if not bstack1ll1lll111_opy_[bstack1ll1l11ll1_opy_] in platform:
          platform[bstack1ll1lll111_opy_[bstack1ll1l11ll1_opy_]] = {}
        platform[bstack1ll1lll111_opy_[bstack1ll1l11ll1_opy_]].update(platform[bstack1ll1l11ll1_opy_])
        del platform[bstack1ll1l11ll1_opy_]
  config = bstack11l111l1_opy_(config)
  return config
def bstack1ll1l1ll11_opy_(config):
  global bstack1ll11llll1_opy_
  if bstack11l11ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡍࡱࡦࡥࡱ࠭ࣉ") in config and str(config[bstack11l11ll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡎࡲࡧࡦࡲࠧ࣊")]).lower() != bstack11l11ll_opy_ (u"ࠫ࡫ࡧ࡬ࡴࡧࠪ࣋"):
    if not bstack11l11ll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷ࡙ࡴࡢࡥ࡮ࡐࡴࡩࡡ࡭ࡑࡳࡸ࡮ࡵ࡮ࡴࠩ࣌") in config:
      config[bstack11l11ll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡓࡵࡣࡦ࡯ࡑࡵࡣࡢ࡮ࡒࡴࡹ࡯࡯࡯ࡵࠪ࣍")] = {}
    if not bstack11l11ll_opy_ (u"ࠧ࡭ࡱࡦࡥࡱࡏࡤࡦࡰࡷ࡭࡫࡯ࡥࡳࠩ࣎") in config[bstack11l11ll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡕࡷࡥࡨࡱࡌࡰࡥࡤࡰࡔࡶࡴࡪࡱࡱࡷ࣏ࠬ")]:
      bstack11ll1llll_opy_ = datetime.datetime.now()
      bstack111111l11_opy_ = bstack11ll1llll_opy_.strftime(bstack11l11ll_opy_ (u"ࠩࠨࡨࡤࠫࡢࡠࠧࡋࠩࡒ࣐࠭"))
      hostname = socket.gethostname()
      bstack111ll1lll_opy_ = bstack11l11ll_opy_ (u"࣑ࠪࠫ").join(random.choices(string.ascii_lowercase + string.digits, k=4))
      identifier = bstack11l11ll_opy_ (u"ࠫࢀࢃ࡟ࡼࡿࡢࡿࢂ࣒࠭").format(bstack111111l11_opy_, hostname, bstack111ll1lll_opy_)
      config[bstack11l11ll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷ࡙ࡴࡢࡥ࡮ࡐࡴࡩࡡ࡭ࡑࡳࡸ࡮ࡵ࡮ࡴ࣓ࠩ")][bstack11l11ll_opy_ (u"࠭࡬ࡰࡥࡤࡰࡎࡪࡥ࡯ࡶ࡬ࡪ࡮࡫ࡲࠨࣔ")] = identifier
    bstack1ll11llll1_opy_ = config[bstack11l11ll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡔࡶࡤࡧࡰࡒ࡯ࡤࡣ࡯ࡓࡵࡺࡩࡰࡰࡶࠫࣕ")][bstack11l11ll_opy_ (u"ࠨ࡮ࡲࡧࡦࡲࡉࡥࡧࡱࡸ࡮࡬ࡩࡦࡴࠪࣖ")]
  return config
def bstack1ll111l111_opy_():
  bstack1ll1lll11l_opy_ =  bstack1lll11ll1l_opy_()[bstack11l11ll_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡠࡰࡸࡱࡧ࡫ࡲࠨࣗ")]
  return bstack1ll1lll11l_opy_ if bstack1ll1lll11l_opy_ else -1
def bstack1llllll1l1_opy_(bstack1ll1lll11l_opy_):
  global CONFIG
  if not bstack11l11ll_opy_ (u"ࠪࠨࢀࡈࡕࡊࡎࡇࡣࡓ࡛ࡍࡃࡇࡕࢁࠬࣘ") in CONFIG[bstack11l11ll_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡌࡨࡪࡴࡴࡪࡨ࡬ࡩࡷ࠭ࣙ")]:
    return
  CONFIG[bstack11l11ll_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡍࡩ࡫࡮ࡵ࡫ࡩ࡭ࡪࡸࠧࣚ")] = CONFIG[bstack11l11ll_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡎࡪࡥ࡯ࡶ࡬ࡪ࡮࡫ࡲࠨࣛ")].replace(
    bstack11l11ll_opy_ (u"ࠧࠥࡽࡅ࡙ࡎࡒࡄࡠࡐࡘࡑࡇࡋࡒࡾࠩࣜ"),
    str(bstack1ll1lll11l_opy_)
  )
def bstack1llll1l1l1_opy_():
  global CONFIG
  if not bstack11l11ll_opy_ (u"ࠨࠦࡾࡈࡆ࡚ࡅࡠࡖࡌࡑࡊࢃࠧࣝ") in CONFIG[bstack11l11ll_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡊࡦࡨࡲࡹ࡯ࡦࡪࡧࡵࠫࣞ")]:
    return
  bstack11ll1llll_opy_ = datetime.datetime.now()
  bstack111111l11_opy_ = bstack11ll1llll_opy_.strftime(bstack11l11ll_opy_ (u"ࠪࠩࡩ࠳ࠥࡣ࠯ࠨࡌ࠿ࠫࡍࠨࣟ"))
  CONFIG[bstack11l11ll_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡌࡨࡪࡴࡴࡪࡨ࡬ࡩࡷ࠭࣠")] = CONFIG[bstack11l11ll_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡍࡩ࡫࡮ࡵ࡫ࡩ࡭ࡪࡸࠧ࣡")].replace(
    bstack11l11ll_opy_ (u"࠭ࠤࡼࡆࡄࡘࡊࡥࡔࡊࡏࡈࢁࠬ࣢"),
    bstack111111l11_opy_
  )
def bstack1ll11l11l1_opy_():
  global CONFIG
  if bstack11l11ll_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡏࡤࡦࡰࡷ࡭࡫࡯ࡥࡳࣣࠩ") in CONFIG and not bool(CONFIG[bstack11l11ll_opy_ (u"ࠨࡤࡸ࡭ࡱࡪࡉࡥࡧࡱࡸ࡮࡬ࡩࡦࡴࠪࣤ")]):
    del CONFIG[bstack11l11ll_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡊࡦࡨࡲࡹ࡯ࡦࡪࡧࡵࠫࣥ")]
    return
  if not bstack11l11ll_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡋࡧࡩࡳࡺࡩࡧ࡫ࡨࡶࣦࠬ") in CONFIG:
    CONFIG[bstack11l11ll_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡌࡨࡪࡴࡴࡪࡨ࡬ࡩࡷ࠭ࣧ")] = bstack11l11ll_opy_ (u"ࠬࠩࠤࡼࡄࡘࡍࡑࡊ࡟ࡏࡗࡐࡆࡊࡘࡽࠨࣨ")
  if bstack11l11ll_opy_ (u"࠭ࠤࡼࡆࡄࡘࡊࡥࡔࡊࡏࡈࢁࣩࠬ") in CONFIG[bstack11l11ll_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡏࡤࡦࡰࡷ࡭࡫࡯ࡥࡳࠩ࣪")]:
    bstack1llll1l1l1_opy_()
    os.environ[bstack11l11ll_opy_ (u"ࠨࡄࡖࡘࡆࡉࡋࡠࡅࡒࡑࡇࡏࡎࡆࡆࡢࡆ࡚ࡏࡌࡅࡡࡌࡈࠬ࣫")] = CONFIG[bstack11l11ll_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡊࡦࡨࡲࡹ࡯ࡦࡪࡧࡵࠫ࣬")]
  if not bstack11l11ll_opy_ (u"ࠪࠨࢀࡈࡕࡊࡎࡇࡣࡓ࡛ࡍࡃࡇࡕࢁ࣭ࠬ") in CONFIG[bstack11l11ll_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡌࡨࡪࡴࡴࡪࡨ࡬ࡩࡷ࣮࠭")]:
    return
  bstack1ll1lll11l_opy_ = bstack11l11ll_opy_ (u"࣯ࠬ࠭")
  bstack1ll11l1l1l_opy_ = bstack1ll111l111_opy_()
  if bstack1ll11l1l1l_opy_ != -1:
    bstack1ll1lll11l_opy_ = bstack11l11ll_opy_ (u"࠭ࡃࡊࣰࠢࠪ") + str(bstack1ll11l1l1l_opy_)
  if bstack1ll1lll11l_opy_ == bstack11l11ll_opy_ (u"ࠧࠨࣱ"):
    bstack11l1ll111_opy_ = bstack1l1ll1l1_opy_(CONFIG[bstack11l11ll_opy_ (u"ࠨࡤࡸ࡭ࡱࡪࡎࡢ࡯ࡨࣲࠫ")])
    if bstack11l1ll111_opy_ != -1:
      bstack1ll1lll11l_opy_ = str(bstack11l1ll111_opy_)
  if bstack1ll1lll11l_opy_:
    bstack1llllll1l1_opy_(bstack1ll1lll11l_opy_)
    os.environ[bstack11l11ll_opy_ (u"ࠩࡅࡗ࡙ࡇࡃࡌࡡࡆࡓࡒࡈࡉࡏࡇࡇࡣࡇ࡛ࡉࡍࡆࡢࡍࡉ࠭ࣳ")] = CONFIG[bstack11l11ll_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡋࡧࡩࡳࡺࡩࡧ࡫ࡨࡶࠬࣴ")]
def bstack1111l111l_opy_(bstack1111l1111_opy_, bstack111l11l11_opy_, path):
  bstack1l11111l_opy_ = {
    bstack11l11ll_opy_ (u"ࠫ࡮ࡪࡥ࡯ࡶ࡬ࡪ࡮࡫ࡲࠨࣵ"): bstack111l11l11_opy_
  }
  if os.path.exists(path):
    bstack1ll1l1l1l_opy_ = json.load(open(path, bstack11l11ll_opy_ (u"ࠬࡸࡢࠨࣶ")))
  else:
    bstack1ll1l1l1l_opy_ = {}
  bstack1ll1l1l1l_opy_[bstack1111l1111_opy_] = bstack1l11111l_opy_
  with open(path, bstack11l11ll_opy_ (u"ࠨࡷࠬࠤࣷ")) as outfile:
    json.dump(bstack1ll1l1l1l_opy_, outfile)
def bstack1l1ll1l1_opy_(bstack1111l1111_opy_):
  bstack1111l1111_opy_ = str(bstack1111l1111_opy_)
  bstack1l11lllll_opy_ = os.path.join(os.path.expanduser(bstack11l11ll_opy_ (u"ࠧࡿࠩࣸ")), bstack11l11ll_opy_ (u"ࠨ࠰ࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࠨࣹ"))
  try:
    if not os.path.exists(bstack1l11lllll_opy_):
      os.makedirs(bstack1l11lllll_opy_)
    file_path = os.path.join(os.path.expanduser(bstack11l11ll_opy_ (u"ࠩࢁࣺࠫ")), bstack11l11ll_opy_ (u"ࠪ࠲ࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࠪࣻ"), bstack11l11ll_opy_ (u"ࠫ࠳ࡨࡵࡪ࡮ࡧ࠱ࡳࡧ࡭ࡦ࠯ࡦࡥࡨ࡮ࡥ࠯࡬ࡶࡳࡳ࠭ࣼ"))
    if not os.path.isfile(file_path):
      with open(file_path, bstack11l11ll_opy_ (u"ࠬࡽࠧࣽ")):
        pass
      with open(file_path, bstack11l11ll_opy_ (u"ࠨࡷࠬࠤࣾ")) as outfile:
        json.dump({}, outfile)
    with open(file_path, bstack11l11ll_opy_ (u"ࠧࡳࠩࣿ")) as bstack111l1ll11_opy_:
      bstack1l11l1111_opy_ = json.load(bstack111l1ll11_opy_)
    if bstack1111l1111_opy_ in bstack1l11l1111_opy_:
      bstack111ll1ll1_opy_ = bstack1l11l1111_opy_[bstack1111l1111_opy_][bstack11l11ll_opy_ (u"ࠨ࡫ࡧࡩࡳࡺࡩࡧ࡫ࡨࡶࠬऀ")]
      bstack11lll11ll_opy_ = int(bstack111ll1ll1_opy_) + 1
      bstack1111l111l_opy_(bstack1111l1111_opy_, bstack11lll11ll_opy_, file_path)
      return bstack11lll11ll_opy_
    else:
      bstack1111l111l_opy_(bstack1111l1111_opy_, 1, file_path)
      return 1
  except Exception as e:
    logger.warn(bstack11ll111l1_opy_.format(str(e)))
    return -1
def bstack11l11llll_opy_(config):
  if not config[bstack11l11ll_opy_ (u"ࠩࡸࡷࡪࡸࡎࡢ࡯ࡨࠫँ")] or not config[bstack11l11ll_opy_ (u"ࠪࡥࡨࡩࡥࡴࡵࡎࡩࡾ࠭ं")]:
    return True
  else:
    return False
def bstack1l1111l1_opy_(config, index=0):
  global bstack11lll11l1_opy_
  bstack1lllllll1_opy_ = {}
  caps = bstack1ll11111_opy_ + bstack1ll11l11ll_opy_
  if bstack11lll11l1_opy_:
    caps += bstack11l1llll_opy_
  for key in config:
    if key in caps + [bstack11l11ll_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡹࠧः")]:
      continue
    bstack1lllllll1_opy_[key] = config[key]
  if bstack11l11ll_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡳࠨऄ") in config:
    for bstack11lllll1_opy_ in config[bstack11l11ll_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩअ")][index]:
      if bstack11lllll1_opy_ in caps + [bstack11l11ll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡏࡣࡰࡩࠬआ"), bstack11l11ll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡘࡨࡶࡸ࡯࡯࡯ࠩइ")]:
        continue
      bstack1lllllll1_opy_[bstack11lllll1_opy_] = config[bstack11l11ll_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࡷࠬई")][index][bstack11lllll1_opy_]
  bstack1lllllll1_opy_[bstack11l11ll_opy_ (u"ࠪ࡬ࡴࡹࡴࡏࡣࡰࡩࠬउ")] = socket.gethostname()
  if bstack11l11ll_opy_ (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲࠬऊ") in bstack1lllllll1_opy_:
    del (bstack1lllllll1_opy_[bstack11l11ll_opy_ (u"ࠬࡼࡥࡳࡵ࡬ࡳࡳ࠭ऋ")])
  return bstack1lllllll1_opy_
def bstack11111ll1l_opy_(config):
  global bstack11lll11l1_opy_
  bstack1ll1l1llll_opy_ = {}
  caps = bstack1ll11l11ll_opy_
  if bstack11lll11l1_opy_:
    caps += bstack11l1llll_opy_
  for key in caps:
    if key in config:
      bstack1ll1l1llll_opy_[key] = config[key]
  return bstack1ll1l1llll_opy_
def bstack1l11l1lll_opy_(bstack1lllllll1_opy_, bstack1ll1l1llll_opy_):
  bstack11l11111l_opy_ = {}
  for key in bstack1lllllll1_opy_.keys():
    if key in bstack11111111_opy_:
      bstack11l11111l_opy_[bstack11111111_opy_[key]] = bstack1lllllll1_opy_[key]
    else:
      bstack11l11111l_opy_[key] = bstack1lllllll1_opy_[key]
  for key in bstack1ll1l1llll_opy_:
    if key in bstack11111111_opy_:
      bstack11l11111l_opy_[bstack11111111_opy_[key]] = bstack1ll1l1llll_opy_[key]
    else:
      bstack11l11111l_opy_[key] = bstack1ll1l1llll_opy_[key]
  return bstack11l11111l_opy_
def bstack111l111l_opy_(config, index=0):
  global bstack11lll11l1_opy_
  config = copy.deepcopy(config)
  caps = {}
  bstack1ll1l1llll_opy_ = bstack11111ll1l_opy_(config)
  bstack11ll1ll11_opy_ = bstack1ll11l11ll_opy_
  bstack11ll1ll11_opy_ += bstack1111llll_opy_
  if bstack11lll11l1_opy_:
    bstack11ll1ll11_opy_ += bstack11l1llll_opy_
  if bstack11l11ll_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩऌ") in config:
    if bstack11l11ll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡏࡣࡰࡩࠬऍ") in config[bstack11l11ll_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠫऎ")][index]:
      caps[bstack11l11ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡑࡥࡲ࡫ࠧए")] = config[bstack11l11ll_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱࡸ࠭ऐ")][index][bstack11l11ll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡓࡧ࡭ࡦࠩऑ")]
    if bstack11l11ll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷ࡜ࡥࡳࡵ࡬ࡳࡳ࠭ऒ") in config[bstack11l11ll_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩओ")][index]:
      caps[bstack11l11ll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡗࡧࡵࡷ࡮ࡵ࡮ࠨऔ")] = str(config[bstack11l11ll_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠫक")][index][bstack11l11ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴ࡙ࡩࡷࡹࡩࡰࡰࠪख")])
    bstack11ll11l1l_opy_ = {}
    for bstack11l11l1l1_opy_ in bstack11ll1ll11_opy_:
      if bstack11l11l1l1_opy_ in config[bstack11l11ll_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱࡸ࠭ग")][index]:
        if bstack11l11l1l1_opy_ == bstack11l11ll_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲ࡜ࡥࡳࡵ࡬ࡳࡳ࠭घ"):
          try:
            bstack11ll11l1l_opy_[bstack11l11l1l1_opy_] = str(config[bstack11l11ll_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡳࠨङ")][index][bstack11l11l1l1_opy_] * 1.0)
          except:
            bstack11ll11l1l_opy_[bstack11l11l1l1_opy_] = str(config[bstack11l11ll_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩच")][index][bstack11l11l1l1_opy_])
        else:
          bstack11ll11l1l_opy_[bstack11l11l1l1_opy_] = config[bstack11l11ll_opy_ (u"ࠧࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡵࠪछ")][index][bstack11l11l1l1_opy_]
        del (config[bstack11l11ll_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠫज")][index][bstack11l11l1l1_opy_])
    bstack1ll1l1llll_opy_ = update(bstack1ll1l1llll_opy_, bstack11ll11l1l_opy_)
  bstack1lllllll1_opy_ = bstack1l1111l1_opy_(config, index)
  for bstack1l1l11111_opy_ in bstack1ll11l11ll_opy_ + [bstack11l11ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡑࡥࡲ࡫ࠧझ"), bstack11l11ll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵ࡚ࡪࡸࡳࡪࡱࡱࠫञ")]:
    if bstack1l1l11111_opy_ in bstack1lllllll1_opy_:
      bstack1ll1l1llll_opy_[bstack1l1l11111_opy_] = bstack1lllllll1_opy_[bstack1l1l11111_opy_]
      del (bstack1lllllll1_opy_[bstack1l1l11111_opy_])
  if bstack1l1ll1l1l_opy_(config):
    bstack1lllllll1_opy_[bstack11l11ll_opy_ (u"ࠫࡺࡹࡥࡘ࠵ࡆࠫट")] = True
    caps.update(bstack1ll1l1llll_opy_)
    caps[bstack11l11ll_opy_ (u"ࠬࡨࡳࡵࡣࡦ࡯࠿ࡵࡰࡵ࡫ࡲࡲࡸ࠭ठ")] = bstack1lllllll1_opy_
  else:
    bstack1lllllll1_opy_[bstack11l11ll_opy_ (u"࠭ࡵࡴࡧ࡚࠷ࡈ࠭ड")] = False
    caps.update(bstack1l11l1lll_opy_(bstack1lllllll1_opy_, bstack1ll1l1llll_opy_))
    if bstack11l11ll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡏࡣࡰࡩࠬढ") in caps:
      caps[bstack11l11ll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࠩण")] = caps[bstack11l11ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡑࡥࡲ࡫ࠧत")]
      del (caps[bstack11l11ll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡒࡦࡳࡥࠨथ")])
    if bstack11l11ll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶ࡛࡫ࡲࡴ࡫ࡲࡲࠬद") in caps:
      caps[bstack11l11ll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡥࡶࡦࡴࡶ࡭ࡴࡴࠧध")] = caps[bstack11l11ll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡖࡦࡴࡶ࡭ࡴࡴࠧन")]
      del (caps[bstack11l11ll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡗࡧࡵࡷ࡮ࡵ࡮ࠨऩ")])
  return caps
def bstack1ll1l111l1_opy_():
  global bstack1111l111_opy_
  if bstack1ll1l1lll_opy_() <= version.parse(bstack11l11ll_opy_ (u"ࠨ࠵࠱࠵࠸࠴࠰ࠨप")):
    if bstack1111l111_opy_ != bstack11l11ll_opy_ (u"ࠩࠪफ"):
      return bstack11l11ll_opy_ (u"ࠥ࡬ࡹࡺࡰ࠻࠱࠲ࠦब") + bstack1111l111_opy_ + bstack11l11ll_opy_ (u"ࠦ࠿࠾࠰࠰ࡹࡧ࠳࡭ࡻࡢࠣभ")
    return bstack1ll1lll1l_opy_
  if bstack1111l111_opy_ != bstack11l11ll_opy_ (u"ࠬ࠭म"):
    return bstack11l11ll_opy_ (u"ࠨࡨࡵࡶࡳࡷ࠿࠵࠯ࠣय") + bstack1111l111_opy_ + bstack11l11ll_opy_ (u"ࠢ࠰ࡹࡧ࠳࡭ࡻࡢࠣर")
  return bstack1lllll111l_opy_
def bstack11l1l1ll_opy_(options):
  return hasattr(options, bstack11l11ll_opy_ (u"ࠨࡵࡨࡸࡤࡩࡡࡱࡣࡥ࡭ࡱ࡯ࡴࡺࠩऱ"))
def update(d, u):
  for k, v in u.items():
    if isinstance(v, collections.abc.Mapping):
      d[k] = update(d.get(k, {}), v)
    else:
      if isinstance(v, list):
        d[k] = d.get(k, []) + v
      else:
        d[k] = v
  return d
def bstack111111ll1_opy_(options, bstack1lll1111l_opy_):
  for bstack1l1l111l1_opy_ in bstack1lll1111l_opy_:
    if bstack1l1l111l1_opy_ in [bstack11l11ll_opy_ (u"ࠩࡤࡶ࡬ࡹࠧल"), bstack11l11ll_opy_ (u"ࠪࡩࡽࡺࡥ࡯ࡵ࡬ࡳࡳࡹࠧळ")]:
      continue
    if bstack1l1l111l1_opy_ in options._experimental_options:
      options._experimental_options[bstack1l1l111l1_opy_] = update(options._experimental_options[bstack1l1l111l1_opy_],
                                                         bstack1lll1111l_opy_[bstack1l1l111l1_opy_])
    else:
      options.add_experimental_option(bstack1l1l111l1_opy_, bstack1lll1111l_opy_[bstack1l1l111l1_opy_])
  if bstack11l11ll_opy_ (u"ࠫࡦࡸࡧࡴࠩऴ") in bstack1lll1111l_opy_:
    for arg in bstack1lll1111l_opy_[bstack11l11ll_opy_ (u"ࠬࡧࡲࡨࡵࠪव")]:
      options.add_argument(arg)
    del (bstack1lll1111l_opy_[bstack11l11ll_opy_ (u"࠭ࡡࡳࡩࡶࠫश")])
  if bstack11l11ll_opy_ (u"ࠧࡦࡺࡷࡩࡳࡹࡩࡰࡰࡶࠫष") in bstack1lll1111l_opy_:
    for ext in bstack1lll1111l_opy_[bstack11l11ll_opy_ (u"ࠨࡧࡻࡸࡪࡴࡳࡪࡱࡱࡷࠬस")]:
      options.add_extension(ext)
    del (bstack1lll1111l_opy_[bstack11l11ll_opy_ (u"ࠩࡨࡼࡹ࡫࡮ࡴ࡫ࡲࡲࡸ࠭ह")])
def bstack1l1l1111l_opy_(options, bstack1ll11lll11_opy_):
  if bstack11l11ll_opy_ (u"ࠪࡴࡷ࡫ࡦࡴࠩऺ") in bstack1ll11lll11_opy_:
    for bstack1lll1l11l1_opy_ in bstack1ll11lll11_opy_[bstack11l11ll_opy_ (u"ࠫࡵࡸࡥࡧࡵࠪऻ")]:
      if bstack1lll1l11l1_opy_ in options._preferences:
        options._preferences[bstack1lll1l11l1_opy_] = update(options._preferences[bstack1lll1l11l1_opy_], bstack1ll11lll11_opy_[bstack11l11ll_opy_ (u"ࠬࡶࡲࡦࡨࡶ़ࠫ")][bstack1lll1l11l1_opy_])
      else:
        options.set_preference(bstack1lll1l11l1_opy_, bstack1ll11lll11_opy_[bstack11l11ll_opy_ (u"࠭ࡰࡳࡧࡩࡷࠬऽ")][bstack1lll1l11l1_opy_])
  if bstack11l11ll_opy_ (u"ࠧࡢࡴࡪࡷࠬा") in bstack1ll11lll11_opy_:
    for arg in bstack1ll11lll11_opy_[bstack11l11ll_opy_ (u"ࠨࡣࡵ࡫ࡸ࠭ि")]:
      options.add_argument(arg)
def bstack11l11ll1_opy_(options, bstack1l111ll11_opy_):
  if bstack11l11ll_opy_ (u"ࠩࡺࡩࡧࡼࡩࡦࡹࠪी") in bstack1l111ll11_opy_:
    options.use_webview(bool(bstack1l111ll11_opy_[bstack11l11ll_opy_ (u"ࠪࡻࡪࡨࡶࡪࡧࡺࠫु")]))
  bstack111111ll1_opy_(options, bstack1l111ll11_opy_)
def bstack1llll1l11_opy_(options, bstack111llll11_opy_):
  for bstack1l1l1ll1l_opy_ in bstack111llll11_opy_:
    if bstack1l1l1ll1l_opy_ in [bstack11l11ll_opy_ (u"ࠫࡹ࡫ࡣࡩࡰࡲࡰࡴ࡭ࡹࡑࡴࡨࡺ࡮࡫ࡷࠨू"), bstack11l11ll_opy_ (u"ࠬࡧࡲࡨࡵࠪृ")]:
      continue
    options.set_capability(bstack1l1l1ll1l_opy_, bstack111llll11_opy_[bstack1l1l1ll1l_opy_])
  if bstack11l11ll_opy_ (u"࠭ࡡࡳࡩࡶࠫॄ") in bstack111llll11_opy_:
    for arg in bstack111llll11_opy_[bstack11l11ll_opy_ (u"ࠧࡢࡴࡪࡷࠬॅ")]:
      options.add_argument(arg)
  if bstack11l11ll_opy_ (u"ࠨࡶࡨࡧ࡭ࡴ࡯࡭ࡱࡪࡽࡕࡸࡥࡷ࡫ࡨࡻࠬॆ") in bstack111llll11_opy_:
    options.bstack1l1l1lll_opy_(bool(bstack111llll11_opy_[bstack11l11ll_opy_ (u"ࠩࡷࡩࡨ࡮࡮ࡰ࡮ࡲ࡫ࡾࡖࡲࡦࡸ࡬ࡩࡼ࠭े")]))
def bstack1l1111lll_opy_(options, bstack1l1l1l1ll_opy_):
  for bstack1ll111ll1l_opy_ in bstack1l1l1l1ll_opy_:
    if bstack1ll111ll1l_opy_ in [bstack11l11ll_opy_ (u"ࠪࡥࡩࡪࡩࡵ࡫ࡲࡲࡦࡲࡏࡱࡶ࡬ࡳࡳࡹࠧै"), bstack11l11ll_opy_ (u"ࠫࡦࡸࡧࡴࠩॉ")]:
      continue
    options._options[bstack1ll111ll1l_opy_] = bstack1l1l1l1ll_opy_[bstack1ll111ll1l_opy_]
  if bstack11l11ll_opy_ (u"ࠬࡧࡤࡥ࡫ࡷ࡭ࡴࡴࡡ࡭ࡑࡳࡸ࡮ࡵ࡮ࡴࠩॊ") in bstack1l1l1l1ll_opy_:
    for bstack1l111l1ll_opy_ in bstack1l1l1l1ll_opy_[bstack11l11ll_opy_ (u"࠭ࡡࡥࡦ࡬ࡸ࡮ࡵ࡮ࡢ࡮ࡒࡴࡹ࡯࡯࡯ࡵࠪो")]:
      options.bstack1llllll111_opy_(
        bstack1l111l1ll_opy_, bstack1l1l1l1ll_opy_[bstack11l11ll_opy_ (u"ࠧࡢࡦࡧ࡭ࡹ࡯࡯࡯ࡣ࡯ࡓࡵࡺࡩࡰࡰࡶࠫौ")][bstack1l111l1ll_opy_])
  if bstack11l11ll_opy_ (u"ࠨࡣࡵ࡫ࡸ्࠭") in bstack1l1l1l1ll_opy_:
    for arg in bstack1l1l1l1ll_opy_[bstack11l11ll_opy_ (u"ࠩࡤࡶ࡬ࡹࠧॎ")]:
      options.add_argument(arg)
def bstack11l1l1ll1_opy_(options, caps):
  if not hasattr(options, bstack11l11ll_opy_ (u"ࠪࡏࡊ࡟ࠧॏ")):
    return
  if options.KEY == bstack11l11ll_opy_ (u"ࠫ࡬ࡵ࡯ࡨ࠼ࡦ࡬ࡷࡵ࡭ࡦࡑࡳࡸ࡮ࡵ࡮ࡴࠩॐ") and options.KEY in caps:
    bstack111111ll1_opy_(options, caps[bstack11l11ll_opy_ (u"ࠬ࡭࡯ࡰࡩ࠽ࡧ࡭ࡸ࡯࡮ࡧࡒࡴࡹ࡯࡯࡯ࡵࠪ॑")])
  elif options.KEY == bstack11l11ll_opy_ (u"࠭࡭ࡰࡼ࠽ࡪ࡮ࡸࡥࡧࡱࡻࡓࡵࡺࡩࡰࡰࡶ॒ࠫ") and options.KEY in caps:
    bstack1l1l1111l_opy_(options, caps[bstack11l11ll_opy_ (u"ࠧ࡮ࡱࡽ࠾࡫࡯ࡲࡦࡨࡲࡼࡔࡶࡴࡪࡱࡱࡷࠬ॓")])
  elif options.KEY == bstack11l11ll_opy_ (u"ࠨࡵࡤࡪࡦࡸࡩ࠯ࡱࡳࡸ࡮ࡵ࡮ࡴࠩ॔") and options.KEY in caps:
    bstack1llll1l11_opy_(options, caps[bstack11l11ll_opy_ (u"ࠩࡶࡥ࡫ࡧࡲࡪ࠰ࡲࡴࡹ࡯࡯࡯ࡵࠪॕ")])
  elif options.KEY == bstack11l11ll_opy_ (u"ࠪࡱࡸࡀࡥࡥࡩࡨࡓࡵࡺࡩࡰࡰࡶࠫॖ") and options.KEY in caps:
    bstack11l11ll1_opy_(options, caps[bstack11l11ll_opy_ (u"ࠫࡲࡹ࠺ࡦࡦࡪࡩࡔࡶࡴࡪࡱࡱࡷࠬॗ")])
  elif options.KEY == bstack11l11ll_opy_ (u"ࠬࡹࡥ࠻࡫ࡨࡓࡵࡺࡩࡰࡰࡶࠫक़") and options.KEY in caps:
    bstack1l1111lll_opy_(options, caps[bstack11l11ll_opy_ (u"࠭ࡳࡦ࠼࡬ࡩࡔࡶࡴࡪࡱࡱࡷࠬख़")])
def bstack11lll11l_opy_(caps):
  global bstack11lll11l1_opy_
  if isinstance(os.environ.get(bstack11l11ll_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡉࡔࡡࡄࡔࡕࡥࡁࡖࡖࡒࡑࡆ࡚ࡅࠨग़")), str):
    bstack11lll11l1_opy_ = eval(os.getenv(bstack11l11ll_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡊࡕࡢࡅࡕࡖ࡟ࡂࡗࡗࡓࡒࡇࡔࡆࠩज़")))
  if bstack11lll11l1_opy_:
    if bstack1l1l1llll_opy_() < version.parse(bstack11l11ll_opy_ (u"ࠩ࠵࠲࠸࠴࠰ࠨड़")):
      return None
    else:
      from appium.options.common.base import AppiumOptions
      options = AppiumOptions().load_capabilities(caps)
      return options
  else:
    browser = bstack11l11ll_opy_ (u"ࠪࡧ࡭ࡸ࡯࡮ࡧࠪढ़")
    if bstack11l11ll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡓࡧ࡭ࡦࠩफ़") in caps:
      browser = caps[bstack11l11ll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡔࡡ࡮ࡧࠪय़")]
    elif bstack11l11ll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࠧॠ") in caps:
      browser = caps[bstack11l11ll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࠨॡ")]
    browser = str(browser).lower()
    if browser == bstack11l11ll_opy_ (u"ࠨ࡫ࡳ࡬ࡴࡴࡥࠨॢ") or browser == bstack11l11ll_opy_ (u"ࠩ࡬ࡴࡦࡪࠧॣ"):
      browser = bstack11l11ll_opy_ (u"ࠪࡷࡦ࡬ࡡࡳ࡫ࠪ।")
    if browser == bstack11l11ll_opy_ (u"ࠫࡸࡧ࡭ࡴࡷࡱ࡫ࠬ॥"):
      browser = bstack11l11ll_opy_ (u"ࠬࡩࡨࡳࡱࡰࡩࠬ०")
    if browser not in [bstack11l11ll_opy_ (u"࠭ࡣࡩࡴࡲࡱࡪ࠭१"), bstack11l11ll_opy_ (u"ࠧࡦࡦࡪࡩࠬ२"), bstack11l11ll_opy_ (u"ࠨ࡫ࡨࠫ३"), bstack11l11ll_opy_ (u"ࠩࡶࡥ࡫ࡧࡲࡪࠩ४"), bstack11l11ll_opy_ (u"ࠪࡪ࡮ࡸࡥࡧࡱࡻࠫ५")]:
      return None
    try:
      package = bstack11l11ll_opy_ (u"ࠫࡸ࡫࡬ࡦࡰ࡬ࡹࡲ࠴ࡷࡦࡤࡧࡶ࡮ࡼࡥࡳ࠰ࡾࢁ࠳ࡵࡰࡵ࡫ࡲࡲࡸ࠭६").format(browser)
      name = bstack11l11ll_opy_ (u"ࠬࡕࡰࡵ࡫ࡲࡲࡸ࠭७")
      browser_options = getattr(__import__(package, fromlist=[name]), name)
      options = browser_options()
      if not bstack11l1l1ll_opy_(options):
        return None
      for bstack1l1l11111_opy_ in caps.keys():
        options.set_capability(bstack1l1l11111_opy_, caps[bstack1l1l11111_opy_])
      bstack11l1l1ll1_opy_(options, caps)
      return options
    except Exception as e:
      logger.debug(str(e))
      return None
def bstack111lll1ll_opy_(options, bstack1l11l111_opy_):
  if not bstack11l1l1ll_opy_(options):
    return
  for bstack1l1l11111_opy_ in bstack1l11l111_opy_.keys():
    if bstack1l1l11111_opy_ in bstack1111llll_opy_:
      continue
    if bstack1l1l11111_opy_ in options._caps and type(options._caps[bstack1l1l11111_opy_]) in [dict, list]:
      options._caps[bstack1l1l11111_opy_] = update(options._caps[bstack1l1l11111_opy_], bstack1l11l111_opy_[bstack1l1l11111_opy_])
    else:
      options.set_capability(bstack1l1l11111_opy_, bstack1l11l111_opy_[bstack1l1l11111_opy_])
  bstack11l1l1ll1_opy_(options, bstack1l11l111_opy_)
  if bstack11l11ll_opy_ (u"࠭࡭ࡰࡼ࠽ࡨࡪࡨࡵࡨࡩࡨࡶࡆࡪࡤࡳࡧࡶࡷࠬ८") in options._caps:
    if options._caps[bstack11l11ll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡏࡣࡰࡩࠬ९")] and options._caps[bstack11l11ll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡐࡤࡱࡪ࠭॰")].lower() != bstack11l11ll_opy_ (u"ࠩࡩ࡭ࡷ࡫ࡦࡰࡺࠪॱ"):
      del options._caps[bstack11l11ll_opy_ (u"ࠪࡱࡴࢀ࠺ࡥࡧࡥࡹ࡬࡭ࡥࡳࡃࡧࡨࡷ࡫ࡳࡴࠩॲ")]
def bstack11l1l11l_opy_(proxy_config):
  if bstack11l11ll_opy_ (u"ࠫ࡭ࡺࡴࡱࡵࡓࡶࡴࡾࡹࠨॳ") in proxy_config:
    proxy_config[bstack11l11ll_opy_ (u"ࠬࡹࡳ࡭ࡒࡵࡳࡽࡿࠧॴ")] = proxy_config[bstack11l11ll_opy_ (u"࠭ࡨࡵࡶࡳࡷࡕࡸ࡯ࡹࡻࠪॵ")]
    del (proxy_config[bstack11l11ll_opy_ (u"ࠧࡩࡶࡷࡴࡸࡖࡲࡰࡺࡼࠫॶ")])
  if bstack11l11ll_opy_ (u"ࠨࡲࡵࡳࡽࡿࡔࡺࡲࡨࠫॷ") in proxy_config and proxy_config[bstack11l11ll_opy_ (u"ࠩࡳࡶࡴࡾࡹࡕࡻࡳࡩࠬॸ")].lower() != bstack11l11ll_opy_ (u"ࠪࡨ࡮ࡸࡥࡤࡶࠪॹ"):
    proxy_config[bstack11l11ll_opy_ (u"ࠫࡵࡸ࡯ࡹࡻࡗࡽࡵ࡫ࠧॺ")] = bstack11l11ll_opy_ (u"ࠬࡳࡡ࡯ࡷࡤࡰࠬॻ")
  if bstack11l11ll_opy_ (u"࠭ࡰࡳࡱࡻࡽࡆࡻࡴࡰࡥࡲࡲ࡫࡯ࡧࡖࡴ࡯ࠫॼ") in proxy_config:
    proxy_config[bstack11l11ll_opy_ (u"ࠧࡱࡴࡲࡼࡾ࡚ࡹࡱࡧࠪॽ")] = bstack11l11ll_opy_ (u"ࠨࡲࡤࡧࠬॾ")
  return proxy_config
def bstack1111l1ll1_opy_(config, proxy):
  from selenium.webdriver.common.proxy import Proxy
  if not bstack11l11ll_opy_ (u"ࠩࡳࡶࡴࡾࡹࠨॿ") in config:
    return proxy
  config[bstack11l11ll_opy_ (u"ࠪࡴࡷࡵࡸࡺࠩঀ")] = bstack11l1l11l_opy_(config[bstack11l11ll_opy_ (u"ࠫࡵࡸ࡯ࡹࡻࠪঁ")])
  if proxy == None:
    proxy = Proxy(config[bstack11l11ll_opy_ (u"ࠬࡶࡲࡰࡺࡼࠫং")])
  return proxy
def bstack1l1lll1l_opy_(self):
  global CONFIG
  global bstack1ll11ll1l_opy_
  try:
    proxy = bstack1lllll1ll1_opy_(CONFIG)
    if proxy:
      if proxy.endswith(bstack11l11ll_opy_ (u"࠭࠮ࡱࡣࡦࠫঃ")):
        proxies = bstack111l1lll_opy_(proxy, bstack1ll1l111l1_opy_())
        if len(proxies) > 0:
          protocol, bstack1ll1ll11l1_opy_ = proxies.popitem()
          if bstack11l11ll_opy_ (u"ࠢ࠻࠱࠲ࠦ঄") in bstack1ll1ll11l1_opy_:
            return bstack1ll1ll11l1_opy_
          else:
            return bstack11l11ll_opy_ (u"ࠣࡪࡷࡸࡵࡀ࠯࠰ࠤঅ") + bstack1ll1ll11l1_opy_
      else:
        return proxy
  except Exception as e:
    logger.error(bstack11l11ll_opy_ (u"ࠤࡈࡶࡷࡵࡲࠡ࡫ࡱࠤࡸ࡫ࡴࡵ࡫ࡱ࡫ࠥࡶࡲࡰࡺࡼࠤࡺࡸ࡬ࠡ࠼ࠣࡿࢂࠨআ").format(str(e)))
  return bstack1ll11ll1l_opy_(self)
def bstack1ll1l1lll1_opy_():
  global CONFIG
  return bstack11ll1ll1_opy_(CONFIG) and bstack1lll11l1l1_opy_() and bstack1ll1l1lll_opy_() >= version.parse(bstack1111l1ll_opy_)
def bstack1ll111l1l_opy_():
  global CONFIG
  return (bstack11l11ll_opy_ (u"ࠪ࡬ࡹࡺࡰࡑࡴࡲࡼࡾ࠭ই") in CONFIG or bstack11l11ll_opy_ (u"ࠫ࡭ࡺࡴࡱࡵࡓࡶࡴࡾࡹࠨঈ") in CONFIG) and bstack111l11lll_opy_()
def bstack1llll111l_opy_(config):
  bstack11l11lll_opy_ = {}
  if bstack11l11ll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷ࡙ࡴࡢࡥ࡮ࡐࡴࡩࡡ࡭ࡑࡳࡸ࡮ࡵ࡮ࡴࠩউ") in config:
    bstack11l11lll_opy_ = config[bstack11l11ll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡓࡵࡣࡦ࡯ࡑࡵࡣࡢ࡮ࡒࡴࡹ࡯࡯࡯ࡵࠪঊ")]
  if bstack11l11ll_opy_ (u"ࠧ࡭ࡱࡦࡥࡱࡕࡰࡵ࡫ࡲࡲࡸ࠭ঋ") in config:
    bstack11l11lll_opy_ = config[bstack11l11ll_opy_ (u"ࠨ࡮ࡲࡧࡦࡲࡏࡱࡶ࡬ࡳࡳࡹࠧঌ")]
  proxy = bstack1lllll1ll1_opy_(config)
  if proxy:
    if proxy.endswith(bstack11l11ll_opy_ (u"ࠩ࠱ࡴࡦࡩࠧ঍")) and os.path.isfile(proxy):
      bstack11l11lll_opy_[bstack11l11ll_opy_ (u"ࠪ࠱ࡵࡧࡣ࠮ࡨ࡬ࡰࡪ࠭঎")] = proxy
    else:
      parsed_url = None
      if proxy.endswith(bstack11l11ll_opy_ (u"ࠫ࠳ࡶࡡࡤࠩএ")):
        proxies = bstack111l11ll_opy_(config, bstack1ll1l111l1_opy_())
        if len(proxies) > 0:
          protocol, bstack1ll1ll11l1_opy_ = proxies.popitem()
          if bstack11l11ll_opy_ (u"ࠧࡀ࠯࠰ࠤঐ") in bstack1ll1ll11l1_opy_:
            parsed_url = urlparse(bstack1ll1ll11l1_opy_)
          else:
            parsed_url = urlparse(protocol + bstack11l11ll_opy_ (u"ࠨ࠺࠰࠱ࠥ঑") + bstack1ll1ll11l1_opy_)
      else:
        parsed_url = urlparse(proxy)
      if parsed_url and parsed_url.hostname: bstack11l11lll_opy_[bstack11l11ll_opy_ (u"ࠧࡱࡴࡲࡼࡾࡎ࡯ࡴࡶࠪ঒")] = str(parsed_url.hostname)
      if parsed_url and parsed_url.port: bstack11l11lll_opy_[bstack11l11ll_opy_ (u"ࠨࡲࡵࡳࡽࡿࡐࡰࡴࡷࠫও")] = str(parsed_url.port)
      if parsed_url and parsed_url.username: bstack11l11lll_opy_[bstack11l11ll_opy_ (u"ࠩࡳࡶࡴࡾࡹࡖࡵࡨࡶࠬঔ")] = str(parsed_url.username)
      if parsed_url and parsed_url.password: bstack11l11lll_opy_[bstack11l11ll_opy_ (u"ࠪࡴࡷࡵࡸࡺࡒࡤࡷࡸ࠭ক")] = str(parsed_url.password)
  return bstack11l11lll_opy_
def bstack11111l1l1_opy_(config):
  if bstack11l11ll_opy_ (u"ࠫࡹ࡫ࡳࡵࡅࡲࡲࡹ࡫ࡸࡵࡑࡳࡸ࡮ࡵ࡮ࡴࠩখ") in config:
    return config[bstack11l11ll_opy_ (u"ࠬࡺࡥࡴࡶࡆࡳࡳࡺࡥࡹࡶࡒࡴࡹ࡯࡯࡯ࡵࠪগ")]
  return {}
def bstack11llll11l_opy_(caps):
  global bstack1ll11llll1_opy_
  if bstack11l11ll_opy_ (u"࠭ࡢࡴࡶࡤࡧࡰࡀ࡯ࡱࡶ࡬ࡳࡳࡹࠧঘ") in caps:
    caps[bstack11l11ll_opy_ (u"ࠧࡣࡵࡷࡥࡨࡱ࠺ࡰࡲࡷ࡭ࡴࡴࡳࠨঙ")][bstack11l11ll_opy_ (u"ࠨ࡮ࡲࡧࡦࡲࠧচ")] = True
    if bstack1ll11llll1_opy_:
      caps[bstack11l11ll_opy_ (u"ࠩࡥࡷࡹࡧࡣ࡬࠼ࡲࡴࡹ࡯࡯࡯ࡵࠪছ")][bstack11l11ll_opy_ (u"ࠪࡰࡴࡩࡡ࡭ࡋࡧࡩࡳࡺࡩࡧ࡫ࡨࡶࠬজ")] = bstack1ll11llll1_opy_
  else:
    caps[bstack11l11ll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭࠱ࡰࡴࡩࡡ࡭ࠩঝ")] = True
    if bstack1ll11llll1_opy_:
      caps[bstack11l11ll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮࠲ࡱࡵࡣࡢ࡮ࡌࡨࡪࡴࡴࡪࡨ࡬ࡩࡷ࠭ঞ")] = bstack1ll11llll1_opy_
def bstack1l111111_opy_():
  global CONFIG
  if bstack11l11ll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡑࡵࡣࡢ࡮ࠪট") in CONFIG and CONFIG[bstack11l11ll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡒ࡯ࡤࡣ࡯ࠫঠ")]:
    bstack11l11lll_opy_ = bstack1llll111l_opy_(CONFIG)
    bstack1ll11l1l1_opy_(CONFIG[bstack11l11ll_opy_ (u"ࠨࡣࡦࡧࡪࡹࡳࡌࡧࡼࠫড")], bstack11l11lll_opy_)
def bstack1ll11l1l1_opy_(key, bstack11l11lll_opy_):
  global bstack1l11ll11_opy_
  logger.info(bstack1ll1ll1ll1_opy_)
  try:
    bstack1l11ll11_opy_ = Local()
    bstack11l1lll11_opy_ = {bstack11l11ll_opy_ (u"ࠩ࡮ࡩࡾ࠭ঢ"): key}
    bstack11l1lll11_opy_.update(bstack11l11lll_opy_)
    logger.debug(bstack1111l1l1_opy_.format(str(bstack11l1lll11_opy_)))
    bstack1l11ll11_opy_.start(**bstack11l1lll11_opy_)
    if bstack1l11ll11_opy_.isRunning():
      logger.info(bstack1lllll1l11_opy_)
  except Exception as e:
    bstack1l1ll1ll_opy_(bstack1l1l11ll_opy_.format(str(e)))
def bstack1lll11111_opy_():
  global bstack1l11ll11_opy_
  if bstack1l11ll11_opy_.isRunning():
    logger.info(bstack1lllll1ll_opy_)
    bstack1l11ll11_opy_.stop()
  bstack1l11ll11_opy_ = None
def bstack11111lll_opy_(bstack1ll1l11l1_opy_=[]):
  global CONFIG
  bstack11l111l11_opy_ = []
  bstack111lllll_opy_ = [bstack11l11ll_opy_ (u"ࠪࡳࡸ࠭ণ"), bstack11l11ll_opy_ (u"ࠫࡴࡹࡖࡦࡴࡶ࡭ࡴࡴࠧত"), bstack11l11ll_opy_ (u"ࠬࡪࡥࡷ࡫ࡦࡩࡓࡧ࡭ࡦࠩথ"), bstack11l11ll_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡗࡧࡵࡷ࡮ࡵ࡮ࠨদ"), bstack11l11ll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡏࡣࡰࡩࠬধ"), bstack11l11ll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡘࡨࡶࡸ࡯࡯࡯ࠩন")]
  try:
    for err in bstack1ll1l11l1_opy_:
      bstack11l111l1l_opy_ = {}
      for k in bstack111lllll_opy_:
        val = CONFIG[bstack11l11ll_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࡷࠬ঩")][int(err[bstack11l11ll_opy_ (u"ࠪ࡭ࡳࡪࡥࡹࠩপ")])].get(k)
        if val:
          bstack11l111l1l_opy_[k] = val
      bstack11l111l1l_opy_[bstack11l11ll_opy_ (u"ࠫࡹ࡫ࡳࡵࡵࠪফ")] = {
        err[bstack11l11ll_opy_ (u"ࠬࡴࡡ࡮ࡧࠪব")]: err[bstack11l11ll_opy_ (u"࠭ࡥࡳࡴࡲࡶࠬভ")]
      }
      bstack11l111l11_opy_.append(bstack11l111l1l_opy_)
  except Exception as e:
    logger.debug(bstack11l11ll_opy_ (u"ࠧࡆࡴࡵࡳࡷࠦࡩ࡯ࠢࡩࡳࡷࡳࡡࡵࡶ࡬ࡲ࡬ࠦࡤࡢࡶࡤࠤ࡫ࡵࡲࠡࡧࡹࡩࡳࡺ࠺ࠡࠩম") + str(e))
  finally:
    return bstack11l111l11_opy_
def bstack11l111ll_opy_():
  global bstack11l1l1111_opy_
  global bstack11lll111_opy_
  global bstack11ll11ll1_opy_
  percy.shutdown()
  if bstack11l1l1111_opy_:
    logger.warning(bstack1ll1l11ll_opy_.format(str(bstack11l1l1111_opy_)))
  else:
    try:
      bstack1ll1l1l1l_opy_ = bstack1ll1llll11_opy_(bstack11l11ll_opy_ (u"ࠨ࠰ࡥࡷࡹࡧࡣ࡬࠯ࡦࡳࡳ࡬ࡩࡨ࠰࡭ࡷࡴࡴࠧয"), logger)
      if bstack1ll1l1l1l_opy_.get(bstack11l11ll_opy_ (u"ࠩࡱࡹࡩ࡭ࡥࡠ࡮ࡲࡧࡦࡲࠧর")) and bstack1ll1l1l1l_opy_.get(bstack11l11ll_opy_ (u"ࠪࡲࡺࡪࡧࡦࡡ࡯ࡳࡨࡧ࡬ࠨ঱")).get(bstack11l11ll_opy_ (u"ࠫ࡭ࡵࡳࡵࡰࡤࡱࡪ࠭ল")):
        logger.warning(bstack1ll1l11ll_opy_.format(str(bstack1ll1l1l1l_opy_[bstack11l11ll_opy_ (u"ࠬࡴࡵࡥࡩࡨࡣࡱࡵࡣࡢ࡮ࠪ঳")][bstack11l11ll_opy_ (u"࠭ࡨࡰࡵࡷࡲࡦࡳࡥࠨ঴")])))
    except Exception as e:
      logger.error(e)
  logger.info(bstack11l1111ll_opy_)
  global bstack1l11ll11_opy_
  if bstack1l11ll11_opy_:
    bstack1lll11111_opy_()
  try:
    for driver in bstack11lll111_opy_:
      driver.quit()
  except Exception as e:
    pass
  logger.info(bstack1l1l11l1_opy_)
  bstack1l1111l11_opy_()
  if len(bstack11ll11ll1_opy_) > 0:
    message = bstack11111lll_opy_(bstack11ll11ll1_opy_)
    bstack1l1111l11_opy_(message)
  else:
    bstack1l1111l11_opy_()
  bstack1ll1ll1l11_opy_(bstack1lll1llll_opy_, logger)
def bstack1l1lll1ll_opy_(self, *args):
  logger.error(bstack1ll1ll1lll_opy_)
  bstack11l111ll_opy_()
  sys.exit(1)
def bstack1l1ll1ll_opy_(err):
  logger.critical(bstack11l1l111_opy_.format(str(err)))
  bstack1l1111l11_opy_(bstack11l1l111_opy_.format(str(err)))
  atexit.unregister(bstack11l111ll_opy_)
  sys.exit(1)
def bstack1ll1l11l11_opy_(error, message):
  logger.critical(str(error))
  logger.critical(message)
  bstack1l1111l11_opy_(message)
  atexit.unregister(bstack11l111ll_opy_)
  sys.exit(1)
def bstack1ll1111ll1_opy_():
  global CONFIG
  global bstack11ll11l1_opy_
  global bstack1ll11ll11l_opy_
  global bstack1l11ll11l_opy_
  CONFIG = bstack111l1llll_opy_()
  bstack1lll1l11ll_opy_()
  bstack1ll111ll11_opy_()
  CONFIG = bstack1l1llllll_opy_(CONFIG)
  update(CONFIG, bstack1ll11ll11l_opy_)
  update(CONFIG, bstack11ll11l1_opy_)
  CONFIG = bstack1ll1l1ll11_opy_(CONFIG)
  bstack1l11ll11l_opy_ = bstack11llllll1_opy_(CONFIG)
  bstack11l1111l_opy_.set_property(bstack11l11ll_opy_ (u"ࠧࡣࡵࡷࡥࡨࡱ࡟ࡴࡧࡶࡷ࡮ࡵ࡮ࠨ঵"), bstack1l11ll11l_opy_)
  if (bstack11l11ll_opy_ (u"ࠨࡤࡸ࡭ࡱࡪࡎࡢ࡯ࡨࠫশ") in CONFIG and bstack11l11ll_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡏࡣࡰࡩࠬষ") in bstack11ll11l1_opy_) or (
          bstack11l11ll_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡐࡤࡱࡪ࠭স") in CONFIG and bstack11l11ll_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡑࡥࡲ࡫ࠧহ") not in bstack1ll11ll11l_opy_):
    if os.getenv(bstack11l11ll_opy_ (u"ࠬࡈࡓࡕࡃࡆࡏࡤࡉࡏࡎࡄࡌࡒࡊࡊ࡟ࡃࡗࡌࡐࡉࡥࡉࡅࠩ঺")):
      CONFIG[bstack11l11ll_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡎࡪࡥ࡯ࡶ࡬ࡪ࡮࡫ࡲࠨ঻")] = os.getenv(bstack11l11ll_opy_ (u"ࠧࡃࡕࡗࡅࡈࡑ࡟ࡄࡑࡐࡆࡎࡔࡅࡅࡡࡅ࡙ࡎࡒࡄࡠࡋࡇ়ࠫ"))
    else:
      bstack1ll11l11l1_opy_()
  elif (bstack11l11ll_opy_ (u"ࠨࡤࡸ࡭ࡱࡪࡎࡢ࡯ࡨࠫঽ") not in CONFIG and bstack11l11ll_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡊࡦࡨࡲࡹ࡯ࡦࡪࡧࡵࠫা") in CONFIG) or (
          bstack11l11ll_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡐࡤࡱࡪ࠭ি") in bstack1ll11ll11l_opy_ and bstack11l11ll_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡑࡥࡲ࡫ࠧী") not in bstack11ll11l1_opy_):
    del (CONFIG[bstack11l11ll_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡍࡩ࡫࡮ࡵ࡫ࡩ࡭ࡪࡸࠧু")])
  if bstack11l11llll_opy_(CONFIG):
    bstack1l1ll1ll_opy_(bstack1ll1l1l1l1_opy_)
  bstack1l1l1ll1_opy_()
  bstack11ll1ll1l_opy_()
  if bstack11lll11l1_opy_:
    CONFIG[bstack11l11ll_opy_ (u"࠭ࡡࡱࡲࠪূ")] = bstack1ll11ll1l1_opy_(CONFIG)
    logger.info(bstack1ll111l11l_opy_.format(CONFIG[bstack11l11ll_opy_ (u"ࠧࡢࡲࡳࠫৃ")]))
def bstack111ll11l1_opy_(config, bstack11l1lllll_opy_):
  global CONFIG
  global bstack11lll11l1_opy_
  CONFIG = config
  bstack11lll11l1_opy_ = bstack11l1lllll_opy_
def bstack11ll1ll1l_opy_():
  global CONFIG
  global bstack11lll11l1_opy_
  if bstack11l11ll_opy_ (u"ࠨࡣࡳࡴࠬৄ") in CONFIG:
    try:
      from appium import version
    except Exception as e:
      bstack1ll1l11l11_opy_(e, bstack1llll11ll1_opy_)
    bstack11lll11l1_opy_ = True
    bstack11l1111l_opy_.set_property(bstack11l11ll_opy_ (u"ࠩࡤࡴࡵࡥࡡࡶࡶࡲࡱࡦࡺࡥࠨ৅"), True)
def bstack1ll11ll1l1_opy_(config):
  bstack1l1l1l1l1_opy_ = bstack11l11ll_opy_ (u"ࠪࠫ৆")
  app = config[bstack11l11ll_opy_ (u"ࠫࡦࡶࡰࠨে")]
  if isinstance(app, str):
    if os.path.splitext(app)[1] in bstack1ll1l11lll_opy_:
      if os.path.exists(app):
        bstack1l1l1l1l1_opy_ = bstack1l111l111_opy_(config, app)
      elif bstack1lll1lllll_opy_(app):
        bstack1l1l1l1l1_opy_ = app
      else:
        bstack1l1ll1ll_opy_(bstack1lll1ll111_opy_.format(app))
    else:
      if bstack1lll1lllll_opy_(app):
        bstack1l1l1l1l1_opy_ = app
      elif os.path.exists(app):
        bstack1l1l1l1l1_opy_ = bstack1l111l111_opy_(app)
      else:
        bstack1l1ll1ll_opy_(bstack1lll1lll1l_opy_)
  else:
    if len(app) > 2:
      bstack1l1ll1ll_opy_(bstack1l1111ll_opy_)
    elif len(app) == 2:
      if bstack11l11ll_opy_ (u"ࠬࡶࡡࡵࡪࠪৈ") in app and bstack11l11ll_opy_ (u"࠭ࡣࡶࡵࡷࡳࡲࡥࡩࡥࠩ৉") in app:
        if os.path.exists(app[bstack11l11ll_opy_ (u"ࠧࡱࡣࡷ࡬ࠬ৊")]):
          bstack1l1l1l1l1_opy_ = bstack1l111l111_opy_(config, app[bstack11l11ll_opy_ (u"ࠨࡲࡤࡸ࡭࠭ো")], app[bstack11l11ll_opy_ (u"ࠩࡦࡹࡸࡺ࡯࡮ࡡ࡬ࡨࠬৌ")])
        else:
          bstack1l1ll1ll_opy_(bstack1lll1ll111_opy_.format(app))
      else:
        bstack1l1ll1ll_opy_(bstack1l1111ll_opy_)
    else:
      for key in app:
        if key in bstack1111l1lll_opy_:
          if key == bstack11l11ll_opy_ (u"ࠪࡴࡦࡺࡨࠨ্"):
            if os.path.exists(app[key]):
              bstack1l1l1l1l1_opy_ = bstack1l111l111_opy_(config, app[key])
            else:
              bstack1l1ll1ll_opy_(bstack1lll1ll111_opy_.format(app))
          else:
            bstack1l1l1l1l1_opy_ = app[key]
        else:
          bstack1l1ll1ll_opy_(bstack1ll11llll_opy_)
  return bstack1l1l1l1l1_opy_
def bstack1lll1lllll_opy_(bstack1l1l1l1l1_opy_):
  import re
  bstack11l1ll1l1_opy_ = re.compile(bstack11l11ll_opy_ (u"ࡶࠧࡤ࡛ࡢ࠯ࡽࡅ࠲ࡠ࠰࠮࠻࡟ࡣ࠳ࡢ࠭࡞ࠬࠧࠦৎ"))
  bstack1l11ll1ll_opy_ = re.compile(bstack11l11ll_opy_ (u"ࡷࠨ࡞࡜ࡣ࠰ࡾࡆ࠳࡚࠱࠯࠼ࡠࡤ࠴࡜࠮࡟࠭࠳ࡠࡧ࠭ࡻࡃ࠰࡞࠵࠳࠹࡝ࡡ࠱ࡠ࠲ࡣࠪࠥࠤ৏"))
  if bstack11l11ll_opy_ (u"࠭ࡢࡴ࠼࠲࠳ࠬ৐") in bstack1l1l1l1l1_opy_ or re.fullmatch(bstack11l1ll1l1_opy_, bstack1l1l1l1l1_opy_) or re.fullmatch(bstack1l11ll1ll_opy_, bstack1l1l1l1l1_opy_):
    return True
  else:
    return False
def bstack1l111l111_opy_(config, path, bstack11l1l111l_opy_=None):
  import requests
  from requests_toolbelt.multipart.encoder import MultipartEncoder
  import hashlib
  md5_hash = hashlib.md5(open(os.path.abspath(path), bstack11l11ll_opy_ (u"ࠧࡳࡤࠪ৑")).read()).hexdigest()
  bstack111l11l1l_opy_ = bstack1l111lll_opy_(md5_hash)
  bstack1l1l1l1l1_opy_ = None
  if bstack111l11l1l_opy_:
    logger.info(bstack1l1ll1lll_opy_.format(bstack111l11l1l_opy_, md5_hash))
    return bstack111l11l1l_opy_
  bstack1111ll11l_opy_ = MultipartEncoder(
    fields={
      bstack11l11ll_opy_ (u"ࠨࡨ࡬ࡰࡪ࠭৒"): (os.path.basename(path), open(os.path.abspath(path), bstack11l11ll_opy_ (u"ࠩࡵࡦࠬ৓")), bstack11l11ll_opy_ (u"ࠪࡸࡪࡾࡴ࠰ࡲ࡯ࡥ࡮ࡴࠧ৔")),
      bstack11l11ll_opy_ (u"ࠫࡨࡻࡳࡵࡱࡰࡣ࡮ࡪࠧ৕"): bstack11l1l111l_opy_
    }
  )
  response = requests.post(bstack11lll1l1l_opy_, data=bstack1111ll11l_opy_,
                           headers={bstack11l11ll_opy_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ৖"): bstack1111ll11l_opy_.content_type},
                           auth=(config[bstack11l11ll_opy_ (u"࠭ࡵࡴࡧࡵࡒࡦࡳࡥࠨৗ")], config[bstack11l11ll_opy_ (u"ࠧࡢࡥࡦࡩࡸࡹࡋࡦࡻࠪ৘")]))
  try:
    res = json.loads(response.text)
    bstack1l1l1l1l1_opy_ = res[bstack11l11ll_opy_ (u"ࠨࡣࡳࡴࡤࡻࡲ࡭ࠩ৙")]
    logger.info(bstack1lll1l1111_opy_.format(bstack1l1l1l1l1_opy_))
    bstack11111ll1_opy_(md5_hash, bstack1l1l1l1l1_opy_)
  except ValueError as err:
    bstack1l1ll1ll_opy_(bstack1ll1ll11l_opy_.format(str(err)))
  return bstack1l1l1l1l1_opy_
def bstack1l1l1ll1_opy_():
  global CONFIG
  global bstack1lll11llll_opy_
  bstack11ll1111l_opy_ = 0
  bstack1l111llll_opy_ = 1
  if bstack11l11ll_opy_ (u"ࠩࡳࡥࡷࡧ࡬࡭ࡧ࡯ࡷࡕ࡫ࡲࡑ࡮ࡤࡸ࡫ࡵࡲ࡮ࠩ৚") in CONFIG:
    bstack1l111llll_opy_ = CONFIG[bstack11l11ll_opy_ (u"ࠪࡴࡦࡸࡡ࡭࡮ࡨࡰࡸࡖࡥࡳࡒ࡯ࡥࡹ࡬࡯ࡳ࡯ࠪ৛")]
  if bstack11l11ll_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡹࠧড়") in CONFIG:
    bstack11ll1111l_opy_ = len(CONFIG[bstack11l11ll_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡳࠨঢ়")])
  bstack1lll11llll_opy_ = int(bstack1l111llll_opy_) * int(bstack11ll1111l_opy_)
def bstack1l111lll_opy_(md5_hash):
  bstack1l111111l_opy_ = os.path.join(os.path.expanduser(bstack11l11ll_opy_ (u"࠭ࡾࠨ৞")), bstack11l11ll_opy_ (u"ࠧ࠯ࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࠧয়"), bstack11l11ll_opy_ (u"ࠨࡣࡳࡴ࡚ࡶ࡬ࡰࡣࡧࡑࡉ࠻ࡈࡢࡵ࡫࠲࡯ࡹ࡯࡯ࠩৠ"))
  if os.path.exists(bstack1l111111l_opy_):
    bstack1ll1lll11_opy_ = json.load(open(bstack1l111111l_opy_, bstack11l11ll_opy_ (u"ࠩࡵࡦࠬৡ")))
    if md5_hash in bstack1ll1lll11_opy_:
      bstack1l1l111l_opy_ = bstack1ll1lll11_opy_[md5_hash]
      bstack1l11l1l1_opy_ = datetime.datetime.now()
      bstack111ll1ll_opy_ = datetime.datetime.strptime(bstack1l1l111l_opy_[bstack11l11ll_opy_ (u"ࠪࡸ࡮ࡳࡥࡴࡶࡤࡱࡵ࠭ৢ")], bstack11l11ll_opy_ (u"ࠫࠪࡪ࠯ࠦ࡯࠲ࠩ࡞ࠦࠥࡉ࠼ࠨࡑ࠿ࠫࡓࠨৣ"))
      if (bstack1l11l1l1_opy_ - bstack111ll1ll_opy_).days > 30:
        return None
      elif version.parse(str(__version__)) > version.parse(bstack1l1l111l_opy_[bstack11l11ll_opy_ (u"ࠬࡹࡤ࡬ࡡࡹࡩࡷࡹࡩࡰࡰࠪ৤")]):
        return None
      return bstack1l1l111l_opy_[bstack11l11ll_opy_ (u"࠭ࡩࡥࠩ৥")]
  else:
    return None
def bstack11111ll1_opy_(md5_hash, bstack1l1l1l1l1_opy_):
  bstack1l11lllll_opy_ = os.path.join(os.path.expanduser(bstack11l11ll_opy_ (u"ࠧࡿࠩ০")), bstack11l11ll_opy_ (u"ࠨ࠰ࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࠨ১"))
  if not os.path.exists(bstack1l11lllll_opy_):
    os.makedirs(bstack1l11lllll_opy_)
  bstack1l111111l_opy_ = os.path.join(os.path.expanduser(bstack11l11ll_opy_ (u"ࠩࢁࠫ২")), bstack11l11ll_opy_ (u"ࠪ࠲ࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࠪ৩"), bstack11l11ll_opy_ (u"ࠫࡦࡶࡰࡖࡲ࡯ࡳࡦࡪࡍࡅ࠷ࡋࡥࡸ࡮࠮࡫ࡵࡲࡲࠬ৪"))
  bstack1ll111lll1_opy_ = {
    bstack11l11ll_opy_ (u"ࠬ࡯ࡤࠨ৫"): bstack1l1l1l1l1_opy_,
    bstack11l11ll_opy_ (u"࠭ࡴࡪ࡯ࡨࡷࡹࡧ࡭ࡱࠩ৬"): datetime.datetime.strftime(datetime.datetime.now(), bstack11l11ll_opy_ (u"ࠧࠦࡦ࠲ࠩࡲ࠵࡚ࠥࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠫ৭")),
    bstack11l11ll_opy_ (u"ࠨࡵࡧ࡯ࡤࡼࡥࡳࡵ࡬ࡳࡳ࠭৮"): str(__version__)
  }
  if os.path.exists(bstack1l111111l_opy_):
    bstack1ll1lll11_opy_ = json.load(open(bstack1l111111l_opy_, bstack11l11ll_opy_ (u"ࠩࡵࡦࠬ৯")))
  else:
    bstack1ll1lll11_opy_ = {}
  bstack1ll1lll11_opy_[md5_hash] = bstack1ll111lll1_opy_
  with open(bstack1l111111l_opy_, bstack11l11ll_opy_ (u"ࠥࡻ࠰ࠨৰ")) as outfile:
    json.dump(bstack1ll1lll11_opy_, outfile)
def bstack11l1llll1_opy_(self):
  return
def bstack11111l11l_opy_(self):
  return
def bstack111ll1l1l_opy_(self):
  from selenium.webdriver.remote.webdriver import WebDriver
  WebDriver.quit(self)
def bstack1l1l1l111_opy_(self):
  global bstack11lllll11_opy_
  global bstack11111l111_opy_
  global bstack1lll1llll1_opy_
  try:
    if bstack11l11ll_opy_ (u"ࠫࡵࡿࡴࡦࡵࡷࠫৱ") in bstack11lllll11_opy_ and self.session_id != None and bstack1ll1llll1l_opy_(threading.current_thread(), bstack11l11ll_opy_ (u"ࠬࡺࡥࡴࡶࡖࡸࡦࡺࡵࡴࠩ৲"), bstack11l11ll_opy_ (u"࠭ࠧ৳")) != bstack11l11ll_opy_ (u"ࠧࡴ࡭࡬ࡴࡵ࡫ࡤࠨ৴"):
      bstack1l11l11l_opy_ = bstack11l11ll_opy_ (u"ࠨࡲࡤࡷࡸ࡫ࡤࠨ৵") if len(threading.current_thread().bstackTestErrorMessages) == 0 else bstack11l11ll_opy_ (u"ࠩࡩࡥ࡮ࡲࡥࡥࠩ৶")
      bstack1lllll1l1l_opy_ = bstack11ll11lll_opy_(bstack11l11ll_opy_ (u"ࠪࡷࡪࡺࡓࡦࡵࡶ࡭ࡴࡴࡓࡵࡣࡷࡹࡸ࠭৷"), bstack11l11ll_opy_ (u"ࠫࠬ৸"), bstack1l11l11l_opy_, bstack11l11ll_opy_ (u"ࠬ࠲ࠠࠨ৹").join(
        threading.current_thread().bstackTestErrorMessages), bstack11l11ll_opy_ (u"࠭ࠧ৺"), bstack11l11ll_opy_ (u"ࠧࠨ৻"))
      if self != None:
        self.execute_script(bstack1lllll1l1l_opy_)
  except Exception as e:
    logger.debug(bstack11l11ll_opy_ (u"ࠣࡇࡵࡶࡴࡸࠠࡸࡪ࡬ࡰࡪࠦ࡭ࡢࡴ࡮࡭ࡳ࡭ࠠࡴࡶࡤࡸࡺࡹ࠺ࠡࠤৼ") + str(e))
  bstack1lll1llll1_opy_(self)
  self.session_id = None
def bstack1ll11lll1l_opy_(self, *args, **kwargs):
  bstack11l11l11l_opy_ = bstack1llll1llll_opy_(self, *args, **kwargs)
  bstack1ll1lll1ll_opy_.bstack11111111l_opy_(self)
  return bstack11l11l11l_opy_
def bstack1ll11l1lll_opy_(self, command_executor,
             desired_capabilities=None, browser_profile=None, proxy=None,
             keep_alive=True, file_detector=None, options=None):
  global CONFIG
  global bstack11111l111_opy_
  global bstack111l11l1_opy_
  global bstack1ll1l1l11l_opy_
  global bstack1ll1ll1ll_opy_
  global bstack11ll1l11_opy_
  global bstack11lllll11_opy_
  global bstack1llll1llll_opy_
  global bstack11lll111_opy_
  global bstack1l1111l1l_opy_
  CONFIG[bstack11l11ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡔࡆࡎࠫ৽")] = str(bstack11lllll11_opy_) + str(__version__)
  command_executor = bstack1ll1l111l1_opy_()
  logger.debug(bstack1lll111ll_opy_.format(command_executor))
  proxy = bstack1111l1ll1_opy_(CONFIG, proxy)
  bstack11lllllll_opy_ = 0 if bstack111l11l1_opy_ < 0 else bstack111l11l1_opy_
  try:
    if bstack1ll1ll1ll_opy_ is True:
      bstack11lllllll_opy_ = int(multiprocessing.current_process().name)
    elif bstack11ll1l11_opy_ is True:
      bstack11lllllll_opy_ = int(threading.current_thread().name)
  except:
    bstack11lllllll_opy_ = 0
  bstack1l11l111_opy_ = bstack111l111l_opy_(CONFIG, bstack11lllllll_opy_)
  logger.debug(bstack1l11l11l1_opy_.format(str(bstack1l11l111_opy_)))
  if bstack11l11ll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡎࡲࡧࡦࡲࠧ৾") in CONFIG and CONFIG[bstack11l11ll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡏࡳࡨࡧ࡬ࠨ৿")]:
    bstack11llll11l_opy_(bstack1l11l111_opy_)
  if desired_capabilities:
    bstack1llll1lll1_opy_ = bstack1l1llllll_opy_(desired_capabilities)
    bstack1llll1lll1_opy_[bstack11l11ll_opy_ (u"ࠬࡻࡳࡦ࡙࠶ࡇࠬ਀")] = bstack1l1ll1l1l_opy_(CONFIG)
    bstack1111llll1_opy_ = bstack111l111l_opy_(bstack1llll1lll1_opy_)
    if bstack1111llll1_opy_:
      bstack1l11l111_opy_ = update(bstack1111llll1_opy_, bstack1l11l111_opy_)
    desired_capabilities = None
  if options:
    bstack111lll1ll_opy_(options, bstack1l11l111_opy_)
  if not options:
    options = bstack11lll11l_opy_(bstack1l11l111_opy_)
  if bstack11lllll1l_opy_.bstack1lllll11l1_opy_(CONFIG, bstack11lllllll_opy_) and bstack11lllll1l_opy_.bstack11l11lll1_opy_(bstack1l11l111_opy_, options):
    bstack11lllll1l_opy_.set_capabilities(bstack1l11l111_opy_, CONFIG)
  if proxy and bstack1ll1l1lll_opy_() >= version.parse(bstack11l11ll_opy_ (u"࠭࠴࠯࠳࠳࠲࠵࠭ਁ")):
    options.proxy(proxy)
  if options and bstack1ll1l1lll_opy_() >= version.parse(bstack11l11ll_opy_ (u"ࠧ࠴࠰࠻࠲࠵࠭ਂ")):
    desired_capabilities = None
  if (
          not options and not desired_capabilities
  ) or (
          bstack1ll1l1lll_opy_() < version.parse(bstack11l11ll_opy_ (u"ࠨ࠵࠱࠼࠳࠶ࠧਃ")) and not desired_capabilities
  ):
    desired_capabilities = {}
    desired_capabilities.update(bstack1l11l111_opy_)
  logger.info(bstack1llll11ll_opy_)
  if bstack1ll1l1lll_opy_() >= version.parse(bstack11l11ll_opy_ (u"ࠩ࠷࠲࠶࠶࠮࠱ࠩ਄")):
    bstack1llll1llll_opy_(self, command_executor=command_executor,
              options=options, keep_alive=keep_alive, file_detector=file_detector)
  elif bstack1ll1l1lll_opy_() >= version.parse(bstack11l11ll_opy_ (u"ࠪ࠷࠳࠾࠮࠱ࠩਅ")):
    bstack1llll1llll_opy_(self, command_executor=command_executor,
              desired_capabilities=desired_capabilities, options=options,
              browser_profile=browser_profile, proxy=proxy,
              keep_alive=keep_alive, file_detector=file_detector)
  elif bstack1ll1l1lll_opy_() >= version.parse(bstack11l11ll_opy_ (u"ࠫ࠷࠴࠵࠴࠰࠳ࠫਆ")):
    bstack1llll1llll_opy_(self, command_executor=command_executor,
              desired_capabilities=desired_capabilities,
              browser_profile=browser_profile, proxy=proxy,
              keep_alive=keep_alive, file_detector=file_detector)
  else:
    bstack1llll1llll_opy_(self, command_executor=command_executor,
              desired_capabilities=desired_capabilities,
              browser_profile=browser_profile, proxy=proxy,
              keep_alive=keep_alive)
  try:
    bstack1ll111ll1_opy_ = bstack11l11ll_opy_ (u"ࠬ࠭ਇ")
    if bstack1ll1l1lll_opy_() >= version.parse(bstack11l11ll_opy_ (u"࠭࠴࠯࠲࠱࠴ࡧ࠷ࠧਈ")):
      bstack1ll111ll1_opy_ = self.caps.get(bstack11l11ll_opy_ (u"ࠢࡰࡲࡷ࡭ࡲࡧ࡬ࡉࡷࡥ࡙ࡷࡲࠢਉ"))
    else:
      bstack1ll111ll1_opy_ = self.capabilities.get(bstack11l11ll_opy_ (u"ࠣࡱࡳࡸ࡮ࡳࡡ࡭ࡊࡸࡦ࡚ࡸ࡬ࠣਊ"))
    if bstack1ll111ll1_opy_:
      if bstack1ll1l1lll_opy_() <= version.parse(bstack11l11ll_opy_ (u"ࠩ࠶࠲࠶࠹࠮࠱ࠩ਋")):
        self.command_executor._url = bstack11l11ll_opy_ (u"ࠥ࡬ࡹࡺࡰ࠻࠱࠲ࠦ਌") + bstack1111l111_opy_ + bstack11l11ll_opy_ (u"ࠦ࠿࠾࠰࠰ࡹࡧ࠳࡭ࡻࡢࠣ਍")
      else:
        self.command_executor._url = bstack11l11ll_opy_ (u"ࠧ࡮ࡴࡵࡲࡶ࠾࠴࠵ࠢ਎") + bstack1ll111ll1_opy_ + bstack11l11ll_opy_ (u"ࠨ࠯ࡸࡦ࠲࡬ࡺࡨࠢਏ")
      logger.debug(bstack11ll1l1l1_opy_.format(bstack1ll111ll1_opy_))
    else:
      logger.debug(bstack1111lllll_opy_.format(bstack11l11ll_opy_ (u"ࠢࡐࡲࡷ࡭ࡲࡧ࡬ࠡࡊࡸࡦࠥࡴ࡯ࡵࠢࡩࡳࡺࡴࡤࠣਐ")))
  except Exception as e:
    logger.debug(bstack1111lllll_opy_.format(e))
  if bstack11l11ll_opy_ (u"ࠨࡴࡲࡦࡴࡺࠧ਑") in bstack11lllll11_opy_:
    bstack1llll1l1ll_opy_(bstack111l11l1_opy_, bstack1l1111l1l_opy_)
  bstack11111l111_opy_ = self.session_id
  if bstack11l11ll_opy_ (u"ࠩࡳࡽࡹ࡫ࡳࡵࠩ਒") in bstack11lllll11_opy_ or bstack11l11ll_opy_ (u"ࠪࡦࡪ࡮ࡡࡷࡧࠪਓ") in bstack11lllll11_opy_:
    threading.current_thread().bstack11l11l1ll_opy_ = self.session_id
    threading.current_thread().bstackSessionDriver = self
    threading.current_thread().bstackTestErrorMessages = []
    bstack1ll1lll1ll_opy_.bstack11111111l_opy_(self)
  bstack11lll111_opy_.append(self)
  if bstack11l11ll_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡹࠧਔ") in CONFIG and bstack11l11ll_opy_ (u"ࠬࡹࡥࡴࡵ࡬ࡳࡳࡔࡡ࡮ࡧࠪਕ") in CONFIG[bstack11l11ll_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩਖ")][bstack11lllllll_opy_]:
    bstack1ll1l1l11l_opy_ = CONFIG[bstack11l11ll_opy_ (u"ࠧࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡵࠪਗ")][bstack11lllllll_opy_][bstack11l11ll_opy_ (u"ࠨࡵࡨࡷࡸ࡯࡯࡯ࡐࡤࡱࡪ࠭ਘ")]
  logger.debug(bstack1lll111111_opy_.format(bstack11111l111_opy_))
try:
  try:
    import Browser
    from subprocess import Popen
    def bstack111lll1l_opy_(self, args, bufsize=-1, executable=None,
              stdin=None, stdout=None, stderr=None,
              preexec_fn=None, close_fds=True,
              shell=False, cwd=None, env=None, universal_newlines=None,
              startupinfo=None, creationflags=0,
              restore_signals=True, start_new_session=False,
              pass_fds=(), *, user=None, group=None, extra_groups=None,
              encoding=None, errors=None, text=None, umask=-1, pipesize=-1):
      global CONFIG
      global bstack1ll1ll11ll_opy_
      if(bstack11l11ll_opy_ (u"ࠤ࡬ࡲࡩ࡫ࡸ࠯࡬ࡶࠦਙ") in args[1]):
        with open(os.path.join(os.path.expanduser(bstack11l11ll_opy_ (u"ࠪࢂࠬਚ")), bstack11l11ll_opy_ (u"ࠫ࠳ࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࠫਛ"), bstack11l11ll_opy_ (u"ࠬ࠴ࡳࡦࡵࡶ࡭ࡴࡴࡩࡥࡵ࠱ࡸࡽࡺࠧਜ")), bstack11l11ll_opy_ (u"࠭ࡷࠨਝ")) as fp:
          fp.write(bstack11l11ll_opy_ (u"ࠢࠣਞ"))
        if(not os.path.exists(os.path.join(os.path.dirname(args[1]), bstack11l11ll_opy_ (u"ࠣ࡫ࡱࡨࡪࡾ࡟ࡣࡵࡷࡥࡨࡱ࠮࡫ࡵࠥਟ")))):
          with open(args[1], bstack11l11ll_opy_ (u"ࠩࡵࠫਠ")) as f:
            lines = f.readlines()
            index = next((i for i, line in enumerate(lines) if bstack11l11ll_opy_ (u"ࠪࡥࡸࡿ࡮ࡤࠢࡩࡹࡳࡩࡴࡪࡱࡱࠤࡤࡴࡥࡸࡒࡤ࡫ࡪ࠮ࡣࡰࡰࡷࡩࡽࡺࠬࠡࡲࡤ࡫ࡪࠦ࠽ࠡࡸࡲ࡭ࡩࠦ࠰ࠪࠩਡ") in line), None)
            if index is not None:
                lines.insert(index+2, bstack1lllllll11_opy_)
            lines.insert(1, bstack1l1ll1l11_opy_)
            f.seek(0)
            with open(os.path.join(os.path.dirname(args[1]), bstack11l11ll_opy_ (u"ࠦ࡮ࡴࡤࡦࡺࡢࡦࡸࡺࡡࡤ࡭࠱࡮ࡸࠨਢ")), bstack11l11ll_opy_ (u"ࠬࡽࠧਣ")) as bstack1ll1l1l1ll_opy_:
              bstack1ll1l1l1ll_opy_.writelines(lines)
        CONFIG[bstack11l11ll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡘࡊࡋࠨਤ")] = str(bstack11lllll11_opy_) + str(__version__)
        bstack11lllllll_opy_ = 0 if bstack111l11l1_opy_ < 0 else bstack111l11l1_opy_
        try:
          if bstack1ll1ll1ll_opy_ is True:
            bstack11lllllll_opy_ = int(multiprocessing.current_process().name)
          elif bstack11ll1l11_opy_ is True:
            bstack11lllllll_opy_ = int(threading.current_thread().name)
        except:
          bstack11lllllll_opy_ = 0
        CONFIG[bstack11l11ll_opy_ (u"ࠢࡶࡵࡨ࡛࠸ࡉࠢਥ")] = False
        CONFIG[bstack11l11ll_opy_ (u"ࠣ࡫ࡶࡔࡱࡧࡹࡸࡴ࡬࡫࡭ࡺࠢਦ")] = True
        bstack1l11l111_opy_ = bstack111l111l_opy_(CONFIG, bstack11lllllll_opy_)
        logger.debug(bstack1l11l11l1_opy_.format(str(bstack1l11l111_opy_)))
        if CONFIG.get(bstack11l11ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡍࡱࡦࡥࡱ࠭ਧ")):
          bstack11llll11l_opy_(bstack1l11l111_opy_)
        if bstack11l11ll_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱࡸ࠭ਨ") in CONFIG and bstack11l11ll_opy_ (u"ࠫࡸ࡫ࡳࡴ࡫ࡲࡲࡓࡧ࡭ࡦࠩ਩") in CONFIG[bstack11l11ll_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡳࠨਪ")][bstack11lllllll_opy_]:
          bstack1ll1l1l11l_opy_ = CONFIG[bstack11l11ll_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩਫ")][bstack11lllllll_opy_][bstack11l11ll_opy_ (u"ࠧࡴࡧࡶࡷ࡮ࡵ࡮ࡏࡣࡰࡩࠬਬ")]
        args.append(os.path.join(os.path.expanduser(bstack11l11ll_opy_ (u"ࠨࢀࠪਭ")), bstack11l11ll_opy_ (u"ࠩ࠱ࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࠩਮ"), bstack11l11ll_opy_ (u"ࠪ࠲ࡸ࡫ࡳࡴ࡫ࡲࡲ࡮ࡪࡳ࠯ࡶࡻࡸࠬਯ")))
        args.append(str(threading.get_ident()))
        args.append(json.dumps(bstack1l11l111_opy_))
        args[1] = os.path.join(os.path.dirname(args[1]), bstack11l11ll_opy_ (u"ࠦ࡮ࡴࡤࡦࡺࡢࡦࡸࡺࡡࡤ࡭࠱࡮ࡸࠨਰ"))
      bstack1ll1ll11ll_opy_ = True
      return bstack11llll1ll_opy_(self, args, bufsize=bufsize, executable=executable,
                    stdin=stdin, stdout=stdout, stderr=stderr,
                    preexec_fn=preexec_fn, close_fds=close_fds,
                    shell=shell, cwd=cwd, env=env, universal_newlines=universal_newlines,
                    startupinfo=startupinfo, creationflags=creationflags,
                    restore_signals=restore_signals, start_new_session=start_new_session,
                    pass_fds=pass_fds, user=user, group=group, extra_groups=extra_groups,
                    encoding=encoding, errors=errors, text=text, umask=umask, pipesize=pipesize)
  except Exception as e:
    pass
  import playwright._impl._api_structures
  import playwright._impl._helper
  def bstack1lll11l1ll_opy_(self,
        executablePath = None,
        channel = None,
        args = None,
        ignoreDefaultArgs = None,
        handleSIGINT = None,
        handleSIGTERM = None,
        handleSIGHUP = None,
        timeout = None,
        env = None,
        headless = None,
        devtools = None,
        proxy = None,
        downloadsPath = None,
        slowMo = None,
        tracesDir = None,
        chromiumSandbox = None,
        firefoxUserPrefs = None
        ):
    global CONFIG
    global bstack111l11l1_opy_
    global bstack1ll1l1l11l_opy_
    global bstack1ll1ll1ll_opy_
    global bstack11ll1l11_opy_
    global bstack11lllll11_opy_
    CONFIG[bstack11l11ll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡗࡉࡑࠧ਱")] = str(bstack11lllll11_opy_) + str(__version__)
    bstack11lllllll_opy_ = 0 if bstack111l11l1_opy_ < 0 else bstack111l11l1_opy_
    try:
      if bstack1ll1ll1ll_opy_ is True:
        bstack11lllllll_opy_ = int(multiprocessing.current_process().name)
      elif bstack11ll1l11_opy_ is True:
        bstack11lllllll_opy_ = int(threading.current_thread().name)
    except:
      bstack11lllllll_opy_ = 0
    CONFIG[bstack11l11ll_opy_ (u"ࠨࡩࡴࡒ࡯ࡥࡾࡽࡲࡪࡩ࡫ࡸࠧਲ")] = True
    bstack1l11l111_opy_ = bstack111l111l_opy_(CONFIG, bstack11lllllll_opy_)
    logger.debug(bstack1l11l11l1_opy_.format(str(bstack1l11l111_opy_)))
    if CONFIG.get(bstack11l11ll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡒ࡯ࡤࡣ࡯ࠫਲ਼")):
      bstack11llll11l_opy_(bstack1l11l111_opy_)
    if bstack11l11ll_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠫ਴") in CONFIG and bstack11l11ll_opy_ (u"ࠩࡶࡩࡸࡹࡩࡰࡰࡑࡥࡲ࡫ࠧਵ") in CONFIG[bstack11l11ll_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱࡸ࠭ਸ਼")][bstack11lllllll_opy_]:
      bstack1ll1l1l11l_opy_ = CONFIG[bstack11l11ll_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡹࠧ਷")][bstack11lllllll_opy_][bstack11l11ll_opy_ (u"ࠬࡹࡥࡴࡵ࡬ࡳࡳࡔࡡ࡮ࡧࠪਸ")]
    import urllib
    import json
    bstack11ll1111_opy_ = bstack11l11ll_opy_ (u"࠭ࡷࡴࡵ࠽࠳࠴ࡩࡤࡱ࠰ࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫࠯ࡥࡲࡱ࠴ࡶ࡬ࡢࡻࡺࡶ࡮࡭ࡨࡵࡁࡦࡥࡵࡹ࠽ࠨਹ") + urllib.parse.quote(json.dumps(bstack1l11l111_opy_))
    browser = self.connect(bstack11ll1111_opy_)
    return browser
except Exception as e:
    pass
def bstack1ll11ll111_opy_():
    global bstack1ll1ll11ll_opy_
    try:
        from playwright._impl._browser_type import BrowserType
        BrowserType.launch = bstack1lll11l1ll_opy_
        bstack1ll1ll11ll_opy_ = True
    except Exception as e:
        pass
    try:
      import Browser
      from subprocess import Popen
      Popen.__init__ = bstack111lll1l_opy_
      bstack1ll1ll11ll_opy_ = True
    except Exception as e:
      pass
def bstack1l1lllll1_opy_(context, bstack111ll111l_opy_):
  try:
    context.page.evaluate(bstack11l11ll_opy_ (u"ࠢࡠࠢࡀࡂࠥࢁࡽࠣ਺"), bstack11l11ll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࡟ࡦࡺࡨࡧࡺࡺ࡯ࡳ࠼ࠣࡿࠧࡧࡣࡵ࡫ࡲࡲࠧࡀࠠࠣࡵࡨࡸࡘ࡫ࡳࡴ࡫ࡲࡲࡓࡧ࡭ࡦࠤ࠯ࠤࠧࡧࡲࡨࡷࡰࡩࡳࡺࡳࠣ࠼ࠣࡿࠧࡴࡡ࡮ࡧࠥ࠾ࠬ਻")+ json.dumps(bstack111ll111l_opy_) + bstack11l11ll_opy_ (u"ࠤࢀࢁ਼ࠧ"))
  except Exception as e:
    logger.debug(bstack11l11ll_opy_ (u"ࠥࡩࡽࡩࡥࡱࡶ࡬ࡳࡳࠦࡩ࡯ࠢࡳࡰࡦࡿࡷࡳ࡫ࡪ࡬ࡹࠦࡳࡦࡵࡶ࡭ࡴࡴࠠ࡯ࡣࡰࡩࠥࢁࡽࠣ਽"), e)
def bstack1lll111l1_opy_(context, message, level):
  try:
    context.page.evaluate(bstack11l11ll_opy_ (u"ࠦࡤࠦ࠽࠿ࠢࡾࢁࠧਾ"), bstack11l11ll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡣࡪࡾࡥࡤࡷࡷࡳࡷࡀࠠࡼࠤࡤࡧࡹ࡯࡯࡯ࠤ࠽ࠤࠧࡧ࡮࡯ࡱࡷࡥࡹ࡫ࠢ࠭ࠢࠥࡥࡷ࡭ࡵ࡮ࡧࡱࡸࡸࠨ࠺ࠡࡽࠥࡨࡦࡺࡡࠣ࠼ࠪਿ") + json.dumps(message) + bstack11l11ll_opy_ (u"࠭ࠬࠣ࡮ࡨࡺࡪࡲࠢ࠻ࠩੀ") + json.dumps(level) + bstack11l11ll_opy_ (u"ࠧࡾࡿࠪੁ"))
  except Exception as e:
    logger.debug(bstack11l11ll_opy_ (u"ࠣࡧࡻࡧࡪࡶࡴࡪࡱࡱࠤ࡮ࡴࠠࡱ࡮ࡤࡽࡼࡸࡩࡨࡪࡷࠤࡦࡴ࡮ࡰࡶࡤࡸ࡮ࡵ࡮ࠡࡽࢀࠦੂ"), e)
def bstack1l11lll1_opy_(context, status, message = bstack11l11ll_opy_ (u"ࠤࠥ੃")):
  try:
    if(status == bstack11l11ll_opy_ (u"ࠥࡪࡦ࡯࡬ࡦࡦࠥ੄")):
      context.page.evaluate(bstack11l11ll_opy_ (u"ࠦࡤࠦ࠽࠿ࠢࡾࢁࠧ੅"), bstack11l11ll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡣࡪࡾࡥࡤࡷࡷࡳࡷࡀࠠࡼࠤࡤࡧࡹ࡯࡯࡯ࠤ࠽ࠤࠧࡹࡥࡵࡕࡨࡷࡸ࡯࡯࡯ࡕࡷࡥࡹࡻࡳࠣ࠮ࠣࠦࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠢ࠻ࠢࡾࠦࡷ࡫ࡡࡴࡱࡱࠦ࠿࠭੆") + json.dumps(bstack11l11ll_opy_ (u"ࠨࡓࡤࡧࡱࡥࡷ࡯࡯ࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡹ࡬ࡸ࡭ࡀࠠࠣੇ") + str(message)) + bstack11l11ll_opy_ (u"ࠧ࠭ࠤࡶࡸࡦࡺࡵࡴࠤ࠽ࠫੈ") + json.dumps(status) + bstack11l11ll_opy_ (u"ࠣࡿࢀࠦ੉"))
    else:
      context.page.evaluate(bstack11l11ll_opy_ (u"ࠤࡢࠤࡂࡄࠠࡼࡿࠥ੊"), bstack11l11ll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡡࡨࡼࡪࡩࡵࡵࡱࡵ࠾ࠥࢁࠢࡢࡥࡷ࡭ࡴࡴࠢ࠻ࠢࠥࡷࡪࡺࡓࡦࡵࡶ࡭ࡴࡴࡓࡵࡣࡷࡹࡸࠨࠬࠡࠤࡤࡶ࡬ࡻ࡭ࡦࡰࡷࡷࠧࡀࠠࡼࠤࡶࡸࡦࡺࡵࡴࠤ࠽ࠫੋ") + json.dumps(status) + bstack11l11ll_opy_ (u"ࠦࢂࢃࠢੌ"))
  except Exception as e:
    logger.debug(bstack11l11ll_opy_ (u"ࠧ࡫ࡸࡤࡧࡳࡸ࡮ࡵ࡮ࠡ࡫ࡱࠤࡵࡲࡡࡺࡹࡵ࡭࡬࡮ࡴࠡࡵࡨࡸࠥࡹࡥࡴࡵ࡬ࡳࡳࠦࡳࡵࡣࡷࡹࡸࠦࡻࡾࠤ੍"), e)
def bstack1l1lll11l_opy_(self, url):
  global bstack1llll11l1l_opy_
  try:
    bstack1lllll1l1_opy_(url)
  except Exception as err:
    logger.debug(bstack1l1ll1ll1_opy_.format(str(err)))
  try:
    bstack1llll11l1l_opy_(self, url)
  except Exception as e:
    try:
      bstack111l111l1_opy_ = str(e)
      if any(err_msg in bstack111l111l1_opy_ for err_msg in bstack111111ll_opy_):
        bstack1lllll1l1_opy_(url, True)
    except Exception as err:
      logger.debug(bstack1l1ll1ll1_opy_.format(str(err)))
    raise e
def bstack1l11lll11_opy_(self):
  global bstack1ll1lllll1_opy_
  bstack1ll1lllll1_opy_ = self
  return
def bstack1lll1lll1_opy_(self):
  global bstack1ll111llll_opy_
  bstack1ll111llll_opy_ = self
  return
def bstack1l1l1111_opy_(self, test):
  global CONFIG
  global bstack1ll111llll_opy_
  global bstack1ll1lllll1_opy_
  global bstack11111l111_opy_
  global bstack111l1l11_opy_
  global bstack1ll1l1l11l_opy_
  global bstack111ll1l1_opy_
  global bstack1ll11l11l_opy_
  global bstack1ll11l1ll1_opy_
  global bstack11lll111_opy_
  try:
    if not bstack11111l111_opy_:
      with open(os.path.join(os.path.expanduser(bstack11l11ll_opy_ (u"࠭ࡾࠨ੎")), bstack11l11ll_opy_ (u"ࠧ࠯ࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࠧ੏"), bstack11l11ll_opy_ (u"ࠨ࠰ࡶࡩࡸࡹࡩࡰࡰ࡬ࡨࡸ࠴ࡴࡹࡶࠪ੐"))) as f:
        bstack1l111lll1_opy_ = json.loads(bstack11l11ll_opy_ (u"ࠤࡾࠦੑ") + f.read().strip() + bstack11l11ll_opy_ (u"ࠪࠦࡽࠨ࠺ࠡࠤࡼࠦࠬ੒") + bstack11l11ll_opy_ (u"ࠦࢂࠨ੓"))
        bstack11111l111_opy_ = bstack1l111lll1_opy_[str(threading.get_ident())]
  except:
    pass
  if bstack11lll111_opy_:
    for driver in bstack11lll111_opy_:
      if bstack11111l111_opy_ == driver.session_id:
        if test:
          bstack1llllllll1_opy_ = str(test.data)
        if not bstack1llll11l1_opy_ and bstack1llllllll1_opy_:
          bstack11ll1l1l_opy_ = {
            bstack11l11ll_opy_ (u"ࠬࡧࡣࡵ࡫ࡲࡲࠬ੔"): bstack11l11ll_opy_ (u"࠭ࡳࡦࡶࡖࡩࡸࡹࡩࡰࡰࡑࡥࡲ࡫ࠧ੕"),
            bstack11l11ll_opy_ (u"ࠧࡢࡴࡪࡹࡲ࡫࡮ࡵࡵࠪ੖"): {
              bstack11l11ll_opy_ (u"ࠨࡰࡤࡱࡪ࠭੗"): bstack1llllllll1_opy_
            }
          }
          bstack1lll11ll1_opy_ = bstack11l11ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡠࡧࡻࡩࡨࡻࡴࡰࡴ࠽ࠤࢀࢃࠧ੘").format(json.dumps(bstack11ll1l1l_opy_))
          driver.execute_script(bstack1lll11ll1_opy_)
        if bstack111l1l11_opy_:
          bstack1l1ll1111_opy_ = {
            bstack11l11ll_opy_ (u"ࠪࡥࡨࡺࡩࡰࡰࠪਖ਼"): bstack11l11ll_opy_ (u"ࠫࡦࡴ࡮ࡰࡶࡤࡸࡪ࠭ਗ਼"),
            bstack11l11ll_opy_ (u"ࠬࡧࡲࡨࡷࡰࡩࡳࡺࡳࠨਜ਼"): {
              bstack11l11ll_opy_ (u"࠭ࡤࡢࡶࡤࠫੜ"): bstack1llllllll1_opy_ + bstack11l11ll_opy_ (u"ࠧࠡࡲࡤࡷࡸ࡫ࡤࠢࠩ੝"),
              bstack11l11ll_opy_ (u"ࠨ࡮ࡨࡺࡪࡲࠧਫ਼"): bstack11l11ll_opy_ (u"ࠩ࡬ࡲ࡫ࡵࠧ੟")
            }
          }
          bstack11ll1l1l_opy_ = {
            bstack11l11ll_opy_ (u"ࠪࡥࡨࡺࡩࡰࡰࠪ੠"): bstack11l11ll_opy_ (u"ࠫࡸ࡫ࡴࡔࡧࡶࡷ࡮ࡵ࡮ࡔࡶࡤࡸࡺࡹࠧ੡"),
            bstack11l11ll_opy_ (u"ࠬࡧࡲࡨࡷࡰࡩࡳࡺࡳࠨ੢"): {
              bstack11l11ll_opy_ (u"࠭ࡳࡵࡣࡷࡹࡸ࠭੣"): bstack11l11ll_opy_ (u"ࠧࡱࡣࡶࡷࡪࡪࠧ੤")
            }
          }
          if bstack111l1l11_opy_.status == bstack11l11ll_opy_ (u"ࠨࡒࡄࡗࡘ࠭੥"):
            bstack11l11111_opy_ = bstack11l11ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡠࡧࡻࡩࡨࡻࡴࡰࡴ࠽ࠤࢀࢃࠧ੦").format(json.dumps(bstack1l1ll1111_opy_))
            driver.execute_script(bstack11l11111_opy_)
            bstack1lll11ll1_opy_ = bstack11l11ll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡡࡨࡼࡪࡩࡵࡵࡱࡵ࠾ࠥࢁࡽࠨ੧").format(json.dumps(bstack11ll1l1l_opy_))
            driver.execute_script(bstack1lll11ll1_opy_)
          elif bstack111l1l11_opy_.status == bstack11l11ll_opy_ (u"ࠫࡋࡇࡉࡍࠩ੨"):
            reason = bstack11l11ll_opy_ (u"ࠧࠨ੩")
            bstack11l1l1l1l_opy_ = bstack1llllllll1_opy_ + bstack11l11ll_opy_ (u"࠭ࠠࡧࡣ࡬ࡰࡪࡪࠧ੪")
            if bstack111l1l11_opy_.message:
              reason = str(bstack111l1l11_opy_.message)
              bstack11l1l1l1l_opy_ = bstack11l1l1l1l_opy_ + bstack11l11ll_opy_ (u"ࠧࠡࡹ࡬ࡸ࡭ࠦࡥࡳࡴࡲࡶ࠿ࠦࠧ੫") + reason
            bstack1l1ll1111_opy_[bstack11l11ll_opy_ (u"ࠨࡣࡵ࡫ࡺࡳࡥ࡯ࡶࡶࠫ੬")] = {
              bstack11l11ll_opy_ (u"ࠩ࡯ࡩࡻ࡫࡬ࠨ੭"): bstack11l11ll_opy_ (u"ࠪࡩࡷࡸ࡯ࡳࠩ੮"),
              bstack11l11ll_opy_ (u"ࠫࡩࡧࡴࡢࠩ੯"): bstack11l1l1l1l_opy_
            }
            bstack11ll1l1l_opy_[bstack11l11ll_opy_ (u"ࠬࡧࡲࡨࡷࡰࡩࡳࡺࡳࠨੰ")] = {
              bstack11l11ll_opy_ (u"࠭ࡳࡵࡣࡷࡹࡸ࠭ੱ"): bstack11l11ll_opy_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧੲ"),
              bstack11l11ll_opy_ (u"ࠨࡴࡨࡥࡸࡵ࡮ࠨੳ"): reason
            }
            bstack11l11111_opy_ = bstack11l11ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡠࡧࡻࡩࡨࡻࡴࡰࡴ࠽ࠤࢀࢃࠧੴ").format(json.dumps(bstack1l1ll1111_opy_))
            driver.execute_script(bstack11l11111_opy_)
            bstack1lll11ll1_opy_ = bstack11l11ll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡡࡨࡼࡪࡩࡵࡵࡱࡵ࠾ࠥࢁࡽࠨੵ").format(json.dumps(bstack11ll1l1l_opy_))
            driver.execute_script(bstack1lll11ll1_opy_)
  elif bstack11111l111_opy_:
    try:
      data = {}
      bstack1llllllll1_opy_ = None
      if test:
        bstack1llllllll1_opy_ = str(test.data)
      if not bstack1llll11l1_opy_ and bstack1llllllll1_opy_:
        data[bstack11l11ll_opy_ (u"ࠫࡳࡧ࡭ࡦࠩ੶")] = bstack1llllllll1_opy_
      if bstack111l1l11_opy_:
        if bstack111l1l11_opy_.status == bstack11l11ll_opy_ (u"ࠬࡖࡁࡔࡕࠪ੷"):
          data[bstack11l11ll_opy_ (u"࠭ࡳࡵࡣࡷࡹࡸ࠭੸")] = bstack11l11ll_opy_ (u"ࠧࡱࡣࡶࡷࡪࡪࠧ੹")
        elif bstack111l1l11_opy_.status == bstack11l11ll_opy_ (u"ࠨࡈࡄࡍࡑ࠭੺"):
          data[bstack11l11ll_opy_ (u"ࠩࡶࡸࡦࡺࡵࡴࠩ੻")] = bstack11l11ll_opy_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪ੼")
          if bstack111l1l11_opy_.message:
            data[bstack11l11ll_opy_ (u"ࠫࡷ࡫ࡡࡴࡱࡱࠫ੽")] = str(bstack111l1l11_opy_.message)
      user = CONFIG[bstack11l11ll_opy_ (u"ࠬࡻࡳࡦࡴࡑࡥࡲ࡫ࠧ੾")]
      key = CONFIG[bstack11l11ll_opy_ (u"࠭ࡡࡤࡥࡨࡷࡸࡑࡥࡺࠩ੿")]
      url = bstack11l11ll_opy_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡽࢀ࠾ࢀࢃࡀࡢࡲ࡬࠲ࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭࠱ࡧࡴࡳ࠯ࡢࡷࡷࡳࡲࡧࡴࡦ࠱ࡶࡩࡸࡹࡩࡰࡰࡶ࠳ࢀࢃ࠮࡫ࡵࡲࡲࠬ઀").format(user, key, bstack11111l111_opy_)
      headers = {
        bstack11l11ll_opy_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡷࡽࡵ࡫ࠧઁ"): bstack11l11ll_opy_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯࡫ࡵࡲࡲࠬં"),
      }
      if bool(data):
        requests.put(url, json=data, headers=headers)
    except Exception as e:
      logger.error(bstack1ll111l1ll_opy_.format(str(e)))
  if bstack1ll111llll_opy_:
    bstack1ll11l11l_opy_(bstack1ll111llll_opy_)
  if bstack1ll1lllll1_opy_:
    bstack1ll11l1ll1_opy_(bstack1ll1lllll1_opy_)
  bstack111ll1l1_opy_(self, test)
def bstack1lll11l11l_opy_(self, parent, test, skip_on_failure=None, rpa=False):
  global bstack1llll1l1l_opy_
  bstack1llll1l1l_opy_(self, parent, test, skip_on_failure=skip_on_failure, rpa=rpa)
  global bstack111l1l11_opy_
  bstack111l1l11_opy_ = self._test
def bstack111l1ll1l_opy_():
  global bstack111lll11l_opy_
  try:
    if os.path.exists(bstack111lll11l_opy_):
      os.remove(bstack111lll11l_opy_)
  except Exception as e:
    logger.debug(bstack11l11ll_opy_ (u"ࠪࡉࡷࡸ࡯ࡳࠢ࡬ࡲࠥࡪࡥ࡭ࡧࡷ࡭ࡳ࡭ࠠࡳࡱࡥࡳࡹࠦࡲࡦࡲࡲࡶࡹࠦࡦࡪ࡮ࡨ࠾ࠥ࠭ઃ") + str(e))
def bstack1lll1l1l1_opy_():
  global bstack111lll11l_opy_
  bstack1ll1l1l1l_opy_ = {}
  try:
    if not os.path.isfile(bstack111lll11l_opy_):
      with open(bstack111lll11l_opy_, bstack11l11ll_opy_ (u"ࠫࡼ࠭઄")):
        pass
      with open(bstack111lll11l_opy_, bstack11l11ll_opy_ (u"ࠧࡽࠫࠣઅ")) as outfile:
        json.dump({}, outfile)
    if os.path.exists(bstack111lll11l_opy_):
      bstack1ll1l1l1l_opy_ = json.load(open(bstack111lll11l_opy_, bstack11l11ll_opy_ (u"࠭ࡲࡣࠩઆ")))
  except Exception as e:
    logger.debug(bstack11l11ll_opy_ (u"ࠧࡆࡴࡵࡳࡷࠦࡩ࡯ࠢࡵࡩࡦࡪࡩ࡯ࡩࠣࡶࡴࡨ࡯ࡵࠢࡵࡩࡵࡵࡲࡵࠢࡩ࡭ࡱ࡫࠺ࠡࠩઇ") + str(e))
  finally:
    return bstack1ll1l1l1l_opy_
def bstack1llll1l1ll_opy_(platform_index, item_index):
  global bstack111lll11l_opy_
  try:
    bstack1ll1l1l1l_opy_ = bstack1lll1l1l1_opy_()
    bstack1ll1l1l1l_opy_[item_index] = platform_index
    with open(bstack111lll11l_opy_, bstack11l11ll_opy_ (u"ࠣࡹ࠮ࠦઈ")) as outfile:
      json.dump(bstack1ll1l1l1l_opy_, outfile)
  except Exception as e:
    logger.debug(bstack11l11ll_opy_ (u"ࠩࡈࡶࡷࡵࡲࠡ࡫ࡱࠤࡼࡸࡩࡵ࡫ࡱ࡫ࠥࡺ࡯ࠡࡴࡲࡦࡴࡺࠠࡳࡧࡳࡳࡷࡺࠠࡧ࡫࡯ࡩ࠿ࠦࠧઉ") + str(e))
def bstack1lll111ll1_opy_(bstack11l11l111_opy_):
  global CONFIG
  bstack1ll1llllll_opy_ = bstack11l11ll_opy_ (u"ࠪࠫઊ")
  if not bstack11l11ll_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡹࠧઋ") in CONFIG:
    logger.info(bstack11l11ll_opy_ (u"ࠬࡔ࡯ࠡࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠤࡵࡧࡳࡴࡧࡧࠤࡺࡴࡡࡣ࡮ࡨࠤࡹࡵࠠࡨࡧࡱࡩࡷࡧࡴࡦࠢࡵࡩࡵࡵࡲࡵࠢࡩࡳࡷࠦࡒࡰࡤࡲࡸࠥࡸࡵ࡯ࠩઌ"))
  try:
    platform = CONFIG[bstack11l11ll_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩઍ")][bstack11l11l111_opy_]
    if bstack11l11ll_opy_ (u"ࠧࡰࡵࠪ઎") in platform:
      bstack1ll1llllll_opy_ += str(platform[bstack11l11ll_opy_ (u"ࠨࡱࡶࠫએ")]) + bstack11l11ll_opy_ (u"ࠩ࠯ࠤࠬઐ")
    if bstack11l11ll_opy_ (u"ࠪࡳࡸ࡜ࡥࡳࡵ࡬ࡳࡳ࠭ઑ") in platform:
      bstack1ll1llllll_opy_ += str(platform[bstack11l11ll_opy_ (u"ࠫࡴࡹࡖࡦࡴࡶ࡭ࡴࡴࠧ઒")]) + bstack11l11ll_opy_ (u"ࠬ࠲ࠠࠨઓ")
    if bstack11l11ll_opy_ (u"࠭ࡤࡦࡸ࡬ࡧࡪࡔࡡ࡮ࡧࠪઔ") in platform:
      bstack1ll1llllll_opy_ += str(platform[bstack11l11ll_opy_ (u"ࠧࡥࡧࡹ࡭ࡨ࡫ࡎࡢ࡯ࡨࠫક")]) + bstack11l11ll_opy_ (u"ࠨ࠮ࠣࠫખ")
    if bstack11l11ll_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰ࡚ࡪࡸࡳࡪࡱࡱࠫગ") in platform:
      bstack1ll1llllll_opy_ += str(platform[bstack11l11ll_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱ࡛࡫ࡲࡴ࡫ࡲࡲࠬઘ")]) + bstack11l11ll_opy_ (u"ࠫ࠱ࠦࠧઙ")
    if bstack11l11ll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡔࡡ࡮ࡧࠪચ") in platform:
      bstack1ll1llllll_opy_ += str(platform[bstack11l11ll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡎࡢ࡯ࡨࠫછ")]) + bstack11l11ll_opy_ (u"ࠧ࠭ࠢࠪજ")
    if bstack11l11ll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡘࡨࡶࡸ࡯࡯࡯ࠩઝ") in platform:
      bstack1ll1llllll_opy_ += str(platform[bstack11l11ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴ࡙ࡩࡷࡹࡩࡰࡰࠪઞ")]) + bstack11l11ll_opy_ (u"ࠪ࠰ࠥ࠭ટ")
  except Exception as e:
    logger.debug(bstack11l11ll_opy_ (u"ࠫࡘࡵ࡭ࡦࠢࡨࡶࡷࡵࡲࠡ࡫ࡱࠤ࡬࡫࡮ࡦࡴࡤࡸ࡮ࡴࡧࠡࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࠣࡷࡹࡸࡩ࡯ࡩࠣࡪࡴࡸࠠࡳࡧࡳࡳࡷࡺࠠࡨࡧࡱࡩࡷࡧࡴࡪࡱࡱࠫઠ") + str(e))
  finally:
    if bstack1ll1llllll_opy_[len(bstack1ll1llllll_opy_) - 2:] == bstack11l11ll_opy_ (u"ࠬ࠲ࠠࠨડ"):
      bstack1ll1llllll_opy_ = bstack1ll1llllll_opy_[:-2]
    return bstack1ll1llllll_opy_
def bstack1ll1l1l111_opy_(path, bstack1ll1llllll_opy_):
  try:
    import xml.etree.ElementTree as ET
    bstack11l1l11ll_opy_ = ET.parse(path)
    bstack1lll11lll_opy_ = bstack11l1l11ll_opy_.getroot()
    bstack111ll1l11_opy_ = None
    for suite in bstack1lll11lll_opy_.iter(bstack11l11ll_opy_ (u"࠭ࡳࡶ࡫ࡷࡩࠬઢ")):
      if bstack11l11ll_opy_ (u"ࠧࡴࡱࡸࡶࡨ࡫ࠧણ") in suite.attrib:
        suite.attrib[bstack11l11ll_opy_ (u"ࠨࡰࡤࡱࡪ࠭ત")] += bstack11l11ll_opy_ (u"ࠩࠣࠫથ") + bstack1ll1llllll_opy_
        bstack111ll1l11_opy_ = suite
    bstack1lll11111l_opy_ = None
    for robot in bstack1lll11lll_opy_.iter(bstack11l11ll_opy_ (u"ࠪࡶࡴࡨ࡯ࡵࠩદ")):
      bstack1lll11111l_opy_ = robot
    bstack1111l11ll_opy_ = len(bstack1lll11111l_opy_.findall(bstack11l11ll_opy_ (u"ࠫࡸࡻࡩࡵࡧࠪધ")))
    if bstack1111l11ll_opy_ == 1:
      bstack1lll11111l_opy_.remove(bstack1lll11111l_opy_.findall(bstack11l11ll_opy_ (u"ࠬࡹࡵࡪࡶࡨࠫન"))[0])
      bstack1ll111l11_opy_ = ET.Element(bstack11l11ll_opy_ (u"࠭ࡳࡶ࡫ࡷࡩࠬ઩"), attrib={bstack11l11ll_opy_ (u"ࠧ࡯ࡣࡰࡩࠬપ"): bstack11l11ll_opy_ (u"ࠨࡕࡸ࡭ࡹ࡫ࡳࠨફ"), bstack11l11ll_opy_ (u"ࠩ࡬ࡨࠬબ"): bstack11l11ll_opy_ (u"ࠪࡷ࠵࠭ભ")})
      bstack1lll11111l_opy_.insert(1, bstack1ll111l11_opy_)
      bstack1l111l1l1_opy_ = None
      for suite in bstack1lll11111l_opy_.iter(bstack11l11ll_opy_ (u"ࠫࡸࡻࡩࡵࡧࠪમ")):
        bstack1l111l1l1_opy_ = suite
      bstack1l111l1l1_opy_.append(bstack111ll1l11_opy_)
      bstack1lll1l1l11_opy_ = None
      for status in bstack111ll1l11_opy_.iter(bstack11l11ll_opy_ (u"ࠬࡹࡴࡢࡶࡸࡷࠬય")):
        bstack1lll1l1l11_opy_ = status
      bstack1l111l1l1_opy_.append(bstack1lll1l1l11_opy_)
    bstack11l1l11ll_opy_.write(path)
  except Exception as e:
    logger.debug(bstack11l11ll_opy_ (u"࠭ࡅࡳࡴࡲࡶࠥ࡯࡮ࠡࡲࡤࡶࡸ࡯࡮ࡨࠢࡺ࡬࡮ࡲࡥࠡࡩࡨࡲࡪࡸࡡࡵ࡫ࡱ࡫ࠥࡸ࡯ࡣࡱࡷࠤࡷ࡫ࡰࡰࡴࡷࠫર") + str(e))
def bstack111l1l1l_opy_(outs_dir, pabot_args, options, start_time_string, tests_root_name):
  global bstack1lll11ll11_opy_
  global CONFIG
  if bstack11l11ll_opy_ (u"ࠢࡱࡻࡷ࡬ࡴࡴࡰࡢࡶ࡫ࠦ઱") in options:
    del options[bstack11l11ll_opy_ (u"ࠣࡲࡼࡸ࡭ࡵ࡮ࡱࡣࡷ࡬ࠧલ")]
  bstack1l11111l_opy_ = bstack1lll1l1l1_opy_()
  for bstack1l11l1l1l_opy_ in bstack1l11111l_opy_.keys():
    path = os.path.join(os.getcwd(), bstack11l11ll_opy_ (u"ࠩࡳࡥࡧࡵࡴࡠࡴࡨࡷࡺࡲࡴࡴࠩળ"), str(bstack1l11l1l1l_opy_), bstack11l11ll_opy_ (u"ࠪࡳࡺࡺࡰࡶࡶ࠱ࡼࡲࡲࠧ઴"))
    bstack1ll1l1l111_opy_(path, bstack1lll111ll1_opy_(bstack1l11111l_opy_[bstack1l11l1l1l_opy_]))
  bstack111l1ll1l_opy_()
  return bstack1lll11ll11_opy_(outs_dir, pabot_args, options, start_time_string, tests_root_name)
def bstack11lll1ll_opy_(self, ff_profile_dir):
  global bstack1ll1l1l11_opy_
  if not ff_profile_dir:
    return None
  return bstack1ll1l1l11_opy_(self, ff_profile_dir)
def bstack1lll111l11_opy_(datasources, opts_for_run, outs_dir, pabot_args, suite_group):
  from pabot.pabot import QueueItem
  global CONFIG
  global bstack1ll11llll1_opy_
  bstack1llllll11_opy_ = []
  if bstack11l11ll_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡹࠧવ") in CONFIG:
    bstack1llllll11_opy_ = CONFIG[bstack11l11ll_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡳࠨશ")]
  return [
    QueueItem(
      datasources,
      outs_dir,
      opts_for_run,
      suite,
      pabot_args[bstack11l11ll_opy_ (u"ࠨࡣࡰ࡯ࡰࡥࡳࡪࠢષ")],
      pabot_args[bstack11l11ll_opy_ (u"ࠢࡷࡧࡵࡦࡴࡹࡥࠣસ")],
      argfile,
      pabot_args.get(bstack11l11ll_opy_ (u"ࠣࡪ࡬ࡺࡪࠨહ")),
      pabot_args[bstack11l11ll_opy_ (u"ࠤࡳࡶࡴࡩࡥࡴࡵࡨࡷࠧ઺")],
      platform[0],
      bstack1ll11llll1_opy_
    )
    for suite in suite_group
    for argfile in pabot_args[bstack11l11ll_opy_ (u"ࠥࡥࡷ࡭ࡵ࡮ࡧࡱࡸ࡫࡯࡬ࡦࡵࠥ઻")] or [(bstack11l11ll_opy_ (u"઼ࠦࠧ"), None)]
    for platform in enumerate(bstack1llllll11_opy_)
  ]
def bstack1l11ll111_opy_(self, datasources, outs_dir, options,
                        execution_item, command, verbose, argfile,
                        hive=None, processes=0, platform_index=0, bstack1lllll11l_opy_=bstack11l11ll_opy_ (u"ࠬ࠭ઽ")):
  global bstack1lllll111_opy_
  self.platform_index = platform_index
  self.bstack1llllll11l_opy_ = bstack1lllll11l_opy_
  bstack1lllll111_opy_(self, datasources, outs_dir, options,
                      execution_item, command, verbose, argfile, hive, processes)
def bstack1lllll11ll_opy_(caller_id, datasources, is_last, item, outs_dir):
  global bstack1ll1l111ll_opy_
  global bstack11ll1lll_opy_
  if not bstack11l11ll_opy_ (u"࠭ࡶࡢࡴ࡬ࡥࡧࡲࡥࠨા") in item.options:
    item.options[bstack11l11ll_opy_ (u"ࠧࡷࡣࡵ࡭ࡦࡨ࡬ࡦࠩિ")] = []
  for v in item.options[bstack11l11ll_opy_ (u"ࠨࡸࡤࡶ࡮ࡧࡢ࡭ࡧࠪી")]:
    if bstack11l11ll_opy_ (u"ࠩࡅࡗ࡙ࡇࡃࡌࡒࡏࡅ࡙ࡌࡏࡓࡏࡌࡒࡉࡋࡘࠨુ") in v:
      item.options[bstack11l11ll_opy_ (u"ࠪࡺࡦࡸࡩࡢࡤ࡯ࡩࠬૂ")].remove(v)
    if bstack11l11ll_opy_ (u"ࠫࡇ࡙ࡔࡂࡅࡎࡇࡑࡏࡁࡓࡉࡖࠫૃ") in v:
      item.options[bstack11l11ll_opy_ (u"ࠬࡼࡡࡳ࡫ࡤࡦࡱ࡫ࠧૄ")].remove(v)
  item.options[bstack11l11ll_opy_ (u"࠭ࡶࡢࡴ࡬ࡥࡧࡲࡥࠨૅ")].insert(0, bstack11l11ll_opy_ (u"ࠧࡃࡕࡗࡅࡈࡑࡐࡍࡃࡗࡊࡔࡘࡍࡊࡐࡇࡉ࡝ࡀࡻࡾࠩ૆").format(item.platform_index))
  item.options[bstack11l11ll_opy_ (u"ࠨࡸࡤࡶ࡮ࡧࡢ࡭ࡧࠪે")].insert(0, bstack11l11ll_opy_ (u"ࠩࡅࡗ࡙ࡇࡃࡌࡆࡈࡊࡑࡕࡃࡂࡎࡌࡈࡊࡔࡔࡊࡈࡌࡉࡗࡀࡻࡾࠩૈ").format(item.bstack1llllll11l_opy_))
  if bstack11ll1lll_opy_:
    item.options[bstack11l11ll_opy_ (u"ࠪࡺࡦࡸࡩࡢࡤ࡯ࡩࠬૉ")].insert(0, bstack11l11ll_opy_ (u"ࠫࡇ࡙ࡔࡂࡅࡎࡇࡑࡏࡁࡓࡉࡖ࠾ࢀࢃࠧ૊").format(bstack11ll1lll_opy_))
  return bstack1ll1l111ll_opy_(caller_id, datasources, is_last, item, outs_dir)
def bstack111llllll_opy_(command, item_index):
  global bstack11ll1lll_opy_
  if bstack11ll1lll_opy_:
    command[0] = command[0].replace(bstack11l11ll_opy_ (u"ࠬࡸ࡯ࡣࡱࡷࠫો"), bstack11l11ll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯࠲ࡹࡤ࡬ࠢࡵࡳࡧࡵࡴ࠮࡫ࡱࡸࡪࡸ࡮ࡢ࡮ࠣ࠱࠲ࡨࡳࡵࡣࡦ࡯ࡤ࡯ࡴࡦ࡯ࡢ࡭ࡳࡪࡥࡹࠢࠪૌ") + str(
      item_index) + bstack11l11ll_opy_ (u"્ࠧࠡࠩ") + bstack11ll1lll_opy_, 1)
  else:
    command[0] = command[0].replace(bstack11l11ll_opy_ (u"ࠨࡴࡲࡦࡴࡺࠧ૎"),
                                    bstack11l11ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫࠮ࡵࡧ࡯ࠥࡸ࡯ࡣࡱࡷ࠱࡮ࡴࡴࡦࡴࡱࡥࡱࠦ࠭࠮ࡤࡶࡸࡦࡩ࡫ࡠ࡫ࡷࡩࡲࡥࡩ࡯ࡦࡨࡼࠥ࠭૏") + str(item_index), 1)
def bstack111l11ll1_opy_(command, stderr, stdout, item_name, verbose, pool_id, item_index):
  global bstack111111111_opy_
  bstack111llllll_opy_(command, item_index)
  return bstack111111111_opy_(command, stderr, stdout, item_name, verbose, pool_id, item_index)
def bstack111111l1_opy_(command, stderr, stdout, item_name, verbose, pool_id, item_index, outs_dir):
  global bstack111111111_opy_
  bstack111llllll_opy_(command, item_index)
  return bstack111111111_opy_(command, stderr, stdout, item_name, verbose, pool_id, item_index, outs_dir)
def bstack11111ll11_opy_(command, stderr, stdout, item_name, verbose, pool_id, item_index, outs_dir, process_timeout):
  global bstack111111111_opy_
  bstack111llllll_opy_(command, item_index)
  return bstack111111111_opy_(command, stderr, stdout, item_name, verbose, pool_id, item_index, outs_dir, process_timeout)
def bstack1111l1l1l_opy_(self, runner, quiet=False, capture=True):
  global bstack1l1l11l1l_opy_
  bstack11ll1lll1_opy_ = bstack1l1l11l1l_opy_(self, runner, quiet=False, capture=True)
  if self.exception:
    if not hasattr(runner, bstack11l11ll_opy_ (u"ࠪࡩࡽࡩࡥࡱࡶ࡬ࡳࡳࡥࡡࡳࡴࠪૐ")):
      runner.exception_arr = []
    if not hasattr(runner, bstack11l11ll_opy_ (u"ࠫࡪࡾࡣࡠࡶࡵࡥࡨ࡫ࡢࡢࡥ࡮ࡣࡦࡸࡲࠨ૑")):
      runner.exc_traceback_arr = []
    runner.exception = self.exception
    runner.exc_traceback = self.exc_traceback
    runner.exception_arr.append(self.exception)
    runner.exc_traceback_arr.append(self.exc_traceback)
  return bstack11ll1lll1_opy_
def bstack1l1lll1l1_opy_(self, name, context, *args):
  global bstack1l1lll111_opy_
  if name == bstack11l11ll_opy_ (u"ࠬࡨࡥࡧࡱࡵࡩࡤ࡬ࡥࡢࡶࡸࡶࡪ࠭૒"):
    bstack1l1lll111_opy_(self, name, context, *args)
    try:
      if not bstack1llll11l1_opy_:
        bstack1ll1ll111l_opy_ = threading.current_thread().bstackSessionDriver if bstack1ll1ll1111_opy_(bstack11l11ll_opy_ (u"࠭ࡢࡴࡶࡤࡧࡰ࡙ࡥࡴࡵ࡬ࡳࡳࡊࡲࡪࡸࡨࡶࠬ૓")) else context.browser
        bstack111ll111l_opy_ = str(self.feature.name)
        bstack1l1lllll1_opy_(context, bstack111ll111l_opy_)
        bstack1ll1ll111l_opy_.execute_script(bstack11l11ll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡥࡥࡹࡧࡦࡹࡹࡵࡲ࠻ࠢࡾࠦࡦࡩࡴࡪࡱࡱࠦ࠿ࠦࠢࡴࡧࡷࡗࡪࡹࡳࡪࡱࡱࡒࡦࡳࡥࠣ࠮ࠣࠦࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠢ࠻ࠢࡾࠦࡳࡧ࡭ࡦࠤ࠽ࠤࠬ૔") + json.dumps(bstack111ll111l_opy_) + bstack11l11ll_opy_ (u"ࠨࡿࢀࠫ૕"))
      self.driver_before_scenario = False
    except Exception as e:
      logger.debug(bstack11l11ll_opy_ (u"ࠩࡉࡥ࡮ࡲࡥࡥࠢࡷࡳࠥࡹࡥࡵࠢࡶࡩࡸࡹࡩࡰࡰࠣࡲࡦࡳࡥࠡ࡫ࡱࠤࡧ࡫ࡦࡰࡴࡨࠤ࡫࡫ࡡࡵࡷࡵࡩ࠿ࠦࡻࡾࠩ૖").format(str(e)))
  elif name == bstack11l11ll_opy_ (u"ࠪࡦࡪ࡬࡯ࡳࡧࡢࡷࡨ࡫࡮ࡢࡴ࡬ࡳࠬ૗"):
    bstack1l1lll111_opy_(self, name, context, *args)
    try:
      if not hasattr(self, bstack11l11ll_opy_ (u"ࠫࡩࡸࡩࡷࡧࡵࡣࡧ࡫ࡦࡰࡴࡨࡣࡸࡩࡥ࡯ࡣࡵ࡭ࡴ࠭૘")):
        self.driver_before_scenario = True
      if (not bstack1llll11l1_opy_):
        scenario_name = args[0].name
        feature_name = bstack111ll111l_opy_ = str(self.feature.name)
        bstack111ll111l_opy_ = feature_name + bstack11l11ll_opy_ (u"ࠬࠦ࠭ࠡࠩ૙") + scenario_name
        bstack1ll1ll111l_opy_ = threading.current_thread().bstackSessionDriver if bstack1ll1ll1111_opy_(bstack11l11ll_opy_ (u"࠭ࡢࡴࡶࡤࡧࡰ࡙ࡥࡴࡵ࡬ࡳࡳࡊࡲࡪࡸࡨࡶࠬ૚")) else context.browser
        if self.driver_before_scenario:
          bstack1l1lllll1_opy_(context, bstack111ll111l_opy_)
          bstack1ll1ll111l_opy_.execute_script(bstack11l11ll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡥࡥࡹࡧࡦࡹࡹࡵࡲ࠻ࠢࡾࠦࡦࡩࡴࡪࡱࡱࠦ࠿ࠦࠢࡴࡧࡷࡗࡪࡹࡳࡪࡱࡱࡒࡦࡳࡥࠣ࠮ࠣࠦࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠢ࠻ࠢࡾࠦࡳࡧ࡭ࡦࠤ࠽ࠤࠬ૛") + json.dumps(bstack111ll111l_opy_) + bstack11l11ll_opy_ (u"ࠨࡿࢀࠫ૜"))
    except Exception as e:
      logger.debug(bstack11l11ll_opy_ (u"ࠩࡉࡥ࡮ࡲࡥࡥࠢࡷࡳࠥࡹࡥࡵࠢࡶࡩࡸࡹࡩࡰࡰࠣࡲࡦࡳࡥࠡ࡫ࡱࠤࡧ࡫ࡦࡰࡴࡨࠤࡸࡩࡥ࡯ࡣࡵ࡭ࡴࡀࠠࡼࡿࠪ૝").format(str(e)))
  elif name == bstack11l11ll_opy_ (u"ࠪࡥ࡫ࡺࡥࡳࡡࡶࡧࡪࡴࡡࡳ࡫ࡲࠫ૞"):
    try:
      bstack1ll1ll1l1l_opy_ = args[0].status.name
      bstack1ll1ll111l_opy_ = threading.current_thread().bstackSessionDriver if bstack11l11ll_opy_ (u"ࠫࡧࡹࡴࡢࡥ࡮ࡗࡪࡹࡳࡪࡱࡱࡈࡷ࡯ࡶࡦࡴࠪ૟") in threading.current_thread().__dict__.keys() else context.browser
      if str(bstack1ll1ll1l1l_opy_).lower() == bstack11l11ll_opy_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬૠ"):
        bstack111ll11l_opy_ = bstack11l11ll_opy_ (u"࠭ࠧૡ")
        bstack11l1l1lll_opy_ = bstack11l11ll_opy_ (u"ࠧࠨૢ")
        bstack1ll11ll11_opy_ = bstack11l11ll_opy_ (u"ࠨࠩૣ")
        try:
          import traceback
          bstack111ll11l_opy_ = self.exception.__class__.__name__
          bstack1l1ll11l1_opy_ = traceback.format_tb(self.exc_traceback)
          bstack11l1l1lll_opy_ = bstack11l11ll_opy_ (u"ࠩࠣࠫ૤").join(bstack1l1ll11l1_opy_)
          bstack1ll11ll11_opy_ = bstack1l1ll11l1_opy_[-1]
        except Exception as e:
          logger.debug(bstack1111l11l1_opy_.format(str(e)))
        bstack111ll11l_opy_ += bstack1ll11ll11_opy_
        bstack1lll111l1_opy_(context, json.dumps(str(args[0].name) + bstack11l11ll_opy_ (u"ࠥࠤ࠲ࠦࡆࡢ࡫࡯ࡩࡩࠧ࡜࡯ࠤ૥") + str(bstack11l1l1lll_opy_)),
                            bstack11l11ll_opy_ (u"ࠦࡪࡸࡲࡰࡴࠥ૦"))
        if self.driver_before_scenario:
          bstack1l11lll1_opy_(context, bstack11l11ll_opy_ (u"ࠧ࡬ࡡࡪ࡮ࡨࡨࠧ૧"), bstack111ll11l_opy_)
          bstack1ll1ll111l_opy_.execute_script(bstack11l11ll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡤ࡫ࡸࡦࡥࡸࡸࡴࡸ࠺ࠡࡽࠥࡥࡨࡺࡩࡰࡰࠥ࠾ࠥࠨࡡ࡯ࡰࡲࡸࡦࡺࡥࠣ࠮ࠣࠦࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠢ࠻ࠢࡾࠦࡩࡧࡴࡢࠤ࠽ࠫ૨") + json.dumps(str(args[0].name) + bstack11l11ll_opy_ (u"ࠢࠡ࠯ࠣࡊࡦ࡯࡬ࡦࡦࠤࡠࡳࠨ૩") + str(bstack11l1l1lll_opy_)) + bstack11l11ll_opy_ (u"ࠨ࠮ࠣࠦࡱ࡫ࡶࡦ࡮ࠥ࠾ࠥࠨࡥࡳࡴࡲࡶࠧࢃࡽࠨ૪"))
        if self.driver_before_scenario:
          bstack1ll1ll111l_opy_.execute_script(bstack11l11ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡠࡧࡻࡩࡨࡻࡴࡰࡴ࠽ࠤࢀࠨࡡࡤࡶ࡬ࡳࡳࠨ࠺ࠡࠤࡶࡩࡹ࡙ࡥࡴࡵ࡬ࡳࡳ࡙ࡴࡢࡶࡸࡷࠧ࠲ࠠࠣࡣࡵ࡫ࡺࡳࡥ࡯ࡶࡶࠦ࠿ࠦࡻࠣࡵࡷࡥࡹࡻࡳࠣ࠼ࠥࡪࡦ࡯࡬ࡦࡦࠥ࠰ࠥࠨࡲࡦࡣࡶࡳࡳࠨ࠺ࠡࠩ૫") + json.dumps(bstack11l11ll_opy_ (u"ࠥࡗࡨ࡫࡮ࡢࡴ࡬ࡳࠥ࡬ࡡࡪ࡮ࡨࡨࠥࡽࡩࡵࡪ࠽ࠤࡡࡴࠢ૬") + str(bstack111ll11l_opy_)) + bstack11l11ll_opy_ (u"ࠫࢂࢃࠧ૭"))
      else:
        bstack1lll111l1_opy_(context, bstack11l11ll_opy_ (u"ࠧࡖࡡࡴࡵࡨࡨࠦࠨ૮"), bstack11l11ll_opy_ (u"ࠨࡩ࡯ࡨࡲࠦ૯"))
        if self.driver_before_scenario:
          bstack1l11lll1_opy_(context, bstack11l11ll_opy_ (u"ࠢࡱࡣࡶࡷࡪࡪࠢ૰"))
        bstack1ll1ll111l_opy_.execute_script(bstack11l11ll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࡟ࡦࡺࡨࡧࡺࡺ࡯ࡳ࠼ࠣࡿࠧࡧࡣࡵ࡫ࡲࡲࠧࡀࠠࠣࡣࡱࡲࡴࡺࡡࡵࡧࠥ࠰ࠥࠨࡡࡳࡩࡸࡱࡪࡴࡴࡴࠤ࠽ࠤࢀࠨࡤࡢࡶࡤࠦ࠿࠭૱") + json.dumps(str(args[0].name) + bstack11l11ll_opy_ (u"ࠤࠣ࠱ࠥࡖࡡࡴࡵࡨࡨࠦࠨ૲")) + bstack11l11ll_opy_ (u"ࠪ࠰ࠥࠨ࡬ࡦࡸࡨࡰࠧࡀࠠࠣ࡫ࡱࡪࡴࠨࡽࡾࠩ૳"))
        if self.driver_before_scenario:
          bstack1ll1ll111l_opy_.execute_script(bstack11l11ll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡢࡩࡽ࡫ࡣࡶࡶࡲࡶ࠿ࠦࡻࠣࡣࡦࡸ࡮ࡵ࡮ࠣ࠼ࠣࠦࡸ࡫ࡴࡔࡧࡶࡷ࡮ࡵ࡮ࡔࡶࡤࡸࡺࡹࠢ࠭ࠢࠥࡥࡷ࡭ࡵ࡮ࡧࡱࡸࡸࠨ࠺ࠡࡽࠥࡷࡹࡧࡴࡶࡵࠥ࠾ࠧࡶࡡࡴࡵࡨࡨࠧࢃࡽࠨ૴"))
    except Exception as e:
      logger.debug(bstack11l11ll_opy_ (u"ࠬࡌࡡࡪ࡮ࡨࡨࠥࡺ࡯ࠡ࡯ࡤࡶࡰࠦࡳࡦࡵࡶ࡭ࡴࡴࠠࡴࡶࡤࡸࡺࡹࠠࡪࡰࠣࡥ࡫ࡺࡥࡳࠢࡩࡩࡦࡺࡵࡳࡧ࠽ࠤࢀࢃࠧ૵").format(str(e)))
  elif name == bstack11l11ll_opy_ (u"࠭ࡡࡧࡶࡨࡶࡤ࡬ࡥࡢࡶࡸࡶࡪ࠭૶"):
    try:
      bstack1ll1ll111l_opy_ = threading.current_thread().bstackSessionDriver if bstack1ll1ll1111_opy_(bstack11l11ll_opy_ (u"ࠧࡣࡵࡷࡥࡨࡱࡓࡦࡵࡶ࡭ࡴࡴࡄࡳ࡫ࡹࡩࡷ࠭૷")) else context.browser
      if context.failed is True:
        bstack1llll1l111_opy_ = []
        bstack1ll1lll1l1_opy_ = []
        bstack11ll111ll_opy_ = []
        bstack1l1lllll_opy_ = bstack11l11ll_opy_ (u"ࠨࠩ૸")
        try:
          import traceback
          for exc in self.exception_arr:
            bstack1llll1l111_opy_.append(exc.__class__.__name__)
          for exc_tb in self.exc_traceback_arr:
            bstack1l1ll11l1_opy_ = traceback.format_tb(exc_tb)
            bstack1ll1l11l1l_opy_ = bstack11l11ll_opy_ (u"ࠩࠣࠫૹ").join(bstack1l1ll11l1_opy_)
            bstack1ll1lll1l1_opy_.append(bstack1ll1l11l1l_opy_)
            bstack11ll111ll_opy_.append(bstack1l1ll11l1_opy_[-1])
        except Exception as e:
          logger.debug(bstack1111l11l1_opy_.format(str(e)))
        bstack111ll11l_opy_ = bstack11l11ll_opy_ (u"ࠪࠫૺ")
        for i in range(len(bstack1llll1l111_opy_)):
          bstack111ll11l_opy_ += bstack1llll1l111_opy_[i] + bstack11ll111ll_opy_[i] + bstack11l11ll_opy_ (u"ࠫࡡࡴࠧૻ")
        bstack1l1lllll_opy_ = bstack11l11ll_opy_ (u"ࠬࠦࠧૼ").join(bstack1ll1lll1l1_opy_)
        if not self.driver_before_scenario:
          bstack1lll111l1_opy_(context, bstack1l1lllll_opy_, bstack11l11ll_opy_ (u"ࠨࡥࡳࡴࡲࡶࠧ૽"))
          bstack1l11lll1_opy_(context, bstack11l11ll_opy_ (u"ࠢࡧࡣ࡬ࡰࡪࡪࠢ૾"), bstack111ll11l_opy_)
          bstack1ll1ll111l_opy_.execute_script(bstack11l11ll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࡟ࡦࡺࡨࡧࡺࡺ࡯ࡳ࠼ࠣࡿࠧࡧࡣࡵ࡫ࡲࡲࠧࡀࠠࠣࡣࡱࡲࡴࡺࡡࡵࡧࠥ࠰ࠥࠨࡡࡳࡩࡸࡱࡪࡴࡴࡴࠤ࠽ࠤࢀࠨࡤࡢࡶࡤࠦ࠿࠭૿") + json.dumps(bstack1l1lllll_opy_) + bstack11l11ll_opy_ (u"ࠩ࠯ࠤࠧࡲࡥࡷࡧ࡯ࠦ࠿ࠦࠢࡦࡴࡵࡳࡷࠨࡽࡾࠩ଀"))
          bstack1ll1ll111l_opy_.execute_script(bstack11l11ll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡡࡨࡼࡪࡩࡵࡵࡱࡵ࠾ࠥࢁࠢࡢࡥࡷ࡭ࡴࡴࠢ࠻ࠢࠥࡷࡪࡺࡓࡦࡵࡶ࡭ࡴࡴࡓࡵࡣࡷࡹࡸࠨࠬࠡࠤࡤࡶ࡬ࡻ࡭ࡦࡰࡷࡷࠧࡀࠠࡼࠤࡶࡸࡦࡺࡵࡴࠤ࠽ࠦ࡫ࡧࡩ࡭ࡧࡧࠦ࠱ࠦࠢࡳࡧࡤࡷࡴࡴࠢ࠻ࠢࠪଁ") + json.dumps(bstack11l11ll_opy_ (u"ࠦࡘࡵ࡭ࡦࠢࡶࡧࡪࡴࡡࡳ࡫ࡲࡷࠥ࡬ࡡࡪ࡮ࡨࡨ࠿ࠦ࡜࡯ࠤଂ") + str(bstack111ll11l_opy_)) + bstack11l11ll_opy_ (u"ࠬࢃࡽࠨଃ"))
      else:
        if not self.driver_before_scenario:
          bstack1lll111l1_opy_(context, bstack11l11ll_opy_ (u"ࠨࡆࡦࡣࡷࡹࡷ࡫࠺ࠡࠤ଄") + str(self.feature.name) + bstack11l11ll_opy_ (u"ࠢࠡࡲࡤࡷࡸ࡫ࡤࠢࠤଅ"), bstack11l11ll_opy_ (u"ࠣ࡫ࡱࡪࡴࠨଆ"))
          bstack1l11lll1_opy_(context, bstack11l11ll_opy_ (u"ࠤࡳࡥࡸࡹࡥࡥࠤଇ"))
          bstack1ll1ll111l_opy_.execute_script(bstack11l11ll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡡࡨࡼࡪࡩࡵࡵࡱࡵ࠾ࠥࢁࠢࡢࡥࡷ࡭ࡴࡴࠢ࠻ࠢࠥࡥࡳࡴ࡯ࡵࡣࡷࡩࠧ࠲ࠠࠣࡣࡵ࡫ࡺࡳࡥ࡯ࡶࡶࠦ࠿ࠦࡻࠣࡦࡤࡸࡦࠨ࠺ࠨଈ") + json.dumps(bstack11l11ll_opy_ (u"ࠦࡋ࡫ࡡࡵࡷࡵࡩ࠿ࠦࠢଉ") + str(self.feature.name) + bstack11l11ll_opy_ (u"ࠧࠦࡰࡢࡵࡶࡩࡩࠧࠢଊ")) + bstack11l11ll_opy_ (u"࠭ࠬࠡࠤ࡯ࡩࡻ࡫࡬ࠣ࠼ࠣࠦ࡮ࡴࡦࡰࠤࢀࢁࠬଋ"))
          bstack1ll1ll111l_opy_.execute_script(bstack11l11ll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡥࡥࡹࡧࡦࡹࡹࡵࡲ࠻ࠢࡾࠦࡦࡩࡴࡪࡱࡱࠦ࠿ࠦࠢࡴࡧࡷࡗࡪࡹࡳࡪࡱࡱࡗࡹࡧࡴࡶࡵࠥ࠰ࠥࠨࡡࡳࡩࡸࡱࡪࡴࡴࡴࠤ࠽ࠤࢀࠨࡳࡵࡣࡷࡹࡸࠨ࠺ࠣࡲࡤࡷࡸ࡫ࡤࠣࡿࢀࠫଌ"))
    except Exception as e:
      logger.debug(bstack11l11ll_opy_ (u"ࠨࡈࡤ࡭ࡱ࡫ࡤࠡࡶࡲࠤࡲࡧࡲ࡬ࠢࡶࡩࡸࡹࡩࡰࡰࠣࡷࡹࡧࡴࡶࡵࠣ࡭ࡳࠦࡡࡧࡶࡨࡶࠥ࡬ࡥࡢࡶࡸࡶࡪࡀࠠࡼࡿࠪ଍").format(str(e)))
  else:
    bstack1l1lll111_opy_(self, name, context, *args)
  if name in [bstack11l11ll_opy_ (u"ࠩࡤࡪࡹ࡫ࡲࡠࡨࡨࡥࡹࡻࡲࡦࠩ଎"), bstack11l11ll_opy_ (u"ࠪࡥ࡫ࡺࡥࡳࡡࡶࡧࡪࡴࡡࡳ࡫ࡲࠫଏ")]:
    bstack1l1lll111_opy_(self, name, context, *args)
    if (name == bstack11l11ll_opy_ (u"ࠫࡦ࡬ࡴࡦࡴࡢࡷࡨ࡫࡮ࡢࡴ࡬ࡳࠬଐ") and self.driver_before_scenario) or (
            name == bstack11l11ll_opy_ (u"ࠬࡧࡦࡵࡧࡵࡣ࡫࡫ࡡࡵࡷࡵࡩࠬ଑") and not self.driver_before_scenario):
      try:
        bstack1ll1ll111l_opy_ = threading.current_thread().bstackSessionDriver if bstack1ll1ll1111_opy_(bstack11l11ll_opy_ (u"࠭ࡢࡴࡶࡤࡧࡰ࡙ࡥࡴࡵ࡬ࡳࡳࡊࡲࡪࡸࡨࡶࠬ଒")) else context.browser
        bstack1ll1ll111l_opy_.quit()
      except Exception:
        pass
def bstack1lll1ll1l1_opy_(config, startdir):
  return bstack11l11ll_opy_ (u"ࠢࡥࡴ࡬ࡺࡪࡸ࠺ࠡࡽ࠳ࢁࠧଓ").format(bstack11l11ll_opy_ (u"ࠣࡄࡵࡳࡼࡹࡥࡳࡕࡷࡥࡨࡱࠢଔ"))
notset = Notset()
def bstack1llll111ll_opy_(self, name: str, default=notset, skip: bool = False):
  global bstack11lll111l_opy_
  if str(name).lower() == bstack11l11ll_opy_ (u"ࠩࡧࡶ࡮ࡼࡥࡳࠩକ"):
    return bstack11l11ll_opy_ (u"ࠥࡆࡷࡵࡷࡴࡧࡵࡗࡹࡧࡣ࡬ࠤଖ")
  else:
    return bstack11lll111l_opy_(self, name, default, skip)
def bstack1lll1l111_opy_(item, when):
  global bstack1llll1ll11_opy_
  try:
    bstack1llll1ll11_opy_(item, when)
  except Exception as e:
    pass
def bstack111lllll1_opy_():
  return
def bstack11ll11lll_opy_(type, name, status, reason, bstack1111111l_opy_, bstack11ll1l11l_opy_):
  bstack11ll1l1l_opy_ = {
    bstack11l11ll_opy_ (u"ࠫࡦࡩࡴࡪࡱࡱࠫଗ"): type,
    bstack11l11ll_opy_ (u"ࠬࡧࡲࡨࡷࡰࡩࡳࡺࡳࠨଘ"): {}
  }
  if type == bstack11l11ll_opy_ (u"࠭ࡡ࡯ࡰࡲࡸࡦࡺࡥࠨଙ"):
    bstack11ll1l1l_opy_[bstack11l11ll_opy_ (u"ࠧࡢࡴࡪࡹࡲ࡫࡮ࡵࡵࠪଚ")][bstack11l11ll_opy_ (u"ࠨ࡮ࡨࡺࡪࡲࠧଛ")] = bstack1111111l_opy_
    bstack11ll1l1l_opy_[bstack11l11ll_opy_ (u"ࠩࡤࡶ࡬ࡻ࡭ࡦࡰࡷࡷࠬଜ")][bstack11l11ll_opy_ (u"ࠪࡨࡦࡺࡡࠨଝ")] = json.dumps(str(bstack11ll1l11l_opy_))
  if type == bstack11l11ll_opy_ (u"ࠫࡸ࡫ࡴࡔࡧࡶࡷ࡮ࡵ࡮ࡏࡣࡰࡩࠬଞ"):
    bstack11ll1l1l_opy_[bstack11l11ll_opy_ (u"ࠬࡧࡲࡨࡷࡰࡩࡳࡺࡳࠨଟ")][bstack11l11ll_opy_ (u"࠭࡮ࡢ࡯ࡨࠫଠ")] = name
  if type == bstack11l11ll_opy_ (u"ࠧࡴࡧࡷࡗࡪࡹࡳࡪࡱࡱࡗࡹࡧࡴࡶࡵࠪଡ"):
    bstack11ll1l1l_opy_[bstack11l11ll_opy_ (u"ࠨࡣࡵ࡫ࡺࡳࡥ࡯ࡶࡶࠫଢ")][bstack11l11ll_opy_ (u"ࠩࡶࡸࡦࡺࡵࡴࠩଣ")] = status
    if status == bstack11l11ll_opy_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪତ"):
      bstack11ll1l1l_opy_[bstack11l11ll_opy_ (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧଥ")][bstack11l11ll_opy_ (u"ࠬࡸࡥࡢࡵࡲࡲࠬଦ")] = json.dumps(str(reason))
  bstack1lll11ll1_opy_ = bstack11l11ll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡤ࡫ࡸࡦࡥࡸࡸࡴࡸ࠺ࠡࡽࢀࠫଧ").format(json.dumps(bstack11ll1l1l_opy_))
  return bstack1lll11ll1_opy_
def bstack1ll1llll1_opy_(item, call, rep):
  global bstack1llll11111_opy_
  global bstack11lll111_opy_
  global bstack1llll11l1_opy_
  name = bstack11l11ll_opy_ (u"ࠧࠨନ")
  try:
    if rep.when == bstack11l11ll_opy_ (u"ࠨࡥࡤࡰࡱ࠭଩"):
      bstack11111l111_opy_ = threading.current_thread().bstack11l11l1ll_opy_
      try:
        if not bstack1llll11l1_opy_:
          name = str(rep.nodeid)
          bstack1lllll1l1l_opy_ = bstack11ll11lll_opy_(bstack11l11ll_opy_ (u"ࠩࡶࡩࡹ࡙ࡥࡴࡵ࡬ࡳࡳࡔࡡ࡮ࡧࠪପ"), name, bstack11l11ll_opy_ (u"ࠪࠫଫ"), bstack11l11ll_opy_ (u"ࠫࠬବ"), bstack11l11ll_opy_ (u"ࠬ࠭ଭ"), bstack11l11ll_opy_ (u"࠭ࠧମ"))
          for driver in bstack11lll111_opy_:
            if bstack11111l111_opy_ == driver.session_id:
              driver.execute_script(bstack1lllll1l1l_opy_)
      except Exception as e:
        logger.debug(bstack11l11ll_opy_ (u"ࠧࡆࡴࡵࡳࡷࠦࡩ࡯ࠢࡶࡩࡹࡺࡩ࡯ࡩࠣࡷࡪࡹࡳࡪࡱࡱࡒࡦࡳࡥࠡࡨࡲࡶࠥࡶࡹࡵࡧࡶࡸ࠲ࡨࡤࡥࠢࡶࡩࡸࡹࡩࡰࡰ࠽ࠤࢀࢃࠧଯ").format(str(e)))
      try:
        bstack1lll1l1l1l_opy_(rep.outcome.lower())
        if rep.outcome.lower() != bstack11l11ll_opy_ (u"ࠨࡵ࡮࡭ࡵࡶࡥࡥࠩର"):
          status = bstack11l11ll_opy_ (u"ࠩࡩࡥ࡮ࡲࡥࡥࠩ଱") if rep.outcome.lower() == bstack11l11ll_opy_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪଲ") else bstack11l11ll_opy_ (u"ࠫࡵࡧࡳࡴࡧࡧࠫଳ")
          reason = bstack11l11ll_opy_ (u"ࠬ࠭଴")
          if status == bstack11l11ll_opy_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭ଵ"):
            reason = rep.longrepr.reprcrash.message
            if (not threading.current_thread().bstackTestErrorMessages):
              threading.current_thread().bstackTestErrorMessages = []
            threading.current_thread().bstackTestErrorMessages.append(reason)
          level = bstack11l11ll_opy_ (u"ࠧࡪࡰࡩࡳࠬଶ") if status == bstack11l11ll_opy_ (u"ࠨࡲࡤࡷࡸ࡫ࡤࠨଷ") else bstack11l11ll_opy_ (u"ࠩࡨࡶࡷࡵࡲࠨସ")
          data = name + bstack11l11ll_opy_ (u"ࠪࠤࡵࡧࡳࡴࡧࡧࠥࠬହ") if status == bstack11l11ll_opy_ (u"ࠫࡵࡧࡳࡴࡧࡧࠫ଺") else name + bstack11l11ll_opy_ (u"ࠬࠦࡦࡢ࡫࡯ࡩࡩࠧࠠࠨ଻") + reason
          bstack1ll1l11111_opy_ = bstack11ll11lll_opy_(bstack11l11ll_opy_ (u"࠭ࡡ࡯ࡰࡲࡸࡦࡺࡥࠨ଼"), bstack11l11ll_opy_ (u"ࠧࠨଽ"), bstack11l11ll_opy_ (u"ࠨࠩା"), bstack11l11ll_opy_ (u"ࠩࠪି"), level, data)
          for driver in bstack11lll111_opy_:
            if bstack11111l111_opy_ == driver.session_id:
              driver.execute_script(bstack1ll1l11111_opy_)
      except Exception as e:
        logger.debug(bstack11l11ll_opy_ (u"ࠪࡉࡷࡸ࡯ࡳࠢ࡬ࡲࠥࡹࡥࡵࡶ࡬ࡲ࡬ࠦࡳࡦࡵࡶ࡭ࡴࡴࠠࡤࡱࡱࡸࡪࡾࡴࠡࡨࡲࡶࠥࡶࡹࡵࡧࡶࡸ࠲ࡨࡤࡥࠢࡶࡩࡸࡹࡩࡰࡰ࠽ࠤࢀࢃࠧୀ").format(str(e)))
  except Exception as e:
    logger.debug(bstack11l11ll_opy_ (u"ࠫࡊࡸࡲࡰࡴࠣ࡭ࡳࠦࡧࡦࡶࡷ࡭ࡳ࡭ࠠࡴࡶࡤࡸࡪࠦࡩ࡯ࠢࡳࡽࡹ࡫ࡳࡵ࠯ࡥࡨࡩࠦࡴࡦࡵࡷࠤࡸࡺࡡࡵࡷࡶ࠾ࠥࢁࡽࠨୁ").format(str(e)))
  bstack1llll11111_opy_(item, call, rep)
def bstack1lll1ll1l_opy_(framework_name):
  global bstack11lllll11_opy_
  global bstack1ll1ll11ll_opy_
  global bstack11l11l1l_opy_
  bstack11lllll11_opy_ = framework_name
  logger.info(bstack1ll1l1ll1l_opy_.format(bstack11lllll11_opy_.split(bstack11l11ll_opy_ (u"ࠬ࠳ࠧୂ"))[0]))
  try:
    from selenium import webdriver
    from selenium.webdriver.common.service import Service
    from selenium.webdriver.remote.webdriver import WebDriver
    if bstack1l11ll11l_opy_:
      Service.start = bstack11l1llll1_opy_
      Service.stop = bstack11111l11l_opy_
      webdriver.Remote.get = bstack1l1lll11l_opy_
      WebDriver.close = bstack111ll1l1l_opy_
      WebDriver.quit = bstack1l1l1l111_opy_
      webdriver.Remote.__init__ = bstack1ll11l1lll_opy_
      WebDriver.getAccessibilityResults = getAccessibilityResults
      WebDriver.getAccessibilityResultsSummary = getAccessibilityResultsSummary
    if not bstack1l11ll11l_opy_ and bstack1ll1lll1ll_opy_.on():
      webdriver.Remote.__init__ = bstack1ll11lll1l_opy_
    bstack1ll1ll11ll_opy_ = True
  except Exception as e:
    pass
  bstack1ll11ll111_opy_()
  if not bstack1ll1ll11ll_opy_:
    bstack1ll1l11l11_opy_(bstack11l11ll_opy_ (u"ࠨࡐࡢࡥ࡮ࡥ࡬࡫ࡳࠡࡰࡲࡸࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࠣୃ"), bstack1ll111111_opy_)
  if bstack1ll1l1lll1_opy_():
    try:
      from selenium.webdriver.remote.remote_connection import RemoteConnection
      RemoteConnection._get_proxy_url = bstack1l1lll1l_opy_
    except Exception as e:
      logger.error(bstack1l1l1l11_opy_.format(str(e)))
  if bstack1ll111l1l_opy_():
    bstack1lllllll1l_opy_(CONFIG, logger)
  if (bstack11l11ll_opy_ (u"ࠧࡳࡱࡥࡳࡹ࠭ୄ") in str(framework_name).lower()):
    try:
      from robot import run_cli
      from robot.output import Output
      from robot.running.status import TestStatus
      from pabot.pabot import QueueItem
      from pabot import pabot
      try:
        from SeleniumLibrary.keywords.webdrivertools.webdrivertools import WebDriverCreator
        WebDriverCreator._get_ff_profile = bstack11lll1ll_opy_
        from SeleniumLibrary.keywords.webdrivertools.webdrivertools import WebDriverCache
        WebDriverCache.close = bstack1lll1lll1_opy_
      except Exception as e:
        logger.warn(bstack1l111l1l_opy_ + str(e))
      try:
        from AppiumLibrary.utils.applicationcache import ApplicationCache
        ApplicationCache.close = bstack1l11lll11_opy_
      except Exception as e:
        logger.debug(bstack11l1l1l1_opy_ + str(e))
    except Exception as e:
      bstack1ll1l11l11_opy_(e, bstack1l111l1l_opy_)
    Output.end_test = bstack1l1l1111_opy_
    TestStatus.__init__ = bstack1lll11l11l_opy_
    QueueItem.__init__ = bstack1l11ll111_opy_
    pabot._create_items = bstack1lll111l11_opy_
    try:
      from pabot import __version__ as bstack11l1ll1l_opy_
      if version.parse(bstack11l1ll1l_opy_) >= version.parse(bstack11l11ll_opy_ (u"ࠨ࠴࠱࠵࠺࠴࠰ࠨ୅")):
        pabot._run = bstack11111ll11_opy_
      elif version.parse(bstack11l1ll1l_opy_) >= version.parse(bstack11l11ll_opy_ (u"ࠩ࠵࠲࠶࠹࠮࠱ࠩ୆")):
        pabot._run = bstack111111l1_opy_
      else:
        pabot._run = bstack111l11ll1_opy_
    except Exception as e:
      pabot._run = bstack111l11ll1_opy_
    pabot._create_command_for_execution = bstack1lllll11ll_opy_
    pabot._report_results = bstack111l1l1l_opy_
  if bstack11l11ll_opy_ (u"ࠪࡦࡪ࡮ࡡࡷࡧࠪେ") in str(framework_name).lower():
    try:
      from behave.runner import Runner
      from behave.model import Step
    except Exception as e:
      bstack1ll1l11l11_opy_(e, bstack1l1l11ll1_opy_)
    Runner.run_hook = bstack1l1lll1l1_opy_
    Step.run = bstack1111l1l1l_opy_
  if bstack11l11ll_opy_ (u"ࠫࡵࡿࡴࡦࡵࡷࠫୈ") in str(framework_name).lower():
    if not bstack1l11ll11l_opy_:
      return
    try:
      from pytest_selenium import pytest_selenium
      from _pytest.config import Config
      pytest_selenium.pytest_report_header = bstack1lll1ll1l1_opy_
      from pytest_selenium.drivers import browserstack
      browserstack.pytest_selenium_runtest_makereport = bstack111lllll1_opy_
      Config.getoption = bstack1llll111ll_opy_
    except Exception as e:
      pass
    try:
      from pytest_bdd import reporting
      reporting.runtest_makereport = bstack1ll1llll1_opy_
    except Exception as e:
      pass
def bstack1l111l11_opy_():
  global CONFIG
  if bstack11l11ll_opy_ (u"ࠬࡶࡡࡳࡣ࡯ࡰࡪࡲࡳࡑࡧࡵࡔࡱࡧࡴࡧࡱࡵࡱࠬ୉") in CONFIG and int(CONFIG[bstack11l11ll_opy_ (u"࠭ࡰࡢࡴࡤࡰࡱ࡫࡬ࡴࡒࡨࡶࡕࡲࡡࡵࡨࡲࡶࡲ࠭୊")]) > 1:
    logger.warn(bstack1l1111ll1_opy_)
def bstack1lllll1lll_opy_(arg, bstack1ll111ll_opy_):
  global CONFIG
  global bstack1111l111_opy_
  global bstack11lll11l1_opy_
  global bstack1l11ll11l_opy_
  global bstack11l1111l_opy_
  bstack1111lll11_opy_ = bstack11l11ll_opy_ (u"ࠧࡱࡻࡷࡩࡸࡺࠧୋ")
  if bstack1ll111ll_opy_ and isinstance(bstack1ll111ll_opy_, str):
    bstack1ll111ll_opy_ = eval(bstack1ll111ll_opy_)
  CONFIG = bstack1ll111ll_opy_[bstack11l11ll_opy_ (u"ࠨࡅࡒࡒࡋࡏࡇࠨୌ")]
  bstack1111l111_opy_ = bstack1ll111ll_opy_[bstack11l11ll_opy_ (u"ࠩࡋ࡙ࡇࡥࡕࡓࡎ୍ࠪ")]
  bstack11lll11l1_opy_ = bstack1ll111ll_opy_[bstack11l11ll_opy_ (u"ࠪࡍࡘࡥࡁࡑࡒࡢࡅ࡚࡚ࡏࡎࡃࡗࡉࠬ୎")]
  bstack1l11ll11l_opy_ = bstack1ll111ll_opy_[bstack11l11ll_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡅ࡚࡚ࡏࡎࡃࡗࡍࡔࡔࠧ୏")]
  bstack11l1111l_opy_.set_property(bstack11l11ll_opy_ (u"ࠬࡨࡳࡵࡣࡦ࡯ࡤࡹࡥࡴࡵ࡬ࡳࡳ࠭୐"), bstack1l11ll11l_opy_)
  os.environ[bstack11l11ll_opy_ (u"࠭ࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤࡌࡒࡂࡏࡈ࡛ࡔࡘࡋࠨ୑")] = bstack1111lll11_opy_
  os.environ[bstack11l11ll_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡃࡐࡐࡉࡍࡌ࠭୒")] = json.dumps(CONFIG)
  os.environ[bstack11l11ll_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡉࡗࡅࡣ࡚ࡘࡌࠨ୓")] = bstack1111l111_opy_
  os.environ[bstack11l11ll_opy_ (u"ࠩࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡋࡖࡣࡆࡖࡐࡠࡃࡘࡘࡔࡓࡁࡕࡇࠪ୔")] = str(bstack11lll11l1_opy_)
  os.environ[bstack11l11ll_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡓ࡝࡙ࡋࡓࡕࡡࡓࡐ࡚ࡍࡉࡏࠩ୕")] = str(True)
  if bstack11lll1111_opy_(arg, [bstack11l11ll_opy_ (u"ࠫ࠲ࡴࠧୖ"), bstack11l11ll_opy_ (u"ࠬ࠳࠭࡯ࡷࡰࡴࡷࡵࡣࡦࡵࡶࡩࡸ࠭ୗ")]) != -1:
    os.environ[bstack11l11ll_opy_ (u"࠭ࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤࡖ࡙ࡕࡇࡖࡘࡤࡖࡁࡓࡃࡏࡐࡊࡒࠧ୘")] = str(True)
  if len(sys.argv) <= 1:
    logger.critical(bstack1l111ll1l_opy_)
    return
  bstack1lll1111l1_opy_()
  global bstack1lll11llll_opy_
  global bstack111l11l1_opy_
  global bstack1ll11llll1_opy_
  global bstack11ll1lll_opy_
  global bstack111l111ll_opy_
  global bstack11l11l1l_opy_
  global bstack1ll1ll1ll_opy_
  arg.append(bstack11l11ll_opy_ (u"ࠢ࠮࡙ࠥ୙"))
  arg.append(bstack11l11ll_opy_ (u"ࠣ࡫ࡪࡲࡴࡸࡥ࠻ࡏࡲࡨࡺࡲࡥࠡࡣ࡯ࡶࡪࡧࡤࡺࠢ࡬ࡱࡵࡵࡲࡵࡧࡧ࠾ࡵࡿࡴࡦࡵࡷ࠲ࡕࡿࡴࡦࡵࡷ࡛ࡦࡸ࡮ࡪࡰࡪࠦ୚"))
  arg.append(bstack11l11ll_opy_ (u"ࠤ࠰࡛ࠧ୛"))
  arg.append(bstack11l11ll_opy_ (u"ࠥ࡭࡬ࡴ࡯ࡳࡧ࠽ࡘ࡭࡫ࠠࡩࡱࡲ࡯࡮ࡳࡰ࡭ࠤଡ଼"))
  global bstack1llll1llll_opy_
  global bstack1lll1llll1_opy_
  global bstack1llll1l1l_opy_
  global bstack1ll1l1l11_opy_
  global bstack1lllll111_opy_
  global bstack1ll1l111ll_opy_
  global bstack1111ll11_opy_
  global bstack1llll11l1l_opy_
  global bstack1ll11ll1l_opy_
  global bstack11lll111l_opy_
  global bstack1llll1ll11_opy_
  global bstack1llll11111_opy_
  try:
    from selenium import webdriver
    from selenium.webdriver.remote.webdriver import WebDriver
    bstack1llll1llll_opy_ = webdriver.Remote.__init__
    bstack1lll1llll1_opy_ = WebDriver.quit
    bstack1111ll11_opy_ = WebDriver.close
    bstack1llll11l1l_opy_ = WebDriver.get
  except Exception as e:
    pass
  if bstack11ll1ll1_opy_(CONFIG) and bstack1lll11l1l1_opy_():
    if bstack1ll1l1lll_opy_() < version.parse(bstack1111l1ll_opy_):
      logger.error(bstack1111111ll_opy_.format(bstack1ll1l1lll_opy_()))
    else:
      try:
        from selenium.webdriver.remote.remote_connection import RemoteConnection
        bstack1ll11ll1l_opy_ = RemoteConnection._get_proxy_url
      except Exception as e:
        logger.error(bstack1l1l1l11_opy_.format(str(e)))
  try:
    from _pytest.config import Config
    bstack11lll111l_opy_ = Config.getoption
    from _pytest import runner
    bstack1llll1ll11_opy_ = runner._update_current_test_var
  except Exception as e:
    logger.warn(e, bstack1ll11l11_opy_)
  try:
    from pytest_bdd import reporting
    bstack1llll11111_opy_ = reporting.runtest_makereport
  except Exception as e:
    logger.debug(bstack11l11ll_opy_ (u"ࠫࡕࡲࡥࡢࡵࡨࠤ࡮ࡴࡳࡵࡣ࡯ࡰࠥࡶࡹࡵࡧࡶࡸ࠲ࡨࡤࡥࠢࡷࡳࠥࡸࡵ࡯ࠢࡳࡽࡹ࡫ࡳࡵ࠯ࡥࡨࡩࠦࡴࡦࡵࡷࡷࠬଢ଼"))
  bstack1ll11llll1_opy_ = CONFIG.get(bstack11l11ll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷ࡙ࡴࡢࡥ࡮ࡐࡴࡩࡡ࡭ࡑࡳࡸ࡮ࡵ࡮ࡴࠩ୞"), {}).get(bstack11l11ll_opy_ (u"࠭࡬ࡰࡥࡤࡰࡎࡪࡥ࡯ࡶ࡬ࡪ࡮࡫ࡲࠨୟ"))
  bstack1ll1ll1ll_opy_ = True
  bstack1lll1ll1l_opy_(bstack1ll1l1l1_opy_)
  os.environ[bstack11l11ll_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡕࡔࡇࡕࡒࡆࡓࡅࠨୠ")] = CONFIG[bstack11l11ll_opy_ (u"ࠨࡷࡶࡩࡷࡔࡡ࡮ࡧࠪୡ")]
  os.environ[bstack11l11ll_opy_ (u"ࠩࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡃࡆࡇࡊ࡙ࡓࡠࡍࡈ࡝ࠬୢ")] = CONFIG[bstack11l11ll_opy_ (u"ࠪࡥࡨࡩࡥࡴࡵࡎࡩࡾ࠭ୣ")]
  os.environ[bstack11l11ll_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡅ࡚࡚ࡏࡎࡃࡗࡍࡔࡔࠧ୤")] = bstack1l11ll11l_opy_.__str__()
  from _pytest.config import main as bstack1l1llll1_opy_
  bstack1l1llll1_opy_(arg)
def bstack1l11111ll_opy_(arg):
  bstack1lll1ll1l_opy_(bstack11l111111_opy_)
  from behave.__main__ import main as bstack1lll1l1lll_opy_
  bstack1lll1l1lll_opy_(arg)
def bstack1l1111111_opy_():
  logger.info(bstack1llllll1l_opy_)
  import argparse
  parser = argparse.ArgumentParser()
  parser.add_argument(bstack11l11ll_opy_ (u"ࠬࡹࡥࡵࡷࡳࠫ୥"), help=bstack11l11ll_opy_ (u"࠭ࡇࡦࡰࡨࡶࡦࡺࡥࠡࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࠠࡤࡱࡱࡪ࡮࡭ࠧ୦"))
  parser.add_argument(bstack11l11ll_opy_ (u"ࠧ࠮ࡷࠪ୧"), bstack11l11ll_opy_ (u"ࠨ࠯࠰ࡹࡸ࡫ࡲ࡯ࡣࡰࡩࠬ୨"), help=bstack11l11ll_opy_ (u"ࠩ࡜ࡳࡺࡸࠠࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࠦࡵࡴࡧࡵࡲࡦࡳࡥࠨ୩"))
  parser.add_argument(bstack11l11ll_opy_ (u"ࠪ࠱ࡰ࠭୪"), bstack11l11ll_opy_ (u"ࠫ࠲࠳࡫ࡦࡻࠪ୫"), help=bstack11l11ll_opy_ (u"ࠬ࡟࡯ࡶࡴࠣࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࠢࡤࡧࡨ࡫ࡳࡴࠢ࡮ࡩࡾ࠭୬"))
  parser.add_argument(bstack11l11ll_opy_ (u"࠭࠭ࡧࠩ୭"), bstack11l11ll_opy_ (u"ࠧ࠮࠯ࡩࡶࡦࡳࡥࡸࡱࡵ࡯ࠬ୮"), help=bstack11l11ll_opy_ (u"ࠨ࡛ࡲࡹࡷࠦࡴࡦࡵࡷࠤ࡫ࡸࡡ࡮ࡧࡺࡳࡷࡱࠧ୯"))
  bstack1ll1111lll_opy_ = parser.parse_args()
  try:
    bstack1lll11lll1_opy_ = bstack11l11ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫࠯ࡩࡨࡲࡪࡸࡩࡤ࠰ࡼࡱࡱ࠴ࡳࡢ࡯ࡳࡰࡪ࠭୰")
    if bstack1ll1111lll_opy_.framework and bstack1ll1111lll_opy_.framework not in (bstack11l11ll_opy_ (u"ࠪࡴࡾࡺࡨࡰࡰࠪୱ"), bstack11l11ll_opy_ (u"ࠫࡵࡿࡴࡩࡱࡱ࠷ࠬ୲")):
      bstack1lll11lll1_opy_ = bstack11l11ll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮࠲࡫ࡸࡡ࡮ࡧࡺࡳࡷࡱ࠮ࡺ࡯࡯࠲ࡸࡧ࡭ࡱ࡮ࡨࠫ୳")
    bstack1l11lll1l_opy_ = os.path.join(os.path.dirname(os.path.realpath(__file__)), bstack1lll11lll1_opy_)
    bstack1llll1ll1l_opy_ = open(bstack1l11lll1l_opy_, bstack11l11ll_opy_ (u"࠭ࡲࠨ୴"))
    bstack1l1l11lll_opy_ = bstack1llll1ll1l_opy_.read()
    bstack1llll1ll1l_opy_.close()
    if bstack1ll1111lll_opy_.username:
      bstack1l1l11lll_opy_ = bstack1l1l11lll_opy_.replace(bstack11l11ll_opy_ (u"࡚ࠧࡑࡘࡖࡤ࡛ࡓࡆࡔࡑࡅࡒࡋࠧ୵"), bstack1ll1111lll_opy_.username)
    if bstack1ll1111lll_opy_.key:
      bstack1l1l11lll_opy_ = bstack1l1l11lll_opy_.replace(bstack11l11ll_opy_ (u"ࠨ࡛ࡒ࡙ࡗࡥࡁࡄࡅࡈࡗࡘࡥࡋࡆ࡛ࠪ୶"), bstack1ll1111lll_opy_.key)
    if bstack1ll1111lll_opy_.framework:
      bstack1l1l11lll_opy_ = bstack1l1l11lll_opy_.replace(bstack11l11ll_opy_ (u"ࠩ࡜ࡓ࡚ࡘ࡟ࡇࡔࡄࡑࡊ࡝ࡏࡓࡍࠪ୷"), bstack1ll1111lll_opy_.framework)
    file_name = bstack11l11ll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬࠰ࡼࡱࡱ࠭୸")
    file_path = os.path.abspath(file_name)
    bstack1lll11l11_opy_ = open(file_path, bstack11l11ll_opy_ (u"ࠫࡼ࠭୹"))
    bstack1lll11l11_opy_.write(bstack1l1l11lll_opy_)
    bstack1lll11l11_opy_.close()
    logger.info(bstack1l1llll1l_opy_)
    try:
      os.environ[bstack11l11ll_opy_ (u"ࠬࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣࡋࡘࡁࡎࡇ࡚ࡓࡗࡑࠧ୺")] = bstack1ll1111lll_opy_.framework if bstack1ll1111lll_opy_.framework != None else bstack11l11ll_opy_ (u"ࠨࠢ୻")
      config = yaml.safe_load(bstack1l1l11lll_opy_)
      config[bstack11l11ll_opy_ (u"ࠧࡴࡱࡸࡶࡨ࡫ࠧ୼")] = bstack11l11ll_opy_ (u"ࠨࡲࡼࡸ࡭ࡵ࡮࠮ࡵࡨࡸࡺࡶࠧ୽")
      bstack11l11l11_opy_(bstack111lll111_opy_, config)
    except Exception as e:
      logger.debug(bstack1llll1l11l_opy_.format(str(e)))
  except Exception as e:
    logger.error(bstack111ll111_opy_.format(str(e)))
def bstack11l11l11_opy_(bstack1l11llll1_opy_, config, bstack1l11l11ll_opy_={}):
  global bstack1l11ll11l_opy_
  if not config:
    return
  bstack11l1lll1_opy_ = bstack111l1lll1_opy_ if not bstack1l11ll11l_opy_ else (
    bstack1lll111lll_opy_ if bstack11l11ll_opy_ (u"ࠩࡤࡴࡵ࠭୾") in config else bstack1ll11lll1_opy_)
  data = {
    bstack11l11ll_opy_ (u"ࠪࡹࡸ࡫ࡲࡏࡣࡰࡩࠬ୿"): config[bstack11l11ll_opy_ (u"ࠫࡺࡹࡥࡳࡐࡤࡱࡪ࠭஀")],
    bstack11l11ll_opy_ (u"ࠬࡧࡣࡤࡧࡶࡷࡐ࡫ࡹࠨ஁"): config[bstack11l11ll_opy_ (u"࠭ࡡࡤࡥࡨࡷࡸࡑࡥࡺࠩஂ")],
    bstack11l11ll_opy_ (u"ࠧࡦࡸࡨࡲࡹࡥࡴࡺࡲࡨࠫஃ"): bstack1l11llll1_opy_,
    bstack11l11ll_opy_ (u"ࠨࡧࡹࡩࡳࡺ࡟ࡱࡴࡲࡴࡪࡸࡴࡪࡧࡶࠫ஄"): {
      bstack11l11ll_opy_ (u"ࠩ࡯ࡥࡳ࡭ࡵࡢࡩࡨࡣ࡫ࡸࡡ࡮ࡧࡺࡳࡷࡱࠧஅ"): str(config[bstack11l11ll_opy_ (u"ࠪࡷࡴࡻࡲࡤࡧࠪஆ")]) if bstack11l11ll_opy_ (u"ࠫࡸࡵࡵࡳࡥࡨࠫஇ") in config else bstack11l11ll_opy_ (u"ࠧࡻ࡮࡬ࡰࡲࡻࡳࠨஈ"),
      bstack11l11ll_opy_ (u"࠭ࡲࡦࡨࡨࡶࡷ࡫ࡲࠨஉ"): bstack1l11ll1l_opy_(os.getenv(bstack11l11ll_opy_ (u"ࠢࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡆࡓࡃࡐࡉ࡜ࡕࡒࡌࠤஊ"), bstack11l11ll_opy_ (u"ࠣࠤ஋"))),
      bstack11l11ll_opy_ (u"ࠩ࡯ࡥࡳ࡭ࡵࡢࡩࡨࠫ஌"): bstack11l11ll_opy_ (u"ࠪࡴࡾࡺࡨࡰࡰࠪ஍"),
      bstack11l11ll_opy_ (u"ࠫࡵࡸ࡯ࡥࡷࡦࡸࠬஎ"): bstack11l1lll1_opy_,
      bstack11l11ll_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡒࡦࡳࡥࠨஏ"): config[bstack11l11ll_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡓࡧ࡭ࡦࠩஐ")] if config[bstack11l11ll_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡔࡡ࡮ࡧࠪ஑")] else bstack11l11ll_opy_ (u"ࠣࡷࡱ࡯ࡳࡵࡷ࡯ࠤஒ"),
      bstack11l11ll_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡊࡦࡨࡲࡹ࡯ࡦࡪࡧࡵࠫஓ"): str(config[bstack11l11ll_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡋࡧࡩࡳࡺࡩࡧ࡫ࡨࡶࠬஔ")]) if bstack11l11ll_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡌࡨࡪࡴࡴࡪࡨ࡬ࡩࡷ࠭க") in config else bstack11l11ll_opy_ (u"ࠧࡻ࡮࡬ࡰࡲࡻࡳࠨ஖"),
      bstack11l11ll_opy_ (u"࠭࡯ࡴࠩ஗"): sys.platform,
      bstack11l11ll_opy_ (u"ࠧࡩࡱࡶࡸࡳࡧ࡭ࡦࠩ஘"): socket.gethostname()
    }
  }
  update(data[bstack11l11ll_opy_ (u"ࠨࡧࡹࡩࡳࡺ࡟ࡱࡴࡲࡴࡪࡸࡴࡪࡧࡶࠫங")], bstack1l11l11ll_opy_)
  try:
    response = bstack1l11l1l11_opy_(bstack11l11ll_opy_ (u"ࠩࡓࡓࡘ࡚ࠧச"), bstack1llll11lll_opy_(bstack1111ll1l1_opy_), data, {
      bstack11l11ll_opy_ (u"ࠪࡥࡺࡺࡨࠨ஛"): (config[bstack11l11ll_opy_ (u"ࠫࡺࡹࡥࡳࡐࡤࡱࡪ࠭ஜ")], config[bstack11l11ll_opy_ (u"ࠬࡧࡣࡤࡧࡶࡷࡐ࡫ࡹࠨ஝")])
    })
    if response:
      logger.debug(bstack11l1lll1l_opy_.format(bstack1l11llll1_opy_, str(response.json())))
  except Exception as e:
    logger.debug(bstack111l1111_opy_.format(str(e)))
def bstack1l11ll1l_opy_(framework):
  return bstack11l11ll_opy_ (u"ࠨࡻࡾ࠯ࡳࡽࡹ࡮࡯࡯ࡣࡪࡩࡳࡺ࠯ࡼࡿࠥஞ").format(str(framework), __version__) if framework else bstack11l11ll_opy_ (u"ࠢࡱࡻࡷ࡬ࡴࡴࡡࡨࡧࡱࡸ࠴ࢁࡽࠣட").format(
    __version__)
def bstack1lll1111l1_opy_():
  global CONFIG
  if bool(CONFIG):
    return
  try:
    bstack1ll1111ll1_opy_()
    logger.debug(bstack1l11ll1l1_opy_.format(str(CONFIG)))
    bstack1ll11l1111_opy_()
    bstack1l11l111l_opy_()
  except Exception as e:
    logger.error(bstack11l11ll_opy_ (u"ࠣࡈࡤ࡭ࡱ࡫ࡤࠡࡶࡲࠤࡸ࡫ࡴࡶࡲ࠯ࠤࡪࡸࡲࡰࡴ࠽ࠤࠧ஠") + str(e))
    sys.exit(1)
  sys.excepthook = bstack11llll1l_opy_
  atexit.register(bstack11l111ll_opy_)
  signal.signal(signal.SIGINT, bstack1l1lll1ll_opy_)
  signal.signal(signal.SIGTERM, bstack1l1lll1ll_opy_)
def bstack11llll1l_opy_(exctype, value, traceback):
  global bstack11lll111_opy_
  try:
    for driver in bstack11lll111_opy_:
      driver.execute_script(
        bstack11l11ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡠࡧࡻࡩࡨࡻࡴࡰࡴ࠽ࠤࢀࠨࡡࡤࡶ࡬ࡳࡳࠨ࠺ࠡࠤࡶࡩࡹ࡙ࡥࡴࡵ࡬ࡳࡳ࡙ࡴࡢࡶࡸࡷࠧ࠲ࠠࠣࡣࡵ࡫ࡺࡳࡥ࡯ࡶࡶࠦ࠿ࠦࡻࠣࡵࡷࡥࡹࡻࡳࠣ࠼ࠥࡪࡦ࡯࡬ࡦࡦࠥ࠰ࠥࠨࡲࡦࡣࡶࡳࡳࠨ࠺ࠡࠩ஡") + json.dumps(
          bstack11l11ll_opy_ (u"ࠥࡗࡪࡹࡳࡪࡱࡱࠤ࡫ࡧࡩ࡭ࡧࡧࠤࡼ࡯ࡴࡩ࠼ࠣࡠࡳࠨ஢") + str(value)) + bstack11l11ll_opy_ (u"ࠫࢂࢃࠧண"))
  except Exception:
    pass
  bstack1l1111l11_opy_(value)
  sys.__excepthook__(exctype, value, traceback)
  sys.exit(1)
def bstack1l1111l11_opy_(message=bstack11l11ll_opy_ (u"ࠬ࠭த")):
  global CONFIG
  try:
    if message:
      bstack1l11l11ll_opy_ = {
        bstack11l11ll_opy_ (u"࠭ࡥࡳࡴࡲࡶࠬ஥"): str(message)
      }
      bstack11l11l11_opy_(bstack1ll11ll1ll_opy_, CONFIG, bstack1l11l11ll_opy_)
    else:
      bstack11l11l11_opy_(bstack1ll11ll1ll_opy_, CONFIG)
  except Exception as e:
    logger.debug(bstack1ll1l1111l_opy_.format(str(e)))
def bstack1ll111l1_opy_(bstack11llll111_opy_, size):
  bstack111llll1l_opy_ = []
  while len(bstack11llll111_opy_) > size:
    bstack1lll1ll11l_opy_ = bstack11llll111_opy_[:size]
    bstack111llll1l_opy_.append(bstack1lll1ll11l_opy_)
    bstack11llll111_opy_ = bstack11llll111_opy_[size:]
  bstack111llll1l_opy_.append(bstack11llll111_opy_)
  return bstack111llll1l_opy_
def bstack111l1111l_opy_(args):
  if bstack11l11ll_opy_ (u"ࠧ࠮࡯ࠪ஦") in args and bstack11l11ll_opy_ (u"ࠨࡲࡧࡦࠬ஧") in args:
    return True
  return False
def run_on_browserstack(bstack1ll11l111l_opy_=None, bstack1ll111l1l1_opy_=None, bstack1ll1l111l_opy_=False):
  global CONFIG
  global bstack1111l111_opy_
  global bstack11lll11l1_opy_
  bstack1111lll11_opy_ = bstack11l11ll_opy_ (u"ࠩࠪந")
  bstack1ll1ll1l11_opy_(bstack1lll1llll_opy_, logger)
  if bstack1ll11l111l_opy_ and isinstance(bstack1ll11l111l_opy_, str):
    bstack1ll11l111l_opy_ = eval(bstack1ll11l111l_opy_)
  if bstack1ll11l111l_opy_:
    CONFIG = bstack1ll11l111l_opy_[bstack11l11ll_opy_ (u"ࠪࡇࡔࡔࡆࡊࡉࠪன")]
    bstack1111l111_opy_ = bstack1ll11l111l_opy_[bstack11l11ll_opy_ (u"ࠫࡍ࡛ࡂࡠࡗࡕࡐࠬப")]
    bstack11lll11l1_opy_ = bstack1ll11l111l_opy_[bstack11l11ll_opy_ (u"ࠬࡏࡓࡠࡃࡓࡔࡤࡇࡕࡕࡑࡐࡅ࡙ࡋࠧ஫")]
    bstack11l1111l_opy_.set_property(bstack11l11ll_opy_ (u"࠭ࡉࡔࡡࡄࡔࡕࡥࡁࡖࡖࡒࡑࡆ࡚ࡅࠨ஬"), bstack11lll11l1_opy_)
    bstack1111lll11_opy_ = bstack11l11ll_opy_ (u"ࠧࡱࡻࡷ࡬ࡴࡴࠧ஭")
  if not bstack1ll1l111l_opy_:
    if len(sys.argv) <= 1:
      logger.critical(bstack1l111ll1l_opy_)
      return
    if sys.argv[1] == bstack11l11ll_opy_ (u"ࠨ࠯࠰ࡺࡪࡸࡳࡪࡱࡱࠫம") or sys.argv[1] == bstack11l11ll_opy_ (u"ࠩ࠰ࡺࠬய"):
      logger.info(bstack11l11ll_opy_ (u"ࠪࡆࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࠢࡓࡽࡹ࡮࡯࡯ࠢࡖࡈࡐࠦࡶࡼࡿࠪர").format(__version__))
      return
    if sys.argv[1] == bstack11l11ll_opy_ (u"ࠫࡸ࡫ࡴࡶࡲࠪற"):
      bstack1l1111111_opy_()
      return
  args = sys.argv
  bstack1lll1111l1_opy_()
  global bstack1lll11llll_opy_
  global bstack1ll1ll1ll_opy_
  global bstack11ll1l11_opy_
  global bstack111l11l1_opy_
  global bstack1ll11llll1_opy_
  global bstack11ll1lll_opy_
  global bstack11ll11ll1_opy_
  global bstack111l111ll_opy_
  global bstack11l11l1l_opy_
  if not bstack1111lll11_opy_:
    if args[1] == bstack11l11ll_opy_ (u"ࠬࡶࡹࡵࡪࡲࡲࠬல") or args[1] == bstack11l11ll_opy_ (u"࠭ࡰࡺࡶ࡫ࡳࡳ࠹ࠧள"):
      bstack1111lll11_opy_ = bstack11l11ll_opy_ (u"ࠧࡱࡻࡷ࡬ࡴࡴࠧழ")
      args = args[2:]
    elif args[1] == bstack11l11ll_opy_ (u"ࠨࡴࡲࡦࡴࡺࠧவ"):
      bstack1111lll11_opy_ = bstack11l11ll_opy_ (u"ࠩࡵࡳࡧࡵࡴࠨஶ")
      args = args[2:]
    elif args[1] == bstack11l11ll_opy_ (u"ࠪࡴࡦࡨ࡯ࡵࠩஷ"):
      bstack1111lll11_opy_ = bstack11l11ll_opy_ (u"ࠫࡵࡧࡢࡰࡶࠪஸ")
      args = args[2:]
    elif args[1] == bstack11l11ll_opy_ (u"ࠬࡸ࡯ࡣࡱࡷ࠱࡮ࡴࡴࡦࡴࡱࡥࡱ࠭ஹ"):
      bstack1111lll11_opy_ = bstack11l11ll_opy_ (u"࠭ࡲࡰࡤࡲࡸ࠲࡯࡮ࡵࡧࡵࡲࡦࡲࠧ஺")
      args = args[2:]
    elif args[1] == bstack11l11ll_opy_ (u"ࠧࡱࡻࡷࡩࡸࡺࠧ஻"):
      bstack1111lll11_opy_ = bstack11l11ll_opy_ (u"ࠨࡲࡼࡸࡪࡹࡴࠨ஼")
      args = args[2:]
    elif args[1] == bstack11l11ll_opy_ (u"ࠩࡥࡩ࡭ࡧࡶࡦࠩ஽"):
      bstack1111lll11_opy_ = bstack11l11ll_opy_ (u"ࠪࡦࡪ࡮ࡡࡷࡧࠪா")
      args = args[2:]
    else:
      if not bstack11l11ll_opy_ (u"ࠫ࡫ࡸࡡ࡮ࡧࡺࡳࡷࡱࠧி") in CONFIG or str(CONFIG[bstack11l11ll_opy_ (u"ࠬ࡬ࡲࡢ࡯ࡨࡻࡴࡸ࡫ࠨீ")]).lower() in [bstack11l11ll_opy_ (u"࠭ࡰࡺࡶ࡫ࡳࡳ࠭ு"), bstack11l11ll_opy_ (u"ࠧࡱࡻࡷ࡬ࡴࡴ࠳ࠨூ")]:
        bstack1111lll11_opy_ = bstack11l11ll_opy_ (u"ࠨࡲࡼࡸ࡭ࡵ࡮ࠨ௃")
        args = args[1:]
      elif str(CONFIG[bstack11l11ll_opy_ (u"ࠩࡩࡶࡦࡳࡥࡸࡱࡵ࡯ࠬ௄")]).lower() == bstack11l11ll_opy_ (u"ࠪࡶࡴࡨ࡯ࡵࠩ௅"):
        bstack1111lll11_opy_ = bstack11l11ll_opy_ (u"ࠫࡷࡵࡢࡰࡶࠪெ")
        args = args[1:]
      elif str(CONFIG[bstack11l11ll_opy_ (u"ࠬ࡬ࡲࡢ࡯ࡨࡻࡴࡸ࡫ࠨே")]).lower() == bstack11l11ll_opy_ (u"࠭ࡰࡢࡤࡲࡸࠬை"):
        bstack1111lll11_opy_ = bstack11l11ll_opy_ (u"ࠧࡱࡣࡥࡳࡹ࠭௉")
        args = args[1:]
      elif str(CONFIG[bstack11l11ll_opy_ (u"ࠨࡨࡵࡥࡲ࡫ࡷࡰࡴ࡮ࠫொ")]).lower() == bstack11l11ll_opy_ (u"ࠩࡳࡽࡹ࡫ࡳࡵࠩோ"):
        bstack1111lll11_opy_ = bstack11l11ll_opy_ (u"ࠪࡴࡾࡺࡥࡴࡶࠪௌ")
        args = args[1:]
      elif str(CONFIG[bstack11l11ll_opy_ (u"ࠫ࡫ࡸࡡ࡮ࡧࡺࡳࡷࡱ்ࠧ")]).lower() == bstack11l11ll_opy_ (u"ࠬࡨࡥࡩࡣࡹࡩࠬ௎"):
        bstack1111lll11_opy_ = bstack11l11ll_opy_ (u"࠭ࡢࡦࡪࡤࡺࡪ࠭௏")
        args = args[1:]
      else:
        os.environ[bstack11l11ll_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡆࡓࡃࡐࡉ࡜ࡕࡒࡌࠩௐ")] = bstack1111lll11_opy_
        bstack1l1ll1ll_opy_(bstack11l11ll11_opy_)
  global bstack11llll1ll_opy_
  if bstack1ll11l111l_opy_:
    try:
      os.environ[bstack11l11ll_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡇࡔࡄࡑࡊ࡝ࡏࡓࡍࠪ௑")] = bstack1111lll11_opy_
      bstack11l11l11_opy_(bstack1lll1111ll_opy_, CONFIG)
    except Exception as e:
      logger.debug(bstack1ll1l1111l_opy_.format(str(e)))
  global bstack1llll1llll_opy_
  global bstack1lll1llll1_opy_
  global bstack111ll1l1_opy_
  global bstack1ll11l1ll1_opy_
  global bstack1ll11l11l_opy_
  global bstack1llll1l1l_opy_
  global bstack1ll1l1l11_opy_
  global bstack111111111_opy_
  global bstack1lllll111_opy_
  global bstack1ll1l111ll_opy_
  global bstack1111ll11_opy_
  global bstack1l1lll111_opy_
  global bstack1l1l11l1l_opy_
  global bstack1llll11l1l_opy_
  global bstack1ll11ll1l_opy_
  global bstack11lll111l_opy_
  global bstack1llll1ll11_opy_
  global bstack1lll11ll11_opy_
  global bstack1llll11111_opy_
  try:
    from selenium import webdriver
    from selenium.webdriver.remote.webdriver import WebDriver
    bstack1llll1llll_opy_ = webdriver.Remote.__init__
    bstack1lll1llll1_opy_ = WebDriver.quit
    bstack1111ll11_opy_ = WebDriver.close
    bstack1llll11l1l_opy_ = WebDriver.get
  except Exception as e:
    pass
  try:
    import Browser
    from subprocess import Popen
    bstack11llll1ll_opy_ = Popen.__init__
  except Exception as e:
    pass
  if bstack11ll1ll1_opy_(CONFIG) and bstack1lll11l1l1_opy_():
    if bstack1ll1l1lll_opy_() < version.parse(bstack1111l1ll_opy_):
      logger.error(bstack1111111ll_opy_.format(bstack1ll1l1lll_opy_()))
    else:
      try:
        from selenium.webdriver.remote.remote_connection import RemoteConnection
        bstack1ll11ll1l_opy_ = RemoteConnection._get_proxy_url
      except Exception as e:
        logger.error(bstack1l1l1l11_opy_.format(str(e)))
  if bstack1111lll11_opy_ != bstack11l11ll_opy_ (u"ࠩࡳࡽࡹ࡮࡯࡯ࠩ௒") or (bstack1111lll11_opy_ == bstack11l11ll_opy_ (u"ࠪࡴࡾࡺࡨࡰࡰࠪ௓") and not bstack1ll11l111l_opy_):
    bstack1lll1ll1ll_opy_()
  if (bstack1111lll11_opy_ in [bstack11l11ll_opy_ (u"ࠫࡵࡧࡢࡰࡶࠪ௔"), bstack11l11ll_opy_ (u"ࠬࡸ࡯ࡣࡱࡷࠫ௕"), bstack11l11ll_opy_ (u"࠭ࡲࡰࡤࡲࡸ࠲࡯࡮ࡵࡧࡵࡲࡦࡲࠧ௖")]):
    try:
      from robot import run_cli
      from robot.output import Output
      from robot.running.status import TestStatus
      from pabot.pabot import QueueItem
      from pabot import pabot
      try:
        from SeleniumLibrary.keywords.webdrivertools.webdrivertools import WebDriverCreator
        from SeleniumLibrary.keywords.webdrivertools.webdrivertools import WebDriverCache
        WebDriverCreator._get_ff_profile = bstack11lll1ll_opy_
        bstack1ll11l11l_opy_ = WebDriverCache.close
      except Exception as e:
        logger.warn(bstack1l111l1l_opy_ + str(e))
      try:
        from AppiumLibrary.utils.applicationcache import ApplicationCache
        bstack1ll11l1ll1_opy_ = ApplicationCache.close
      except Exception as e:
        logger.debug(bstack11l1l1l1_opy_ + str(e))
    except Exception as e:
      bstack1ll1l11l11_opy_(e, bstack1l111l1l_opy_)
    if bstack1111lll11_opy_ != bstack11l11ll_opy_ (u"ࠧࡳࡱࡥࡳࡹ࠳ࡩ࡯ࡶࡨࡶࡳࡧ࡬ࠨௗ"):
      bstack111l1ll1l_opy_()
    bstack111ll1l1_opy_ = Output.end_test
    bstack1llll1l1l_opy_ = TestStatus.__init__
    bstack111111111_opy_ = pabot._run
    bstack1lllll111_opy_ = QueueItem.__init__
    bstack1ll1l111ll_opy_ = pabot._create_command_for_execution
    bstack1lll11ll11_opy_ = pabot._report_results
  if bstack1111lll11_opy_ == bstack11l11ll_opy_ (u"ࠨࡤࡨ࡬ࡦࡼࡥࠨ௘"):
    try:
      from behave.runner import Runner
      from behave.model import Step
    except Exception as e:
      bstack1ll1l11l11_opy_(e, bstack1l1l11ll1_opy_)
    bstack1l1lll111_opy_ = Runner.run_hook
    bstack1l1l11l1l_opy_ = Step.run
  if bstack11l11ll_opy_ (u"ࠩࡤࡧࡨ࡫ࡳࡴ࡫ࡥ࡭ࡱ࡯ࡴࡺࡑࡳࡸ࡮ࡵ࡮ࡴࠩ௙") in CONFIG:
    os.environ[bstack11l11ll_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡗࡉࡘ࡚࡟ࡂࡅࡆࡉࡘ࡙ࡉࡃࡋࡏࡍ࡙࡟࡟ࡄࡑࡑࡊࡎࡍࡕࡓࡃࡗࡍࡔࡔ࡟࡚ࡏࡏࠫ௚")] = json.dumps(CONFIG[bstack11l11ll_opy_ (u"ࠫࡦࡩࡣࡦࡵࡶ࡭ࡧ࡯࡬ࡪࡶࡼࡓࡵࡺࡩࡰࡰࡶࠫ௛")])
    CONFIG[bstack11l11ll_opy_ (u"ࠬࡧࡣࡤࡧࡶࡷ࡮ࡨࡩ࡭࡫ࡷࡽࡔࡶࡴࡪࡱࡱࡷࠬ௜")].pop(bstack11l11ll_opy_ (u"࠭ࡩ࡯ࡥ࡯ࡹࡩ࡫ࡔࡢࡩࡶࡍࡳ࡚ࡥࡴࡶ࡬ࡲ࡬࡙ࡣࡰࡲࡨࠫ௝"), None)
    CONFIG[bstack11l11ll_opy_ (u"ࠧࡢࡥࡦࡩࡸࡹࡩࡣ࡫࡯࡭ࡹࡿࡏࡱࡶ࡬ࡳࡳࡹࠧ௞")].pop(bstack11l11ll_opy_ (u"ࠨࡧࡻࡧࡱࡻࡤࡦࡖࡤ࡫ࡸࡏ࡮ࡕࡧࡶࡸ࡮ࡴࡧࡔࡥࡲࡴࡪ࠭௟"), None)
  if bstack1111lll11_opy_ == bstack11l11ll_opy_ (u"ࠩࡳࡽࡹ࡫ࡳࡵࠩ௠"):
    try:
      bstack1ll1lll1ll_opy_.launch(CONFIG, {
        bstack11l11ll_opy_ (u"ࠪࡪࡷࡧ࡭ࡦࡹࡲࡶࡰࡥ࡮ࡢ࡯ࡨࠫ௡"): bstack11l11ll_opy_ (u"ࠫࡕࡿࡴࡦࡵࡷ࠱ࡨࡻࡣࡶ࡯ࡥࡩࡷ࠭௢") if bstack1llll1111_opy_() else bstack11l11ll_opy_ (u"ࠬࡖࡹࡵࡧࡶࡸࠬ௣"),
        bstack11l11ll_opy_ (u"࠭ࡦࡳࡣࡰࡩࡼࡵࡲ࡬ࡡࡹࡩࡷࡹࡩࡰࡰࠪ௤"): bstack1lll1ll1_opy_.version(),
        bstack11l11ll_opy_ (u"ࠧࡴࡦ࡮ࡣࡻ࡫ࡲࡴ࡫ࡲࡲࠬ௥"): __version__
      })
      if bstack1l11ll11l_opy_ and bstack11lllll1l_opy_.bstack1111ll111_opy_(CONFIG):
        bstack11l1ll11_opy_, bstack111lll11_opy_ = bstack11lllll1l_opy_.bstack11ll111l_opy_(CONFIG, bstack1111lll11_opy_, bstack1lll1ll1_opy_.version());
        if not bstack11l1ll11_opy_ is None:
          os.environ[bstack11l11ll_opy_ (u"ࠨࡄࡖࡣࡆ࠷࠱࡚ࡡࡍ࡛࡙࠭௦")] = bstack11l1ll11_opy_;
          os.environ[bstack11l11ll_opy_ (u"ࠩࡅࡗࡤࡇ࠱࠲࡛ࡢࡘࡊ࡙ࡔࡠࡔࡘࡒࡤࡏࡄࠨ௧")] = str(bstack111lll11_opy_);
      from _pytest.config import Config
      bstack11lll111l_opy_ = Config.getoption
      from _pytest import runner
      bstack1llll1ll11_opy_ = runner._update_current_test_var
    except Exception as e:
      logger.warn(e, bstack1ll11l11_opy_)
    try:
      from pytest_bdd import reporting
      bstack1llll11111_opy_ = reporting.runtest_makereport
    except Exception as e:
      logger.debug(bstack11l11ll_opy_ (u"ࠪࡔࡱ࡫ࡡࡴࡧࠣ࡭ࡳࡹࡴࡢ࡮࡯ࠤࡵࡿࡴࡦࡵࡷ࠱ࡧࡪࡤࠡࡶࡲࠤࡷࡻ࡮ࠡࡲࡼࡸࡪࡹࡴ࠮ࡤࡧࡨࠥࡺࡥࡴࡶࡶࠫ௨"))
  if bstack1111lll11_opy_ == bstack11l11ll_opy_ (u"ࠫࡵࡿࡴࡩࡱࡱࠫ௩"):
    bstack1ll1ll1ll_opy_ = True
    if bstack1ll11l111l_opy_ and bstack1ll1l111l_opy_:
      bstack1ll11llll1_opy_ = CONFIG.get(bstack11l11ll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷ࡙ࡴࡢࡥ࡮ࡐࡴࡩࡡ࡭ࡑࡳࡸ࡮ࡵ࡮ࡴࠩ௪"), {}).get(bstack11l11ll_opy_ (u"࠭࡬ࡰࡥࡤࡰࡎࡪࡥ࡯ࡶ࡬ࡪ࡮࡫ࡲࠨ௫"))
      bstack1lll1ll1l_opy_(bstack1111lll1l_opy_)
    elif bstack1ll11l111l_opy_:
      bstack1ll11llll1_opy_ = CONFIG.get(bstack11l11ll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡔࡶࡤࡧࡰࡒ࡯ࡤࡣ࡯ࡓࡵࡺࡩࡰࡰࡶࠫ௬"), {}).get(bstack11l11ll_opy_ (u"ࠨ࡮ࡲࡧࡦࡲࡉࡥࡧࡱࡸ࡮࡬ࡩࡦࡴࠪ௭"))
      global bstack11lll111_opy_
      try:
        if bstack111l1111l_opy_(bstack1ll11l111l_opy_[bstack11l11ll_opy_ (u"ࠩࡩ࡭ࡱ࡫࡟࡯ࡣࡰࡩࠬ௮")]) and multiprocessing.current_process().name == bstack11l11ll_opy_ (u"ࠪ࠴ࠬ௯"):
          bstack1ll11l111l_opy_[bstack11l11ll_opy_ (u"ࠫ࡫࡯࡬ࡦࡡࡱࡥࡲ࡫ࠧ௰")].remove(bstack11l11ll_opy_ (u"ࠬ࠳࡭ࠨ௱"))
          bstack1ll11l111l_opy_[bstack11l11ll_opy_ (u"࠭ࡦࡪ࡮ࡨࡣࡳࡧ࡭ࡦࠩ௲")].remove(bstack11l11ll_opy_ (u"ࠧࡱࡦࡥࠫ௳"))
          bstack1ll11l111l_opy_[bstack11l11ll_opy_ (u"ࠨࡨ࡬ࡰࡪࡥ࡮ࡢ࡯ࡨࠫ௴")] = bstack1ll11l111l_opy_[bstack11l11ll_opy_ (u"ࠩࡩ࡭ࡱ࡫࡟࡯ࡣࡰࡩࠬ௵")][0]
          with open(bstack1ll11l111l_opy_[bstack11l11ll_opy_ (u"ࠪࡪ࡮ࡲࡥࡠࡰࡤࡱࡪ࠭௶")], bstack11l11ll_opy_ (u"ࠫࡷ࠭௷")) as f:
            bstack1llll1lll_opy_ = f.read()
          bstack1111lll1_opy_ = bstack11l11ll_opy_ (u"ࠧࠨࠢࡧࡴࡲࡱࠥࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡣࡸࡪ࡫ࠡ࡫ࡰࡴࡴࡸࡴࠡࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࡟ࡪࡰ࡬ࡸ࡮ࡧ࡬ࡪࡼࡨ࠿ࠥࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡣ࡮ࡴࡩࡵ࡫ࡤࡰ࡮ࢀࡥࠩࡽࢀ࠭ࡀࠦࡦࡳࡱࡰࠤࡵࡪࡢࠡ࡫ࡰࡴࡴࡸࡴࠡࡒࡧࡦࡀࠦ࡯ࡨࡡࡧࡦࠥࡃࠠࡑࡦࡥ࠲ࡩࡵ࡟ࡣࡴࡨࡥࡰࡁࠊࡥࡧࡩࠤࡲࡵࡤࡠࡤࡵࡩࡦࡱࠨࡴࡧ࡯ࡪ࠱ࠦࡡࡳࡩ࠯ࠤࡹ࡫࡭ࡱࡱࡵࡥࡷࡿࠠ࠾ࠢ࠳࠭࠿ࠐࠠࠡࡶࡵࡽ࠿ࠐࠠࠡࠢࠣࡥࡷ࡭ࠠ࠾ࠢࡶࡸࡷ࠮ࡩ࡯ࡶࠫࡥࡷ࡭ࠩࠬ࠳࠳࠭ࠏࠦࠠࡦࡺࡦࡩࡵࡺࠠࡆࡺࡦࡩࡵࡺࡩࡰࡰࠣࡥࡸࠦࡥ࠻ࠌࠣࠤࠥࠦࡰࡢࡵࡶࠎࠥࠦ࡯ࡨࡡࡧࡦ࠭ࡹࡥ࡭ࡨ࠯ࡥࡷ࡭ࠬࡵࡧࡰࡴࡴࡸࡡࡳࡻࠬࠎࡕࡪࡢ࠯ࡦࡲࡣࡧࠦ࠽ࠡ࡯ࡲࡨࡤࡨࡲࡦࡣ࡮ࠎࡕࡪࡢ࠯ࡦࡲࡣࡧࡸࡥࡢ࡭ࠣࡁࠥࡳ࡯ࡥࡡࡥࡶࡪࡧ࡫ࠋࡒࡧࡦ࠭࠯࠮ࡴࡧࡷࡣࡹࡸࡡࡤࡧࠫ࠭ࡡࡴࠢࠣࠤ௸").format(str(bstack1ll11l111l_opy_))
          bstack111l1ll1_opy_ = bstack1111lll1_opy_ + bstack1llll1lll_opy_
          bstack1llllllll_opy_ = bstack1ll11l111l_opy_[bstack11l11ll_opy_ (u"࠭ࡦࡪ࡮ࡨࡣࡳࡧ࡭ࡦࠩ௹")] + bstack11l11ll_opy_ (u"ࠧࡠࡤࡶࡸࡦࡩ࡫ࡠࡶࡨࡱࡵ࠴ࡰࡺࠩ௺")
          with open(bstack1llllllll_opy_, bstack11l11ll_opy_ (u"ࠨࡹࠪ௻")):
            pass
          with open(bstack1llllllll_opy_, bstack11l11ll_opy_ (u"ࠤࡺ࠯ࠧ௼")) as f:
            f.write(bstack111l1ll1_opy_)
          import subprocess
          process_data = subprocess.run([bstack11l11ll_opy_ (u"ࠥࡴࡾࡺࡨࡰࡰࠥ௽"), bstack1llllllll_opy_])
          if os.path.exists(bstack1llllllll_opy_):
            os.unlink(bstack1llllllll_opy_)
          os._exit(process_data.returncode)
        else:
          if bstack111l1111l_opy_(bstack1ll11l111l_opy_[bstack11l11ll_opy_ (u"ࠫ࡫࡯࡬ࡦࡡࡱࡥࡲ࡫ࠧ௾")]):
            bstack1ll11l111l_opy_[bstack11l11ll_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡢࡲࡦࡳࡥࠨ௿")].remove(bstack11l11ll_opy_ (u"࠭࠭࡮ࠩఀ"))
            bstack1ll11l111l_opy_[bstack11l11ll_opy_ (u"ࠧࡧ࡫࡯ࡩࡤࡴࡡ࡮ࡧࠪఁ")].remove(bstack11l11ll_opy_ (u"ࠨࡲࡧࡦࠬం"))
            bstack1ll11l111l_opy_[bstack11l11ll_opy_ (u"ࠩࡩ࡭ࡱ࡫࡟࡯ࡣࡰࡩࠬః")] = bstack1ll11l111l_opy_[bstack11l11ll_opy_ (u"ࠪࡪ࡮ࡲࡥࡠࡰࡤࡱࡪ࠭ఄ")][0]
          bstack1lll1ll1l_opy_(bstack1111lll1l_opy_)
          sys.path.append(os.path.dirname(os.path.abspath(bstack1ll11l111l_opy_[bstack11l11ll_opy_ (u"ࠫ࡫࡯࡬ࡦࡡࡱࡥࡲ࡫ࠧఅ")])))
          sys.argv = sys.argv[2:]
          mod_globals = globals()
          mod_globals[bstack11l11ll_opy_ (u"ࠬࡥ࡟࡯ࡣࡰࡩࡤࡥࠧఆ")] = bstack11l11ll_opy_ (u"࠭࡟ࡠ࡯ࡤ࡭ࡳࡥ࡟ࠨఇ")
          mod_globals[bstack11l11ll_opy_ (u"ࠧࡠࡡࡩ࡭ࡱ࡫࡟ࡠࠩఈ")] = os.path.abspath(bstack1ll11l111l_opy_[bstack11l11ll_opy_ (u"ࠨࡨ࡬ࡰࡪࡥ࡮ࡢ࡯ࡨࠫఉ")])
          exec(open(bstack1ll11l111l_opy_[bstack11l11ll_opy_ (u"ࠩࡩ࡭ࡱ࡫࡟࡯ࡣࡰࡩࠬఊ")]).read(), mod_globals)
      except BaseException as e:
        try:
          traceback.print_exc()
          logger.error(bstack11l11ll_opy_ (u"ࠪࡇࡦࡻࡧࡩࡶࠣࡉࡽࡩࡥࡱࡶ࡬ࡳࡳࡀࠠࡼࡿࠪఋ").format(str(e)))
          for driver in bstack11lll111_opy_:
            bstack1ll111l1l1_opy_.append({
              bstack11l11ll_opy_ (u"ࠫࡳࡧ࡭ࡦࠩఌ"): bstack1ll11l111l_opy_[bstack11l11ll_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡢࡲࡦࡳࡥࠨ఍")],
              bstack11l11ll_opy_ (u"࠭ࡥࡳࡴࡲࡶࠬఎ"): str(e),
              bstack11l11ll_opy_ (u"ࠧࡪࡰࡧࡩࡽ࠭ఏ"): multiprocessing.current_process().name
            })
            driver.execute_script(
              bstack11l11ll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࡟ࡦࡺࡨࡧࡺࡺ࡯ࡳ࠼ࠣࡿࠧࡧࡣࡵ࡫ࡲࡲࠧࡀࠠࠣࡵࡨࡸࡘ࡫ࡳࡴ࡫ࡲࡲࡘࡺࡡࡵࡷࡶࠦ࠱ࠦࠢࡢࡴࡪࡹࡲ࡫࡮ࡵࡵࠥ࠾ࠥࢁࠢࡴࡶࡤࡸࡺࡹࠢ࠻ࠤࡩࡥ࡮ࡲࡥࡥࠤ࠯ࠤࠧࡸࡥࡢࡵࡲࡲࠧࡀࠠࠨఐ") + json.dumps(
                bstack11l11ll_opy_ (u"ࠤࡖࡩࡸࡹࡩࡰࡰࠣࡪࡦ࡯࡬ࡦࡦࠣࡻ࡮ࡺࡨ࠻ࠢ࡟ࡲࠧ఑") + str(e)) + bstack11l11ll_opy_ (u"ࠪࢁࢂ࠭ఒ"))
        except Exception:
          pass
      finally:
        try:
          for driver in bstack11lll111_opy_:
            driver.quit()
        except Exception as e:
          pass
    else:
      percy.init(bstack11lll11l1_opy_, CONFIG, logger)
      bstack1l111111_opy_()
      bstack1l111l11_opy_()
      bstack1ll111ll_opy_ = {
        bstack11l11ll_opy_ (u"ࠫ࡫࡯࡬ࡦࡡࡱࡥࡲ࡫ࠧఓ"): args[0],
        bstack11l11ll_opy_ (u"ࠬࡉࡏࡏࡈࡌࡋࠬఔ"): CONFIG,
        bstack11l11ll_opy_ (u"࠭ࡈࡖࡄࡢ࡙ࡗࡒࠧక"): bstack1111l111_opy_,
        bstack11l11ll_opy_ (u"ࠧࡊࡕࡢࡅࡕࡖ࡟ࡂࡗࡗࡓࡒࡇࡔࡆࠩఖ"): bstack11lll11l1_opy_
      }
      percy.bstack1l1ll11ll_opy_()
      if bstack11l11ll_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠫగ") in CONFIG:
        bstack1lll11l1_opy_ = []
        manager = multiprocessing.Manager()
        bstack1llll1l1_opy_ = manager.list()
        if bstack111l1111l_opy_(args):
          for index, platform in enumerate(CONFIG[bstack11l11ll_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࡷࠬఘ")]):
            if index == 0:
              bstack1ll111ll_opy_[bstack11l11ll_opy_ (u"ࠪࡪ࡮ࡲࡥࡠࡰࡤࡱࡪ࠭ఙ")] = args
            bstack1lll11l1_opy_.append(multiprocessing.Process(name=str(index),
                                                       target=run_on_browserstack,
                                                       args=(bstack1ll111ll_opy_, bstack1llll1l1_opy_)))
        else:
          for index, platform in enumerate(CONFIG[bstack11l11ll_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡹࠧచ")]):
            bstack1lll11l1_opy_.append(multiprocessing.Process(name=str(index),
                                                       target=run_on_browserstack,
                                                       args=(bstack1ll111ll_opy_, bstack1llll1l1_opy_)))
        for t in bstack1lll11l1_opy_:
          t.start()
        for t in bstack1lll11l1_opy_:
          t.join()
        bstack11ll11ll1_opy_ = list(bstack1llll1l1_opy_)
      else:
        if bstack111l1111l_opy_(args):
          bstack1ll111ll_opy_[bstack11l11ll_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡢࡲࡦࡳࡥࠨఛ")] = args
          test = multiprocessing.Process(name=str(0),
                                         target=run_on_browserstack, args=(bstack1ll111ll_opy_,))
          test.start()
          test.join()
        else:
          bstack1lll1ll1l_opy_(bstack1111lll1l_opy_)
          sys.path.append(os.path.dirname(os.path.abspath(args[0])))
          mod_globals = globals()
          mod_globals[bstack11l11ll_opy_ (u"࠭࡟ࡠࡰࡤࡱࡪࡥ࡟ࠨజ")] = bstack11l11ll_opy_ (u"ࠧࡠࡡࡰࡥ࡮ࡴ࡟ࡠࠩఝ")
          mod_globals[bstack11l11ll_opy_ (u"ࠨࡡࡢࡪ࡮ࡲࡥࡠࡡࠪఞ")] = os.path.abspath(args[0])
          sys.argv = sys.argv[2:]
          exec(open(args[0]).read(), mod_globals)
  elif bstack1111lll11_opy_ == bstack11l11ll_opy_ (u"ࠩࡳࡥࡧࡵࡴࠨట") or bstack1111lll11_opy_ == bstack11l11ll_opy_ (u"ࠪࡶࡴࡨ࡯ࡵࠩఠ"):
    try:
      from pabot import pabot
    except Exception as e:
      bstack1ll1l11l11_opy_(e, bstack1l111l1l_opy_)
    bstack1l111111_opy_()
    bstack1lll1ll1l_opy_(bstack111l1l111_opy_)
    if bstack11l11ll_opy_ (u"ࠫ࠲࠳ࡰࡳࡱࡦࡩࡸࡹࡥࡴࠩడ") in args:
      i = args.index(bstack11l11ll_opy_ (u"ࠬ࠳࠭ࡱࡴࡲࡧࡪࡹࡳࡦࡵࠪఢ"))
      args.pop(i)
      args.pop(i)
    args.insert(0, str(bstack1lll11llll_opy_))
    args.insert(0, str(bstack11l11ll_opy_ (u"࠭࠭࠮ࡲࡵࡳࡨ࡫ࡳࡴࡧࡶࠫణ")))
    pabot.main(args)
  elif bstack1111lll11_opy_ == bstack11l11ll_opy_ (u"ࠧࡳࡱࡥࡳࡹ࠳ࡩ࡯ࡶࡨࡶࡳࡧ࡬ࠨత"):
    try:
      from robot import run_cli
    except Exception as e:
      bstack1ll1l11l11_opy_(e, bstack1l111l1l_opy_)
    for a in args:
      if bstack11l11ll_opy_ (u"ࠨࡄࡖࡘࡆࡉࡋࡑࡎࡄࡘࡋࡕࡒࡎࡋࡑࡈࡊ࡞ࠧథ") in a:
        bstack111l11l1_opy_ = int(a.split(bstack11l11ll_opy_ (u"ࠩ࠽ࠫద"))[1])
      if bstack11l11ll_opy_ (u"ࠪࡆࡘ࡚ࡁࡄࡍࡇࡉࡋࡒࡏࡄࡃࡏࡍࡉࡋࡎࡕࡋࡉࡍࡊࡘࠧధ") in a:
        bstack1ll11llll1_opy_ = str(a.split(bstack11l11ll_opy_ (u"ࠫ࠿࠭న"))[1])
      if bstack11l11ll_opy_ (u"ࠬࡈࡓࡕࡃࡆࡏࡈࡒࡉࡂࡔࡊࡗࠬ఩") in a:
        bstack11ll1lll_opy_ = str(a.split(bstack11l11ll_opy_ (u"࠭࠺ࠨప"))[1])
    bstack1111l11l_opy_ = None
    if bstack11l11ll_opy_ (u"ࠧ࠮࠯ࡥࡷࡹࡧࡣ࡬ࡡ࡬ࡸࡪࡳ࡟ࡪࡰࡧࡩࡽ࠭ఫ") in args:
      i = args.index(bstack11l11ll_opy_ (u"ࠨ࠯࠰ࡦࡸࡺࡡࡤ࡭ࡢ࡭ࡹ࡫࡭ࡠ࡫ࡱࡨࡪࡾࠧబ"))
      args.pop(i)
      bstack1111l11l_opy_ = args.pop(i)
    if bstack1111l11l_opy_ is not None:
      global bstack1l1111l1l_opy_
      bstack1l1111l1l_opy_ = bstack1111l11l_opy_
    bstack1lll1ll1l_opy_(bstack111l1l111_opy_)
    run_cli(args)
  elif bstack1111lll11_opy_ == bstack11l11ll_opy_ (u"ࠩࡳࡽࡹ࡫ࡳࡵࠩభ"):
    bstack1lll11l1l_opy_ = bstack1lll1ll1_opy_(args, logger, CONFIG, bstack1l11ll11l_opy_)
    bstack1lll11l1l_opy_.bstack1ll1l11l_opy_()
    bstack1l111111_opy_()
    bstack11ll1l11_opy_ = True
    bstack11l11l1l_opy_ = bstack1lll11l1l_opy_.bstack1llll111_opy_()
    bstack1lll11l1l_opy_.bstack1ll111ll_opy_(bstack1llll11l1_opy_)
    bstack111l111ll_opy_ = bstack1lll11l1l_opy_.bstack1ll1l1ll_opy_(bstack1lllll1lll_opy_, {
      bstack11l11ll_opy_ (u"ࠪࡌ࡚ࡈ࡟ࡖࡔࡏࠫమ"): bstack1111l111_opy_,
      bstack11l11ll_opy_ (u"ࠫࡎ࡙࡟ࡂࡒࡓࡣࡆ࡛ࡔࡐࡏࡄࡘࡊ࠭య"): bstack11lll11l1_opy_,
      bstack11l11ll_opy_ (u"ࠬࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣࡆ࡛ࡔࡐࡏࡄࡘࡎࡕࡎࠨర"): bstack1l11ll11l_opy_
    })
  elif bstack1111lll11_opy_ == bstack11l11ll_opy_ (u"࠭ࡢࡦࡪࡤࡺࡪ࠭ఱ"):
    try:
      from behave.__main__ import main as bstack1lll1l1lll_opy_
      from behave.configuration import Configuration
    except Exception as e:
      bstack1ll1l11l11_opy_(e, bstack1l1l11ll1_opy_)
    bstack1l111111_opy_()
    bstack11ll1l11_opy_ = True
    bstack1ll1ll11_opy_ = 1
    if bstack11l11ll_opy_ (u"ࠧࡱࡣࡵࡥࡱࡲࡥ࡭ࡵࡓࡩࡷࡖ࡬ࡢࡶࡩࡳࡷࡳࠧల") in CONFIG:
      bstack1ll1ll11_opy_ = CONFIG[bstack11l11ll_opy_ (u"ࠨࡲࡤࡶࡦࡲ࡬ࡦ࡮ࡶࡔࡪࡸࡐ࡭ࡣࡷࡪࡴࡸ࡭ࠨళ")]
    bstack1l11l1ll1_opy_ = int(bstack1ll1ll11_opy_) * int(len(CONFIG[bstack11l11ll_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࡷࠬఴ")]))
    config = Configuration(args)
    bstack1l11111l1_opy_ = config.paths
    if len(bstack1l11111l1_opy_) == 0:
      import glob
      pattern = bstack11l11ll_opy_ (u"ࠪ࠮࠯࠵ࠪ࠯ࡨࡨࡥࡹࡻࡲࡦࠩవ")
      bstack1l1l1lll1_opy_ = glob.glob(pattern, recursive=True)
      args.extend(bstack1l1l1lll1_opy_)
      config = Configuration(args)
      bstack1l11111l1_opy_ = config.paths
    bstack1ll1llll_opy_ = [os.path.normpath(item) for item in bstack1l11111l1_opy_]
    bstack11l1111l1_opy_ = [os.path.normpath(item) for item in args]
    bstack11l1l11l1_opy_ = [item for item in bstack11l1111l1_opy_ if item not in bstack1ll1llll_opy_]
    import platform as pf
    if pf.system().lower() == bstack11l11ll_opy_ (u"ࠫࡼ࡯࡮ࡥࡱࡺࡷࠬశ"):
      from pathlib import PureWindowsPath, PurePosixPath
      bstack1ll1llll_opy_ = [str(PurePosixPath(PureWindowsPath(bstack1l1llll11_opy_)))
                    for bstack1l1llll11_opy_ in bstack1ll1llll_opy_]
    bstack1ll1lll1_opy_ = []
    for spec in bstack1ll1llll_opy_:
      bstack1llll11l_opy_ = []
      bstack1llll11l_opy_ += bstack11l1l11l1_opy_
      bstack1llll11l_opy_.append(spec)
      bstack1ll1lll1_opy_.append(bstack1llll11l_opy_)
    execution_items = []
    for bstack1llll11l_opy_ in bstack1ll1lll1_opy_:
      for index, _ in enumerate(CONFIG[bstack11l11ll_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡳࠨష")]):
        item = {}
        item[bstack11l11ll_opy_ (u"࠭ࡡࡳࡩࠪస")] = bstack11l11ll_opy_ (u"ࠧࠡࠩహ").join(bstack1llll11l_opy_)
        item[bstack11l11ll_opy_ (u"ࠨ࡫ࡱࡨࡪࡾࠧ఺")] = index
        execution_items.append(item)
    bstack1lll1lll11_opy_ = bstack1ll111l1_opy_(execution_items, bstack1l11l1ll1_opy_)
    for execution_item in bstack1lll1lll11_opy_:
      bstack1lll11l1_opy_ = []
      for item in execution_item:
        bstack1lll11l1_opy_.append(bstack11ll11l11_opy_(name=str(item[bstack11l11ll_opy_ (u"ࠩ࡬ࡲࡩ࡫ࡸࠨ఻")]),
                                             target=bstack1l11111ll_opy_,
                                             args=(item[bstack11l11ll_opy_ (u"ࠪࡥࡷ࡭఼ࠧ")],)))
      for t in bstack1lll11l1_opy_:
        t.start()
      for t in bstack1lll11l1_opy_:
        t.join()
  else:
    bstack1l1ll1ll_opy_(bstack11l11ll11_opy_)
  if not bstack1ll11l111l_opy_:
    bstack11111l1ll_opy_()
def browserstack_initialize(bstack1l11llll_opy_=None):
  run_on_browserstack(bstack1l11llll_opy_, None, True)
def bstack11111l1ll_opy_():
  global CONFIG
  bstack1ll1lll1ll_opy_.stop()
  bstack1ll1lll1ll_opy_.bstack111l1l1ll_opy_()
  if bstack11lllll1l_opy_.bstack1111ll111_opy_(CONFIG):
    bstack11lllll1l_opy_.bstack1llll1111l_opy_()
  [bstack1lllllllll_opy_, bstack11l1ll1ll_opy_] = bstack1ll1ll111_opy_()
  if bstack1lllllllll_opy_ is not None and bstack1ll111l111_opy_() != -1:
    sessions = bstack1ll11l1ll_opy_(bstack1lllllllll_opy_)
    bstack1ll1ll1l1_opy_(sessions, bstack11l1ll1ll_opy_)
def bstack11llllll_opy_(bstack1l1ll111_opy_):
  if bstack1l1ll111_opy_:
    return bstack1l1ll111_opy_.capitalize()
  else:
    return bstack1l1ll111_opy_
def bstack11l111lll_opy_(bstack111l1l11l_opy_):
  if bstack11l11ll_opy_ (u"ࠫࡳࡧ࡭ࡦࠩఽ") in bstack111l1l11l_opy_ and bstack111l1l11l_opy_[bstack11l11ll_opy_ (u"ࠬࡴࡡ࡮ࡧࠪా")] != bstack11l11ll_opy_ (u"࠭ࠧి"):
    return bstack111l1l11l_opy_[bstack11l11ll_opy_ (u"ࠧ࡯ࡣࡰࡩࠬీ")]
  else:
    bstack1llllllll1_opy_ = bstack11l11ll_opy_ (u"ࠣࠤు")
    if bstack11l11ll_opy_ (u"ࠩࡧࡩࡻ࡯ࡣࡦࠩూ") in bstack111l1l11l_opy_ and bstack111l1l11l_opy_[bstack11l11ll_opy_ (u"ࠪࡨࡪࡼࡩࡤࡧࠪృ")] != None:
      bstack1llllllll1_opy_ += bstack111l1l11l_opy_[bstack11l11ll_opy_ (u"ࠫࡩ࡫ࡶࡪࡥࡨࠫౄ")] + bstack11l11ll_opy_ (u"ࠧ࠲ࠠࠣ౅")
      if bstack111l1l11l_opy_[bstack11l11ll_opy_ (u"࠭࡯ࡴࠩె")] == bstack11l11ll_opy_ (u"ࠢࡪࡱࡶࠦే"):
        bstack1llllllll1_opy_ += bstack11l11ll_opy_ (u"ࠣ࡫ࡒࡗࠥࠨై")
      bstack1llllllll1_opy_ += (bstack111l1l11l_opy_[bstack11l11ll_opy_ (u"ࠩࡲࡷࡤࡼࡥࡳࡵ࡬ࡳࡳ࠭౉")] or bstack11l11ll_opy_ (u"ࠪࠫొ"))
      return bstack1llllllll1_opy_
    else:
      bstack1llllllll1_opy_ += bstack11llllll_opy_(bstack111l1l11l_opy_[bstack11l11ll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࠬో")]) + bstack11l11ll_opy_ (u"ࠧࠦࠢౌ") + (
              bstack111l1l11l_opy_[bstack11l11ll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸ࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࠨ్")] or bstack11l11ll_opy_ (u"ࠧࠨ౎")) + bstack11l11ll_opy_ (u"ࠣ࠮ࠣࠦ౏")
      if bstack111l1l11l_opy_[bstack11l11ll_opy_ (u"ࠩࡲࡷࠬ౐")] == bstack11l11ll_opy_ (u"࡛ࠥ࡮ࡴࡤࡰࡹࡶࠦ౑"):
        bstack1llllllll1_opy_ += bstack11l11ll_opy_ (u"ࠦ࡜࡯࡮ࠡࠤ౒")
      bstack1llllllll1_opy_ += bstack111l1l11l_opy_[bstack11l11ll_opy_ (u"ࠬࡵࡳࡠࡸࡨࡶࡸ࡯࡯࡯ࠩ౓")] or bstack11l11ll_opy_ (u"࠭ࠧ౔")
      return bstack1llllllll1_opy_
def bstack1ll11l111_opy_(bstack1llll111l1_opy_):
  if bstack1llll111l1_opy_ == bstack11l11ll_opy_ (u"ࠢࡥࡱࡱࡩౕࠧ"):
    return bstack11l11ll_opy_ (u"ࠨ࠾ࡷࡨࠥࡩ࡬ࡢࡵࡶࡁࠧࡨࡳࡵࡣࡦ࡯࠲ࡪࡡࡵࡣࠥࠤࡸࡺࡹ࡭ࡧࡀࠦࡨࡵ࡬ࡰࡴ࠽࡫ࡷ࡫ࡥ࡯࠽ࠥࡂࡁ࡬࡯࡯ࡶࠣࡧࡴࡲ࡯ࡳ࠿ࠥ࡫ࡷ࡫ࡥ࡯ࠤࡁࡇࡴࡳࡰ࡭ࡧࡷࡩࡩࡂ࠯ࡧࡱࡱࡸࡃࡂ࠯ࡵࡦࡁౖࠫ")
  elif bstack1llll111l1_opy_ == bstack11l11ll_opy_ (u"ࠤࡩࡥ࡮ࡲࡥࡥࠤ౗"):
    return bstack11l11ll_opy_ (u"ࠪࡀࡹࡪࠠࡤ࡮ࡤࡷࡸࡃࠢࡣࡵࡷࡥࡨࡱ࠭ࡥࡣࡷࡥࠧࠦࡳࡵࡻ࡯ࡩࡂࠨࡣࡰ࡮ࡲࡶ࠿ࡸࡥࡥ࠽ࠥࡂࡁ࡬࡯࡯ࡶࠣࡧࡴࡲ࡯ࡳ࠿ࠥࡶࡪࡪࠢ࠿ࡈࡤ࡭ࡱ࡫ࡤ࠽࠱ࡩࡳࡳࡺ࠾࠽࠱ࡷࡨࡃ࠭ౘ")
  elif bstack1llll111l1_opy_ == bstack11l11ll_opy_ (u"ࠦࡵࡧࡳࡴࡧࡧࠦౙ"):
    return bstack11l11ll_opy_ (u"ࠬࡂࡴࡥࠢࡦࡰࡦࡹࡳ࠾ࠤࡥࡷࡹࡧࡣ࡬࠯ࡧࡥࡹࡧࠢࠡࡵࡷࡽࡱ࡫࠽ࠣࡥࡲࡰࡴࡸ࠺ࡨࡴࡨࡩࡳࡁࠢ࠿࠾ࡩࡳࡳࡺࠠࡤࡱ࡯ࡳࡷࡃࠢࡨࡴࡨࡩࡳࠨ࠾ࡑࡣࡶࡷࡪࡪ࠼࠰ࡨࡲࡲࡹࡄ࠼࠰ࡶࡧࡂࠬౚ")
  elif bstack1llll111l1_opy_ == bstack11l11ll_opy_ (u"ࠨࡥࡳࡴࡲࡶࠧ౛"):
    return bstack11l11ll_opy_ (u"ࠧ࠽ࡶࡧࠤࡨࡲࡡࡴࡵࡀࠦࡧࡹࡴࡢࡥ࡮࠱ࡩࡧࡴࡢࠤࠣࡷࡹࡿ࡬ࡦ࠿ࠥࡧࡴࡲ࡯ࡳ࠼ࡵࡩࡩࡁࠢ࠿࠾ࡩࡳࡳࡺࠠࡤࡱ࡯ࡳࡷࡃࠢࡳࡧࡧࠦࡃࡋࡲࡳࡱࡵࡀ࠴࡬࡯࡯ࡶࡁࡀ࠴ࡺࡤ࠿ࠩ౜")
  elif bstack1llll111l1_opy_ == bstack11l11ll_opy_ (u"ࠣࡶ࡬ࡱࡪࡵࡵࡵࠤౝ"):
    return bstack11l11ll_opy_ (u"ࠩ࠿ࡸࡩࠦࡣ࡭ࡣࡶࡷࡂࠨࡢࡴࡶࡤࡧࡰ࠳ࡤࡢࡶࡤࠦࠥࡹࡴࡺ࡮ࡨࡁࠧࡩ࡯࡭ࡱࡵ࠾ࠨ࡫ࡥࡢ࠵࠵࠺ࡀࠨ࠾࠽ࡨࡲࡲࡹࠦࡣࡰ࡮ࡲࡶࡂࠨࠣࡦࡧࡤ࠷࠷࠼ࠢ࠿ࡖ࡬ࡱࡪࡵࡵࡵ࠾࠲ࡪࡴࡴࡴ࠿࠾࠲ࡸࡩࡄࠧ౞")
  elif bstack1llll111l1_opy_ == bstack11l11ll_opy_ (u"ࠥࡶࡺࡴ࡮ࡪࡰࡪࠦ౟"):
    return bstack11l11ll_opy_ (u"ࠫࡁࡺࡤࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡤࡶࡸࡦࡩ࡫࠮ࡦࡤࡸࡦࠨࠠࡴࡶࡼࡰࡪࡃࠢࡤࡱ࡯ࡳࡷࡀࡢ࡭ࡣࡦ࡯ࡀࠨ࠾࠽ࡨࡲࡲࡹࠦࡣࡰ࡮ࡲࡶࡂࠨࡢ࡭ࡣࡦ࡯ࠧࡄࡒࡶࡰࡱ࡭ࡳ࡭࠼࠰ࡨࡲࡲࡹࡄ࠼࠰ࡶࡧࡂࠬౠ")
  else:
    return bstack11l11ll_opy_ (u"ࠬࡂࡴࡥࠢࡤࡰ࡮࡭࡮࠾ࠤࡦࡩࡳࡺࡥࡳࠤࠣࡧࡱࡧࡳࡴ࠿ࠥࡦࡸࡺࡡࡤ࡭࠰ࡨࡦࡺࡡࠣࠢࡶࡸࡾࡲࡥ࠾ࠤࡦࡳࡱࡵࡲ࠻ࡤ࡯ࡥࡨࡱ࠻ࠣࡀ࠿ࡪࡴࡴࡴࠡࡥࡲࡰࡴࡸ࠽ࠣࡤ࡯ࡥࡨࡱࠢ࠿ࠩౡ") + bstack11llllll_opy_(
      bstack1llll111l1_opy_) + bstack11l11ll_opy_ (u"࠭࠼࠰ࡨࡲࡲࡹࡄ࠼࠰ࡶࡧࡂࠬౢ")
def bstack1lll111l1l_opy_(session):
  return bstack11l11ll_opy_ (u"ࠧ࠽ࡶࡵࠤࡨࡲࡡࡴࡵࡀࠦࡧࡹࡴࡢࡥ࡮࠱ࡷࡵࡷࠣࡀ࠿ࡸࡩࠦࡣ࡭ࡣࡶࡷࡂࠨࡢࡴࡶࡤࡧࡰ࠳ࡤࡢࡶࡤࠤࡸ࡫ࡳࡴ࡫ࡲࡲ࠲ࡴࡡ࡮ࡧࠥࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࡻࡾࠤࠣࡸࡦࡸࡧࡦࡶࡀࠦࡤࡨ࡬ࡢࡰ࡮ࠦࡃࢁࡽ࠽࠱ࡤࡂࡁ࠵ࡴࡥࡀࡾࢁࢀࢃ࠼ࡵࡦࠣࡥࡱ࡯ࡧ࡯࠿ࠥࡧࡪࡴࡴࡦࡴࠥࠤࡨࡲࡡࡴࡵࡀࠦࡧࡹࡴࡢࡥ࡮࠱ࡩࡧࡴࡢࠤࡁࡿࢂࡂ࠯ࡵࡦࡁࡀࡹࡪࠠࡢ࡮࡬࡫ࡳࡃࠢࡤࡧࡱࡸࡪࡸࠢࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡤࡶࡸࡦࡩ࡫࠮ࡦࡤࡸࡦࠨ࠾ࡼࡿ࠿࠳ࡹࡪ࠾࠽ࡶࡧࠤࡦࡲࡩࡨࡰࡀࠦࡨ࡫࡮ࡵࡧࡵࠦࠥࡩ࡬ࡢࡵࡶࡁࠧࡨࡳࡵࡣࡦ࡯࠲ࡪࡡࡵࡣࠥࡂࢀࢃ࠼࠰ࡶࡧࡂࡁࡺࡤࠡࡣ࡯࡭࡬ࡴ࠽ࠣࡥࡨࡲࡹ࡫ࡲࠣࠢࡦࡰࡦࡹࡳ࠾ࠤࡥࡷࡹࡧࡣ࡬࠯ࡧࡥࡹࡧࠢ࠿ࡽࢀࡀ࠴ࡺࡤ࠿࠾࠲ࡸࡷࡄࠧౣ").format(
    session[bstack11l11ll_opy_ (u"ࠨࡲࡸࡦࡱ࡯ࡣࡠࡷࡵࡰࠬ౤")], bstack11l111lll_opy_(session), bstack1ll11l111_opy_(session[bstack11l11ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡠࡵࡷࡥࡹࡻࡳࠨ౥")]),
    bstack1ll11l111_opy_(session[bstack11l11ll_opy_ (u"ࠪࡷࡹࡧࡴࡶࡵࠪ౦")]),
    bstack11llllll_opy_(session[bstack11l11ll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࠬ౧")] or session[bstack11l11ll_opy_ (u"ࠬࡪࡥࡷ࡫ࡦࡩࠬ౨")] or bstack11l11ll_opy_ (u"࠭ࠧ౩")) + bstack11l11ll_opy_ (u"ࠢࠡࠤ౪") + (session[bstack11l11ll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡡࡹࡩࡷࡹࡩࡰࡰࠪ౫")] or bstack11l11ll_opy_ (u"ࠩࠪ౬")),
    session[bstack11l11ll_opy_ (u"ࠪࡳࡸ࠭౭")] + bstack11l11ll_opy_ (u"ࠦࠥࠨ౮") + session[bstack11l11ll_opy_ (u"ࠬࡵࡳࡠࡸࡨࡶࡸ࡯࡯࡯ࠩ౯")], session[bstack11l11ll_opy_ (u"࠭ࡤࡶࡴࡤࡸ࡮ࡵ࡮ࠨ౰")] or bstack11l11ll_opy_ (u"ࠧࠨ౱"),
    session[bstack11l11ll_opy_ (u"ࠨࡥࡵࡩࡦࡺࡥࡥࡡࡤࡸࠬ౲")] if session[bstack11l11ll_opy_ (u"ࠩࡦࡶࡪࡧࡴࡦࡦࡢࡥࡹ࠭౳")] else bstack11l11ll_opy_ (u"ࠪࠫ౴"))
def bstack1ll1ll1l1_opy_(sessions, bstack11l1ll1ll_opy_):
  try:
    bstack111ll1111_opy_ = bstack11l11ll_opy_ (u"ࠦࠧ౵")
    if not os.path.exists(bstack1ll11lllll_opy_):
      os.mkdir(bstack1ll11lllll_opy_)
    with open(os.path.join(os.path.dirname(os.path.realpath(__file__)), bstack11l11ll_opy_ (u"ࠬࡧࡳࡴࡧࡷࡷ࠴ࡸࡥࡱࡱࡵࡸ࠳࡮ࡴ࡮࡮ࠪ౶")), bstack11l11ll_opy_ (u"࠭ࡲࠨ౷")) as f:
      bstack111ll1111_opy_ = f.read()
    bstack111ll1111_opy_ = bstack111ll1111_opy_.replace(bstack11l11ll_opy_ (u"ࠧࡼࠧࡕࡉࡘ࡛ࡌࡕࡕࡢࡇࡔ࡛ࡎࡕࠧࢀࠫ౸"), str(len(sessions)))
    bstack111ll1111_opy_ = bstack111ll1111_opy_.replace(bstack11l11ll_opy_ (u"ࠨࡽࠨࡆ࡚ࡏࡌࡅࡡࡘࡖࡑࠫࡽࠨ౹"), bstack11l1ll1ll_opy_)
    bstack111ll1111_opy_ = bstack111ll1111_opy_.replace(bstack11l11ll_opy_ (u"ࠩࡾࠩࡇ࡛ࡉࡍࡆࡢࡒࡆࡓࡅࠦࡿࠪ౺"),
                                              sessions[0].get(bstack11l11ll_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡡࡱࡥࡲ࡫ࠧ౻")) if sessions[0] else bstack11l11ll_opy_ (u"ࠫࠬ౼"))
    with open(os.path.join(bstack1ll11lllll_opy_, bstack11l11ll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮࠱ࡷ࡫ࡰࡰࡴࡷ࠲࡭ࡺ࡭࡭ࠩ౽")), bstack11l11ll_opy_ (u"࠭ࡷࠨ౾")) as stream:
      stream.write(bstack111ll1111_opy_.split(bstack11l11ll_opy_ (u"ࠧࡼࠧࡖࡉࡘ࡙ࡉࡐࡐࡖࡣࡉࡇࡔࡂࠧࢀࠫ౿"))[0])
      for session in sessions:
        stream.write(bstack1lll111l1l_opy_(session))
      stream.write(bstack111ll1111_opy_.split(bstack11l11ll_opy_ (u"ࠨࡽࠨࡗࡊ࡙ࡓࡊࡑࡑࡗࡤࡊࡁࡕࡃࠨࢁࠬಀ"))[1])
    logger.info(bstack11l11ll_opy_ (u"ࠩࡊࡩࡳ࡫ࡲࡢࡶࡨࡨࠥࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࠤࡧࡻࡩ࡭ࡦࠣࡥࡷࡺࡩࡧࡣࡦࡸࡸࠦࡡࡵࠢࡾࢁࠬಁ").format(bstack1ll11lllll_opy_));
  except Exception as e:
    logger.debug(bstack1lll1l1ll_opy_.format(str(e)))
def bstack1ll11l1ll_opy_(bstack1lllllllll_opy_):
  global CONFIG
  try:
    host = bstack11l11ll_opy_ (u"ࠪࡥࡵ࡯࠭ࡤ࡮ࡲࡹࡩ࠭ಂ") if bstack11l11ll_opy_ (u"ࠫࡦࡶࡰࠨಃ") in CONFIG else bstack11l11ll_opy_ (u"ࠬࡧࡰࡪࠩ಄")
    user = CONFIG[bstack11l11ll_opy_ (u"࠭ࡵࡴࡧࡵࡒࡦࡳࡥࠨಅ")]
    key = CONFIG[bstack11l11ll_opy_ (u"ࠧࡢࡥࡦࡩࡸࡹࡋࡦࡻࠪಆ")]
    bstack1l111l11l_opy_ = bstack11l11ll_opy_ (u"ࠨࡣࡳࡴ࠲ࡧࡵࡵࡱࡰࡥࡹ࡫ࠧಇ") if bstack11l11ll_opy_ (u"ࠩࡤࡴࡵ࠭ಈ") in CONFIG else bstack11l11ll_opy_ (u"ࠪࡥࡺࡺ࡯࡮ࡣࡷࡩࠬಉ")
    url = bstack11l11ll_opy_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࢁࡽ࠻ࡽࢀࡄࢀࢃ࠮ࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠴ࡣࡰ࡯࠲ࡿࢂ࠵ࡢࡶ࡫࡯ࡨࡸ࠵ࡻࡾ࠱ࡶࡩࡸࡹࡩࡰࡰࡶ࠲࡯ࡹ࡯࡯ࠩಊ").format(user, key, host, bstack1l111l11l_opy_,
                                                                                bstack1lllllllll_opy_)
    headers = {
      bstack11l11ll_opy_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡴࡺࡲࡨࠫಋ"): bstack11l11ll_opy_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳࡯ࡹ࡯࡯ࠩಌ"),
    }
    proxies = bstack111l11ll_opy_(CONFIG, url)
    response = requests.get(url, headers=headers, proxies=proxies)
    if response.json():
      return list(map(lambda session: session[bstack11l11ll_opy_ (u"ࠧࡢࡷࡷࡳࡲࡧࡴࡪࡱࡱࡣࡸ࡫ࡳࡴ࡫ࡲࡲࠬ಍")], response.json()))
  except Exception as e:
    logger.debug(bstack11ll1l111_opy_.format(str(e)))
def bstack1ll1ll111_opy_():
  global CONFIG
  try:
    if bstack11l11ll_opy_ (u"ࠨࡤࡸ࡭ࡱࡪࡎࡢ࡯ࡨࠫಎ") in CONFIG:
      host = bstack11l11ll_opy_ (u"ࠩࡤࡴ࡮࠳ࡣ࡭ࡱࡸࡨࠬಏ") if bstack11l11ll_opy_ (u"ࠪࡥࡵࡶࠧಐ") in CONFIG else bstack11l11ll_opy_ (u"ࠫࡦࡶࡩࠨ಑")
      user = CONFIG[bstack11l11ll_opy_ (u"ࠬࡻࡳࡦࡴࡑࡥࡲ࡫ࠧಒ")]
      key = CONFIG[bstack11l11ll_opy_ (u"࠭ࡡࡤࡥࡨࡷࡸࡑࡥࡺࠩಓ")]
      bstack1l111l11l_opy_ = bstack11l11ll_opy_ (u"ࠧࡢࡲࡳ࠱ࡦࡻࡴࡰ࡯ࡤࡸࡪ࠭ಔ") if bstack11l11ll_opy_ (u"ࠨࡣࡳࡴࠬಕ") in CONFIG else bstack11l11ll_opy_ (u"ࠩࡤࡹࡹࡵ࡭ࡢࡶࡨࠫಖ")
      url = bstack11l11ll_opy_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࢀࢃ࠺ࡼࡿࡃࡿࢂ࠴ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯࠳ࡩ࡯࡮࠱ࡾࢁ࠴ࡨࡵࡪ࡮ࡧࡷ࠳ࡰࡳࡰࡰࠪಗ").format(user, key, host, bstack1l111l11l_opy_)
      headers = {
        bstack11l11ll_opy_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲ࡺࡹࡱࡧࠪಘ"): bstack11l11ll_opy_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲࡮ࡸࡵ࡮ࠨಙ"),
      }
      if bstack11l11ll_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡎࡪࡥ࡯ࡶ࡬ࡪ࡮࡫ࡲࠨಚ") in CONFIG:
        params = {bstack11l11ll_opy_ (u"ࠧ࡯ࡣࡰࡩࠬಛ"): CONFIG[bstack11l11ll_opy_ (u"ࠨࡤࡸ࡭ࡱࡪࡎࡢ࡯ࡨࠫಜ")], bstack11l11ll_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡠ࡫ࡧࡩࡳࡺࡩࡧ࡫ࡨࡶࠬಝ"): CONFIG[bstack11l11ll_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡋࡧࡩࡳࡺࡩࡧ࡫ࡨࡶࠬಞ")]}
      else:
        params = {bstack11l11ll_opy_ (u"ࠫࡳࡧ࡭ࡦࠩಟ"): CONFIG[bstack11l11ll_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡒࡦࡳࡥࠨಠ")]}
      proxies = bstack111l11ll_opy_(CONFIG, url)
      response = requests.get(url, params=params, headers=headers, proxies=proxies)
      if response.json():
        bstack11llll1l1_opy_ = response.json()[0][bstack11l11ll_opy_ (u"࠭ࡡࡶࡶࡲࡱࡦࡺࡩࡰࡰࡢࡦࡺ࡯࡬ࡥࠩಡ")]
        if bstack11llll1l1_opy_:
          bstack11l1ll1ll_opy_ = bstack11llll1l1_opy_[bstack11l11ll_opy_ (u"ࠧࡱࡷࡥࡰ࡮ࡩ࡟ࡶࡴ࡯ࠫಢ")].split(bstack11l11ll_opy_ (u"ࠨࡲࡸࡦࡱ࡯ࡣ࠮ࡤࡸ࡭ࡱࡪࠧಣ"))[0] + bstack11l11ll_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡴ࠱ࠪತ") + bstack11llll1l1_opy_[
            bstack11l11ll_opy_ (u"ࠪ࡬ࡦࡹࡨࡦࡦࡢ࡭ࡩ࠭ಥ")]
          logger.info(bstack11ll11ll_opy_.format(bstack11l1ll1ll_opy_))
          bstack111ll11ll_opy_ = CONFIG[bstack11l11ll_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡑࡥࡲ࡫ࠧದ")]
          if bstack11l11ll_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡍࡩ࡫࡮ࡵ࡫ࡩ࡭ࡪࡸࠧಧ") in CONFIG:
            bstack111ll11ll_opy_ += bstack11l11ll_opy_ (u"࠭ࠠࠨನ") + CONFIG[bstack11l11ll_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡏࡤࡦࡰࡷ࡭࡫࡯ࡥࡳࠩ಩")]
          if bstack111ll11ll_opy_ != bstack11llll1l1_opy_[bstack11l11ll_opy_ (u"ࠨࡰࡤࡱࡪ࠭ಪ")]:
            logger.debug(bstack11lll1ll1_opy_.format(bstack11llll1l1_opy_[bstack11l11ll_opy_ (u"ࠩࡱࡥࡲ࡫ࠧಫ")], bstack111ll11ll_opy_))
          return [bstack11llll1l1_opy_[bstack11l11ll_opy_ (u"ࠪ࡬ࡦࡹࡨࡦࡦࡢ࡭ࡩ࠭ಬ")], bstack11l1ll1ll_opy_]
    else:
      logger.warn(bstack1llll1ll1_opy_)
  except Exception as e:
    logger.debug(bstack1ll11l1l11_opy_.format(str(e)))
  return [None, None]
def bstack1lllll1l1_opy_(url, bstack111111l1l_opy_=False):
  global CONFIG
  global bstack11l1l1111_opy_
  if not bstack11l1l1111_opy_:
    hostname = bstack11l1l1l11_opy_(url)
    is_private = bstack1l11l1ll_opy_(hostname)
    if (bstack11l11ll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡏࡳࡨࡧ࡬ࠨಭ") in CONFIG and not CONFIG[bstack11l11ll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡐࡴࡩࡡ࡭ࠩಮ")]) and (is_private or bstack111111l1l_opy_):
      bstack11l1l1111_opy_ = hostname
def bstack11l1l1l11_opy_(url):
  return urlparse(url).hostname
def bstack1l11l1ll_opy_(hostname):
  for bstack11lll1l11_opy_ in bstack111111lll_opy_:
    regex = re.compile(bstack11lll1l11_opy_)
    if regex.match(hostname):
      return True
  return False
def bstack1ll1ll1111_opy_(key_name):
  return True if key_name in threading.current_thread().__dict__.keys() else False
def getAccessibilityResults(driver):
  global CONFIG
  global bstack111l11l1_opy_
  if not bstack11lllll1l_opy_.bstack1lllll11l1_opy_(CONFIG, bstack111l11l1_opy_):
    logger.warning(bstack11l11ll_opy_ (u"ࠨࡎࡰࡶࠣࡥࡳࠦࡁࡤࡥࡨࡷࡸ࡯ࡢࡪ࡮࡬ࡸࡾࠦࡁࡶࡶࡲࡱࡦࡺࡩࡰࡰࠣࡷࡪࡹࡳࡪࡱࡱ࠰ࠥࡩࡡ࡯ࡰࡲࡸࠥࡸࡥࡵࡴ࡬ࡩࡻ࡫ࠠࡂࡥࡦࡩࡸࡹࡩࡣ࡫࡯࡭ࡹࡿࠠࡳࡧࡶࡹࡱࡺࡳ࠯ࠤಯ"))
    return {}
  try:
    results = driver.execute_script(bstack11l11ll_opy_ (u"ࠢࠣࠤࠍࠤࠥࠦࠠࠡࠢࠣࠤࡷ࡫ࡴࡶࡴࡱࠤࡳ࡫ࡷࠡࡒࡵࡳࡲ࡯ࡳࡦࠪࡩࡹࡳࡩࡴࡪࡱࡱࠤ࠭ࡸࡥࡴࡱ࡯ࡺࡪ࠲ࠠࡳࡧ࡭ࡩࡨࡺࠩࠡࡽࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࡶࡵࡽࠥࢁࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࡦࡳࡳࡹࡴࠡࡧࡹࡩࡳࡺࠠ࠾ࠢࡱࡩࡼࠦࡃࡶࡵࡷࡳࡲࡋࡶࡦࡰࡷࠬࠬࡇ࠱࠲࡛ࡢࡘࡆࡖ࡟ࡈࡇࡗࡣࡗࡋࡓࡖࡎࡗࡗࠬ࠯࠻ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࡧࡴࡴࡳࡵࠢࡩࡲࠥࡃࠠࡧࡷࡱࡧࡹ࡯࡯࡯ࠢࠫࡩࡻ࡫࡮ࡵࠫࠣࡿࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡼ࡯࡮ࡥࡱࡺ࠲ࡷ࡫࡭ࡰࡸࡨࡉࡻ࡫࡮ࡵࡎ࡬ࡷࡹ࡫࡮ࡦࡴࠫࠫࡆ࠷࠱࡚ࡡࡕࡉࡘ࡛ࡌࡕࡕࡢࡖࡊ࡙ࡐࡐࡐࡖࡉࠬ࠲ࠠࡧࡰࠬ࠿ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡷ࡫ࡳࡰ࡮ࡹࡩ࠭࡫ࡶࡦࡰࡷ࠲ࡩ࡫ࡴࡢ࡫࡯࠲ࡩࡧࡴࡢࠫ࠾ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡽ࠼ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡼ࡯࡮ࡥࡱࡺ࠲ࡦࡪࡤࡆࡸࡨࡲࡹࡒࡩࡴࡶࡨࡲࡪࡸࠨࠨࡃ࠴࠵࡞ࡥࡒࡆࡕࡘࡐ࡙࡙࡟ࡓࡇࡖࡔࡔࡔࡓࡆࠩ࠯ࠤ࡫ࡴࠩ࠼ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡼ࡯࡮ࡥࡱࡺ࠲ࡩ࡯ࡳࡱࡣࡷࡧ࡭ࡋࡶࡦࡰࡷࠬࡪࡼࡥ࡯ࡶࠬ࠿ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࢁࠥࡩࡡࡵࡥ࡫ࠤࢀࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࡴࡨ࡮ࡪࡩࡴࠩࠫ࠾ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࢀࠎࠥࠦࠠࠡࠢࠣࠤࠥࢃࠩ࠼ࠌࠣࠤࠥࠦࠢࠣࠤರ"))
    return results
  except Exception:
    logger.error(bstack11l11ll_opy_ (u"ࠣࡐࡲࠤࡦࡩࡣࡦࡵࡶ࡭ࡧ࡯࡬ࡪࡶࡼࠤࡷ࡫ࡳࡶ࡮ࡷࡷࠥࡽࡥࡳࡧࠣࡪࡴࡻ࡮ࡥ࠰ࠥಱ"))
    return {}
def getAccessibilityResultsSummary(driver):
  global CONFIG
  global bstack111l11l1_opy_
  if not bstack11lllll1l_opy_.bstack1lllll11l1_opy_(CONFIG, bstack111l11l1_opy_):
    logger.warning(bstack11l11ll_opy_ (u"ࠤࡑࡳࡹࠦࡡ࡯ࠢࡄࡧࡨ࡫ࡳࡴ࡫ࡥ࡭ࡱ࡯ࡴࡺࠢࡄࡹࡹࡵ࡭ࡢࡶ࡬ࡳࡳࠦࡳࡦࡵࡶ࡭ࡴࡴࠬࠡࡥࡤࡲࡳࡵࡴࠡࡴࡨࡸࡷ࡯ࡥࡷࡧࠣࡅࡨࡩࡥࡴࡵ࡬ࡦ࡮ࡲࡩࡵࡻࠣࡶࡪࡹࡵ࡭ࡶࡶࠤࡸࡻ࡭࡮ࡣࡵࡽ࠳ࠨಲ"))
    return {}
  try:
    bstack1l1l1l11l_opy_ = driver.execute_script(bstack11l11ll_opy_ (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡳࡧࡷࡹࡷࡴࠠ࡯ࡧࡺࠤࡕࡸ࡯࡮࡫ࡶࡩ࠭࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠠࠩࡴࡨࡷࡴࡲࡶࡦ࠮ࠣࡶࡪࡰࡥࡤࡶࠬࠤࢀࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡹࡸࡹࠡࡽࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡩ࡯࡯ࡵࡷࠤࡪࡼࡥ࡯ࡶࠣࡁࠥࡴࡥࡸࠢࡆࡹࡸࡺ࡯࡮ࡇࡹࡩࡳࡺࠨࠨࡃ࠴࠵࡞ࡥࡔࡂࡒࡢࡋࡊ࡚࡟ࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡕࡘࡑࡒࡇࡒ࡚ࠩࠬ࠿ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࡤࡱࡱࡷࡹࠦࡦ࡯ࠢࡀࠤ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳࠦࠨࡦࡸࡨࡲࡹ࠯ࠠࡼࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࡹ࡬ࡲࡩࡵࡷ࠯ࡴࡨࡱࡴࡼࡥࡆࡸࡨࡲࡹࡒࡩࡴࡶࡨࡲࡪࡸࠨࠨࡃ࠴࠵࡞ࡥࡒࡆࡕࡘࡐ࡙࡙࡟ࡔࡗࡐࡑࡆࡘ࡙ࡠࡔࡈࡗࡕࡕࡎࡔࡇࠪ࠰ࠥ࡬࡮ࠪ࠽ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࡵࡩࡸࡵ࡬ࡷࡧࠫࡩࡻ࡫࡮ࡵ࠰ࡧࡩࡹࡧࡩ࡭࠰ࡶࡹࡲࡳࡡࡳࡻࠬ࠿ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࡾ࠽ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡽࡩ࡯ࡦࡲࡻ࠳ࡧࡤࡥࡇࡹࡩࡳࡺࡌࡪࡵࡷࡩࡳ࡫ࡲࠩࠩࡄ࠵࠶࡟࡟ࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡕࡘࡑࡒࡇࡒ࡚ࡡࡕࡉࡘࡖࡏࡏࡕࡈࠫ࠱ࠦࡦ࡯ࠫ࠾ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡷࡪࡰࡧࡳࡼ࠴ࡤࡪࡵࡳࡥࡹࡩࡨࡆࡸࡨࡲࡹ࠮ࡥࡷࡧࡱࡸ࠮ࡁࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࢃࠠࡤࡣࡷࡧ࡭ࠦࡻࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࡶࡪࡰࡥࡤࡶࠫ࠭ࡀࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࢂࠐࠠࠡࠢࠣࠤࠥࠦࠠࡾࠫ࠾ࠎࠥࠦࠠࠡࠤࠥࠦಳ"))
    return bstack1l1l1l11l_opy_
  except Exception:
    logger.error(bstack11l11ll_opy_ (u"ࠦࡓࡵࠠࡢࡥࡦࡩࡸࡹࡩࡣ࡫࡯࡭ࡹࡿࠠࡴࡷࡰࡱࡦࡸࡹࠡࡹࡤࡷࠥ࡬࡯ࡶࡰࡧ࠲ࠧ಴"))
    return {}