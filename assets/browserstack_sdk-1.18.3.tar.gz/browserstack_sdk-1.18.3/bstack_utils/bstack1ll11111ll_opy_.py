# coding: UTF-8
import sys
bstack111llll_opy_ = sys.version_info [0] == 2
bstack1llllll_opy_ = 2048
bstack11ll1l_opy_ = 7
def bstack11l11ll_opy_ (bstack1l1ll11_opy_):
    global bstack1l11l_opy_
    bstack1l11ll_opy_ = ord (bstack1l1ll11_opy_ [-1])
    bstack111ll1_opy_ = bstack1l1ll11_opy_ [:-1]
    bstack1lllll_opy_ = bstack1l11ll_opy_ % len (bstack111ll1_opy_)
    bstack11l1l1l_opy_ = bstack111ll1_opy_ [:bstack1lllll_opy_] + bstack111ll1_opy_ [bstack1lllll_opy_:]
    if bstack111llll_opy_:
        bstack1ll1l_opy_ = unicode () .join ([unichr (ord (char) - bstack1llllll_opy_ - (bstack1l11l1_opy_ + bstack1l11ll_opy_) % bstack11ll1l_opy_) for bstack1l11l1_opy_, char in enumerate (bstack11l1l1l_opy_)])
    else:
        bstack1ll1l_opy_ = str () .join ([chr (ord (char) - bstack1llllll_opy_ - (bstack1l11l1_opy_ + bstack1l11ll_opy_) % bstack11ll1l_opy_) for bstack1l11l1_opy_, char in enumerate (bstack11l1l1l_opy_)])
    return eval (bstack1ll1l_opy_)
import json
import os
import threading
from bstack_utils.helper import bstack1ll11111l1_opy_, bstack11l1l1l11_opy_, bstack1ll1llll1l_opy_, bstack1l11l1ll_opy_, \
    bstack1l1lllll1l_opy_
def bstack11l111ll_opy_(bstack1l1llllll1_opy_):
    for driver in bstack1l1llllll1_opy_:
        try:
            driver.quit()
        except Exception as e:
            pass
def bstack11ll11lll_opy_(type, name, status, reason, bstack1111111l_opy_, bstack11ll1l11l_opy_):
    bstack11ll1l1l_opy_ = {
        bstack11l11ll_opy_ (u"ࠧࡢࡥࡷ࡭ࡴࡴࠧಷ"): type,
        bstack11l11ll_opy_ (u"ࠨࡣࡵ࡫ࡺࡳࡥ࡯ࡶࡶࠫಸ"): {}
    }
    if type == bstack11l11ll_opy_ (u"ࠩࡤࡲࡳࡵࡴࡢࡶࡨࠫಹ"):
        bstack11ll1l1l_opy_[bstack11l11ll_opy_ (u"ࠪࡥࡷ࡭ࡵ࡮ࡧࡱࡸࡸ࠭಺")][bstack11l11ll_opy_ (u"ࠫࡱ࡫ࡶࡦ࡮ࠪ಻")] = bstack1111111l_opy_
        bstack11ll1l1l_opy_[bstack11l11ll_opy_ (u"ࠬࡧࡲࡨࡷࡰࡩࡳࡺࡳࠨ಼")][bstack11l11ll_opy_ (u"࠭ࡤࡢࡶࡤࠫಽ")] = json.dumps(str(bstack11ll1l11l_opy_))
    if type == bstack11l11ll_opy_ (u"ࠧࡴࡧࡷࡗࡪࡹࡳࡪࡱࡱࡒࡦࡳࡥࠨಾ"):
        bstack11ll1l1l_opy_[bstack11l11ll_opy_ (u"ࠨࡣࡵ࡫ࡺࡳࡥ࡯ࡶࡶࠫಿ")][bstack11l11ll_opy_ (u"ࠩࡱࡥࡲ࡫ࠧೀ")] = name
    if type == bstack11l11ll_opy_ (u"ࠪࡷࡪࡺࡓࡦࡵࡶ࡭ࡴࡴࡓࡵࡣࡷࡹࡸ࠭ು"):
        bstack11ll1l1l_opy_[bstack11l11ll_opy_ (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧೂ")][bstack11l11ll_opy_ (u"ࠬࡹࡴࡢࡶࡸࡷࠬೃ")] = status
        if status == bstack11l11ll_opy_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭ೄ") and str(reason) != bstack11l11ll_opy_ (u"ࠢࠣ೅"):
            bstack11ll1l1l_opy_[bstack11l11ll_opy_ (u"ࠨࡣࡵ࡫ࡺࡳࡥ࡯ࡶࡶࠫೆ")][bstack11l11ll_opy_ (u"ࠩࡵࡩࡦࡹ࡯࡯ࠩೇ")] = json.dumps(str(reason))
    bstack1lll11ll1_opy_ = bstack11l11ll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡡࡨࡼࡪࡩࡵࡵࡱࡵ࠾ࠥࢁࡽࠨೈ").format(json.dumps(bstack11ll1l1l_opy_))
    return bstack1lll11ll1_opy_
def bstack1lllll1l1_opy_(url, config, logger, bstack111111l1l_opy_=False):
    hostname = bstack11l1l1l11_opy_(url)
    is_private = bstack1l11l1ll_opy_(hostname)
    try:
        if is_private or bstack111111l1l_opy_:
            file_path = bstack1ll11111l1_opy_(bstack11l11ll_opy_ (u"ࠫ࠳ࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࠫ೉"), bstack11l11ll_opy_ (u"ࠬ࠴ࡢࡴࡶࡤࡧࡰ࠳ࡣࡰࡰࡩ࡭࡬࠴ࡪࡴࡱࡱࠫೊ"), logger)
            if os.environ.get(bstack11l11ll_opy_ (u"࠭ࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤࡒࡏࡄࡃࡏࡣࡓࡕࡔࡠࡕࡈࡘࡤࡋࡒࡓࡑࡕࠫೋ")) and eval(
                    os.environ.get(bstack11l11ll_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡌࡐࡅࡄࡐࡤࡔࡏࡕࡡࡖࡉ࡙ࡥࡅࡓࡔࡒࡖࠬೌ"))):
                return
            if (bstack11l11ll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࡌࡰࡥࡤࡰ್ࠬ") in config and not config[bstack11l11ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡍࡱࡦࡥࡱ࠭೎")]):
                os.environ[bstack11l11ll_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡏࡓࡈࡇࡌࡠࡐࡒࡘࡤ࡙ࡅࡕࡡࡈࡖࡗࡕࡒࠨ೏")] = str(True)
                bstack1l1llll1ll_opy_ = {bstack11l11ll_opy_ (u"ࠫ࡭ࡵࡳࡵࡰࡤࡱࡪ࠭೐"): hostname}
                bstack1l1lllll1l_opy_(bstack11l11ll_opy_ (u"ࠬ࠴ࡢࡴࡶࡤࡧࡰ࠳ࡣࡰࡰࡩ࡭࡬࠴ࡪࡴࡱࡱࠫ೑"), bstack11l11ll_opy_ (u"࠭࡮ࡶࡦࡪࡩࡤࡲ࡯ࡤࡣ࡯ࠫ೒"), bstack1l1llll1ll_opy_, logger)
    except Exception as e:
        pass
def bstack11llll11l_opy_(caps, bstack1l1lllllll_opy_):
    if bstack11l11ll_opy_ (u"ࠧࡣࡵࡷࡥࡨࡱ࠺ࡰࡲࡷ࡭ࡴࡴࡳࠨ೓") in caps:
        caps[bstack11l11ll_opy_ (u"ࠨࡤࡶࡸࡦࡩ࡫࠻ࡱࡳࡸ࡮ࡵ࡮ࡴࠩ೔")][bstack11l11ll_opy_ (u"ࠩ࡯ࡳࡨࡧ࡬ࠨೕ")] = True
        if bstack1l1lllllll_opy_:
            caps[bstack11l11ll_opy_ (u"ࠪࡦࡸࡺࡡࡤ࡭࠽ࡳࡵࡺࡩࡰࡰࡶࠫೖ")][bstack11l11ll_opy_ (u"ࠫࡱࡵࡣࡢ࡮ࡌࡨࡪࡴࡴࡪࡨ࡬ࡩࡷ࠭೗")] = bstack1l1lllllll_opy_
    else:
        caps[bstack11l11ll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮࠲ࡱࡵࡣࡢ࡮ࠪ೘")] = True
        if bstack1l1lllllll_opy_:
            caps[bstack11l11ll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯࠳ࡲ࡯ࡤࡣ࡯ࡍࡩ࡫࡮ࡵ࡫ࡩ࡭ࡪࡸࠧ೙")] = bstack1l1lllllll_opy_
def bstack1l1lllll11_opy_(bstack1ll1111111_opy_):
    bstack1ll111111l_opy_ = bstack1ll1llll1l_opy_(threading.current_thread(), bstack11l11ll_opy_ (u"ࠧࡵࡧࡶࡸࡘࡺࡡࡵࡷࡶࠫ೚"), bstack11l11ll_opy_ (u"ࠨࠩ೛"))
    if bstack1ll111111l_opy_ == bstack11l11ll_opy_ (u"ࠩࠪ೜") or bstack1ll111111l_opy_ == bstack11l11ll_opy_ (u"ࠪࡷࡰ࡯ࡰࡱࡧࡧࠫೝ"):
        threading.current_thread().testStatus = bstack1ll1111111_opy_
    else:
        if bstack1ll1111111_opy_ == bstack11l11ll_opy_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫೞ"):
            threading.current_thread().testStatus = bstack1ll1111111_opy_