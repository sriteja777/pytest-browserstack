# coding: UTF-8
import sys
bstack111llll_opy_ = sys.version_info [0] == 2
bstack1llllll_opy_ = 2048
bstack11ll1l_opy_ = 7
def bstack11l11ll_opy_ (bstack1l1ll11_opy_):
    global bstack1l11l_opy_
    bstack1l11ll_opy_ = ord (bstack1l1ll11_opy_ [-1])
    bstack111ll1_opy_ = bstack1l1ll11_opy_ [:-1]
    bstack1lllll_opy_ = bstack1l11ll_opy_ % len (bstack111ll1_opy_)
    bstack11l1l1l_opy_ = bstack111ll1_opy_ [:bstack1lllll_opy_] + bstack111ll1_opy_ [bstack1lllll_opy_:]
    if bstack111llll_opy_:
        bstack1ll1l_opy_ = unicode () .join ([unichr (ord (char) - bstack1llllll_opy_ - (bstack1l11l1_opy_ + bstack1l11ll_opy_) % bstack11ll1l_opy_) for bstack1l11l1_opy_, char in enumerate (bstack11l1l1l_opy_)])
    else:
        bstack1ll1l_opy_ = str () .join ([chr (ord (char) - bstack1llllll_opy_ - (bstack1l11l1_opy_ + bstack1l11ll_opy_) % bstack11ll1l_opy_) for bstack1l11l1_opy_, char in enumerate (bstack11l1l1l_opy_)])
    return eval (bstack1ll1l_opy_)
import sys
class bstack1l111l11l1_opy_:
    def __init__(self, handler):
        self._1l111l1l1l_opy_ = sys.stdout.write
        self._1l111l1l11_opy_ = sys.stderr.write
        self.handler = handler
        self._started = False
    def start(self):
        if self._started:
            return
        self._started = True
        sys.stdout.write = self.bstack1l111l11ll_opy_
        sys.stdout.error = self.bstack1l111l1ll1_opy_
    def bstack1l111l11ll_opy_(self, _str):
        self._1l111l1l1l_opy_(_str)
        if self.handler:
            self.handler({bstack11l11ll_opy_ (u"ࠩ࡯ࡩࡻ࡫࡬ࠨၣ"): bstack11l11ll_opy_ (u"ࠪࡍࡓࡌࡏࠨၤ"), bstack11l11ll_opy_ (u"ࠫࡲ࡫ࡳࡴࡣࡪࡩࠬၥ"): _str})
    def bstack1l111l1ll1_opy_(self, _str):
        self._1l111l1l11_opy_(_str)
        if self.handler:
            self.handler({bstack11l11ll_opy_ (u"ࠬࡲࡥࡷࡧ࡯ࠫၦ"): bstack11l11ll_opy_ (u"࠭ࡅࡓࡔࡒࡖࠬၧ"), bstack11l11ll_opy_ (u"ࠧ࡮ࡧࡶࡷࡦ࡭ࡥࠨၨ"): _str})
    def reset(self):
        if not self._started:
            return
        self._started = False
        sys.stdout.write = self._1l111l1l1l_opy_
        sys.stderr.write = self._1l111l1l11_opy_