# coding: UTF-8
import sys
bstack111llll_opy_ = sys.version_info [0] == 2
bstack1llllll_opy_ = 2048
bstack11ll1l_opy_ = 7
def bstack11l11ll_opy_ (bstack1l1ll11_opy_):
    global bstack1l11l_opy_
    bstack1l11ll_opy_ = ord (bstack1l1ll11_opy_ [-1])
    bstack111ll1_opy_ = bstack1l1ll11_opy_ [:-1]
    bstack1lllll_opy_ = bstack1l11ll_opy_ % len (bstack111ll1_opy_)
    bstack11l1l1l_opy_ = bstack111ll1_opy_ [:bstack1lllll_opy_] + bstack111ll1_opy_ [bstack1lllll_opy_:]
    if bstack111llll_opy_:
        bstack1ll1l_opy_ = unicode () .join ([unichr (ord (char) - bstack1llllll_opy_ - (bstack1l11l1_opy_ + bstack1l11ll_opy_) % bstack11ll1l_opy_) for bstack1l11l1_opy_, char in enumerate (bstack11l1l1l_opy_)])
    else:
        bstack1ll1l_opy_ = str () .join ([chr (ord (char) - bstack1llllll_opy_ - (bstack1l11l1_opy_ + bstack1l11ll_opy_) % bstack11ll1l_opy_) for bstack1l11l1_opy_, char in enumerate (bstack11l1l1l_opy_)])
    return eval (bstack1ll1l_opy_)
import os
from urllib.parse import urlparse
from bstack_utils.messages import bstack1l1lll1lll_opy_
def bstack1l1lll1ll1_opy_(url):
    try:
        result = urlparse(url)
        return all([result.scheme, result.netloc])
    except:
        return False
def bstack1l1llll1l1_opy_(bstack1l1lll1l11_opy_, bstack1l1llll111_opy_):
    from pypac import get_pac
    from pypac import PACSession
    from pypac.parser import PACFile
    import socket
    if os.path.isfile(bstack1l1lll1l11_opy_):
        with open(bstack1l1lll1l11_opy_) as f:
            pac = PACFile(f.read())
    elif bstack1l1lll1ll1_opy_(bstack1l1lll1l11_opy_):
        pac = get_pac(url=bstack1l1lll1l11_opy_)
    else:
        raise Exception(bstack11l11ll_opy_ (u"ࠬࡖࡡࡤࠢࡩ࡭ࡱ࡫ࠠࡥࡱࡨࡷࠥࡴ࡯ࡵࠢࡨࡼ࡮ࡹࡴ࠻ࠢࡾࢁࠬ೟").format(bstack1l1lll1l11_opy_))
    session = PACSession(pac)
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect((bstack11l11ll_opy_ (u"ࠨ࠸࠯࠺࠱࠼࠳࠾ࠢೠ"), 80))
        bstack1l1lll11ll_opy_ = s.getsockname()[0]
        s.close()
    except:
        bstack1l1lll11ll_opy_ = bstack11l11ll_opy_ (u"ࠧ࠱࠰࠳࠲࠵࠴࠰ࠨೡ")
    proxy_url = session.get_pac().find_proxy_for_url(bstack1l1llll111_opy_, bstack1l1lll11ll_opy_)
    return proxy_url
def bstack11ll1ll1_opy_(config):
    return bstack11l11ll_opy_ (u"ࠨࡪࡷࡸࡵࡖࡲࡰࡺࡼࠫೢ") in config or bstack11l11ll_opy_ (u"ࠩ࡫ࡸࡹࡶࡳࡑࡴࡲࡼࡾ࠭ೣ") in config
def bstack1lllll1ll1_opy_(config):
    if not bstack11ll1ll1_opy_(config):
        return
    if config.get(bstack11l11ll_opy_ (u"ࠪ࡬ࡹࡺࡰࡑࡴࡲࡼࡾ࠭೤")):
        return config.get(bstack11l11ll_opy_ (u"ࠫ࡭ࡺࡴࡱࡒࡵࡳࡽࡿࠧ೥"))
    if config.get(bstack11l11ll_opy_ (u"ࠬ࡮ࡴࡵࡲࡶࡔࡷࡵࡸࡺࠩ೦")):
        return config.get(bstack11l11ll_opy_ (u"࠭ࡨࡵࡶࡳࡷࡕࡸ࡯ࡹࡻࠪ೧"))
def bstack111l11ll_opy_(config, bstack1l1llll111_opy_):
    proxy = bstack1lllll1ll1_opy_(config)
    proxies = {}
    if config.get(bstack11l11ll_opy_ (u"ࠧࡩࡶࡷࡴࡕࡸ࡯ࡹࡻࠪ೨")) or config.get(bstack11l11ll_opy_ (u"ࠨࡪࡷࡸࡵࡹࡐࡳࡱࡻࡽࠬ೩")):
        if proxy.endswith(bstack11l11ll_opy_ (u"ࠩ࠱ࡴࡦࡩࠧ೪")):
            proxies = bstack111l1lll_opy_(proxy, bstack1l1llll111_opy_)
        else:
            proxies = {
                bstack11l11ll_opy_ (u"ࠪ࡬ࡹࡺࡰࡴࠩ೫"): proxy
            }
    return proxies
def bstack111l1lll_opy_(bstack1l1lll1l11_opy_, bstack1l1llll111_opy_):
    proxies = {}
    global bstack1l1llll11l_opy_
    if bstack11l11ll_opy_ (u"ࠫࡕࡇࡃࡠࡒࡕࡓ࡝࡟ࠧ೬") in globals():
        return bstack1l1llll11l_opy_
    try:
        proxy = bstack1l1llll1l1_opy_(bstack1l1lll1l11_opy_, bstack1l1llll111_opy_)
        if bstack11l11ll_opy_ (u"ࠧࡊࡉࡓࡇࡆࡘࠧ೭") in proxy:
            proxies = {}
        elif bstack11l11ll_opy_ (u"ࠨࡈࡕࡖࡓࠦ೮") in proxy or bstack11l11ll_opy_ (u"ࠢࡉࡖࡗࡔࡘࠨ೯") in proxy or bstack11l11ll_opy_ (u"ࠣࡕࡒࡇࡐ࡙ࠢ೰") in proxy:
            bstack1l1lll1l1l_opy_ = proxy.split(bstack11l11ll_opy_ (u"ࠤࠣࠦೱ"))
            if bstack11l11ll_opy_ (u"ࠥ࠾࠴࠵ࠢೲ") in bstack11l11ll_opy_ (u"ࠦࠧೳ").join(bstack1l1lll1l1l_opy_[1:]):
                proxies = {
                    bstack11l11ll_opy_ (u"ࠬ࡮ࡴࡵࡲࡶࠫ೴"): bstack11l11ll_opy_ (u"ࠨࠢ೵").join(bstack1l1lll1l1l_opy_[1:])
                }
            else:
                proxies = {
                    bstack11l11ll_opy_ (u"ࠧࡩࡶࡷࡴࡸ࠭೶"): str(bstack1l1lll1l1l_opy_[0]).lower() + bstack11l11ll_opy_ (u"ࠣ࠼࠲࠳ࠧ೷") + bstack11l11ll_opy_ (u"ࠤࠥ೸").join(bstack1l1lll1l1l_opy_[1:])
                }
        elif bstack11l11ll_opy_ (u"ࠥࡔࡗࡕࡘ࡚ࠤ೹") in proxy:
            bstack1l1lll1l1l_opy_ = proxy.split(bstack11l11ll_opy_ (u"ࠦࠥࠨ೺"))
            if bstack11l11ll_opy_ (u"ࠧࡀ࠯࠰ࠤ೻") in bstack11l11ll_opy_ (u"ࠨࠢ೼").join(bstack1l1lll1l1l_opy_[1:]):
                proxies = {
                    bstack11l11ll_opy_ (u"ࠧࡩࡶࡷࡴࡸ࠭೽"): bstack11l11ll_opy_ (u"ࠣࠤ೾").join(bstack1l1lll1l1l_opy_[1:])
                }
            else:
                proxies = {
                    bstack11l11ll_opy_ (u"ࠩ࡫ࡸࡹࡶࡳࠨ೿"): bstack11l11ll_opy_ (u"ࠥ࡬ࡹࡺࡰ࠻࠱࠲ࠦഀ") + bstack11l11ll_opy_ (u"ࠦࠧഁ").join(bstack1l1lll1l1l_opy_[1:])
                }
        else:
            proxies = {
                bstack11l11ll_opy_ (u"ࠬ࡮ࡴࡵࡲࡶࠫം"): proxy
            }
    except Exception as e:
        print(bstack11l11ll_opy_ (u"ࠨࡳࡰ࡯ࡨࠤࡪࡸࡲࡰࡴࠥഃ"), bstack1l1lll1lll_opy_.format(bstack1l1lll1l11_opy_, str(e)))
    bstack1l1llll11l_opy_ = proxies
    return proxies