# coding: UTF-8
import sys
bstack111llll_opy_ = sys.version_info [0] == 2
bstack1llllll_opy_ = 2048
bstack11ll1l_opy_ = 7
def bstack11l11ll_opy_ (bstack1l1ll11_opy_):
    global bstack1l11l_opy_
    bstack1l11ll_opy_ = ord (bstack1l1ll11_opy_ [-1])
    bstack111ll1_opy_ = bstack1l1ll11_opy_ [:-1]
    bstack1lllll_opy_ = bstack1l11ll_opy_ % len (bstack111ll1_opy_)
    bstack11l1l1l_opy_ = bstack111ll1_opy_ [:bstack1lllll_opy_] + bstack111ll1_opy_ [bstack1lllll_opy_:]
    if bstack111llll_opy_:
        bstack1ll1l_opy_ = unicode () .join ([unichr (ord (char) - bstack1llllll_opy_ - (bstack1l11l1_opy_ + bstack1l11ll_opy_) % bstack11ll1l_opy_) for bstack1l11l1_opy_, char in enumerate (bstack11l1l1l_opy_)])
    else:
        bstack1ll1l_opy_ = str () .join ([chr (ord (char) - bstack1llllll_opy_ - (bstack1l11l1_opy_ + bstack1l11ll_opy_) % bstack11ll1l_opy_) for bstack1l11l1_opy_, char in enumerate (bstack11l1l1l_opy_)])
    return eval (bstack1ll1l_opy_)
import threading
bstack1l1111l1l1_opy_ = 1000
bstack1l1111lll1_opy_ = 5
bstack1l1111l1ll_opy_ = 30
bstack1l1111llll_opy_ = 2
class bstack1l11ll1l1l_opy_:
    def __init__(self, handler, bstack1l1111l111_opy_=bstack1l1111l1l1_opy_, bstack1l1111l11l_opy_=bstack1l1111lll1_opy_):
        self.queue = []
        self.handler = handler
        self.bstack1l1111l111_opy_ = bstack1l1111l111_opy_
        self.bstack1l1111l11l_opy_ = bstack1l1111l11l_opy_
        self.lock = threading.Lock()
        self.timer = None
    def start(self):
        if not self.timer:
            self.bstack1l111l111l_opy_()
    def bstack1l111l111l_opy_(self):
        self.timer = threading.Timer(self.bstack1l1111l11l_opy_, self.bstack1l1111ll11_opy_)
        self.timer.start()
    def bstack1l111l1111_opy_(self):
        self.timer.cancel()
    def bstack1l1111ll1l_opy_(self):
        self.bstack1l111l1111_opy_()
        self.bstack1l111l111l_opy_()
    def add(self, event):
        with self.lock:
            self.queue.append(event)
            if len(self.queue) >= self.bstack1l1111l111_opy_:
                t = threading.Thread(target=self.bstack1l1111ll11_opy_)
                t.start()
                self.bstack1l1111ll1l_opy_()
    def bstack1l1111ll11_opy_(self):
        if len(self.queue) <= 0:
            return
        data = self.queue[:self.bstack1l1111l111_opy_]
        del self.queue[:self.bstack1l1111l111_opy_]
        self.handler(data)
    def shutdown(self):
        self.bstack1l111l1111_opy_()
        while len(self.queue) > 0:
            self.bstack1l1111ll11_opy_()