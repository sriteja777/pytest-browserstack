# coding: UTF-8
import sys
bstack111llll_opy_ = sys.version_info [0] == 2
bstack1llllll_opy_ = 2048
bstack11ll1l_opy_ = 7
def bstack11l11ll_opy_ (bstack1l1ll11_opy_):
    global bstack1l11l_opy_
    bstack1l11ll_opy_ = ord (bstack1l1ll11_opy_ [-1])
    bstack111ll1_opy_ = bstack1l1ll11_opy_ [:-1]
    bstack1lllll_opy_ = bstack1l11ll_opy_ % len (bstack111ll1_opy_)
    bstack11l1l1l_opy_ = bstack111ll1_opy_ [:bstack1lllll_opy_] + bstack111ll1_opy_ [bstack1lllll_opy_:]
    if bstack111llll_opy_:
        bstack1ll1l_opy_ = unicode () .join ([unichr (ord (char) - bstack1llllll_opy_ - (bstack1l11l1_opy_ + bstack1l11ll_opy_) % bstack11ll1l_opy_) for bstack1l11l1_opy_, char in enumerate (bstack11l1l1l_opy_)])
    else:
        bstack1ll1l_opy_ = str () .join ([chr (ord (char) - bstack1llllll_opy_ - (bstack1l11l1_opy_ + bstack1l11ll_opy_) % bstack11ll1l_opy_) for bstack1l11l1_opy_, char in enumerate (bstack11l1l1l_opy_)])
    return eval (bstack1ll1l_opy_)
class bstack1l1l1ll111_opy_:
    def __init__(self, handler):
        self._1l1l1ll1ll_opy_ = None
        self.handler = handler
        self._1l1l1l1lll_opy_ = self.bstack1l1l1ll1l1_opy_()
        self.patch()
    def patch(self):
        self._1l1l1ll1ll_opy_ = self._1l1l1l1lll_opy_.execute
        self._1l1l1l1lll_opy_.execute = self.bstack1l1l1l1ll1_opy_()
    def bstack1l1l1l1ll1_opy_(self):
        def execute(this, driver_command, *args, **kwargs):
            response = self._1l1l1ll1ll_opy_(this, driver_command, *args, **kwargs)
            self.handler(driver_command, response)
            return response
        return execute
    def reset(self):
        self._1l1l1l1lll_opy_.execute = self._1l1l1ll1ll_opy_
    @staticmethod
    def bstack1l1l1ll1l1_opy_():
        from selenium.webdriver.remote.webdriver import WebDriver
        return WebDriver