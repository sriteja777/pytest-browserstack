# coding: UTF-8
import sys
bstack111llll_opy_ = sys.version_info [0] == 2
bstack1llllll_opy_ = 2048
bstack11ll1l_opy_ = 7
def bstack11l11ll_opy_ (bstack1l1ll11_opy_):
    global bstack1l11l_opy_
    bstack1l11ll_opy_ = ord (bstack1l1ll11_opy_ [-1])
    bstack111ll1_opy_ = bstack1l1ll11_opy_ [:-1]
    bstack1lllll_opy_ = bstack1l11ll_opy_ % len (bstack111ll1_opy_)
    bstack11l1l1l_opy_ = bstack111ll1_opy_ [:bstack1lllll_opy_] + bstack111ll1_opy_ [bstack1lllll_opy_:]
    if bstack111llll_opy_:
        bstack1ll1l_opy_ = unicode () .join ([unichr (ord (char) - bstack1llllll_opy_ - (bstack1l11l1_opy_ + bstack1l11ll_opy_) % bstack11ll1l_opy_) for bstack1l11l1_opy_, char in enumerate (bstack11l1l1l_opy_)])
    else:
        bstack1ll1l_opy_ = str () .join ([chr (ord (char) - bstack1llllll_opy_ - (bstack1l11l1_opy_ + bstack1l11ll_opy_) % bstack11ll1l_opy_) for bstack1l11l1_opy_, char in enumerate (bstack11l1l1l_opy_)])
    return eval (bstack1ll1l_opy_)
import os
import re
import sys
import json
import time
import shutil
import tempfile
import requests
import subprocess
from threading import Thread
from os.path import expanduser
from bstack_utils.constants import *
from requests.auth import HTTPBasicAuth
from bstack_utils.helper import bstack1llll11lll_opy_, bstack1l11l1l11_opy_
class bstack1llll11l11_opy_:
  working_dir = os.getcwd()
  bstack11l1lllll_opy_ = False
  config = {}
  binary_path = bstack11l11ll_opy_ (u"ࠩࠪቛ")
  bstack11l1ll11l1_opy_ = bstack11l11ll_opy_ (u"ࠪࠫቜ")
  bstack11l11lllll_opy_ = False
  bstack11ll11l1l1_opy_ = None
  bstack11l1ll111l_opy_ = {}
  bstack11l1lllll1_opy_ = 300
  bstack11ll11l11l_opy_ = False
  logger = None
  bstack11l1lll1l1_opy_ = False
  bstack11ll1111ll_opy_ = bstack11l11ll_opy_ (u"ࠫࠬቝ")
  bstack11ll11l111_opy_ = {
    bstack11l11ll_opy_ (u"ࠬࡩࡨࡳࡱࡰࡩࠬ቞") : 1,
    bstack11l11ll_opy_ (u"࠭ࡦࡪࡴࡨࡪࡴࡾࠧ቟") : 2,
    bstack11l11ll_opy_ (u"ࠧࡦࡦࡪࡩࠬበ") : 3,
    bstack11l11ll_opy_ (u"ࠨࡵࡤࡪࡦࡸࡩࠨቡ") : 4
  }
  def __init__(self) -> None: pass
  def bstack11ll1111l1_opy_(self):
    bstack11l1llllll_opy_ = bstack11l11ll_opy_ (u"ࠩࠪቢ")
    bstack11l1l111l1_opy_ = sys.platform
    bstack11l1lll11l_opy_ = bstack11l11ll_opy_ (u"ࠪࡴࡪࡸࡣࡺࠩባ")
    if re.match(bstack11l11ll_opy_ (u"ࠦࡩࡧࡲࡸ࡫ࡱࢀࡲࡧࡣࠡࡱࡶࠦቤ"), bstack11l1l111l1_opy_) != None:
      bstack11l1llllll_opy_ = bstack1l1ll111l1_opy_ + bstack11l11ll_opy_ (u"ࠧ࠵ࡰࡦࡴࡦࡽ࠲ࡵࡳࡹ࠰ࡽ࡭ࡵࠨብ")
      self.bstack11ll1111ll_opy_ = bstack11l11ll_opy_ (u"࠭࡭ࡢࡥࠪቦ")
    elif re.match(bstack11l11ll_opy_ (u"ࠢ࡮ࡵࡺ࡭ࡳࢂ࡭ࡴࡻࡶࢀࡲ࡯࡮ࡨࡹࡿࡧࡾ࡭ࡷࡪࡰࡿࡦࡨࡩࡷࡪࡰࡿࡻ࡮ࡴࡣࡦࡾࡨࡱࡨࢂࡷࡪࡰ࠶࠶ࠧቧ"), bstack11l1l111l1_opy_) != None:
      bstack11l1llllll_opy_ = bstack1l1ll111l1_opy_ + bstack11l11ll_opy_ (u"ࠣ࠱ࡳࡩࡷࡩࡹ࠮ࡹ࡬ࡲ࠳ࢀࡩࡱࠤቨ")
      bstack11l1lll11l_opy_ = bstack11l11ll_opy_ (u"ࠤࡳࡩࡷࡩࡹ࠯ࡧࡻࡩࠧቩ")
      self.bstack11ll1111ll_opy_ = bstack11l11ll_opy_ (u"ࠪࡻ࡮ࡴࠧቪ")
    else:
      bstack11l1llllll_opy_ = bstack1l1ll111l1_opy_ + bstack11l11ll_opy_ (u"ࠦ࠴ࡶࡥࡳࡥࡼ࠱ࡱ࡯࡮ࡶࡺ࠱ࡾ࡮ࡶࠢቫ")
      self.bstack11ll1111ll_opy_ = bstack11l11ll_opy_ (u"ࠬࡲࡩ࡯ࡷࡻࠫቬ")
    return bstack11l1llllll_opy_, bstack11l1lll11l_opy_
  def bstack11l1l1l1ll_opy_(self):
    try:
      bstack11l1ll1l1l_opy_ = [os.path.join(expanduser(bstack11l11ll_opy_ (u"ࠨࡾࠣቭ")), bstack11l11ll_opy_ (u"ࠧ࠯ࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࠧቮ")), self.working_dir, tempfile.gettempdir()]
      for path in bstack11l1ll1l1l_opy_:
        if(self.bstack11l1l11l1l_opy_(path)):
          return path
      raise bstack11l11ll_opy_ (u"ࠣࡗࡱࡥࡱࡨࡥࠡࡶࡲࠤࡩࡵࡷ࡯࡮ࡲࡥࡩࠦࡰࡦࡴࡦࡽࠥࡨࡩ࡯ࡣࡵࡽࠧቯ")
    except Exception as e:
      self.logger.error(bstack11l11ll_opy_ (u"ࠤࡉࡥ࡮ࡲࡥࡥࠢࡷࡳࠥ࡬ࡩ࡯ࡦࠣࡥࡻࡧࡩ࡭ࡣࡥࡰࡪࠦࡰࡢࡶ࡫ࠤ࡫ࡵࡲࠡࡲࡨࡶࡨࡿࠠࡥࡱࡺࡲࡱࡵࡡࡥ࠮ࠣࡉࡽࡩࡥࡱࡶ࡬ࡳࡳࠦ࠭ࠡࡽࢀࠦተ").format(e))
  def bstack11l1l11l1l_opy_(self, path):
    try:
      if not os.path.exists(path):
        os.makedirs(path)
      return True
    except:
      return False
  def bstack11l11llll1_opy_(self, bstack11l1llllll_opy_, bstack11l1lll11l_opy_):
    try:
      bstack11ll11ll1l_opy_ = self.bstack11l1l1l1ll_opy_()
      bstack11l1l11111_opy_ = os.path.join(bstack11ll11ll1l_opy_, bstack11l11ll_opy_ (u"ࠪࡴࡪࡸࡣࡺ࠰ࡽ࡭ࡵ࠭ቱ"))
      bstack11l1ll1lll_opy_ = os.path.join(bstack11ll11ll1l_opy_, bstack11l1lll11l_opy_)
      if os.path.exists(bstack11l1ll1lll_opy_):
        self.logger.info(bstack11l11ll_opy_ (u"ࠦࡕ࡫ࡲࡤࡻࠣࡦ࡮ࡴࡡࡳࡻࠣࡪࡴࡻ࡮ࡥࠢ࡬ࡲࠥࢁࡽ࠭ࠢࡶ࡯࡮ࡶࡰࡪࡰࡪࠤࡩࡵࡷ࡯࡮ࡲࡥࡩࠨቲ").format(bstack11l1ll1lll_opy_))
        return bstack11l1ll1lll_opy_
      if os.path.exists(bstack11l1l11111_opy_):
        self.logger.info(bstack11l11ll_opy_ (u"ࠧࡖࡥࡳࡥࡼࠤࡿ࡯ࡰࠡࡨࡲࡹࡳࡪࠠࡪࡰࠣࡿࢂ࠲ࠠࡶࡰࡽ࡭ࡵࡶࡩ࡯ࡩࠥታ").format(bstack11l1l11111_opy_))
        return self.bstack11ll111l1l_opy_(bstack11l1l11111_opy_, bstack11l1lll11l_opy_)
      self.logger.info(bstack11l11ll_opy_ (u"ࠨࡄࡰࡹࡱࡰࡴࡧࡤࡪࡰࡪࠤࡵ࡫ࡲࡤࡻࠣࡦ࡮ࡴࡡࡳࡻࠣࡪࡷࡵ࡭ࠡࡽࢀࠦቴ").format(bstack11l1llllll_opy_))
      response = bstack1l11l1l11_opy_(bstack11l11ll_opy_ (u"ࠧࡈࡇࡗࠫት"), bstack11l1llllll_opy_, {}, {})
      if response.status_code == 200:
        with open(bstack11l1l11111_opy_, bstack11l11ll_opy_ (u"ࠨࡹࡥࠫቶ")) as file:
          file.write(response.content)
        self.logger.info(bstack11ll11ll11_opy_ (u"ࠤࡇࡳࡼࡴ࡬ࡰࡣࡧࡩࡩࠦࡰࡦࡴࡦࡽࠥࡨࡩ࡯ࡣࡵࡽࠥࡧ࡮ࡥࠢࡶࡥࡻ࡫ࡤࠡࡣࡷࠤࢀࡨࡩ࡯ࡣࡵࡽࡤࢀࡩࡱࡡࡳࡥࡹ࡮ࡽࠣቷ"))
        return self.bstack11ll111l1l_opy_(bstack11l1l11111_opy_, bstack11l1lll11l_opy_)
      else:
        raise(bstack11ll11ll11_opy_ (u"ࠥࡊࡦ࡯࡬ࡦࡦࠣࡸࡴࠦࡤࡰࡹࡱࡰࡴࡧࡤࠡࡶ࡫ࡩࠥ࡬ࡩ࡭ࡧ࠱ࠤࡘࡺࡡࡵࡷࡶࠤࡨࡵࡤࡦ࠼ࠣࡿࡷ࡫ࡳࡱࡱࡱࡷࡪ࠴ࡳࡵࡣࡷࡹࡸࡥࡣࡰࡦࡨࢁࠧቸ"))
    except:
      self.logger.error(bstack11l11ll_opy_ (u"࡚ࠦࡴࡡࡣ࡮ࡨࠤࡹࡵࠠࡥࡱࡺࡲࡱࡵࡡࡥࠢࡳࡩࡷࡩࡹࠡࡤ࡬ࡲࡦࡸࡹࠣቹ"))
  def bstack11l1l11lll_opy_(self, bstack11l1llllll_opy_, bstack11l1lll11l_opy_):
    try:
      bstack11l1ll1lll_opy_ = self.bstack11l11llll1_opy_(bstack11l1llllll_opy_, bstack11l1lll11l_opy_)
      bstack11l1l1lll1_opy_ = self.bstack11l1l1l11l_opy_(bstack11l1llllll_opy_, bstack11l1lll11l_opy_, bstack11l1ll1lll_opy_)
      return bstack11l1ll1lll_opy_, bstack11l1l1lll1_opy_
    except Exception as e:
      self.logger.error(bstack11l11ll_opy_ (u"࡛ࠧ࡮ࡢࡤ࡯ࡩࠥࡺ࡯ࠡࡩࡨࡸࠥࡶࡥࡳࡥࡼࠤࡧ࡯࡮ࡢࡴࡼࠤࡵࡧࡴࡩࠤቺ").format(e))
    return bstack11l1ll1lll_opy_, False
  def bstack11l1l1l11l_opy_(self, bstack11l1llllll_opy_, bstack11l1lll11l_opy_, bstack11l1ll1lll_opy_, bstack11l11lll1l_opy_ = 0):
    if bstack11l11lll1l_opy_ > 1:
      return False
    if bstack11l1ll1lll_opy_ == None or os.path.exists(bstack11l1ll1lll_opy_) == False:
      self.logger.warn(bstack11l11ll_opy_ (u"ࠨࡐࡦࡴࡦࡽࠥࡶࡡࡵࡪࠣࡲࡴࡺࠠࡧࡱࡸࡲࡩ࠲ࠠࡳࡧࡷࡶࡾ࡯࡮ࡨࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࠦቻ"))
      bstack11l1ll1lll_opy_ = self.bstack11l11llll1_opy_(bstack11l1llllll_opy_, bstack11l1lll11l_opy_)
      self.bstack11l1l1l11l_opy_(bstack11l1llllll_opy_, bstack11l1lll11l_opy_, bstack11l1ll1lll_opy_, bstack11l11lll1l_opy_+1)
    bstack11l11lll11_opy_ = bstack11l11ll_opy_ (u"ࠢ࡟࠰࠭ࡄࡵ࡫ࡲࡤࡻ࡟࠳ࡨࡲࡩࠡ࡞ࡧ࠲ࡡࡪࠫ࠯࡞ࡧ࠯ࠧቼ")
    command = bstack11l11ll_opy_ (u"ࠨࡽࢀࠤ࠲࠳ࡶࡦࡴࡶ࡭ࡴࡴࠧች").format(bstack11l1ll1lll_opy_)
    bstack11l1l11l11_opy_ = subprocess.check_output(command, shell=True, text=True)
    if re.match(bstack11l11lll11_opy_, bstack11l1l11l11_opy_) != None:
      return True
    else:
      self.logger.error(bstack11l11ll_opy_ (u"ࠤࡓࡩࡷࡩࡹࠡࡸࡨࡶࡸ࡯࡯࡯ࠢࡦ࡬ࡪࡩ࡫ࠡࡨࡤ࡭ࡱ࡫ࡤࠣቾ"))
      bstack11l1ll1lll_opy_ = self.bstack11l11llll1_opy_(bstack11l1llllll_opy_, bstack11l1lll11l_opy_)
      self.bstack11l1l1l11l_opy_(bstack11l1llllll_opy_, bstack11l1lll11l_opy_, bstack11l1ll1lll_opy_, bstack11l11lll1l_opy_+1)
  def bstack11ll111l1l_opy_(self, bstack11l1l11111_opy_, bstack11l1lll11l_opy_):
    try:
      working_dir = os.path.dirname(bstack11l1l11111_opy_)
      shutil.unpack_archive(bstack11l1l11111_opy_, working_dir)
      bstack11l1ll1lll_opy_ = os.path.join(working_dir, bstack11l1lll11l_opy_)
      os.chmod(bstack11l1ll1lll_opy_, 0o755)
      return bstack11l1ll1lll_opy_
    except Exception as e:
      self.logger.error(bstack11l11ll_opy_ (u"࡙ࠥࡳࡧࡢ࡭ࡧࠣࡸࡴࠦࡵ࡯ࡼ࡬ࡴࠥࡶࡥࡳࡥࡼࠤࡧ࡯࡮ࡢࡴࡼࠦቿ"))
  def bstack11l1llll1l_opy_(self):
    try:
      percy = str(self.config.get(bstack11l11ll_opy_ (u"ࠫࡵ࡫ࡲࡤࡻࠪኀ"), bstack11l11ll_opy_ (u"ࠧ࡬ࡡ࡭ࡵࡨࠦኁ"))).lower()
      if percy != bstack11l11ll_opy_ (u"ࠨࡴࡳࡷࡨࠦኂ"):
        return False
      self.bstack11l11lllll_opy_ = True
      return True
    except Exception as e:
      self.logger.error(bstack11l11ll_opy_ (u"ࠢࡖࡰࡤࡦࡱ࡫ࠠࡵࡱࠣࡨࡪࡺࡥࡤࡶࠣࡴࡪࡸࡣࡺ࠮ࠣࡉࡽࡩࡥࡱࡶ࡬ࡳࡳࠦࡻࡾࠤኃ").format(e))
  def init(self, bstack11l1lllll_opy_, config, logger):
    self.bstack11l1lllll_opy_ = bstack11l1lllll_opy_
    self.config = config
    self.logger = logger
    if not self.bstack11l1llll1l_opy_():
      return
    self.bstack11l1ll111l_opy_ = config.get(bstack11l11ll_opy_ (u"ࠨࡲࡨࡶࡨࡿࡏࡱࡶ࡬ࡳࡳࡹࠧኄ"), {})
    try:
      bstack11l1llllll_opy_, bstack11l1lll11l_opy_ = self.bstack11ll1111l1_opy_()
      bstack11l1ll1lll_opy_, bstack11l1l1lll1_opy_ = self.bstack11l1l11lll_opy_(bstack11l1llllll_opy_, bstack11l1lll11l_opy_)
      if bstack11l1l1lll1_opy_:
        self.binary_path = bstack11l1ll1lll_opy_
        thread = Thread(target=self.bstack11ll111l11_opy_)
        thread.start()
      else:
        self.bstack11l1lll1l1_opy_ = True
        self.logger.error(bstack11l11ll_opy_ (u"ࠤࡌࡲࡻࡧ࡬ࡪࡦࠣࡴࡪࡸࡣࡺࠢࡳࡥࡹ࡮ࠠࡧࡱࡸࡲࡩࠦ࠭ࠡࡽࢀ࠰࡛ࠥ࡮ࡢࡤ࡯ࡩࠥࡺ࡯ࠡࡵࡷࡥࡷࡺࠠࡑࡧࡵࡧࡾࠨኅ").format(bstack11l1ll1lll_opy_))
    except Exception as e:
      self.logger.error(bstack11l11ll_opy_ (u"࡙ࠥࡳࡧࡢ࡭ࡧࠣࡸࡴࠦࡳࡵࡣࡵࡸࠥࡶࡥࡳࡥࡼ࠰ࠥࡋࡸࡤࡧࡳࡸ࡮ࡵ࡮ࠡࡽࢀࠦኆ").format(e))
  def bstack11l1l1llll_opy_(self):
    try:
      logfile = os.path.join(self.working_dir, bstack11l11ll_opy_ (u"ࠫࡱࡵࡧࠨኇ"), bstack11l11ll_opy_ (u"ࠬࡶࡥࡳࡥࡼ࠲ࡱࡵࡧࠨኈ"))
      os.makedirs(os.path.dirname(logfile)) if not os.path.exists(os.path.dirname(logfile)) else None
      self.logger.debug(bstack11l11ll_opy_ (u"ࠨࡐࡶࡵ࡫࡭ࡳ࡭ࠠࡱࡧࡵࡧࡾࠦ࡬ࡰࡩࡶࠤࡦࡺࠠࡼࡿࠥ኉").format(logfile))
      self.bstack11l1ll11l1_opy_ = logfile
    except Exception as e:
      self.logger.error(bstack11l11ll_opy_ (u"ࠢࡖࡰࡤࡦࡱ࡫ࠠࡵࡱࠣࡷࡪࡺࠠࡱࡧࡵࡧࡾࠦ࡬ࡰࡩࠣࡴࡦࡺࡨ࠭ࠢࡈࡼࡨ࡫ࡰࡵ࡫ࡲࡲࠥࢁࡽࠣኊ").format(e))
  def bstack11ll111l11_opy_(self):
    bstack11l1l1l1l1_opy_ = self.bstack11l1l1111l_opy_()
    if bstack11l1l1l1l1_opy_ == None:
      self.bstack11l1lll1l1_opy_ = True
      self.logger.error(bstack11l11ll_opy_ (u"ࠣࡒࡨࡶࡨࡿࠠࡵࡱ࡮ࡩࡳࠦ࡮ࡰࡶࠣࡪࡴࡻ࡮ࡥ࠮ࠣࡊࡦ࡯࡬ࡦࡦࠣࡸࡴࠦࡳࡵࡣࡵࡸࠥࡶࡥࡳࡥࡼࠦኋ"))
      return False
    command_args = [bstack11l11ll_opy_ (u"ࠤࡤࡴࡵࡀࡥࡹࡧࡦ࠾ࡸࡺࡡࡳࡶࠥኌ") if self.bstack11l1lllll_opy_ else bstack11l11ll_opy_ (u"ࠪࡩࡽ࡫ࡣ࠻ࡵࡷࡥࡷࡺࠧኍ")]
    bstack11l1ll1111_opy_ = self.bstack11l1llll11_opy_()
    if bstack11l1ll1111_opy_ != None:
      command_args.append(bstack11l11ll_opy_ (u"ࠦ࠲ࡩࠠࡼࡿࠥ኎").format(bstack11l1ll1111_opy_))
    env = os.environ.copy()
    env[bstack11l11ll_opy_ (u"ࠧࡖࡅࡓࡅ࡜ࡣ࡙ࡕࡋࡆࡐࠥ኏")] = bstack11l1l1l1l1_opy_
    bstack11l1ll1ll1_opy_ = [self.binary_path]
    self.bstack11l1l1llll_opy_()
    self.bstack11ll11l1l1_opy_ = self.bstack11ll11l1ll_opy_(bstack11l1ll1ll1_opy_ + command_args, env)
    self.logger.debug(bstack11l11ll_opy_ (u"ࠨࡓࡵࡣࡵࡸ࡮ࡴࡧࠡࡊࡨࡥࡱࡺࡨࠡࡅ࡫ࡩࡨࡱࠢነ"))
    bstack11l11lll1l_opy_ = 0
    while self.bstack11ll11l1l1_opy_.poll() == None:
      bstack11l1l1ll11_opy_ = self.bstack11l1l111ll_opy_()
      if bstack11l1l1ll11_opy_:
        self.logger.debug(bstack11l11ll_opy_ (u"ࠢࡉࡧࡤࡰࡹ࡮ࠠࡄࡪࡨࡧࡰࠦࡳࡶࡥࡦࡩࡸࡹࡦࡶ࡮ࠥኑ"))
        self.bstack11ll11l11l_opy_ = True
        return True
      bstack11l11lll1l_opy_ += 1
      self.logger.debug(bstack11l11ll_opy_ (u"ࠣࡊࡨࡥࡱࡺࡨࠡࡅ࡫ࡩࡨࡱࠠࡓࡧࡷࡶࡾࠦ࠭ࠡࡽࢀࠦኒ").format(bstack11l11lll1l_opy_))
      time.sleep(2)
    self.logger.error(bstack11l11ll_opy_ (u"ࠤࡉࡥ࡮ࡲࡥࡥࠢࡷࡳࠥࡹࡴࡢࡴࡷࠤࡵ࡫ࡲࡤࡻ࠯ࠤࡍ࡫ࡡ࡭ࡶ࡫ࠤࡈ࡮ࡥࡤ࡭ࠣࡊࡦ࡯࡬ࡦࡦࠣࡥ࡫ࡺࡥࡳࠢࡾࢁࠥࡧࡴࡵࡧࡰࡴࡹࡹࠢና").format(bstack11l11lll1l_opy_))
    self.bstack11l1lll1l1_opy_ = True
    return False
  def bstack11l1l111ll_opy_(self, bstack11l11lll1l_opy_ = 0):
    try:
      if bstack11l11lll1l_opy_ > 10:
        return False
      bstack11l1lll1ll_opy_ = os.environ.get(bstack11l11ll_opy_ (u"ࠪࡔࡊࡘࡃ࡚ࡡࡖࡉࡗ࡜ࡅࡓࡡࡄࡈࡉࡘࡅࡔࡕࠪኔ"), bstack11l11ll_opy_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡱࡵࡣࡢ࡮࡫ࡳࡸࡺ࠺࠶࠵࠶࠼ࠬን"))
      bstack11l1ll1l11_opy_ = bstack11l1lll1ll_opy_ + bstack1l1l1lllll_opy_
      response = requests.get(bstack11l1ll1l11_opy_)
      return True if response.json() else False
    except:
      return False
  def bstack11l1l1111l_opy_(self):
    bstack11l11ll1ll_opy_ = bstack11l11ll_opy_ (u"ࠬࡧࡰࡱࠩኖ") if self.bstack11l1lllll_opy_ else bstack11l11ll_opy_ (u"࠭ࡡࡶࡶࡲࡱࡦࡺࡥࠨኗ")
    bstack1l11l11ll1_opy_ = bstack11l11ll_opy_ (u"ࠢࡢࡲ࡬࠳ࡦࡶࡰࡠࡲࡨࡶࡨࡿ࠯ࡨࡧࡷࡣࡵࡸ࡯࡫ࡧࡦࡸࡤࡺ࡯࡬ࡧࡱࡃࡳࡧ࡭ࡦ࠿ࡾࢁࠫࡺࡹࡱࡧࡀࡿࢂࠨኘ").format(self.config[bstack11l11ll_opy_ (u"ࠨࡲࡵࡳ࡯࡫ࡣࡵࡐࡤࡱࡪ࠭ኙ")], bstack11l11ll1ll_opy_)
    uri = bstack1llll11lll_opy_(bstack1l11l11ll1_opy_)
    try:
      response = bstack1l11l1l11_opy_(bstack11l11ll_opy_ (u"ࠩࡊࡉ࡙࠭ኚ"), uri, {}, {bstack11l11ll_opy_ (u"ࠪࡥࡺࡺࡨࠨኛ"): (self.config[bstack11l11ll_opy_ (u"ࠫࡺࡹࡥࡳࡐࡤࡱࡪ࠭ኜ")], self.config[bstack11l11ll_opy_ (u"ࠬࡧࡣࡤࡧࡶࡷࡐ࡫ࡹࠨኝ")])})
      if response.status_code == 200:
        bstack11l1l1ll1l_opy_ = response.json()
        if bstack11l11ll_opy_ (u"ࠨࡴࡰ࡭ࡨࡲࠧኞ") in bstack11l1l1ll1l_opy_:
          return bstack11l1l1ll1l_opy_[bstack11l11ll_opy_ (u"ࠢࡵࡱ࡮ࡩࡳࠨኟ")]
        else:
          raise bstack11l11ll_opy_ (u"ࠨࡖࡲ࡯ࡪࡴࠠࡏࡱࡷࠤࡋࡵࡵ࡯ࡦࠣ࠱ࠥࢁࡽࠨአ").format(bstack11l1l1ll1l_opy_)
      else:
        raise bstack11l11ll_opy_ (u"ࠤࡉࡥ࡮ࡲࡥࡥࠢࡷࡳࠥ࡬ࡥࡵࡥ࡫ࠤࡵ࡫ࡲࡤࡻࠣࡸࡴࡱࡥ࡯࠮ࠣࡖࡪࡹࡰࡰࡰࡶࡩࠥࡹࡴࡢࡶࡸࡷࠥ࠳ࠠࡼࡿ࠯ࠤࡗ࡫ࡳࡱࡱࡱࡷࡪࠦࡂࡰࡦࡼࠤ࠲ࠦࡻࡾࠤኡ").format(response.status_code, response.json())
    except Exception as e:
      self.logger.error(bstack11l11ll_opy_ (u"ࠥࡉࡽࡩࡥࡱࡶ࡬ࡳࡳࠦࡩ࡯ࠢࡦࡶࡪࡧࡴࡪࡰࡪࠤࡵ࡫ࡲࡤࡻࠣࡴࡷࡵࡪࡦࡥࡷࠦኢ").format(e))
  def bstack11l1llll11_opy_(self):
    bstack11ll111ll1_opy_ = os.path.join(tempfile.gettempdir(), bstack11l11ll_opy_ (u"ࠦࡵ࡫ࡲࡤࡻࡆࡳࡳ࡬ࡩࡨ࠰࡭ࡷࡴࡴࠢኣ"))
    try:
      if bstack11l11ll_opy_ (u"ࠬࡼࡥࡳࡵ࡬ࡳࡳ࠭ኤ") not in self.bstack11l1ll111l_opy_:
        self.bstack11l1ll111l_opy_[bstack11l11ll_opy_ (u"࠭ࡶࡦࡴࡶ࡭ࡴࡴࠧእ")] = 2
      with open(bstack11ll111ll1_opy_, bstack11l11ll_opy_ (u"ࠧࡸࠩኦ")) as fp:
        json.dump(self.bstack11l1ll111l_opy_, fp)
      return bstack11ll111ll1_opy_
    except Exception as e:
      self.logger.error(bstack11l11ll_opy_ (u"ࠣࡗࡱࡥࡧࡲࡥࠡࡶࡲࠤࡨࡸࡥࡢࡶࡨࠤࡵ࡫ࡲࡤࡻࠣࡧࡴࡴࡦ࠭ࠢࡈࡼࡨ࡫ࡰࡵ࡫ࡲࡲࠥࢁࡽࠣኧ").format(e))
  def bstack11ll11l1ll_opy_(self, cmd, env = os.environ.copy()):
    try:
      if self.bstack11ll1111ll_opy_ == bstack11l11ll_opy_ (u"ࠩࡺ࡭ࡳ࠭ከ"):
        bstack11l1l11ll1_opy_ = [bstack11l11ll_opy_ (u"ࠪࡧࡲࡪ࠮ࡦࡺࡨࠫኩ"), bstack11l11ll_opy_ (u"ࠫ࠴ࡩࠧኪ")]
        cmd = bstack11l1l11ll1_opy_ + cmd
      cmd = bstack11l11ll_opy_ (u"ࠬࠦࠧካ").join(cmd)
      self.logger.debug(bstack11l11ll_opy_ (u"ࠨࡒࡶࡰࡱ࡭ࡳ࡭ࠠࡼࡿࠥኬ").format(cmd))
      with open(self.bstack11l1ll11l1_opy_, bstack11l11ll_opy_ (u"ࠢࡢࠤክ")) as bstack11ll111lll_opy_:
        process = subprocess.Popen(cmd, shell=True, stdout=bstack11ll111lll_opy_, text=True, stderr=bstack11ll111lll_opy_, env=env, universal_newlines=True)
      return process
    except Exception as e:
      self.bstack11l1lll1l1_opy_ = True
      self.logger.error(bstack11l11ll_opy_ (u"ࠣࡈࡤ࡭ࡱ࡫ࡤࠡࡶࡲࠤࡸࡺࡡࡳࡶࠣࡴࡪࡸࡣࡺࠢࡺ࡭ࡹ࡮ࠠࡤ࡯ࡧࠤ࠲ࠦࡻࡾ࠮ࠣࡉࡽࡩࡥࡱࡶ࡬ࡳࡳࡀࠠࡼࡿࠥኮ").format(cmd, e))
  def shutdown(self):
    try:
      if self.bstack11ll11l11l_opy_:
        self.logger.info(bstack11l11ll_opy_ (u"ࠤࡖࡸࡴࡶࡰࡪࡰࡪࠤࡕ࡫ࡲࡤࡻࠥኯ"))
        cmd = [self.binary_path, bstack11l11ll_opy_ (u"ࠥࡩࡽ࡫ࡣ࠻ࡵࡷࡳࡵࠨኰ")]
        self.bstack11ll11l1ll_opy_(cmd)
        self.bstack11ll11l11l_opy_ = False
    except Exception as e:
      self.logger.error(bstack11l11ll_opy_ (u"ࠦࡋࡧࡩ࡭ࡧࡧࠤࡹࡵࠠࡴࡶࡲࡴࠥࡹࡥࡴࡵ࡬ࡳࡳࠦࡷࡪࡶ࡫ࠤࡨࡵ࡭࡮ࡣࡱࡨࠥ࠳ࠠࡼࡿ࠯ࠤࡊࡾࡣࡦࡲࡷ࡭ࡴࡴ࠺ࠡࡽࢀࠦ኱").format(cmd, e))
  def bstack1l1ll11ll_opy_(self):
    if not self.bstack11l11lllll_opy_:
      return
    try:
      bstack11ll11111l_opy_ = 0
      while not self.bstack11ll11l11l_opy_ and bstack11ll11111l_opy_ < self.bstack11l1lllll1_opy_:
        if self.bstack11l1lll1l1_opy_:
          self.logger.info(bstack11l11ll_opy_ (u"ࠧࡖࡥࡳࡥࡼࠤࡸ࡫ࡴࡶࡲࠣࡪࡦ࡯࡬ࡦࡦࠥኲ"))
          return
        time.sleep(1)
        bstack11ll11111l_opy_ += 1
      os.environ[bstack11l11ll_opy_ (u"࠭ࡐࡆࡔࡆ࡝ࡤࡈࡅࡔࡖࡢࡔࡑࡇࡔࡇࡑࡕࡑࠬኳ")] = str(self.bstack11l11ll1l1_opy_())
      self.logger.info(bstack11l11ll_opy_ (u"ࠢࡑࡧࡵࡧࡾࠦࡳࡦࡶࡸࡴࠥࡩ࡯࡮ࡲ࡯ࡩࡹ࡫ࡤࠣኴ"))
    except Exception as e:
      self.logger.error(bstack11l11ll_opy_ (u"ࠣࡗࡱࡥࡧࡲࡥࠡࡶࡲࠤࡸ࡫ࡴࡶࡲࠣࡴࡪࡸࡣࡺ࠮ࠣࡉࡽࡩࡥࡱࡶ࡬ࡳࡳࠦࡻࡾࠤኵ").format(e))
  def bstack11l11ll1l1_opy_(self):
    if self.bstack11l1lllll_opy_:
      return
    try:
      bstack11ll111111_opy_ = [platform[bstack11l11ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡑࡥࡲ࡫ࠧ኶")].lower() for platform in self.config.get(bstack11l11ll_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱࡸ࠭኷"), [])]
      bstack11l1ll11ll_opy_ = sys.maxsize
      bstack11l1lll111_opy_ = bstack11l11ll_opy_ (u"ࠫࠬኸ")
      for browser in bstack11ll111111_opy_:
        if browser in self.bstack11ll11l111_opy_:
          bstack11l1l1l111_opy_ = self.bstack11ll11l111_opy_[browser]
        if bstack11l1l1l111_opy_ < bstack11l1ll11ll_opy_:
          bstack11l1ll11ll_opy_ = bstack11l1l1l111_opy_
          bstack11l1lll111_opy_ = browser
      return bstack11l1lll111_opy_
    except Exception as e:
      self.logger.error(bstack11l11ll_opy_ (u"࡛ࠧ࡮ࡢࡤ࡯ࡩࠥࡺ࡯ࠡࡨ࡬ࡲࡩࠦࡢࡦࡵࡷࠤࡵࡲࡡࡵࡨࡲࡶࡲ࠲ࠠࡆࡺࡦࡩࡵࡺࡩࡰࡰࠣࡿࢂࠨኹ").format(e))