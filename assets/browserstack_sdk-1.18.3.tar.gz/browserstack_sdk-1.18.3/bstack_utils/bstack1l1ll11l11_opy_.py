# coding: UTF-8
import sys
bstack111llll_opy_ = sys.version_info [0] == 2
bstack1llllll_opy_ = 2048
bstack11ll1l_opy_ = 7
def bstack11l11ll_opy_ (bstack1l1ll11_opy_):
    global bstack1l11l_opy_
    bstack1l11ll_opy_ = ord (bstack1l1ll11_opy_ [-1])
    bstack111ll1_opy_ = bstack1l1ll11_opy_ [:-1]
    bstack1lllll_opy_ = bstack1l11ll_opy_ % len (bstack111ll1_opy_)
    bstack11l1l1l_opy_ = bstack111ll1_opy_ [:bstack1lllll_opy_] + bstack111ll1_opy_ [bstack1lllll_opy_:]
    if bstack111llll_opy_:
        bstack1ll1l_opy_ = unicode () .join ([unichr (ord (char) - bstack1llllll_opy_ - (bstack1l11l1_opy_ + bstack1l11ll_opy_) % bstack11ll1l_opy_) for bstack1l11l1_opy_, char in enumerate (bstack11l1l1l_opy_)])
    else:
        bstack1ll1l_opy_ = str () .join ([chr (ord (char) - bstack1llllll_opy_ - (bstack1l11l1_opy_ + bstack1l11ll_opy_) % bstack11ll1l_opy_) for bstack1l11l1_opy_, char in enumerate (bstack11l1l1l_opy_)])
    return eval (bstack1ll1l_opy_)
from _pytest import fixtures
from _pytest.python import _call_with_optional_argument
from pytest import Module, Class
from bstack_utils.helper import Result
def _1l1ll11lll_opy_(method, this, arg):
    arg_count = method.__code__.co_argcount
    if arg_count > 1:
        method(this, arg)
    else:
        method(this)
class bstack1l1ll1l111_opy_:
    def __init__(self, handler):
        self._1l1ll1ll1l_opy_ = {}
        self._1l1ll1l1ll_opy_ = {}
        self.handler = handler
        self.patch()
        pass
    def patch(self):
        self._1l1ll1ll1l_opy_[bstack11l11ll_opy_ (u"ࠧࡧࡷࡱࡧࡹ࡯࡯࡯ࡡࡩ࡭ࡽࡺࡵࡳࡧࠪഄ")] = Module._inject_setup_function_fixture
        self._1l1ll1ll1l_opy_[bstack11l11ll_opy_ (u"ࠨ࡯ࡲࡨࡺࡲࡥࡠࡨ࡬ࡼࡹࡻࡲࡦࠩഅ")] = Module._inject_setup_module_fixture
        self._1l1ll1ll1l_opy_[bstack11l11ll_opy_ (u"ࠩࡦࡰࡦࡹࡳࡠࡨ࡬ࡼࡹࡻࡲࡦࠩആ")] = Class._inject_setup_class_fixture
        self._1l1ll1ll1l_opy_[bstack11l11ll_opy_ (u"ࠪࡱࡪࡺࡨࡰࡦࡢࡪ࡮ࡾࡴࡶࡴࡨࠫഇ")] = Class._inject_setup_method_fixture
        Module._inject_setup_function_fixture = self.bstack1l1lll1111_opy_(bstack11l11ll_opy_ (u"ࠫ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳࡥࡦࡪࡺࡷࡹࡷ࡫ࠧഈ"))
        Module._inject_setup_module_fixture = self.bstack1l1lll1111_opy_(bstack11l11ll_opy_ (u"ࠬࡳ࡯ࡥࡷ࡯ࡩࡤ࡬ࡩࡹࡶࡸࡶࡪ࠭ഉ"))
        Class._inject_setup_class_fixture = self.bstack1l1lll1111_opy_(bstack11l11ll_opy_ (u"࠭ࡣ࡭ࡣࡶࡷࡤ࡬ࡩࡹࡶࡸࡶࡪ࠭ഊ"))
        Class._inject_setup_method_fixture = self.bstack1l1lll1111_opy_(bstack11l11ll_opy_ (u"ࠧ࡮ࡧࡷ࡬ࡴࡪ࡟ࡧ࡫ࡻࡸࡺࡸࡥࠨഋ"))
    def bstack1l1lll11l1_opy_(self, bstack1l1ll11ll1_opy_, hook_type):
        meth = getattr(bstack1l1ll11ll1_opy_, hook_type, None)
        if meth is not None and fixtures.getfixturemarker(meth) is None:
            self._1l1ll1l1ll_opy_[hook_type] = meth
            setattr(bstack1l1ll11ll1_opy_, hook_type, self.bstack1l1ll11l1l_opy_(hook_type))
    def bstack1l1ll1ll11_opy_(self, instance, bstack1l1ll1l11l_opy_):
        if bstack1l1ll1l11l_opy_ == bstack11l11ll_opy_ (u"ࠣࡨࡸࡲࡨࡺࡩࡰࡰࡢࡪ࡮ࡾࡴࡶࡴࡨࠦഌ"):
            self.bstack1l1lll11l1_opy_(instance.obj, bstack11l11ll_opy_ (u"ࠤࡶࡩࡹࡻࡰࡠࡨࡸࡲࡨࡺࡩࡰࡰࠥ഍"))
            self.bstack1l1lll11l1_opy_(instance.obj, bstack11l11ll_opy_ (u"ࠥࡸࡪࡧࡲࡥࡱࡺࡲࡤ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠢഎ"))
        if bstack1l1ll1l11l_opy_ == bstack11l11ll_opy_ (u"ࠦࡲࡵࡤࡶ࡮ࡨࡣ࡫࡯ࡸࡵࡷࡵࡩࠧഏ"):
            self.bstack1l1lll11l1_opy_(instance.obj, bstack11l11ll_opy_ (u"ࠧࡹࡥࡵࡷࡳࡣࡲࡵࡤࡶ࡮ࡨࠦഐ"))
            self.bstack1l1lll11l1_opy_(instance.obj, bstack11l11ll_opy_ (u"ࠨࡴࡦࡣࡵࡨࡴࡽ࡮ࡠ࡯ࡲࡨࡺࡲࡥࠣ഑"))
        if bstack1l1ll1l11l_opy_ == bstack11l11ll_opy_ (u"ࠢࡤ࡮ࡤࡷࡸࡥࡦࡪࡺࡷࡹࡷ࡫ࠢഒ"):
            self.bstack1l1lll11l1_opy_(instance.obj, bstack11l11ll_opy_ (u"ࠣࡵࡨࡸࡺࡶ࡟ࡤ࡮ࡤࡷࡸࠨഓ"))
            self.bstack1l1lll11l1_opy_(instance.obj, bstack11l11ll_opy_ (u"ࠤࡷࡩࡦࡸࡤࡰࡹࡱࡣࡨࡲࡡࡴࡵࠥഔ"))
        if bstack1l1ll1l11l_opy_ == bstack11l11ll_opy_ (u"ࠥࡱࡪࡺࡨࡰࡦࡢࡪ࡮ࡾࡴࡶࡴࡨࠦക"):
            self.bstack1l1lll11l1_opy_(instance.obj, bstack11l11ll_opy_ (u"ࠦࡸ࡫ࡴࡶࡲࡢࡱࡪࡺࡨࡰࡦࠥഖ"))
            self.bstack1l1lll11l1_opy_(instance.obj, bstack11l11ll_opy_ (u"ࠧࡺࡥࡢࡴࡧࡳࡼࡴ࡟࡮ࡧࡷ࡬ࡴࡪࠢഗ"))
    @staticmethod
    def bstack1l1ll1l1l1_opy_(hook_type, func, args):
        if hook_type in [bstack11l11ll_opy_ (u"࠭ࡳࡦࡶࡸࡴࡤࡳࡥࡵࡪࡲࡨࠬഘ"), bstack11l11ll_opy_ (u"ࠧࡵࡧࡤࡶࡩࡵࡷ࡯ࡡࡰࡩࡹ࡮࡯ࡥࠩങ")]:
            _1l1ll11lll_opy_(func, args[0], args[1])
            return
        _call_with_optional_argument(func, args[0])
    def bstack1l1ll11l1l_opy_(self, hook_type):
        def bstack1l1lll111l_opy_(arg=None):
            self.handler(hook_type, bstack11l11ll_opy_ (u"ࠨࡤࡨࡪࡴࡸࡥࠨച"))
            result = None
            exception = None
            try:
                self.bstack1l1ll1l1l1_opy_(hook_type, self._1l1ll1l1ll_opy_[hook_type], (arg,))
                result = Result(result=bstack11l11ll_opy_ (u"ࠩࡳࡥࡸࡹࡥࡥࠩഛ"))
            except Exception as e:
                result = Result(result=bstack11l11ll_opy_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪജ"), exception=e)
                self.handler(hook_type, bstack11l11ll_opy_ (u"ࠫࡦ࡬ࡴࡦࡴࠪഝ"), result)
                raise e.with_traceback(e.__traceback__)
            self.handler(hook_type, bstack11l11ll_opy_ (u"ࠬࡧࡦࡵࡧࡵࠫഞ"), result)
        def bstack1l1ll1lll1_opy_(this, arg=None):
            self.handler(hook_type, bstack11l11ll_opy_ (u"࠭ࡢࡦࡨࡲࡶࡪ࠭ട"))
            result = None
            exception = None
            try:
                self.bstack1l1ll1l1l1_opy_(hook_type, self._1l1ll1l1ll_opy_[hook_type], (this, arg))
                result = Result(result=bstack11l11ll_opy_ (u"ࠧࡱࡣࡶࡷࡪࡪࠧഠ"))
            except Exception as e:
                result = Result(result=bstack11l11ll_opy_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨഡ"), exception=e)
                self.handler(hook_type, bstack11l11ll_opy_ (u"ࠩࡤࡪࡹ࡫ࡲࠨഢ"), result)
                raise e.with_traceback(e.__traceback__)
            self.handler(hook_type, bstack11l11ll_opy_ (u"ࠪࡥ࡫ࡺࡥࡳࠩണ"), result)
        if hook_type in [bstack11l11ll_opy_ (u"ࠫࡸ࡫ࡴࡶࡲࡢࡱࡪࡺࡨࡰࡦࠪത"), bstack11l11ll_opy_ (u"ࠬࡺࡥࡢࡴࡧࡳࡼࡴ࡟࡮ࡧࡷ࡬ࡴࡪࠧഥ")]:
            return bstack1l1ll1lll1_opy_
        return bstack1l1lll111l_opy_
    def bstack1l1lll1111_opy_(self, bstack1l1ll1l11l_opy_):
        def bstack1l1ll1llll_opy_(this, *args, **kwargs):
            self.bstack1l1ll1ll11_opy_(this, bstack1l1ll1l11l_opy_)
            self._1l1ll1ll1l_opy_[bstack1l1ll1l11l_opy_](this, *args, **kwargs)
        return bstack1l1ll1llll_opy_