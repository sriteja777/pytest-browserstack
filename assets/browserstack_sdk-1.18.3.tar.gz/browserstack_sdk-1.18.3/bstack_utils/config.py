# coding: UTF-8
import sys
bstack111llll_opy_ = sys.version_info [0] == 2
bstack1llllll_opy_ = 2048
bstack11ll1l_opy_ = 7
def bstack11l11ll_opy_ (bstack1l1ll11_opy_):
    global bstack1l11l_opy_
    bstack1l11ll_opy_ = ord (bstack1l1ll11_opy_ [-1])
    bstack111ll1_opy_ = bstack1l1ll11_opy_ [:-1]
    bstack1lllll_opy_ = bstack1l11ll_opy_ % len (bstack111ll1_opy_)
    bstack11l1l1l_opy_ = bstack111ll1_opy_ [:bstack1lllll_opy_] + bstack111ll1_opy_ [bstack1lllll_opy_:]
    if bstack111llll_opy_:
        bstack1ll1l_opy_ = unicode () .join ([unichr (ord (char) - bstack1llllll_opy_ - (bstack1l11l1_opy_ + bstack1l11ll_opy_) % bstack11ll1l_opy_) for bstack1l11l1_opy_, char in enumerate (bstack11l1l1l_opy_)])
    else:
        bstack1ll1l_opy_ = str () .join ([chr (ord (char) - bstack1llllll_opy_ - (bstack1l11l1_opy_ + bstack1l11ll_opy_) % bstack11ll1l_opy_) for bstack1l11l1_opy_, char in enumerate (bstack11l1l1l_opy_)])
    return eval (bstack1ll1l_opy_)
conf = {
    bstack11l11ll_opy_ (u"ࠬࡧࡰࡱࡡࡤࡹࡹࡵ࡭ࡢࡶࡨࠫವ"): False,
    bstack11l11ll_opy_ (u"࠭ࡢࡴࡶࡤࡧࡰࡥࡳࡦࡵࡶ࡭ࡴࡴࠧಶ"): True,
}
class Config(object):
    instance = None
    def __init__(self):
        self._1ll1111l11_opy_ = conf
    @classmethod
    def get_instance(cls):
        if cls.instance:
            return cls.instance
        return Config()
    def get_property(self, property_name):
        return self._1ll1111l11_opy_.get(property_name, None)
    def set_property(self, property_name, bstack1ll1111l1l_opy_):
        self._1ll1111l11_opy_[property_name] = bstack1ll1111l1l_opy_