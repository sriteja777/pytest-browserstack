# coding: UTF-8
import sys
bstack111llll_opy_ = sys.version_info [0] == 2
bstack1llllll_opy_ = 2048
bstack11ll1l_opy_ = 7
def bstack11l11ll_opy_ (bstack1l1ll11_opy_):
    global bstack1l11l_opy_
    bstack1l11ll_opy_ = ord (bstack1l1ll11_opy_ [-1])
    bstack111ll1_opy_ = bstack1l1ll11_opy_ [:-1]
    bstack1lllll_opy_ = bstack1l11ll_opy_ % len (bstack111ll1_opy_)
    bstack11l1l1l_opy_ = bstack111ll1_opy_ [:bstack1lllll_opy_] + bstack111ll1_opy_ [bstack1lllll_opy_:]
    if bstack111llll_opy_:
        bstack1ll1l_opy_ = unicode () .join ([unichr (ord (char) - bstack1llllll_opy_ - (bstack1l11l1_opy_ + bstack1l11ll_opy_) % bstack11ll1l_opy_) for bstack1l11l1_opy_, char in enumerate (bstack11l1l1l_opy_)])
    else:
        bstack1ll1l_opy_ = str () .join ([chr (ord (char) - bstack1llllll_opy_ - (bstack1l11l1_opy_ + bstack1l11ll_opy_) % bstack11ll1l_opy_) for bstack1l11l1_opy_, char in enumerate (bstack11l1l1l_opy_)])
    return eval (bstack1ll1l_opy_)
import os
from uuid import uuid4
from bstack_utils.helper import bstack11ll1llll_opy_, bstack11llll1lll_opy_
from bstack_utils.bstack11111llll_opy_ import bstack1l11l111ll_opy_
class bstack1l11l1l11l_opy_:
    def __init__(self, name=None, code=None, uuid=None, file_path=None, bstack11ll1lllll_opy_=None, framework=None, tags=[], scope=[], bstack11ll11lll1_opy_=None, bstack11ll11llll_opy_=True, bstack11ll1l1l11_opy_=None, bstack1l11llll1_opy_=None, result=None, duration=None, meta={}):
        self.name = name
        self.code = code
        self.file_path = file_path
        self.uuid = uuid
        if not self.uuid and bstack11ll11llll_opy_:
            self.uuid = uuid4().__str__()
        self.bstack11ll1lllll_opy_ = bstack11ll1lllll_opy_
        self.framework = framework
        self.tags = tags
        self.scope = scope
        self.bstack11ll11lll1_opy_ = bstack11ll11lll1_opy_
        self.bstack11ll1l1l11_opy_ = bstack11ll1l1l11_opy_
        self.bstack1l11llll1_opy_ = bstack1l11llll1_opy_
        self.result = result
        self.duration = duration
        self.meta = meta
    def bstack11ll1ll1l1_opy_(self):
        if self.uuid:
            return self.uuid
        self.uuid = uuid4().__str__()
        return self.uuid
    def bstack11ll1lll11_opy_(self):
        bstack11ll1ll11l_opy_ = os.path.relpath(self.file_path, start=os.getcwd())
        return {
            bstack11l11ll_opy_ (u"ࠫ࡫࡯࡬ࡦࡡࡱࡥࡲ࡫ࠧሥ"): bstack11ll1ll11l_opy_,
            bstack11l11ll_opy_ (u"ࠬࡲ࡯ࡤࡣࡷ࡭ࡴࡴࠧሦ"): bstack11ll1ll11l_opy_,
            bstack11l11ll_opy_ (u"࠭ࡶࡤࡡࡩ࡭ࡱ࡫ࡰࡢࡶ࡫ࠫሧ"): bstack11ll1ll11l_opy_
        }
    def set(self, **kwargs):
        for key, val in kwargs.items():
            if not hasattr(self, key):
                raise TypeError(bstack11l11ll_opy_ (u"ࠢࡖࡰࡨࡼࡵ࡫ࡣࡵࡧࡧࠤࡦࡸࡧࡶ࡯ࡨࡲࡹࡀࠠࠣረ") + key)
            setattr(self, key, val)
    def bstack11ll1l1l1l_opy_(self):
        return {
            bstack11l11ll_opy_ (u"ࠨࡰࡤࡱࡪ࠭ሩ"): self.name,
            bstack11l11ll_opy_ (u"ࠩࡥࡳࡩࡿࠧሪ"): {
                bstack11l11ll_opy_ (u"ࠪࡰࡦࡴࡧࠨራ"): bstack11l11ll_opy_ (u"ࠫࡵࡿࡴࡩࡱࡱࠫሬ"),
                bstack11l11ll_opy_ (u"ࠬࡩ࡯ࡥࡧࠪር"): self.code
            },
            bstack11l11ll_opy_ (u"࠭ࡳࡤࡱࡳࡩࡸ࠭ሮ"): self.scope,
            bstack11l11ll_opy_ (u"ࠧࡵࡣࡪࡷࠬሯ"): self.tags,
            bstack11l11ll_opy_ (u"ࠨࡨࡵࡥࡲ࡫ࡷࡰࡴ࡮ࠫሰ"): self.framework,
            bstack11l11ll_opy_ (u"ࠩࡶࡸࡦࡸࡴࡦࡦࡢࡥࡹ࠭ሱ"): self.bstack11ll1lllll_opy_
        }
    def bstack11ll1lll1l_opy_(self):
        return {
         bstack11l11ll_opy_ (u"ࠪࡱࡪࡺࡡࠨሲ"): self.meta
        }
    def bstack11ll1l1ll1_opy_(self):
        return {
            bstack11l11ll_opy_ (u"ࠫࡨࡻࡳࡵࡱࡰࡖࡪࡸࡵ࡯ࡒࡤࡶࡦࡳࠧሳ"): {
                bstack11l11ll_opy_ (u"ࠬࡸࡥࡳࡷࡱࡣࡳࡧ࡭ࡦࠩሴ"): self.bstack11ll11lll1_opy_
            }
        }
    def bstack11lll11111_opy_(self, bstack11ll1l1111_opy_, details):
        step = next(filter(lambda st: st[bstack11l11ll_opy_ (u"࠭ࡩࡥࠩስ")] == bstack11ll1l1111_opy_, self.meta[bstack11l11ll_opy_ (u"ࠧࡴࡶࡨࡴࡸ࠭ሶ")]), None)
        step.update(details)
    def bstack11ll1llll1_opy_(self, bstack11ll1l1111_opy_):
        step = next(filter(lambda st: st[bstack11l11ll_opy_ (u"ࠨ࡫ࡧࠫሷ")] == bstack11ll1l1111_opy_, self.meta[bstack11l11ll_opy_ (u"ࠩࡶࡸࡪࡶࡳࠨሸ")]), None)
        step.update({
            bstack11l11ll_opy_ (u"ࠪࡷࡹࡧࡲࡵࡧࡧࡣࡦࡺࠧሹ"): bstack11ll1llll_opy_()
        })
    def bstack11ll1ll111_opy_(self, bstack11ll1l1111_opy_, result):
        bstack11ll1l1l11_opy_ = bstack11ll1llll_opy_()
        step = next(filter(lambda st: st[bstack11l11ll_opy_ (u"ࠫ࡮ࡪࠧሺ")] == bstack11ll1l1111_opy_, self.meta[bstack11l11ll_opy_ (u"ࠬࡹࡴࡦࡲࡶࠫሻ")]), None)
        step.update({
            bstack11l11ll_opy_ (u"࠭ࡦࡪࡰ࡬ࡷ࡭࡫ࡤࡠࡣࡷࠫሼ"): bstack11ll1l1l11_opy_,
            bstack11l11ll_opy_ (u"ࠧࡥࡷࡵࡥࡹ࡯࡯࡯ࠩሽ"): bstack11llll1lll_opy_(step[bstack11l11ll_opy_ (u"ࠨࡵࡷࡥࡷࡺࡥࡥࡡࡤࡸࠬሾ")], bstack11ll1l1l11_opy_),
            bstack11l11ll_opy_ (u"ࠩࡵࡩࡸࡻ࡬ࡵࠩሿ"): result.result,
            bstack11l11ll_opy_ (u"ࠪࡪࡦ࡯࡬ࡶࡴࡨࠫቀ"): str(result.exception) if result.exception else None
        })
    def bstack11ll1l11l1_opy_(self):
        return {
            bstack11l11ll_opy_ (u"ࠫࡺࡻࡩࡥࠩቁ"): self.bstack11ll1ll1l1_opy_(),
            **self.bstack11ll1l1l1l_opy_(),
            **self.bstack11ll1lll11_opy_(),
            **self.bstack11ll1lll1l_opy_()
        }
    def bstack11ll1l1lll_opy_(self):
        data = {
            bstack11l11ll_opy_ (u"ࠬ࡬ࡩ࡯࡫ࡶ࡬ࡪࡪ࡟ࡢࡶࠪቂ"): self.bstack11ll1l1l11_opy_,
            bstack11l11ll_opy_ (u"࠭ࡤࡶࡴࡤࡸ࡮ࡵ࡮ࡠ࡫ࡱࡣࡲࡹࠧቃ"): self.duration,
            bstack11l11ll_opy_ (u"ࠧࡳࡧࡶࡹࡱࡺࠧቄ"): self.result.result
        }
        if data[bstack11l11ll_opy_ (u"ࠨࡴࡨࡷࡺࡲࡴࠨቅ")] == bstack11l11ll_opy_ (u"ࠩࡩࡥ࡮ࡲࡥࡥࠩቆ"):
            data[bstack11l11ll_opy_ (u"ࠪࡪࡦ࡯࡬ࡶࡴࡨࡣࡹࡿࡰࡦࠩቇ")] = self.result.bstack1l11l1l111_opy_()
            data[bstack11l11ll_opy_ (u"ࠫ࡫ࡧࡩ࡭ࡷࡵࡩࠬቈ")] = [{bstack11l11ll_opy_ (u"ࠬࡨࡡࡤ࡭ࡷࡶࡦࡩࡥࠨ቉"): self.result.bstack11lll1ll1l_opy_()}]
        return data
    def bstack11ll1l11ll_opy_(self):
        return {
            bstack11l11ll_opy_ (u"࠭ࡵࡶ࡫ࡧࠫቊ"): self.bstack11ll1ll1l1_opy_(),
            **self.bstack11ll1l1l1l_opy_(),
            **self.bstack11ll1lll11_opy_(),
            **self.bstack11ll1l1lll_opy_(),
            **self.bstack11ll1lll1l_opy_()
        }
    def bstack1l1l1l111l_opy_(self, event, result=None):
        if result:
            self.result = result
        if event == bstack11l11ll_opy_ (u"ࠧࡕࡧࡶࡸࡗࡻ࡮ࡔࡶࡤࡶࡹ࡫ࡤࠨቋ"):
            return self.bstack11ll1l11l1_opy_()
        elif event == bstack11l11ll_opy_ (u"ࠨࡖࡨࡷࡹࡘࡵ࡯ࡈ࡬ࡲ࡮ࡹࡨࡦࡦࠪቌ"):
            return self.bstack11ll1l11ll_opy_()
    def bstack1l1l11ll1l_opy_(self):
        pass
    def stop(self, time=None, duration=None, result=None):
        self.bstack11ll1l1l11_opy_ = time if time else bstack11ll1llll_opy_()
        self.duration = duration if duration else bstack11llll1lll_opy_(self.bstack11ll1lllll_opy_, self.bstack11ll1l1l11_opy_)
        if result:
            self.result = result
class bstack11ll1l111l_opy_(bstack1l11l1l11l_opy_):
    def __init__(self, *args, hooks=[], **kwargs):
        self.hooks = hooks
        super().__init__(*args, **kwargs, bstack1l11llll1_opy_=bstack11l11ll_opy_ (u"ࠩࡷࡩࡸࡺࠧቍ"))
    @classmethod
    def bstack11ll1ll1ll_opy_(cls, scenario, feature, test, **kwargs):
        steps = []
        for step in scenario.steps:
            steps.append({
                bstack11l11ll_opy_ (u"ࠪ࡭ࡩ࠭቎"): id(step),
                bstack11l11ll_opy_ (u"ࠫࡹ࡫ࡸࡵࠩ቏"): step.name,
                bstack11l11ll_opy_ (u"ࠬࡱࡥࡺࡹࡲࡶࡩ࠭ቐ"): step.keyword,
            })
        return bstack11ll1l111l_opy_(
            **kwargs,
            meta={
                bstack11l11ll_opy_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࠧቑ"): {
                    bstack11l11ll_opy_ (u"ࠧ࡯ࡣࡰࡩࠬቒ"): feature.name,
                    bstack11l11ll_opy_ (u"ࠨࡲࡤࡸ࡭࠭ቓ"): feature.filename,
                    bstack11l11ll_opy_ (u"ࠩࡧࡩࡸࡩࡲࡪࡲࡷ࡭ࡴࡴࠧቔ"): feature.description
                },
                bstack11l11ll_opy_ (u"ࠪࡷࡨ࡫࡮ࡢࡴ࡬ࡳࠬቕ"): {
                    bstack11l11ll_opy_ (u"ࠫࡳࡧ࡭ࡦࠩቖ"): scenario.name
                },
                bstack11l11ll_opy_ (u"ࠬࡹࡴࡦࡲࡶࠫ቗"): steps,
                bstack11l11ll_opy_ (u"࠭ࡥࡹࡣࡰࡴࡱ࡫ࡳࠨቘ"): bstack1l11l111ll_opy_(test)
            }
        )
    def bstack11lll1111l_opy_(self):
        return {
            bstack11l11ll_opy_ (u"ࠧࡩࡱࡲ࡯ࡸ࠭቙"): self.hooks
        }
    def bstack11ll1l11ll_opy_(self):
        return {
            **super().bstack11ll1l11ll_opy_(),
            **self.bstack11lll1111l_opy_()
        }
    def bstack1l1l11ll1l_opy_(self):
        return bstack11l11ll_opy_ (u"ࠨࡶࡨࡷࡹࡥࡲࡶࡰࠪቚ")