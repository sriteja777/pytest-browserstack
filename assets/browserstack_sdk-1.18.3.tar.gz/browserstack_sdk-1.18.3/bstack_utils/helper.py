# coding: UTF-8
import sys
bstack111llll_opy_ = sys.version_info [0] == 2
bstack1llllll_opy_ = 2048
bstack11ll1l_opy_ = 7
def bstack11l11ll_opy_ (bstack1l1ll11_opy_):
    global bstack1l11l_opy_
    bstack1l11ll_opy_ = ord (bstack1l1ll11_opy_ [-1])
    bstack111ll1_opy_ = bstack1l1ll11_opy_ [:-1]
    bstack1lllll_opy_ = bstack1l11ll_opy_ % len (bstack111ll1_opy_)
    bstack11l1l1l_opy_ = bstack111ll1_opy_ [:bstack1lllll_opy_] + bstack111ll1_opy_ [bstack1lllll_opy_:]
    if bstack111llll_opy_:
        bstack1ll1l_opy_ = unicode () .join ([unichr (ord (char) - bstack1llllll_opy_ - (bstack1l11l1_opy_ + bstack1l11ll_opy_) % bstack11ll1l_opy_) for bstack1l11l1_opy_, char in enumerate (bstack11l1l1l_opy_)])
    else:
        bstack1ll1l_opy_ = str () .join ([chr (ord (char) - bstack1llllll_opy_ - (bstack1l11l1_opy_ + bstack1l11ll_opy_) % bstack11ll1l_opy_) for bstack1l11l1_opy_, char in enumerate (bstack11l1l1l_opy_)])
    return eval (bstack1ll1l_opy_)
import datetime
import json
import os
import platform
import re
import subprocess
import traceback
from urllib.parse import urlparse
import git
import requests
from packaging import version
from bstack_utils.config import Config
from bstack_utils.constants import bstack1l1ll111ll_opy_, bstack111111lll_opy_, bstack1ll1lll1l_opy_, bstack1lllll111l_opy_
from bstack_utils.messages import bstack11ll111l1_opy_, bstack1l1l1l11_opy_
from bstack_utils.proxy import bstack111l11ll_opy_, bstack1lllll1ll1_opy_
bstack11l1111l_opy_ = Config.get_instance()
def bstack1l11l1l1l1_opy_(config):
    return config[bstack11l11ll_opy_ (u"ࠨࡷࡶࡩࡷࡔࡡ࡮ࡧࠪၩ")]
def bstack1l11lllll1_opy_(config):
    return config[bstack11l11ll_opy_ (u"ࠩࡤࡧࡨ࡫ࡳࡴࡍࡨࡽࠬၪ")]
def bstack111l11lll_opy_():
    try:
        import playwright
        return True
    except ImportError:
        return False
def bstack11lll1l11l_opy_(obj):
    values = []
    bstack11llll1111_opy_ = re.compile(bstack11l11ll_opy_ (u"ࡵࠦࡣࡉࡕࡔࡖࡒࡑࡤ࡚ࡁࡈࡡ࡟ࡨ࠰ࠪࠢၫ"), re.I)
    for key in obj.keys():
        if bstack11llll1111_opy_.match(key):
            values.append(obj[key])
    return values
def bstack1l11l11l1l_opy_(config):
    tags = []
    tags.extend(bstack11lll1l11l_opy_(os.environ))
    tags.extend(bstack11lll1l11l_opy_(config))
    return tags
def bstack11llll111l_opy_(markers):
    tags = []
    for marker in markers:
        tags.append(marker.name)
    return tags
def bstack11lll1l1ll_opy_(bstack1l11111ll1_opy_):
    if not bstack1l11111ll1_opy_:
        return bstack11l11ll_opy_ (u"ࠫࠬၬ")
    return bstack11l11ll_opy_ (u"ࠧࢁࡽࠡࠪࡾࢁ࠮ࠨၭ").format(bstack1l11111ll1_opy_.name, bstack1l11111ll1_opy_.email)
def bstack1l1l1l11l1_opy_():
    try:
        repo = git.Repo(search_parent_directories=True)
        bstack11lllll1l1_opy_ = repo.common_dir
        info = {
            bstack11l11ll_opy_ (u"ࠨࡳࡩࡣࠥၮ"): repo.head.commit.hexsha,
            bstack11l11ll_opy_ (u"ࠢࡴࡪࡲࡶࡹࡥࡳࡩࡣࠥၯ"): repo.git.rev_parse(repo.head.commit, short=True),
            bstack11l11ll_opy_ (u"ࠣࡤࡵࡥࡳࡩࡨࠣၰ"): repo.active_branch.name,
            bstack11l11ll_opy_ (u"ࠤࡷࡥ࡬ࠨၱ"): repo.git.describe(all=True, tags=True, exact_match=True),
            bstack11l11ll_opy_ (u"ࠥࡧࡴࡳ࡭ࡪࡶࡷࡩࡷࠨၲ"): bstack11lll1l1ll_opy_(repo.head.commit.committer),
            bstack11l11ll_opy_ (u"ࠦࡨࡵ࡭࡮࡫ࡷࡸࡪࡸ࡟ࡥࡣࡷࡩࠧၳ"): repo.head.commit.committed_datetime.isoformat(),
            bstack11l11ll_opy_ (u"ࠧࡧࡵࡵࡪࡲࡶࠧၴ"): bstack11lll1l1ll_opy_(repo.head.commit.author),
            bstack11l11ll_opy_ (u"ࠨࡡࡶࡶ࡫ࡳࡷࡥࡤࡢࡶࡨࠦၵ"): repo.head.commit.authored_datetime.isoformat(),
            bstack11l11ll_opy_ (u"ࠢࡤࡱࡰࡱ࡮ࡺ࡟࡮ࡧࡶࡷࡦ࡭ࡥࠣၶ"): repo.head.commit.message,
            bstack11l11ll_opy_ (u"ࠣࡴࡲࡳࡹࠨၷ"): repo.git.rev_parse(bstack11l11ll_opy_ (u"ࠤ࠰࠱ࡸ࡮࡯ࡸ࠯ࡷࡳࡵࡲࡥࡷࡧ࡯ࠦၸ")),
            bstack11l11ll_opy_ (u"ࠥࡧࡴࡳ࡭ࡰࡰࡢ࡫࡮ࡺ࡟ࡥ࡫ࡵࠦၹ"): bstack11lllll1l1_opy_,
            bstack11l11ll_opy_ (u"ࠦࡼࡵࡲ࡬ࡶࡵࡩࡪࡥࡧࡪࡶࡢࡨ࡮ࡸࠢၺ"): subprocess.check_output([bstack11l11ll_opy_ (u"ࠧ࡭ࡩࡵࠤၻ"), bstack11l11ll_opy_ (u"ࠨࡲࡦࡸ࠰ࡴࡦࡸࡳࡦࠤၼ"), bstack11l11ll_opy_ (u"ࠢ࠮࠯ࡪ࡭ࡹ࠳ࡣࡰ࡯ࡰࡳࡳ࠳ࡤࡪࡴࠥၽ")]).strip().decode(
                bstack11l11ll_opy_ (u"ࠨࡷࡷࡪ࠲࠾ࠧၾ")),
            bstack11l11ll_opy_ (u"ࠤ࡯ࡥࡸࡺ࡟ࡵࡣࡪࠦၿ"): repo.git.describe(tags=True, abbrev=0, always=True),
            bstack11l11ll_opy_ (u"ࠥࡧࡴࡳ࡭ࡪࡶࡶࡣࡸ࡯࡮ࡤࡧࡢࡰࡦࡹࡴࡠࡶࡤ࡫ࠧႀ"): repo.git.rev_list(
                bstack11l11ll_opy_ (u"ࠦࢀࢃ࠮࠯ࡽࢀࠦႁ").format(repo.head.commit, repo.git.describe(tags=True, abbrev=0, always=True)), count=True)
        }
        remotes = repo.remotes
        bstack1l11111l11_opy_ = []
        for remote in remotes:
            bstack11llll1l1l_opy_ = {
                bstack11l11ll_opy_ (u"ࠧࡴࡡ࡮ࡧࠥႂ"): remote.name,
                bstack11l11ll_opy_ (u"ࠨࡵࡳ࡮ࠥႃ"): remote.url,
            }
            bstack1l11111l11_opy_.append(bstack11llll1l1l_opy_)
        return {
            bstack11l11ll_opy_ (u"ࠢ࡯ࡣࡰࡩࠧႄ"): bstack11l11ll_opy_ (u"ࠣࡩ࡬ࡸࠧႅ"),
            **info,
            bstack11l11ll_opy_ (u"ࠤࡵࡩࡲࡵࡴࡦࡵࠥႆ"): bstack1l11111l11_opy_
        }
    except Exception as err:
        print(bstack11l11ll_opy_ (u"ࠥࡉࡽࡩࡥࡱࡶ࡬ࡳࡳࠦࡩ࡯ࠢࡳࡳࡵࡻ࡬ࡢࡶ࡬ࡲ࡬ࠦࡇࡪࡶࠣࡱࡪࡺࡡࡥࡣࡷࡥࠥࡽࡩࡵࡪࠣࡩࡷࡸ࡯ࡳ࠼ࠣࡿࢂࠨႇ").format(err))
        return {}
def bstack1lll11ll1l_opy_():
    env = os.environ
    if (bstack11l11ll_opy_ (u"ࠦࡏࡋࡎࡌࡋࡑࡗࡤ࡛ࡒࡍࠤႈ") in env and len(env[bstack11l11ll_opy_ (u"ࠧࡐࡅࡏࡍࡌࡒࡘࡥࡕࡓࡎࠥႉ")]) > 0) or (
            bstack11l11ll_opy_ (u"ࠨࡊࡆࡐࡎࡍࡓ࡙࡟ࡉࡑࡐࡉࠧႊ") in env and len(env[bstack11l11ll_opy_ (u"ࠢࡋࡇࡑࡏࡎࡔࡓࡠࡊࡒࡑࡊࠨႋ")]) > 0):
        return {
            bstack11l11ll_opy_ (u"ࠣࡰࡤࡱࡪࠨႌ"): bstack11l11ll_opy_ (u"ࠤࡍࡩࡳࡱࡩ࡯ࡵႍࠥ"),
            bstack11l11ll_opy_ (u"ࠥࡦࡺ࡯࡬ࡥࡡࡸࡶࡱࠨႎ"): env.get(bstack11l11ll_opy_ (u"ࠦࡇ࡛ࡉࡍࡆࡢ࡙ࡗࡒࠢႏ")),
            bstack11l11ll_opy_ (u"ࠧࡰ࡯ࡣࡡࡱࡥࡲ࡫ࠢ႐"): env.get(bstack11l11ll_opy_ (u"ࠨࡊࡐࡄࡢࡒࡆࡓࡅࠣ႑")),
            bstack11l11ll_opy_ (u"ࠢࡣࡷ࡬ࡰࡩࡥ࡮ࡶ࡯ࡥࡩࡷࠨ႒"): env.get(bstack11l11ll_opy_ (u"ࠣࡄࡘࡍࡑࡊ࡟ࡏࡗࡐࡆࡊࡘࠢ႓"))
        }
    if env.get(bstack11l11ll_opy_ (u"ࠤࡆࡍࠧ႔")) == bstack11l11ll_opy_ (u"ࠥࡸࡷࡻࡥࠣ႕") and bstack1l1l11l111_opy_(env.get(bstack11l11ll_opy_ (u"ࠦࡈࡏࡒࡄࡎࡈࡇࡎࠨ႖"))):
        return {
            bstack11l11ll_opy_ (u"ࠧࡴࡡ࡮ࡧࠥ႗"): bstack11l11ll_opy_ (u"ࠨࡃࡪࡴࡦࡰࡪࡉࡉࠣ႘"),
            bstack11l11ll_opy_ (u"ࠢࡣࡷ࡬ࡰࡩࡥࡵࡳ࡮ࠥ႙"): env.get(bstack11l11ll_opy_ (u"ࠣࡅࡌࡖࡈࡒࡅࡠࡄࡘࡍࡑࡊ࡟ࡖࡔࡏࠦႚ")),
            bstack11l11ll_opy_ (u"ࠤ࡭ࡳࡧࡥ࡮ࡢ࡯ࡨࠦႛ"): env.get(bstack11l11ll_opy_ (u"ࠥࡇࡎࡘࡃࡍࡇࡢࡎࡔࡈࠢႜ")),
            bstack11l11ll_opy_ (u"ࠦࡧࡻࡩ࡭ࡦࡢࡲࡺࡳࡢࡦࡴࠥႝ"): env.get(bstack11l11ll_opy_ (u"ࠧࡉࡉࡓࡅࡏࡉࡤࡈࡕࡊࡎࡇࡣࡓ࡛ࡍࠣ႞"))
        }
    if env.get(bstack11l11ll_opy_ (u"ࠨࡃࡊࠤ႟")) == bstack11l11ll_opy_ (u"ࠢࡵࡴࡸࡩࠧႠ") and bstack1l1l11l111_opy_(env.get(bstack11l11ll_opy_ (u"ࠣࡖࡕࡅ࡛ࡏࡓࠣႡ"))):
        return {
            bstack11l11ll_opy_ (u"ࠤࡱࡥࡲ࡫ࠢႢ"): bstack11l11ll_opy_ (u"ࠥࡘࡷࡧࡶࡪࡵࠣࡇࡎࠨႣ"),
            bstack11l11ll_opy_ (u"ࠦࡧࡻࡩ࡭ࡦࡢࡹࡷࡲࠢႤ"): env.get(bstack11l11ll_opy_ (u"࡚ࠧࡒࡂࡘࡌࡗࡤࡈࡕࡊࡎࡇࡣ࡜ࡋࡂࡠࡗࡕࡐࠧႥ")),
            bstack11l11ll_opy_ (u"ࠨࡪࡰࡤࡢࡲࡦࡳࡥࠣႦ"): env.get(bstack11l11ll_opy_ (u"ࠢࡕࡔࡄ࡚ࡎ࡙࡟ࡋࡑࡅࡣࡓࡇࡍࡆࠤႧ")),
            bstack11l11ll_opy_ (u"ࠣࡤࡸ࡭ࡱࡪ࡟࡯ࡷࡰࡦࡪࡸࠢႨ"): env.get(bstack11l11ll_opy_ (u"ࠤࡗࡖࡆ࡜ࡉࡔࡡࡅ࡙ࡎࡒࡄࡠࡐࡘࡑࡇࡋࡒࠣႩ"))
        }
    if env.get(bstack11l11ll_opy_ (u"ࠥࡇࡎࠨႪ")) == bstack11l11ll_opy_ (u"ࠦࡹࡸࡵࡦࠤႫ") and env.get(bstack11l11ll_opy_ (u"ࠧࡉࡉࡠࡐࡄࡑࡊࠨႬ")) == bstack11l11ll_opy_ (u"ࠨࡣࡰࡦࡨࡷ࡭࡯ࡰࠣႭ"):
        return {
            bstack11l11ll_opy_ (u"ࠢ࡯ࡣࡰࡩࠧႮ"): bstack11l11ll_opy_ (u"ࠣࡅࡲࡨࡪࡹࡨࡪࡲࠥႯ"),
            bstack11l11ll_opy_ (u"ࠤࡥࡹ࡮ࡲࡤࡠࡷࡵࡰࠧႰ"): None,
            bstack11l11ll_opy_ (u"ࠥ࡮ࡴࡨ࡟࡯ࡣࡰࡩࠧႱ"): None,
            bstack11l11ll_opy_ (u"ࠦࡧࡻࡩ࡭ࡦࡢࡲࡺࡳࡢࡦࡴࠥႲ"): None
        }
    if env.get(bstack11l11ll_opy_ (u"ࠧࡈࡉࡕࡄࡘࡇࡐࡋࡔࡠࡄࡕࡅࡓࡉࡈࠣႳ")) and env.get(bstack11l11ll_opy_ (u"ࠨࡂࡊࡖࡅ࡙ࡈࡑࡅࡕࡡࡆࡓࡒࡓࡉࡕࠤႴ")):
        return {
            bstack11l11ll_opy_ (u"ࠢ࡯ࡣࡰࡩࠧႵ"): bstack11l11ll_opy_ (u"ࠣࡄ࡬ࡸࡧࡻࡣ࡬ࡧࡷࠦႶ"),
            bstack11l11ll_opy_ (u"ࠤࡥࡹ࡮ࡲࡤࡠࡷࡵࡰࠧႷ"): env.get(bstack11l11ll_opy_ (u"ࠥࡆࡎ࡚ࡂࡖࡅࡎࡉ࡙ࡥࡇࡊࡖࡢࡌ࡙࡚ࡐࡠࡑࡕࡍࡌࡏࡎࠣႸ")),
            bstack11l11ll_opy_ (u"ࠦ࡯ࡵࡢࡠࡰࡤࡱࡪࠨႹ"): None,
            bstack11l11ll_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡳࡻ࡭ࡣࡧࡵࠦႺ"): env.get(bstack11l11ll_opy_ (u"ࠨࡂࡊࡖࡅ࡙ࡈࡑࡅࡕࡡࡅ࡙ࡎࡒࡄࡠࡐࡘࡑࡇࡋࡒࠣႻ"))
        }
    if env.get(bstack11l11ll_opy_ (u"ࠢࡄࡋࠥႼ")) == bstack11l11ll_opy_ (u"ࠣࡶࡵࡹࡪࠨႽ") and bstack1l1l11l111_opy_(env.get(bstack11l11ll_opy_ (u"ࠤࡇࡖࡔࡔࡅࠣႾ"))):
        return {
            bstack11l11ll_opy_ (u"ࠥࡲࡦࡳࡥࠣႿ"): bstack11l11ll_opy_ (u"ࠦࡉࡸ࡯࡯ࡧࠥჀ"),
            bstack11l11ll_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡺࡸ࡬ࠣჁ"): env.get(bstack11l11ll_opy_ (u"ࠨࡄࡓࡑࡑࡉࡤࡈࡕࡊࡎࡇࡣࡑࡏࡎࡌࠤჂ")),
            bstack11l11ll_opy_ (u"ࠢ࡫ࡱࡥࡣࡳࡧ࡭ࡦࠤჃ"): None,
            bstack11l11ll_opy_ (u"ࠣࡤࡸ࡭ࡱࡪ࡟࡯ࡷࡰࡦࡪࡸࠢჄ"): env.get(bstack11l11ll_opy_ (u"ࠤࡇࡖࡔࡔࡅࡠࡄࡘࡍࡑࡊ࡟ࡏࡗࡐࡆࡊࡘࠢჅ"))
        }
    if env.get(bstack11l11ll_opy_ (u"ࠥࡇࡎࠨ჆")) == bstack11l11ll_opy_ (u"ࠦࡹࡸࡵࡦࠤჇ") and bstack1l1l11l111_opy_(env.get(bstack11l11ll_opy_ (u"࡙ࠧࡅࡎࡃࡓࡌࡔࡘࡅࠣ჈"))):
        return {
            bstack11l11ll_opy_ (u"ࠨ࡮ࡢ࡯ࡨࠦ჉"): bstack11l11ll_opy_ (u"ࠢࡔࡧࡰࡥࡵ࡮࡯ࡳࡧࠥ჊"),
            bstack11l11ll_opy_ (u"ࠣࡤࡸ࡭ࡱࡪ࡟ࡶࡴ࡯ࠦ჋"): env.get(bstack11l11ll_opy_ (u"ࠤࡖࡉࡒࡇࡐࡉࡑࡕࡉࡤࡕࡒࡈࡃࡑࡍ࡟ࡇࡔࡊࡑࡑࡣ࡚ࡘࡌࠣ჌")),
            bstack11l11ll_opy_ (u"ࠥ࡮ࡴࡨ࡟࡯ࡣࡰࡩࠧჍ"): env.get(bstack11l11ll_opy_ (u"ࠦࡘࡋࡍࡂࡒࡋࡓࡗࡋ࡟ࡋࡑࡅࡣࡓࡇࡍࡆࠤ჎")),
            bstack11l11ll_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡳࡻ࡭ࡣࡧࡵࠦ჏"): env.get(bstack11l11ll_opy_ (u"ࠨࡓࡆࡏࡄࡔࡍࡕࡒࡆࡡࡍࡓࡇࡥࡉࡅࠤა"))
        }
    if env.get(bstack11l11ll_opy_ (u"ࠢࡄࡋࠥბ")) == bstack11l11ll_opy_ (u"ࠣࡶࡵࡹࡪࠨგ") and bstack1l1l11l111_opy_(env.get(bstack11l11ll_opy_ (u"ࠤࡊࡍ࡙ࡒࡁࡃࡡࡆࡍࠧდ"))):
        return {
            bstack11l11ll_opy_ (u"ࠥࡲࡦࡳࡥࠣე"): bstack11l11ll_opy_ (u"ࠦࡌ࡯ࡴࡍࡣࡥࠦვ"),
            bstack11l11ll_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡺࡸ࡬ࠣზ"): env.get(bstack11l11ll_opy_ (u"ࠨࡃࡊࡡࡍࡓࡇࡥࡕࡓࡎࠥთ")),
            bstack11l11ll_opy_ (u"ࠢ࡫ࡱࡥࡣࡳࡧ࡭ࡦࠤი"): env.get(bstack11l11ll_opy_ (u"ࠣࡅࡌࡣࡏࡕࡂࡠࡐࡄࡑࡊࠨკ")),
            bstack11l11ll_opy_ (u"ࠤࡥࡹ࡮ࡲࡤࡠࡰࡸࡱࡧ࡫ࡲࠣლ"): env.get(bstack11l11ll_opy_ (u"ࠥࡇࡎࡥࡊࡐࡄࡢࡍࡉࠨმ"))
        }
    if env.get(bstack11l11ll_opy_ (u"ࠦࡈࡏࠢნ")) == bstack11l11ll_opy_ (u"ࠧࡺࡲࡶࡧࠥო") and bstack1l1l11l111_opy_(env.get(bstack11l11ll_opy_ (u"ࠨࡂࡖࡋࡏࡈࡐࡏࡔࡆࠤპ"))):
        return {
            bstack11l11ll_opy_ (u"ࠢ࡯ࡣࡰࡩࠧჟ"): bstack11l11ll_opy_ (u"ࠣࡄࡸ࡭ࡱࡪ࡫ࡪࡶࡨࠦრ"),
            bstack11l11ll_opy_ (u"ࠤࡥࡹ࡮ࡲࡤࡠࡷࡵࡰࠧს"): env.get(bstack11l11ll_opy_ (u"ࠥࡆ࡚ࡏࡌࡅࡍࡌࡘࡊࡥࡂࡖࡋࡏࡈࡤ࡛ࡒࡍࠤტ")),
            bstack11l11ll_opy_ (u"ࠦ࡯ࡵࡢࡠࡰࡤࡱࡪࠨუ"): env.get(bstack11l11ll_opy_ (u"ࠧࡈࡕࡊࡎࡇࡏࡎ࡚ࡅࡠࡎࡄࡆࡊࡒࠢფ")) or env.get(bstack11l11ll_opy_ (u"ࠨࡂࡖࡋࡏࡈࡐࡏࡔࡆࡡࡓࡍࡕࡋࡌࡊࡐࡈࡣࡓࡇࡍࡆࠤქ")),
            bstack11l11ll_opy_ (u"ࠢࡣࡷ࡬ࡰࡩࡥ࡮ࡶ࡯ࡥࡩࡷࠨღ"): env.get(bstack11l11ll_opy_ (u"ࠣࡄࡘࡍࡑࡊࡋࡊࡖࡈࡣࡇ࡛ࡉࡍࡆࡢࡒ࡚ࡓࡂࡆࡔࠥყ"))
        }
    if bstack1l1l11l111_opy_(env.get(bstack11l11ll_opy_ (u"ࠤࡗࡊࡤࡈࡕࡊࡎࡇࠦშ"))):
        return {
            bstack11l11ll_opy_ (u"ࠥࡲࡦࡳࡥࠣჩ"): bstack11l11ll_opy_ (u"࡛ࠦ࡯ࡳࡶࡣ࡯ࠤࡘࡺࡵࡥ࡫ࡲࠤ࡙࡫ࡡ࡮ࠢࡖࡩࡷࡼࡩࡤࡧࡶࠦც"),
            bstack11l11ll_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡺࡸ࡬ࠣძ"): bstack11l11ll_opy_ (u"ࠨࡻࡾࡽࢀࠦწ").format(env.get(bstack11l11ll_opy_ (u"ࠧࡔ࡛ࡖࡘࡊࡓ࡟ࡕࡇࡄࡑࡋࡕࡕࡏࡆࡄࡘࡎࡕࡎࡔࡇࡕ࡚ࡊࡘࡕࡓࡋࠪჭ")), env.get(bstack11l11ll_opy_ (u"ࠨࡕ࡜ࡗ࡙ࡋࡍࡠࡖࡈࡅࡒࡖࡒࡐࡌࡈࡇ࡙ࡏࡄࠨხ"))),
            bstack11l11ll_opy_ (u"ࠤ࡭ࡳࡧࡥ࡮ࡢ࡯ࡨࠦჯ"): env.get(bstack11l11ll_opy_ (u"ࠥࡗ࡞࡙ࡔࡆࡏࡢࡈࡊࡌࡉࡏࡋࡗࡍࡔࡔࡉࡅࠤჰ")),
            bstack11l11ll_opy_ (u"ࠦࡧࡻࡩ࡭ࡦࡢࡲࡺࡳࡢࡦࡴࠥჱ"): env.get(bstack11l11ll_opy_ (u"ࠧࡈࡕࡊࡎࡇࡣࡇ࡛ࡉࡍࡆࡌࡈࠧჲ"))
        }
    if bstack1l1l11l111_opy_(env.get(bstack11l11ll_opy_ (u"ࠨࡁࡑࡒ࡙ࡉ࡞ࡕࡒࠣჳ"))):
        return {
            bstack11l11ll_opy_ (u"ࠢ࡯ࡣࡰࡩࠧჴ"): bstack11l11ll_opy_ (u"ࠣࡃࡳࡴࡻ࡫ࡹࡰࡴࠥჵ"),
            bstack11l11ll_opy_ (u"ࠤࡥࡹ࡮ࡲࡤࡠࡷࡵࡰࠧჶ"): bstack11l11ll_opy_ (u"ࠥࡿࢂ࠵ࡰࡳࡱ࡭ࡩࡨࡺ࠯ࡼࡿ࠲ࡿࢂ࠵ࡢࡶ࡫࡯ࡨࡸ࠵ࡻࡾࠤჷ").format(env.get(bstack11l11ll_opy_ (u"ࠫࡆࡖࡐࡗࡇ࡜ࡓࡗࡥࡕࡓࡎࠪჸ")), env.get(bstack11l11ll_opy_ (u"ࠬࡇࡐࡑࡘࡈ࡝ࡔࡘ࡟ࡂࡅࡆࡓ࡚ࡔࡔࡠࡐࡄࡑࡊ࠭ჹ")), env.get(bstack11l11ll_opy_ (u"࠭ࡁࡑࡒ࡙ࡉ࡞ࡕࡒࡠࡒࡕࡓࡏࡋࡃࡕࡡࡖࡐ࡚ࡍࠧჺ")), env.get(bstack11l11ll_opy_ (u"ࠧࡂࡒࡓ࡚ࡊ࡟ࡏࡓࡡࡅ࡙ࡎࡒࡄࡠࡋࡇࠫ჻"))),
            bstack11l11ll_opy_ (u"ࠣ࡬ࡲࡦࡤࡴࡡ࡮ࡧࠥჼ"): env.get(bstack11l11ll_opy_ (u"ࠤࡄࡔࡕ࡜ࡅ࡚ࡑࡕࡣࡏࡕࡂࡠࡐࡄࡑࡊࠨჽ")),
            bstack11l11ll_opy_ (u"ࠥࡦࡺ࡯࡬ࡥࡡࡱࡹࡲࡨࡥࡳࠤჾ"): env.get(bstack11l11ll_opy_ (u"ࠦࡆࡖࡐࡗࡇ࡜ࡓࡗࡥࡂࡖࡋࡏࡈࡤࡔࡕࡎࡄࡈࡖࠧჿ"))
        }
    if env.get(bstack11l11ll_opy_ (u"ࠧࡇ࡚ࡖࡔࡈࡣࡍ࡚ࡔࡑࡡࡘࡗࡊࡘ࡟ࡂࡉࡈࡒ࡙ࠨᄀ")) and env.get(bstack11l11ll_opy_ (u"ࠨࡔࡇࡡࡅ࡙ࡎࡒࡄࠣᄁ")):
        return {
            bstack11l11ll_opy_ (u"ࠢ࡯ࡣࡰࡩࠧᄂ"): bstack11l11ll_opy_ (u"ࠣࡃࡽࡹࡷ࡫ࠠࡄࡋࠥᄃ"),
            bstack11l11ll_opy_ (u"ࠤࡥࡹ࡮ࡲࡤࡠࡷࡵࡰࠧᄄ"): bstack11l11ll_opy_ (u"ࠥࡿࢂࢁࡽ࠰ࡡࡥࡹ࡮ࡲࡤ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡥࡹ࡮ࡲࡤࡊࡦࡀࡿࢂࠨᄅ").format(env.get(bstack11l11ll_opy_ (u"ࠫࡘ࡟ࡓࡕࡇࡐࡣ࡙ࡋࡁࡎࡈࡒ࡙ࡓࡊࡁࡕࡋࡒࡒࡘࡋࡒࡗࡇࡕ࡙ࡗࡏࠧᄆ")), env.get(bstack11l11ll_opy_ (u"࡙࡙ࠬࡔࡖࡈࡑࡤ࡚ࡅࡂࡏࡓࡖࡔࡐࡅࡄࡖࠪᄇ")), env.get(bstack11l11ll_opy_ (u"࠭ࡂࡖࡋࡏࡈࡤࡈࡕࡊࡎࡇࡍࡉ࠭ᄈ"))),
            bstack11l11ll_opy_ (u"ࠢ࡫ࡱࡥࡣࡳࡧ࡭ࡦࠤᄉ"): env.get(bstack11l11ll_opy_ (u"ࠣࡄࡘࡍࡑࡊ࡟ࡃࡗࡌࡐࡉࡏࡄࠣᄊ")),
            bstack11l11ll_opy_ (u"ࠤࡥࡹ࡮ࡲࡤࡠࡰࡸࡱࡧ࡫ࡲࠣᄋ"): env.get(bstack11l11ll_opy_ (u"ࠥࡆ࡚ࡏࡌࡅࡡࡅ࡙ࡎࡒࡄࡊࡆࠥᄌ"))
        }
    if any([env.get(bstack11l11ll_opy_ (u"ࠦࡈࡕࡄࡆࡄࡘࡍࡑࡊ࡟ࡃࡗࡌࡐࡉࡥࡉࡅࠤᄍ")), env.get(bstack11l11ll_opy_ (u"ࠧࡉࡏࡅࡇࡅ࡙ࡎࡒࡄࡠࡔࡈࡗࡔࡒࡖࡆࡆࡢࡗࡔ࡛ࡒࡄࡇࡢ࡚ࡊࡘࡓࡊࡑࡑࠦᄎ")), env.get(bstack11l11ll_opy_ (u"ࠨࡃࡐࡆࡈࡆ࡚ࡏࡌࡅࡡࡖࡓ࡚ࡘࡃࡆࡡ࡙ࡉࡗ࡙ࡉࡐࡐࠥᄏ"))]):
        return {
            bstack11l11ll_opy_ (u"ࠢ࡯ࡣࡰࡩࠧᄐ"): bstack11l11ll_opy_ (u"ࠣࡃ࡚ࡗࠥࡉ࡯ࡥࡧࡅࡹ࡮ࡲࡤࠣᄑ"),
            bstack11l11ll_opy_ (u"ࠤࡥࡹ࡮ࡲࡤࡠࡷࡵࡰࠧᄒ"): env.get(bstack11l11ll_opy_ (u"ࠥࡇࡔࡊࡅࡃࡗࡌࡐࡉࡥࡐࡖࡄࡏࡍࡈࡥࡂࡖࡋࡏࡈࡤ࡛ࡒࡍࠤᄓ")),
            bstack11l11ll_opy_ (u"ࠦ࡯ࡵࡢࡠࡰࡤࡱࡪࠨᄔ"): env.get(bstack11l11ll_opy_ (u"ࠧࡉࡏࡅࡇࡅ࡙ࡎࡒࡄࡠࡄࡘࡍࡑࡊ࡟ࡊࡆࠥᄕ")),
            bstack11l11ll_opy_ (u"ࠨࡢࡶ࡫࡯ࡨࡤࡴࡵ࡮ࡤࡨࡶࠧᄖ"): env.get(bstack11l11ll_opy_ (u"ࠢࡄࡑࡇࡉࡇ࡛ࡉࡍࡆࡢࡆ࡚ࡏࡌࡅࡡࡌࡈࠧᄗ"))
        }
    if env.get(bstack11l11ll_opy_ (u"ࠣࡤࡤࡱࡧࡵ࡯ࡠࡤࡸ࡭ࡱࡪࡎࡶ࡯ࡥࡩࡷࠨᄘ")):
        return {
            bstack11l11ll_opy_ (u"ࠤࡱࡥࡲ࡫ࠢᄙ"): bstack11l11ll_opy_ (u"ࠥࡆࡦࡳࡢࡰࡱࠥᄚ"),
            bstack11l11ll_opy_ (u"ࠦࡧࡻࡩ࡭ࡦࡢࡹࡷࡲࠢᄛ"): env.get(bstack11l11ll_opy_ (u"ࠧࡨࡡ࡮ࡤࡲࡳࡤࡨࡵࡪ࡮ࡧࡖࡪࡹࡵ࡭ࡶࡶ࡙ࡷࡲࠢᄜ")),
            bstack11l11ll_opy_ (u"ࠨࡪࡰࡤࡢࡲࡦࡳࡥࠣᄝ"): env.get(bstack11l11ll_opy_ (u"ࠢࡣࡣࡰࡦࡴࡵ࡟ࡴࡪࡲࡶࡹࡐ࡯ࡣࡐࡤࡱࡪࠨᄞ")),
            bstack11l11ll_opy_ (u"ࠣࡤࡸ࡭ࡱࡪ࡟࡯ࡷࡰࡦࡪࡸࠢᄟ"): env.get(bstack11l11ll_opy_ (u"ࠤࡥࡥࡲࡨ࡯ࡰࡡࡥࡹ࡮ࡲࡤࡏࡷࡰࡦࡪࡸࠢᄠ"))
        }
    if env.get(bstack11l11ll_opy_ (u"࡛ࠥࡊࡘࡃࡌࡇࡕࠦᄡ")) or env.get(bstack11l11ll_opy_ (u"ࠦ࡜ࡋࡒࡄࡍࡈࡖࡤࡓࡁࡊࡐࡢࡔࡎࡖࡅࡍࡋࡑࡉࡤ࡙ࡔࡂࡔࡗࡉࡉࠨᄢ")):
        return {
            bstack11l11ll_opy_ (u"ࠧࡴࡡ࡮ࡧࠥᄣ"): bstack11l11ll_opy_ (u"ࠨࡗࡦࡴࡦ࡯ࡪࡸࠢᄤ"),
            bstack11l11ll_opy_ (u"ࠢࡣࡷ࡬ࡰࡩࡥࡵࡳ࡮ࠥᄥ"): env.get(bstack11l11ll_opy_ (u"࡙ࠣࡈࡖࡈࡑࡅࡓࡡࡅ࡙ࡎࡒࡄࡠࡗࡕࡐࠧᄦ")),
            bstack11l11ll_opy_ (u"ࠤ࡭ࡳࡧࡥ࡮ࡢ࡯ࡨࠦᄧ"): bstack11l11ll_opy_ (u"ࠥࡑࡦ࡯࡮ࠡࡒ࡬ࡴࡪࡲࡩ࡯ࡧࠥᄨ") if env.get(bstack11l11ll_opy_ (u"ࠦ࡜ࡋࡒࡄࡍࡈࡖࡤࡓࡁࡊࡐࡢࡔࡎࡖࡅࡍࡋࡑࡉࡤ࡙ࡔࡂࡔࡗࡉࡉࠨᄩ")) else None,
            bstack11l11ll_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡳࡻ࡭ࡣࡧࡵࠦᄪ"): env.get(bstack11l11ll_opy_ (u"ࠨࡗࡆࡔࡆࡏࡊࡘ࡟ࡈࡋࡗࡣࡈࡕࡍࡎࡋࡗࠦᄫ"))
        }
    if any([env.get(bstack11l11ll_opy_ (u"ࠢࡈࡅࡓࡣࡕࡘࡏࡋࡇࡆࡘࠧᄬ")), env.get(bstack11l11ll_opy_ (u"ࠣࡉࡆࡐࡔ࡛ࡄࡠࡒࡕࡓࡏࡋࡃࡕࠤᄭ")), env.get(bstack11l11ll_opy_ (u"ࠤࡊࡓࡔࡍࡌࡆࡡࡆࡐࡔ࡛ࡄࡠࡒࡕࡓࡏࡋࡃࡕࠤᄮ"))]):
        return {
            bstack11l11ll_opy_ (u"ࠥࡲࡦࡳࡥࠣᄯ"): bstack11l11ll_opy_ (u"ࠦࡌࡵ࡯ࡨ࡮ࡨࠤࡈࡲ࡯ࡶࡦࠥᄰ"),
            bstack11l11ll_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡺࡸ࡬ࠣᄱ"): None,
            bstack11l11ll_opy_ (u"ࠨࡪࡰࡤࡢࡲࡦࡳࡥࠣᄲ"): env.get(bstack11l11ll_opy_ (u"ࠢࡑࡔࡒࡎࡊࡉࡔࡠࡋࡇࠦᄳ")),
            bstack11l11ll_opy_ (u"ࠣࡤࡸ࡭ࡱࡪ࡟࡯ࡷࡰࡦࡪࡸࠢᄴ"): env.get(bstack11l11ll_opy_ (u"ࠤࡅ࡙ࡎࡒࡄࡠࡋࡇࠦᄵ"))
        }
    if env.get(bstack11l11ll_opy_ (u"ࠥࡗࡍࡏࡐࡑࡃࡅࡐࡊࠨᄶ")):
        return {
            bstack11l11ll_opy_ (u"ࠦࡳࡧ࡭ࡦࠤᄷ"): bstack11l11ll_opy_ (u"࡙ࠧࡨࡪࡲࡳࡥࡧࡲࡥࠣᄸ"),
            bstack11l11ll_opy_ (u"ࠨࡢࡶ࡫࡯ࡨࡤࡻࡲ࡭ࠤᄹ"): env.get(bstack11l11ll_opy_ (u"ࠢࡔࡊࡌࡔࡕࡇࡂࡍࡇࡢࡆ࡚ࡏࡌࡅࡡࡘࡖࡑࠨᄺ")),
            bstack11l11ll_opy_ (u"ࠣ࡬ࡲࡦࡤࡴࡡ࡮ࡧࠥᄻ"): bstack11l11ll_opy_ (u"ࠤࡍࡳࡧࠦࠣࡼࡿࠥᄼ").format(env.get(bstack11l11ll_opy_ (u"ࠪࡗࡍࡏࡐࡑࡃࡅࡐࡊࡥࡊࡐࡄࡢࡍࡉ࠭ᄽ"))) if env.get(bstack11l11ll_opy_ (u"ࠦࡘࡎࡉࡑࡒࡄࡆࡑࡋ࡟ࡋࡑࡅࡣࡎࡊࠢᄾ")) else None,
            bstack11l11ll_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡳࡻ࡭ࡣࡧࡵࠦᄿ"): env.get(bstack11l11ll_opy_ (u"ࠨࡓࡉࡋࡓࡔࡆࡈࡌࡆࡡࡅ࡙ࡎࡒࡄࡠࡐࡘࡑࡇࡋࡒࠣᅀ"))
        }
    if bstack1l1l11l111_opy_(env.get(bstack11l11ll_opy_ (u"ࠢࡏࡇࡗࡐࡎࡌ࡙ࠣᅁ"))):
        return {
            bstack11l11ll_opy_ (u"ࠣࡰࡤࡱࡪࠨᅂ"): bstack11l11ll_opy_ (u"ࠤࡑࡩࡹࡲࡩࡧࡻࠥᅃ"),
            bstack11l11ll_opy_ (u"ࠥࡦࡺ࡯࡬ࡥࡡࡸࡶࡱࠨᅄ"): env.get(bstack11l11ll_opy_ (u"ࠦࡉࡋࡐࡍࡑ࡜ࡣ࡚ࡘࡌࠣᅅ")),
            bstack11l11ll_opy_ (u"ࠧࡰ࡯ࡣࡡࡱࡥࡲ࡫ࠢᅆ"): env.get(bstack11l11ll_opy_ (u"ࠨࡓࡊࡖࡈࡣࡓࡇࡍࡆࠤᅇ")),
            bstack11l11ll_opy_ (u"ࠢࡣࡷ࡬ࡰࡩࡥ࡮ࡶ࡯ࡥࡩࡷࠨᅈ"): env.get(bstack11l11ll_opy_ (u"ࠣࡄࡘࡍࡑࡊ࡟ࡊࡆࠥᅉ"))
        }
    if bstack1l1l11l111_opy_(env.get(bstack11l11ll_opy_ (u"ࠤࡊࡍ࡙ࡎࡕࡃࡡࡄࡇ࡙ࡏࡏࡏࡕࠥᅊ"))):
        return {
            bstack11l11ll_opy_ (u"ࠥࡲࡦࡳࡥࠣᅋ"): bstack11l11ll_opy_ (u"ࠦࡌ࡯ࡴࡉࡷࡥࠤࡆࡩࡴࡪࡱࡱࡷࠧᅌ"),
            bstack11l11ll_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡺࡸ࡬ࠣᅍ"): bstack11l11ll_opy_ (u"ࠨࡻࡾ࠱ࡾࢁ࠴ࡧࡣࡵ࡫ࡲࡲࡸ࠵ࡲࡶࡰࡶ࠳ࢀࢃࠢᅎ").format(env.get(bstack11l11ll_opy_ (u"ࠧࡈࡋࡗࡌ࡚ࡈ࡟ࡔࡇࡕ࡚ࡊࡘ࡟ࡖࡔࡏࠫᅏ")), env.get(bstack11l11ll_opy_ (u"ࠨࡉࡌࡘࡍ࡛ࡂࡠࡔࡈࡔࡔ࡙ࡉࡕࡑࡕ࡝ࠬᅐ")), env.get(bstack11l11ll_opy_ (u"ࠩࡊࡍ࡙ࡎࡕࡃࡡࡕ࡙ࡓࡥࡉࡅࠩᅑ"))),
            bstack11l11ll_opy_ (u"ࠥ࡮ࡴࡨ࡟࡯ࡣࡰࡩࠧᅒ"): env.get(bstack11l11ll_opy_ (u"ࠦࡌࡏࡔࡉࡗࡅࡣ࡜ࡕࡒࡌࡈࡏࡓ࡜ࠨᅓ")),
            bstack11l11ll_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡳࡻ࡭ࡣࡧࡵࠦᅔ"): env.get(bstack11l11ll_opy_ (u"ࠨࡇࡊࡖࡋ࡙ࡇࡥࡒࡖࡐࡢࡍࡉࠨᅕ"))
        }
    if env.get(bstack11l11ll_opy_ (u"ࠢࡄࡋࠥᅖ")) == bstack11l11ll_opy_ (u"ࠣࡶࡵࡹࡪࠨᅗ") and env.get(bstack11l11ll_opy_ (u"ࠤ࡙ࡉࡗࡉࡅࡍࠤᅘ")) == bstack11l11ll_opy_ (u"ࠥ࠵ࠧᅙ"):
        return {
            bstack11l11ll_opy_ (u"ࠦࡳࡧ࡭ࡦࠤᅚ"): bstack11l11ll_opy_ (u"ࠧ࡜ࡥࡳࡥࡨࡰࠧᅛ"),
            bstack11l11ll_opy_ (u"ࠨࡢࡶ࡫࡯ࡨࡤࡻࡲ࡭ࠤᅜ"): bstack11l11ll_opy_ (u"ࠢࡩࡶࡷࡴ࠿࠵࠯ࡼࡿࠥᅝ").format(env.get(bstack11l11ll_opy_ (u"ࠨࡘࡈࡖࡈࡋࡌࡠࡗࡕࡐࠬᅞ"))),
            bstack11l11ll_opy_ (u"ࠤ࡭ࡳࡧࡥ࡮ࡢ࡯ࡨࠦᅟ"): None,
            bstack11l11ll_opy_ (u"ࠥࡦࡺ࡯࡬ࡥࡡࡱࡹࡲࡨࡥࡳࠤᅠ"): None,
        }
    if env.get(bstack11l11ll_opy_ (u"࡙ࠦࡋࡁࡎࡅࡌࡘ࡞ࡥࡖࡆࡔࡖࡍࡔࡔࠢᅡ")):
        return {
            bstack11l11ll_opy_ (u"ࠧࡴࡡ࡮ࡧࠥᅢ"): bstack11l11ll_opy_ (u"ࠨࡔࡦࡣࡰࡧ࡮ࡺࡹࠣᅣ"),
            bstack11l11ll_opy_ (u"ࠢࡣࡷ࡬ࡰࡩࡥࡵࡳ࡮ࠥᅤ"): None,
            bstack11l11ll_opy_ (u"ࠣ࡬ࡲࡦࡤࡴࡡ࡮ࡧࠥᅥ"): env.get(bstack11l11ll_opy_ (u"ࠤࡗࡉࡆࡓࡃࡊࡖ࡜ࡣࡕࡘࡏࡋࡇࡆࡘࡤࡔࡁࡎࡇࠥᅦ")),
            bstack11l11ll_opy_ (u"ࠥࡦࡺ࡯࡬ࡥࡡࡱࡹࡲࡨࡥࡳࠤᅧ"): env.get(bstack11l11ll_opy_ (u"ࠦࡇ࡛ࡉࡍࡆࡢࡒ࡚ࡓࡂࡆࡔࠥᅨ"))
        }
    if any([env.get(bstack11l11ll_opy_ (u"ࠧࡉࡏࡏࡅࡒ࡙ࡗ࡙ࡅࠣᅩ")), env.get(bstack11l11ll_opy_ (u"ࠨࡃࡐࡐࡆࡓ࡚ࡘࡓࡆࡡࡘࡖࡑࠨᅪ")), env.get(bstack11l11ll_opy_ (u"ࠢࡄࡑࡑࡇࡔ࡛ࡒࡔࡇࡢ࡙ࡘࡋࡒࡏࡃࡐࡉࠧᅫ")), env.get(bstack11l11ll_opy_ (u"ࠣࡅࡒࡒࡈࡕࡕࡓࡕࡈࡣ࡙ࡋࡁࡎࠤᅬ"))]):
        return {
            bstack11l11ll_opy_ (u"ࠤࡱࡥࡲ࡫ࠢᅭ"): bstack11l11ll_opy_ (u"ࠥࡇࡴࡴࡣࡰࡷࡵࡷࡪࠨᅮ"),
            bstack11l11ll_opy_ (u"ࠦࡧࡻࡩ࡭ࡦࡢࡹࡷࡲࠢᅯ"): None,
            bstack11l11ll_opy_ (u"ࠧࡰ࡯ࡣࡡࡱࡥࡲ࡫ࠢᅰ"): env.get(bstack11l11ll_opy_ (u"ࠨࡂࡖࡋࡏࡈࡤࡐࡏࡃࡡࡑࡅࡒࡋࠢᅱ")) or None,
            bstack11l11ll_opy_ (u"ࠢࡣࡷ࡬ࡰࡩࡥ࡮ࡶ࡯ࡥࡩࡷࠨᅲ"): env.get(bstack11l11ll_opy_ (u"ࠣࡄࡘࡍࡑࡊ࡟ࡊࡆࠥᅳ"), 0)
        }
    if env.get(bstack11l11ll_opy_ (u"ࠤࡊࡓࡤࡐࡏࡃࡡࡑࡅࡒࡋࠢᅴ")):
        return {
            bstack11l11ll_opy_ (u"ࠥࡲࡦࡳࡥࠣᅵ"): bstack11l11ll_opy_ (u"ࠦࡌࡵࡃࡅࠤᅶ"),
            bstack11l11ll_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡺࡸ࡬ࠣᅷ"): None,
            bstack11l11ll_opy_ (u"ࠨࡪࡰࡤࡢࡲࡦࡳࡥࠣᅸ"): env.get(bstack11l11ll_opy_ (u"ࠢࡈࡑࡢࡎࡔࡈ࡟ࡏࡃࡐࡉࠧᅹ")),
            bstack11l11ll_opy_ (u"ࠣࡤࡸ࡭ࡱࡪ࡟࡯ࡷࡰࡦࡪࡸࠢᅺ"): env.get(bstack11l11ll_opy_ (u"ࠤࡊࡓࡤࡖࡉࡑࡇࡏࡍࡓࡋ࡟ࡄࡑࡘࡒ࡙ࡋࡒࠣᅻ"))
        }
    if env.get(bstack11l11ll_opy_ (u"ࠥࡇࡋࡥࡂࡖࡋࡏࡈࡤࡏࡄࠣᅼ")):
        return {
            bstack11l11ll_opy_ (u"ࠦࡳࡧ࡭ࡦࠤᅽ"): bstack11l11ll_opy_ (u"ࠧࡉ࡯ࡥࡧࡉࡶࡪࡹࡨࠣᅾ"),
            bstack11l11ll_opy_ (u"ࠨࡢࡶ࡫࡯ࡨࡤࡻࡲ࡭ࠤᅿ"): env.get(bstack11l11ll_opy_ (u"ࠢࡄࡈࡢࡆ࡚ࡏࡌࡅࡡࡘࡖࡑࠨᆀ")),
            bstack11l11ll_opy_ (u"ࠣ࡬ࡲࡦࡤࡴࡡ࡮ࡧࠥᆁ"): env.get(bstack11l11ll_opy_ (u"ࠤࡆࡊࡤࡖࡉࡑࡇࡏࡍࡓࡋ࡟ࡏࡃࡐࡉࠧᆂ")),
            bstack11l11ll_opy_ (u"ࠥࡦࡺ࡯࡬ࡥࡡࡱࡹࡲࡨࡥࡳࠤᆃ"): env.get(bstack11l11ll_opy_ (u"ࠦࡈࡌ࡟ࡃࡗࡌࡐࡉࡥࡉࡅࠤᆄ"))
        }
    return {bstack11l11ll_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡳࡻ࡭ࡣࡧࡵࠦᆅ"): None}
def get_host_info():
    return {
        bstack11l11ll_opy_ (u"ࠨࡨࡰࡵࡷࡲࡦࡳࡥࠣᆆ"): platform.node(),
        bstack11l11ll_opy_ (u"ࠢࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࠤᆇ"): platform.system(),
        bstack11l11ll_opy_ (u"ࠣࡶࡼࡴࡪࠨᆈ"): platform.machine(),
        bstack11l11ll_opy_ (u"ࠤࡹࡩࡷࡹࡩࡰࡰࠥᆉ"): platform.version(),
        bstack11l11ll_opy_ (u"ࠥࡥࡷࡩࡨࠣᆊ"): platform.architecture()[0]
    }
def bstack1lll11l1l1_opy_():
    try:
        import selenium
        return True
    except ImportError:
        return False
def bstack1l11lll1ll_opy_():
    if bstack11l1111l_opy_.get_property(bstack11l11ll_opy_ (u"ࠫࡧࡹࡴࡢࡥ࡮ࡣࡸ࡫ࡳࡴ࡫ࡲࡲࠬᆋ")):
        return bstack11l11ll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࠫᆌ")
    return bstack11l11ll_opy_ (u"࠭ࡵ࡯࡭ࡱࡳࡼࡴ࡟ࡨࡴ࡬ࡨࠬᆍ")
def bstack1l11lll111_opy_(driver):
    info = {
        bstack11l11ll_opy_ (u"ࠧࡤࡣࡳࡥࡧ࡯࡬ࡪࡶ࡬ࡩࡸ࠭ᆎ"): driver.capabilities,
        bstack11l11ll_opy_ (u"ࠨࡵࡨࡷࡸ࡯࡯࡯ࡡ࡬ࡨࠬᆏ"): driver.session_id,
        bstack11l11ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࠪᆐ"): driver.capabilities.get(bstack11l11ll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡒࡦࡳࡥࠨᆑ"), None),
        bstack11l11ll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡤࡼࡥࡳࡵ࡬ࡳࡳ࠭ᆒ"): driver.capabilities.get(bstack11l11ll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷ࡜ࡥࡳࡵ࡬ࡳࡳ࠭ᆓ"), None),
        bstack11l11ll_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࠨᆔ"): driver.capabilities.get(bstack11l11ll_opy_ (u"ࠧࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡐࡤࡱࡪ࠭ᆕ"), None),
    }
    if bstack1l11lll1ll_opy_() == bstack11l11ll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࠧᆖ"):
        info[bstack11l11ll_opy_ (u"ࠩࡳࡶࡴࡪࡵࡤࡶࠪᆗ")] = bstack11l11ll_opy_ (u"ࠪࡥࡵࡶ࠭ࡢࡷࡷࡳࡲࡧࡴࡦࠩᆘ") if bstack11l1lllll_opy_() else bstack11l11ll_opy_ (u"ࠫࡦࡻࡴࡰ࡯ࡤࡸࡪ࠭ᆙ")
    return info
def bstack11l1lllll_opy_():
    if bstack11l1111l_opy_.get_property(bstack11l11ll_opy_ (u"ࠬࡧࡰࡱࡡࡤࡹࡹࡵ࡭ࡢࡶࡨࠫᆚ")):
        return True
    if bstack1l1l11l111_opy_(os.environ.get(bstack11l11ll_opy_ (u"࠭ࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤࡏࡓࡠࡃࡓࡔࡤࡇࡕࡕࡑࡐࡅ࡙ࡋࠧᆛ"), None)):
        return True
    return False
def bstack1l11l1l11_opy_(bstack11llll11l1_opy_, url, data, config):
    headers = config.get(bstack11l11ll_opy_ (u"ࠧࡩࡧࡤࡨࡪࡸࡳࠨᆜ"), None)
    proxies = bstack111l11ll_opy_(config, url)
    auth = config.get(bstack11l11ll_opy_ (u"ࠨࡣࡸࡸ࡭࠭ᆝ"), None)
    response = requests.request(
            bstack11llll11l1_opy_,
            url=url,
            headers=headers,
            auth=auth,
            json=data,
            proxies=proxies
        )
    return response
def bstack1ll111l1_opy_(bstack11llll111_opy_, size):
    bstack111llll1l_opy_ = []
    while len(bstack11llll111_opy_) > size:
        bstack1lll1ll11l_opy_ = bstack11llll111_opy_[:size]
        bstack111llll1l_opy_.append(bstack1lll1ll11l_opy_)
        bstack11llll111_opy_ = bstack11llll111_opy_[size:]
    bstack111llll1l_opy_.append(bstack11llll111_opy_)
    return bstack111llll1l_opy_
def bstack1l1l11l11l_opy_(message, bstack11llll1l11_opy_=False):
    os.write(1, bytes(message, bstack11l11ll_opy_ (u"ࠩࡸࡸ࡫࠳࠸ࠨᆞ")))
    os.write(1, bytes(bstack11l11ll_opy_ (u"ࠪࡠࡳ࠭ᆟ"), bstack11l11ll_opy_ (u"ࠫࡺࡺࡦ࠮࠺ࠪᆠ")))
    if bstack11llll1l11_opy_:
        with open(bstack11l11ll_opy_ (u"ࠬࡨࡳࡵࡣࡦ࡯࠲ࡵ࠱࠲ࡻ࠰ࠫᆡ") + os.environ[bstack11l11ll_opy_ (u"࠭ࡂࡔࡡࡗࡉࡘ࡚ࡏࡑࡕࡢࡆ࡚ࡏࡌࡅࡡࡋࡅࡘࡎࡅࡅࡡࡌࡈࠬᆢ")] + bstack11l11ll_opy_ (u"ࠧ࠯࡮ࡲ࡫ࠬᆣ"), bstack11l11ll_opy_ (u"ࠨࡣࠪᆤ")) as f:
            f.write(message + bstack11l11ll_opy_ (u"ࠩ࡟ࡲࠬᆥ"))
def bstack11lll1lll1_opy_():
    return os.environ[bstack11l11ll_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡄ࡙࡙ࡕࡍࡂࡖࡌࡓࡓ࠭ᆦ")].lower() == bstack11l11ll_opy_ (u"ࠫࡹࡸࡵࡦࠩᆧ")
def bstack1llll11lll_opy_(bstack1l11l11ll1_opy_):
    return bstack11l11ll_opy_ (u"ࠬࢁࡽ࠰ࡽࢀࠫᆨ").format(bstack1l1ll111ll_opy_, bstack1l11l11ll1_opy_)
def bstack11ll1llll_opy_():
    return datetime.datetime.utcnow().isoformat() + bstack11l11ll_opy_ (u"࡚࠭ࠨᆩ")
def bstack11llll1lll_opy_(start, finish):
    return (datetime.datetime.fromisoformat(finish.rstrip(bstack11l11ll_opy_ (u"࡛ࠧࠩᆪ"))) - datetime.datetime.fromisoformat(start.rstrip(bstack11l11ll_opy_ (u"ࠨ࡜ࠪᆫ")))).total_seconds() * 1000
def bstack1l11111l1l_opy_(timestamp):
    return datetime.datetime.utcfromtimestamp(timestamp).isoformat() + bstack11l11ll_opy_ (u"ࠩ࡝ࠫᆬ")
def bstack1l111111ll_opy_(outcome):
    _, exception, _ = outcome.excinfo or (None, None, None)
    if exception:
        return bstack11l11ll_opy_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪᆭ")
    else:
        return bstack11l11ll_opy_ (u"ࠫࡵࡧࡳࡴࡧࡧࠫᆮ")
def bstack1l1l11l111_opy_(val):
    if val is None:
        return False
    return val.__str__().lower() == bstack11l11ll_opy_ (u"ࠬࡺࡲࡶࡧࠪᆯ")
def bstack11lll11lll_opy_(val):
    return val.__str__().lower() == bstack11l11ll_opy_ (u"࠭ࡦࡢ࡮ࡶࡩࠬᆰ")
def bstack1l1l11l1ll_opy_(bstack11lll1l111_opy_=Exception, class_method=False, default_value=None):
    def decorator(func):
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except bstack11lll1l111_opy_ as e:
                print(bstack11l11ll_opy_ (u"ࠢࡆࡺࡦࡩࡵࡺࡩࡰࡰࠣ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠡࡽࢀࠤ࠲ࡄࠠࡼࡿ࠽ࠤࢀࢃࠢᆱ").format(func.__name__, bstack11lll1l111_opy_.__name__, str(e)))
                return default_value
        return wrapper
    def bstack1l11111lll_opy_(bstack11lll1llll_opy_):
        def wrapped(cls, *args, **kwargs):
            try:
                return bstack11lll1llll_opy_(cls, *args, **kwargs)
            except bstack11lll1l111_opy_ as e:
                print(bstack11l11ll_opy_ (u"ࠣࡇࡻࡧࡪࡶࡴࡪࡱࡱࠤ࡮ࡴࠠࡧࡷࡱࡧࡹ࡯࡯࡯ࠢࡾࢁࠥ࠳࠾ࠡࡽࢀ࠾ࠥࢁࡽࠣᆲ").format(bstack11lll1llll_opy_.__name__, bstack11lll1l111_opy_.__name__, str(e)))
                return default_value
        return wrapped
    if class_method:
        return bstack1l11111lll_opy_
    else:
        return decorator
def bstack11llllll1_opy_(bstack1ll1111l_opy_):
    if bstack11l11ll_opy_ (u"ࠩࡤࡹࡹࡵ࡭ࡢࡶ࡬ࡳࡳ࠭ᆳ") in bstack1ll1111l_opy_ and bstack11lll11lll_opy_(bstack1ll1111l_opy_[bstack11l11ll_opy_ (u"ࠪࡥࡺࡺ࡯࡮ࡣࡷ࡭ࡴࡴࠧᆴ")]):
        return False
    if bstack11l11ll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡄࡹࡹࡵ࡭ࡢࡶ࡬ࡳࡳ࠭ᆵ") in bstack1ll1111l_opy_ and bstack11lll11lll_opy_(bstack1ll1111l_opy_[bstack11l11ll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡅࡺࡺ࡯࡮ࡣࡷ࡭ࡴࡴࠧᆶ")]):
        return False
    return True
def bstack1llll1111_opy_():
    try:
        from pytest_bdd import reporting
        return True
    except Exception as e:
        return False
def bstack1ll1l111l1_opy_(hub_url):
    if bstack1ll1l1lll_opy_() <= version.parse(bstack11l11ll_opy_ (u"࠭࠳࠯࠳࠶࠲࠵࠭ᆷ")):
        if hub_url != bstack11l11ll_opy_ (u"ࠧࠨᆸ"):
            return bstack11l11ll_opy_ (u"ࠣࡪࡷࡸࡵࡀ࠯࠰ࠤᆹ") + hub_url + bstack11l11ll_opy_ (u"ࠤ࠽࠼࠵࠵ࡷࡥ࠱࡫ࡹࡧࠨᆺ")
        return bstack1ll1lll1l_opy_
    if hub_url != bstack11l11ll_opy_ (u"ࠪࠫᆻ"):
        return bstack11l11ll_opy_ (u"ࠦ࡭ࡺࡴࡱࡵ࠽࠳࠴ࠨᆼ") + hub_url + bstack11l11ll_opy_ (u"ࠧ࠵ࡷࡥ࠱࡫ࡹࡧࠨᆽ")
    return bstack1lllll111l_opy_
def bstack1l1111111l_opy_():
    return isinstance(os.getenv(bstack11l11ll_opy_ (u"࠭ࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤࡖ࡙ࡕࡇࡖࡘࡤࡖࡌࡖࡉࡌࡒࠬᆾ")), str)
def bstack11l1l1l11_opy_(url):
    return urlparse(url).hostname
def bstack1l11l1ll_opy_(hostname):
    for bstack11lll1l11_opy_ in bstack111111lll_opy_:
        regex = re.compile(bstack11lll1l11_opy_)
        if regex.match(hostname):
            return True
    return False
def bstack1ll11111l1_opy_(bstack1l11111111_opy_, file_name, logger):
    bstack1l11lllll_opy_ = os.path.join(os.path.expanduser(bstack11l11ll_opy_ (u"ࠧࡿࠩᆿ")), bstack1l11111111_opy_)
    try:
        if not os.path.exists(bstack1l11lllll_opy_):
            os.makedirs(bstack1l11lllll_opy_)
        file_path = os.path.join(os.path.expanduser(bstack11l11ll_opy_ (u"ࠨࢀࠪᇀ")), bstack1l11111111_opy_, file_name)
        if not os.path.isfile(file_path):
            with open(file_path, bstack11l11ll_opy_ (u"ࠩࡺࠫᇁ")):
                pass
            with open(file_path, bstack11l11ll_opy_ (u"ࠥࡻ࠰ࠨᇂ")) as outfile:
                json.dump({}, outfile)
        return file_path
    except Exception as e:
        logger.debug(bstack11ll111l1_opy_.format(str(e)))
def bstack1l1lllll1l_opy_(file_name, key, value, logger):
    file_path = bstack1ll11111l1_opy_(bstack11l11ll_opy_ (u"ࠫ࠳ࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࠫᇃ"), file_name, logger)
    if file_path != None:
        if os.path.exists(file_path):
            bstack1ll1l1l1l_opy_ = json.load(open(file_path, bstack11l11ll_opy_ (u"ࠬࡸࡢࠨᇄ")))
        else:
            bstack1ll1l1l1l_opy_ = {}
        bstack1ll1l1l1l_opy_[key] = value
        with open(file_path, bstack11l11ll_opy_ (u"ࠨࡷࠬࠤᇅ")) as outfile:
            json.dump(bstack1ll1l1l1l_opy_, outfile)
def bstack1ll1llll11_opy_(file_name, logger):
    file_path = bstack1ll11111l1_opy_(bstack11l11ll_opy_ (u"ࠧ࠯ࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࠧᇆ"), file_name, logger)
    bstack1ll1l1l1l_opy_ = {}
    if file_path != None and os.path.exists(file_path):
        with open(file_path, bstack11l11ll_opy_ (u"ࠨࡴࠪᇇ")) as bstack111l1ll11_opy_:
            bstack1ll1l1l1l_opy_ = json.load(bstack111l1ll11_opy_)
    return bstack1ll1l1l1l_opy_
def bstack1ll1ll1l11_opy_(file_path, logger):
    try:
        if os.path.exists(file_path):
            os.remove(file_path)
    except Exception as e:
        logger.debug(bstack11l11ll_opy_ (u"ࠩࡈࡶࡷࡵࡲࠡ࡫ࡱࠤࡩ࡫࡬ࡦࡶ࡬ࡲ࡬ࠦࡦࡪ࡮ࡨ࠾ࠥ࠭ᇈ") + file_path + bstack11l11ll_opy_ (u"ࠪࠤࠬᇉ") + str(e))
def bstack1ll1l1lll_opy_():
    from selenium import webdriver
    return version.parse(webdriver.__version__)
class Notset:
    def __repr__(self):
        return bstack11l11ll_opy_ (u"ࠦࡁࡔࡏࡕࡕࡈࡘࡃࠨᇊ")
def bstack1l1ll1l1l_opy_(config):
    if bstack11l11ll_opy_ (u"ࠬ࡯ࡳࡑ࡮ࡤࡽࡼࡸࡩࡨࡪࡷࠫᇋ") in config:
        del (config[bstack11l11ll_opy_ (u"࠭ࡩࡴࡒ࡯ࡥࡾࡽࡲࡪࡩ࡫ࡸࠬᇌ")])
        return False
    if bstack1ll1l1lll_opy_() < version.parse(bstack11l11ll_opy_ (u"ࠧ࠴࠰࠷࠲࠵࠭ᇍ")):
        return False
    if bstack1ll1l1lll_opy_() >= version.parse(bstack11l11ll_opy_ (u"ࠨ࠶࠱࠵࠳࠻ࠧᇎ")):
        return True
    if bstack11l11ll_opy_ (u"ࠩࡸࡷࡪ࡝࠳ࡄࠩᇏ") in config and config[bstack11l11ll_opy_ (u"ࠪࡹࡸ࡫ࡗ࠴ࡅࠪᇐ")] is False:
        return False
    else:
        return True
def bstack11lll1111_opy_(args_list, bstack11llll1ll1_opy_):
    index = -1
    for value in bstack11llll1ll1_opy_:
        try:
            index = args_list.index(value)
            return index
        except Exception as e:
            return index
    return index
class Result:
    def __init__(self, result=None, duration=None, exception=None, bstack11llllll11_opy_=None):
        self.result = result
        self.duration = duration
        self.exception = exception
        self.exception_type = type(self.exception).__name__ if exception else None
        self.bstack11llllll11_opy_ = bstack11llllll11_opy_
    @classmethod
    def passed(cls):
        return Result(result=bstack11l11ll_opy_ (u"ࠫࡵࡧࡳࡴࡧࡧࠫᇑ"))
    @classmethod
    def failed(cls, exception=None):
        return Result(result=bstack11l11ll_opy_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬᇒ"), exception=exception)
    def bstack1l11l1l111_opy_(self):
        if self.result != bstack11l11ll_opy_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭ᇓ"):
            return None
        if bstack11l11ll_opy_ (u"ࠢࡂࡵࡶࡩࡷࡺࡩࡰࡰࠥᇔ") in self.exception_type:
            return bstack11l11ll_opy_ (u"ࠣࡃࡶࡷࡪࡸࡴࡪࡱࡱࡉࡷࡸ࡯ࡳࠤᇕ")
        return bstack11l11ll_opy_ (u"ࠤࡘࡲ࡭ࡧ࡮ࡥ࡮ࡨࡨࡊࡸࡲࡰࡴࠥᇖ")
    def bstack11lll1ll1l_opy_(self):
        if self.result != bstack11l11ll_opy_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪᇗ"):
            return None
        if self.bstack11llllll11_opy_:
            return self.bstack11llllll11_opy_
        return bstack11llllll1l_opy_(self.exception)
def bstack11llllll1l_opy_(exc):
    return traceback.format_exception(exc)
def bstack11lllllll1_opy_(message):
    if isinstance(message, str):
        return not bool(message and message.strip())
    return True
def bstack1ll1llll1l_opy_(object, key, default_value):
    if key in object.__dict__.keys():
        return object.__dict__.get(key)
    return default_value
def bstack1lllllll1l_opy_(config, logger):
    try:
        import playwright
        bstack11lllll11l_opy_ = playwright.__file__
        bstack11llll11ll_opy_ = os.path.split(bstack11lllll11l_opy_)
        bstack11lll1ll11_opy_ = bstack11llll11ll_opy_[0] + bstack11l11ll_opy_ (u"ࠫ࠴ࡪࡲࡪࡸࡨࡶ࠴ࡶࡡࡤ࡭ࡤ࡫ࡪ࠵࡬ࡪࡤ࠲ࡧࡱ࡯࠯ࡤ࡮࡬࠲࡯ࡹࠧᇘ")
        os.environ[bstack11l11ll_opy_ (u"ࠬࡍࡌࡐࡄࡄࡐࡤࡇࡇࡆࡐࡗࡣࡍ࡚ࡔࡑࡡࡓࡖࡔ࡞࡙ࠨᇙ")] = bstack1lllll1ll1_opy_(config)
        with open(bstack11lll1ll11_opy_, bstack11l11ll_opy_ (u"࠭ࡲࠨᇚ")) as f:
            bstack1llll1lll_opy_ = f.read()
            bstack1l111111l1_opy_ = bstack11l11ll_opy_ (u"ࠧࡨ࡮ࡲࡦࡦࡲ࠭ࡢࡩࡨࡲࡹ࠭ᇛ")
            bstack11llllllll_opy_ = bstack1llll1lll_opy_.find(bstack1l111111l1_opy_)
            if bstack11llllllll_opy_ is -1:
              process = subprocess.Popen(bstack11l11ll_opy_ (u"ࠣࡰࡳࡱࠥ࡯࡮ࡴࡶࡤࡰࡱࠦࡧ࡭ࡱࡥࡥࡱ࠳ࡡࡨࡧࡱࡸࠧᇜ"), shell=True, cwd=bstack11llll11ll_opy_[0])
              process.wait()
              bstack11lllll111_opy_ = bstack11l11ll_opy_ (u"ࠩࠥࡹࡸ࡫ࠠࡴࡶࡵ࡭ࡨࡺࠢ࠼ࠩᇝ")
              bstack11lll1l1l1_opy_ = bstack11l11ll_opy_ (u"ࠥࠦࠧࠦ࡜ࠣࡷࡶࡩࠥࡹࡴࡳ࡫ࡦࡸࡡࠨ࠻ࠡࡥࡲࡲࡸࡺࠠࡼࠢࡥࡳࡴࡺࡳࡵࡴࡤࡴࠥࢃࠠ࠾ࠢࡵࡩࡶࡻࡩࡳࡧࠫࠫ࡬ࡲ࡯ࡣࡣ࡯࠱ࡦ࡭ࡥ࡯ࡶࠪ࠭ࡀࠦࡩࡧࠢࠫࡴࡷࡵࡣࡦࡵࡶ࠲ࡪࡴࡶ࠯ࡉࡏࡓࡇࡇࡌࡠࡃࡊࡉࡓ࡚࡟ࡉࡖࡗࡔࡤࡖࡒࡐ࡚࡜࠭ࠥࡨ࡯ࡰࡶࡶࡸࡷࡧࡰࠩࠫ࠾ࠤࠧࠨࠢᇞ")
              bstack11lllll1ll_opy_ = bstack1llll1lll_opy_.replace(bstack11lllll111_opy_, bstack11lll1l1l1_opy_)
              with open(bstack11lll1ll11_opy_, bstack11l11ll_opy_ (u"ࠫࡼ࠭ᇟ")) as f:
                f.write(bstack11lllll1ll_opy_)
    except Exception as e:
        logger.error(bstack1l1l1l11_opy_.format(str(e)))