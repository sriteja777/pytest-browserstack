# coding: UTF-8
import sys
bstack111llll_opy_ = sys.version_info [0] == 2
bstack1llllll_opy_ = 2048
bstack11ll1l_opy_ = 7
def bstack11l11ll_opy_ (bstack1l1ll11_opy_):
    global bstack1l11l_opy_
    bstack1l11ll_opy_ = ord (bstack1l1ll11_opy_ [-1])
    bstack111ll1_opy_ = bstack1l1ll11_opy_ [:-1]
    bstack1lllll_opy_ = bstack1l11ll_opy_ % len (bstack111ll1_opy_)
    bstack11l1l1l_opy_ = bstack111ll1_opy_ [:bstack1lllll_opy_] + bstack111ll1_opy_ [bstack1lllll_opy_:]
    if bstack111llll_opy_:
        bstack1ll1l_opy_ = unicode () .join ([unichr (ord (char) - bstack1llllll_opy_ - (bstack1l11l1_opy_ + bstack1l11ll_opy_) % bstack11ll1l_opy_) for bstack1l11l1_opy_, char in enumerate (bstack11l1l1l_opy_)])
    else:
        bstack1ll1l_opy_ = str () .join ([chr (ord (char) - bstack1llllll_opy_ - (bstack1l11l1_opy_ + bstack1l11ll_opy_) % bstack11ll1l_opy_) for bstack1l11l1_opy_, char in enumerate (bstack11l1l1l_opy_)])
    return eval (bstack1ll1l_opy_)
import datetime
import json
import logging
import os
import threading
from bstack_utils.helper import bstack1l1l1l11l1_opy_, bstack1lll11ll1l_opy_, get_host_info, bstack1l11l1l1l1_opy_, bstack1l11lllll1_opy_, bstack1l11l11l1l_opy_, \
    bstack1l11lll111_opy_, bstack1l11lll1ll_opy_, bstack1l11l1l11_opy_, bstack1l1l11l11l_opy_, bstack1l1l11l111_opy_, bstack1l1l11l1ll_opy_
from bstack_utils.bstack1l11l11lll_opy_ import bstack1l11ll1l1l_opy_
from bstack_utils.bstack1l11ll11l1_opy_ import bstack1l11l1l11l_opy_
bstack1l11l1ll11_opy_ = [
    bstack11l11ll_opy_ (u"ࠩࡏࡳ࡬ࡉࡲࡦࡣࡷࡩࡩ࠭ཧ"), bstack11l11ll_opy_ (u"ࠪࡇࡇ࡚ࡓࡦࡵࡶ࡭ࡴࡴࡃࡳࡧࡤࡸࡪࡪࠧཨ"), bstack11l11ll_opy_ (u"࡙ࠫ࡫ࡳࡵࡔࡸࡲࡋ࡯࡮ࡪࡵ࡫ࡩࡩ࠭ཀྵ"), bstack11l11ll_opy_ (u"࡚ࠬࡥࡴࡶࡕࡹࡳ࡙࡫ࡪࡲࡳࡩࡩ࠭ཪ"),
    bstack11l11ll_opy_ (u"࠭ࡈࡰࡱ࡮ࡖࡺࡴࡆࡪࡰ࡬ࡷ࡭࡫ࡤࠨཫ"), bstack11l11ll_opy_ (u"ࠧࡕࡧࡶࡸࡗࡻ࡮ࡔࡶࡤࡶࡹ࡫ࡤࠨཬ"), bstack11l11ll_opy_ (u"ࠨࡊࡲࡳࡰࡘࡵ࡯ࡕࡷࡥࡷࡺࡥࡥࠩ཭")
]
bstack1l11llllll_opy_ = bstack11l11ll_opy_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡧࡴࡲ࡬ࡦࡥࡷࡳࡷ࠳࡯ࡣࡵࡨࡶࡻࡧࡢࡪ࡮࡬ࡸࡾ࠴ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯࠳ࡩ࡯࡮ࠩ཮")
logger = logging.getLogger(__name__)
class bstack1ll1lll1ll_opy_:
    bstack1l11l11lll_opy_ = None
    bs_config = None
    @classmethod
    @bstack1l1l11l1ll_opy_(class_method=True)
    def launch(cls, bs_config, bstack1l11l11l11_opy_):
        cls.bs_config = bs_config
        if not cls.bstack1l11l1llll_opy_():
            return
        cls.bstack1l1l11l1l1_opy_()
        bstack1l11l1l1ll_opy_ = bstack1l11l1l1l1_opy_(bs_config)
        bstack1l11llll11_opy_ = bstack1l11lllll1_opy_(bs_config)
        data = {
            bstack11l11ll_opy_ (u"ࠪࡪࡴࡸ࡭ࡢࡶࠪ཯"): bstack11l11ll_opy_ (u"ࠫ࡯ࡹ࡯࡯ࠩ཰"),
            bstack11l11ll_opy_ (u"ࠬࡶࡲࡰ࡬ࡨࡧࡹࡥ࡮ࡢ࡯ࡨཱࠫ"): bs_config.get(bstack11l11ll_opy_ (u"࠭ࡰࡳࡱ࡭ࡩࡨࡺࡎࡢ࡯ࡨིࠫ"), bstack11l11ll_opy_ (u"ࠧࠨཱི")),
            bstack11l11ll_opy_ (u"ࠨࡰࡤࡱࡪུ࠭"): bs_config.get(bstack11l11ll_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡏࡣࡰࡩཱུࠬ"), os.path.basename(os.path.abspath(os.getcwd()))),
            bstack11l11ll_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡡ࡬ࡨࡪࡴࡴࡪࡨ࡬ࡩࡷ࠭ྲྀ"): bs_config.get(bstack11l11ll_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡌࡨࡪࡴࡴࡪࡨ࡬ࡩࡷ࠭ཷ")),
            bstack11l11ll_opy_ (u"ࠬࡪࡥࡴࡥࡵ࡭ࡵࡺࡩࡰࡰࠪླྀ"): bs_config.get(bstack11l11ll_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡉ࡫ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯ࠩཹ"), bstack11l11ll_opy_ (u"ࠧࠨེ")),
            bstack11l11ll_opy_ (u"ࠨࡵࡷࡥࡷࡺ࡟ࡵ࡫ࡰࡩཻࠬ"): datetime.datetime.now().isoformat(),
            bstack11l11ll_opy_ (u"ࠩࡷࡥ࡬ࡹོࠧ"): bstack1l11l11l1l_opy_(bs_config),
            bstack11l11ll_opy_ (u"ࠪ࡬ࡴࡹࡴࡠ࡫ࡱࡪࡴཽ࠭"): get_host_info(),
            bstack11l11ll_opy_ (u"ࠫࡨ࡯࡟ࡪࡰࡩࡳࠬཾ"): bstack1lll11ll1l_opy_(),
            bstack11l11ll_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡣࡷࡻ࡮ࡠ࡫ࡧࡩࡳࡺࡩࡧ࡫ࡨࡶࠬཿ"): os.environ.get(bstack11l11ll_opy_ (u"࠭ࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤࡈࡕࡊࡎࡇࡣࡗ࡛ࡎࡠࡋࡇࡉࡓ࡚ࡉࡇࡋࡈࡖྀࠬ")),
            bstack11l11ll_opy_ (u"ࠧࡧࡣ࡬ࡰࡪࡪ࡟ࡵࡧࡶࡸࡸࡥࡲࡦࡴࡸࡲཱྀࠬ"): os.environ.get(bstack11l11ll_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡓࡇࡕ࡙ࡓ࠭ྂ"), False),
            bstack11l11ll_opy_ (u"ࠩࡹࡩࡷࡹࡩࡰࡰࡢࡧࡴࡴࡴࡳࡱ࡯ࠫྃ"): bstack1l1l1l11l1_opy_(),
            bstack11l11ll_opy_ (u"ࠪࡳࡧࡹࡥࡳࡸࡤࡦ࡮ࡲࡩࡵࡻࡢࡺࡪࡸࡳࡪࡱࡱ྄ࠫ"): {
                bstack11l11ll_opy_ (u"ࠫ࡫ࡸࡡ࡮ࡧࡺࡳࡷࡱࡎࡢ࡯ࡨࠫ྅"): bstack1l11l11l11_opy_.get(bstack11l11ll_opy_ (u"ࠬ࡬ࡲࡢ࡯ࡨࡻࡴࡸ࡫ࡠࡰࡤࡱࡪ࠭྆"), bstack11l11ll_opy_ (u"࠭ࡐࡺࡶࡨࡷࡹ࠭྇")),
                bstack11l11ll_opy_ (u"ࠧࡧࡴࡤࡱࡪࡽ࡯ࡳ࡭࡙ࡩࡷࡹࡩࡰࡰࠪྈ"): bstack1l11l11l11_opy_.get(bstack11l11ll_opy_ (u"ࠨࡨࡵࡥࡲ࡫ࡷࡰࡴ࡮ࡣࡻ࡫ࡲࡴ࡫ࡲࡲࠬྉ")),
                bstack11l11ll_opy_ (u"ࠩࡶࡨࡰ࡜ࡥࡳࡵ࡬ࡳࡳ࠭ྊ"): bstack1l11l11l11_opy_.get(bstack11l11ll_opy_ (u"ࠪࡷࡩࡱ࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࠨྋ"))
            }
        }
        config = {
            bstack11l11ll_opy_ (u"ࠫࡦࡻࡴࡩࠩྌ"): (bstack1l11l1l1ll_opy_, bstack1l11llll11_opy_),
            bstack11l11ll_opy_ (u"ࠬ࡮ࡥࡢࡦࡨࡶࡸ࠭ྍ"): cls.default_headers()
        }
        response = bstack1l11l1l11_opy_(bstack11l11ll_opy_ (u"࠭ࡐࡐࡕࡗࠫྎ"), cls.request_url(bstack11l11ll_opy_ (u"ࠧࡢࡲ࡬࠳ࡻ࠷࠯ࡣࡷ࡬ࡰࡩࡹࠧྏ")), data, config)
        if response.status_code != 200:
            os.environ[bstack11l11ll_opy_ (u"ࠨࡄࡖࡣ࡙ࡋࡓࡕࡑࡓࡗࡤࡈࡕࡊࡎࡇࡣࡈࡕࡍࡑࡎࡈࡘࡊࡊࠧྐ")] = bstack11l11ll_opy_ (u"ࠩࡩࡥࡱࡹࡥࠨྑ")
            os.environ[bstack11l11ll_opy_ (u"ࠪࡆࡘࡥࡔࡆࡕࡗࡓࡕ࡙࡟ࡋ࡙ࡗࠫྒ")] = bstack11l11ll_opy_ (u"ࠫࡳࡻ࡬࡭ࠩྒྷ")
            os.environ[bstack11l11ll_opy_ (u"ࠬࡈࡓࡠࡖࡈࡗ࡙ࡕࡐࡔࡡࡅ࡙ࡎࡒࡄࡠࡊࡄࡗࡍࡋࡄࡠࡋࡇࠫྔ")] = bstack11l11ll_opy_ (u"ࠨ࡮ࡶ࡮࡯ࠦྕ")
            os.environ[bstack11l11ll_opy_ (u"ࠧࡃࡕࡢࡘࡊ࡙ࡔࡐࡒࡖࡣࡆࡒࡌࡐ࡙ࡢࡗࡈࡘࡅࡆࡐࡖࡌࡔ࡚ࡓࠨྖ")] = bstack11l11ll_opy_ (u"ࠣࡰࡸࡰࡱࠨྗ")
            bstack1l1l111ll1_opy_ = response.json()
            if bstack1l1l111ll1_opy_ and bstack1l1l111ll1_opy_[bstack11l11ll_opy_ (u"ࠩࡰࡩࡸࡹࡡࡨࡧࠪ྘")]:
                error_message = bstack1l1l111ll1_opy_[bstack11l11ll_opy_ (u"ࠪࡱࡪࡹࡳࡢࡩࡨࠫྙ")]
                if bstack1l1l111ll1_opy_[bstack11l11ll_opy_ (u"ࠫࡪࡸࡲࡰࡴࡗࡽࡵ࡫ࠧྚ")] == bstack11l11ll_opy_ (u"ࠬࡋࡒࡓࡑࡕࡣࡎࡔࡖࡂࡎࡌࡈࡤࡉࡒࡆࡆࡈࡒ࡙ࡏࡁࡍࡕࠪྛ"):
                    logger.error(error_message)
                elif bstack1l1l111ll1_opy_[bstack11l11ll_opy_ (u"࠭ࡥࡳࡴࡲࡶ࡙ࡿࡰࡦࠩྜ")] == bstack11l11ll_opy_ (u"ࠧࡆࡔࡕࡓࡗࡥࡁࡄࡅࡈࡗࡘࡥࡄࡆࡐࡌࡉࡉ࠭ྜྷ"):
                    logger.info(error_message)
                elif bstack1l1l111ll1_opy_[bstack11l11ll_opy_ (u"ࠨࡧࡵࡶࡴࡸࡔࡺࡲࡨࠫྞ")] == bstack11l11ll_opy_ (u"ࠩࡈࡖࡗࡕࡒࡠࡕࡇࡏࡤࡊࡅࡑࡔࡈࡇࡆ࡚ࡅࡅࠩྟ"):
                    logger.error(error_message)
                else:
                    logger.error(error_message)
            else:
                logger.error(bstack11l11ll_opy_ (u"ࠥࡈࡦࡺࡡࠡࡷࡳࡰࡴࡧࡤࠡࡶࡲࠤࡇࡸ࡯ࡸࡵࡨࡶࡘࡺࡡࡤ࡭ࠣࡘࡪࡹࡴࠡࡑࡥࡷࡪࡸࡶࡢࡤ࡬ࡰ࡮ࡺࡹࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡦࡸࡩࠥࡺ࡯ࠡࡵࡲࡱࡪࠦࡥࡳࡴࡲࡶࠧྠ"))
            return [None, None, None]
        logger.debug(bstack11l11ll_opy_ (u"࡙ࠫ࡫ࡳࡵࠢࡒࡦࡸ࡫ࡲࡷࡣࡥ࡭ࡱ࡯ࡴࡺࠢࡅࡹ࡮ࡲࡤࠡࡥࡵࡩࡦࡺࡩࡰࡰࠣࡗࡺࡩࡣࡦࡵࡶࡪࡺࡲࠡࠨྡ"))
        os.environ[bstack11l11ll_opy_ (u"ࠬࡈࡓࡠࡖࡈࡗ࡙ࡕࡐࡔࡡࡅ࡙ࡎࡒࡄࡠࡅࡒࡑࡕࡒࡅࡕࡇࡇࠫྡྷ")] = bstack11l11ll_opy_ (u"࠭ࡴࡳࡷࡨࠫྣ")
        bstack1l1l111ll1_opy_ = response.json()
        if bstack1l1l111ll1_opy_.get(bstack11l11ll_opy_ (u"ࠧ࡫ࡹࡷࠫྤ")):
            os.environ[bstack11l11ll_opy_ (u"ࠨࡄࡖࡣ࡙ࡋࡓࡕࡑࡓࡗࡤࡐࡗࡕࠩྥ")] = bstack1l1l111ll1_opy_[bstack11l11ll_opy_ (u"ࠩ࡭ࡻࡹ࠭ྦ")]
            os.environ[bstack11l11ll_opy_ (u"ࠪࡇࡗࡋࡄࡆࡐࡗࡍࡆࡒࡓࡠࡈࡒࡖࡤࡉࡒࡂࡕࡋࡣࡗࡋࡐࡐࡔࡗࡍࡓࡍࠧྦྷ")] = json.dumps({
                bstack11l11ll_opy_ (u"ࠫࡺࡹࡥࡳࡰࡤࡱࡪ࠭ྨ"): bstack1l11l1l1ll_opy_,
                bstack11l11ll_opy_ (u"ࠬࡶࡡࡴࡵࡺࡳࡷࡪࠧྩ"): bstack1l11llll11_opy_
            })
        if bstack1l1l111ll1_opy_.get(bstack11l11ll_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡤ࡮ࡡࡴࡪࡨࡨࡤ࡯ࡤࠨྪ")):
            os.environ[bstack11l11ll_opy_ (u"ࠧࡃࡕࡢࡘࡊ࡙ࡔࡐࡒࡖࡣࡇ࡛ࡉࡍࡆࡢࡌࡆ࡙ࡈࡆࡆࡢࡍࡉ࠭ྫ")] = bstack1l1l111ll1_opy_[bstack11l11ll_opy_ (u"ࠨࡤࡸ࡭ࡱࡪ࡟ࡩࡣࡶ࡬ࡪࡪ࡟ࡪࡦࠪྫྷ")]
        if bstack1l1l111ll1_opy_.get(bstack11l11ll_opy_ (u"ࠩࡤࡰࡱࡵࡷࡠࡵࡦࡶࡪ࡫࡮ࡴࡪࡲࡸࡸ࠭ྭ")):
            os.environ[bstack11l11ll_opy_ (u"ࠪࡆࡘࡥࡔࡆࡕࡗࡓࡕ࡙࡟ࡂࡎࡏࡓ࡜ࡥࡓࡄࡔࡈࡉࡓ࡙ࡈࡐࡖࡖࠫྮ")] = str(bstack1l1l111ll1_opy_[bstack11l11ll_opy_ (u"ࠫࡦࡲ࡬ࡰࡹࡢࡷࡨࡸࡥࡦࡰࡶ࡬ࡴࡺࡳࠨྯ")])
        return [bstack1l1l111ll1_opy_[bstack11l11ll_opy_ (u"ࠬࡰࡷࡵࠩྰ")], bstack1l1l111ll1_opy_[bstack11l11ll_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡤ࡮ࡡࡴࡪࡨࡨࡤ࡯ࡤࠨྱ")], bstack1l1l111ll1_opy_[bstack11l11ll_opy_ (u"ࠧࡢ࡮࡯ࡳࡼࡥࡳࡤࡴࡨࡩࡳࡹࡨࡰࡶࡶࠫྲ")]]
    @classmethod
    @bstack1l1l11l1ll_opy_(class_method=True)
    def stop(cls):
        if not cls.on():
            return
        if os.environ[bstack11l11ll_opy_ (u"ࠨࡄࡖࡣ࡙ࡋࡓࡕࡑࡓࡗࡤࡐࡗࡕࠩླ")] == bstack11l11ll_opy_ (u"ࠤࡱࡹࡱࡲࠢྴ") or os.environ[bstack11l11ll_opy_ (u"ࠪࡆࡘࡥࡔࡆࡕࡗࡓࡕ࡙࡟ࡃࡗࡌࡐࡉࡥࡈࡂࡕࡋࡉࡉࡥࡉࡅࠩྵ")] == bstack11l11ll_opy_ (u"ࠦࡳࡻ࡬࡭ࠤྶ"):
            print(bstack11l11ll_opy_ (u"ࠬࡋࡘࡄࡇࡓࡘࡎࡕࡎࠡࡋࡑࠤࡸࡺ࡯ࡱࡄࡸ࡭ࡱࡪࡕࡱࡵࡷࡶࡪࡧ࡭ࠡࡔࡈࡕ࡚ࡋࡓࡕࠢࡗࡓ࡚ࠥࡅࡔࡖࠣࡓࡇ࡙ࡅࡓࡘࡄࡆࡎࡒࡉࡕ࡛ࠣ࠾ࠥࡓࡩࡴࡵ࡬ࡲ࡬ࠦࡡࡶࡶ࡫ࡩࡳࡺࡩࡤࡣࡷ࡭ࡴࡴࠠࡵࡱ࡮ࡩࡳ࠭ྷ"))
            return {
                bstack11l11ll_opy_ (u"࠭ࡳࡵࡣࡷࡹࡸ࠭ྸ"): bstack11l11ll_opy_ (u"ࠧࡦࡴࡵࡳࡷ࠭ྐྵ"),
                bstack11l11ll_opy_ (u"ࠨ࡯ࡨࡷࡸࡧࡧࡦࠩྺ"): bstack11l11ll_opy_ (u"ࠩࡗࡳࡰ࡫࡮࠰ࡤࡸ࡭ࡱࡪࡉࡅࠢ࡬ࡷࠥࡻ࡮ࡥࡧࡩ࡭ࡳ࡫ࡤ࠭ࠢࡥࡹ࡮ࡲࡤࠡࡥࡵࡩࡦࡺࡩࡰࡰࠣࡱ࡮࡭ࡨࡵࠢ࡫ࡥࡻ࡫ࠠࡧࡣ࡬ࡰࡪࡪࠧྻ")
            }
        else:
            cls.bstack1l11l11lll_opy_.shutdown()
            data = {
                bstack11l11ll_opy_ (u"ࠪࡷࡹࡵࡰࡠࡶ࡬ࡱࡪ࠭ྼ"): datetime.datetime.now().isoformat()
            }
            config = {
                bstack11l11ll_opy_ (u"ࠫ࡭࡫ࡡࡥࡧࡵࡷࠬ྽"): cls.default_headers()
            }
            bstack1l11l11ll1_opy_ = bstack11l11ll_opy_ (u"ࠬࡧࡰࡪ࠱ࡹ࠵࠴ࡨࡵࡪ࡮ࡧࡷ࠴ࢁࡽ࠰ࡵࡷࡳࡵ࠭྾").format(os.environ[bstack11l11ll_opy_ (u"ࠨࡂࡔࡡࡗࡉࡘ࡚ࡏࡑࡕࡢࡆ࡚ࡏࡌࡅࡡࡋࡅࡘࡎࡅࡅࡡࡌࡈࠧ྿")])
            bstack1l1l1l11ll_opy_ = cls.request_url(bstack1l11l11ll1_opy_)
            response = bstack1l11l1l11_opy_(bstack11l11ll_opy_ (u"ࠧࡑࡗࡗࠫ࿀"), bstack1l1l1l11ll_opy_, data, config)
            if not response.ok:
                raise Exception(bstack11l11ll_opy_ (u"ࠣࡕࡷࡳࡵࠦࡲࡦࡳࡸࡩࡸࡺࠠ࡯ࡱࡷࠤࡴࡱࠢ࿁"))
    @classmethod
    def bstack1l11ll1l11_opy_(cls):
        if cls.bstack1l11l11lll_opy_ is None:
            return
        cls.bstack1l11l11lll_opy_.shutdown()
    @classmethod
    def bstack111l1l1ll_opy_(cls):
        if cls.on():
            print(
                bstack11l11ll_opy_ (u"࡙ࠩ࡭ࡸ࡯ࡴࠡࡪࡷࡸࡵࡹ࠺࠰࠱ࡲࡦࡸ࡫ࡲࡷࡣࡥ࡭ࡱ࡯ࡴࡺ࠰ࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫࠯ࡥࡲࡱ࠴ࡨࡵࡪ࡮ࡧࡷ࠴ࢁࡽࠡࡶࡲࠤࡻ࡯ࡥࡸࠢࡥࡹ࡮ࡲࡤࠡࡴࡨࡴࡴࡸࡴ࠭ࠢ࡬ࡲࡸ࡯ࡧࡩࡶࡶ࠰ࠥࡧ࡮ࡥࠢࡰࡥࡳࡿࠠ࡮ࡱࡵࡩࠥࡪࡥࡣࡷࡪ࡫࡮ࡴࡧࠡ࡫ࡱࡪࡴࡸ࡭ࡢࡶ࡬ࡳࡳࠦࡡ࡭࡮ࠣࡥࡹࠦ࡯࡯ࡧࠣࡴࡱࡧࡣࡦࠣ࡟ࡲࠬ࿂").format(os.environ[bstack11l11ll_opy_ (u"ࠥࡆࡘࡥࡔࡆࡕࡗࡓࡕ࡙࡟ࡃࡗࡌࡐࡉࡥࡈࡂࡕࡋࡉࡉࡥࡉࡅࠤ࿃")]))
    @classmethod
    def bstack1l1l11l1l1_opy_(cls):
        if cls.bstack1l11l11lll_opy_ is not None:
            return
        cls.bstack1l11l11lll_opy_ = bstack1l11ll1l1l_opy_(cls.bstack1l1l1111ll_opy_)
        cls.bstack1l11l11lll_opy_.start()
    @classmethod
    def bstack1l1l1l1l11_opy_(cls, bstack1l11ll111l_opy_, bstack1l11ll1lll_opy_=bstack11l11ll_opy_ (u"ࠫࡦࡶࡩ࠰ࡸ࠴࠳ࡧࡧࡴࡤࡪࠪ࿄")):
        if not cls.on():
            return
        bstack1l11llll1_opy_ = bstack1l11ll111l_opy_[bstack11l11ll_opy_ (u"ࠬ࡫ࡶࡦࡰࡷࡣࡹࡿࡰࡦࠩ࿅")]
        bstack1l11ll1ll1_opy_ = {
            bstack11l11ll_opy_ (u"࠭ࡔࡦࡵࡷࡖࡺࡴࡓࡵࡣࡵࡸࡪࡪ࿆ࠧ"): bstack11l11ll_opy_ (u"ࠧࡕࡧࡶࡸࡤ࡙ࡴࡢࡴࡷࡣ࡚ࡶ࡬ࡰࡣࡧࠫ࿇"),
            bstack11l11ll_opy_ (u"ࠨࡖࡨࡷࡹࡘࡵ࡯ࡈ࡬ࡲ࡮ࡹࡨࡦࡦࠪ࿈"): bstack11l11ll_opy_ (u"ࠩࡗࡩࡸࡺ࡟ࡆࡰࡧࡣ࡚ࡶ࡬ࡰࡣࡧࠫ࿉"),
            bstack11l11ll_opy_ (u"ࠪࡘࡪࡹࡴࡓࡷࡱࡗࡰ࡯ࡰࡱࡧࡧࠫ࿊"): bstack11l11ll_opy_ (u"࡙ࠫ࡫ࡳࡵࡡࡖ࡯࡮ࡶࡰࡦࡦࡢ࡙ࡵࡲ࡯ࡢࡦࠪ࿋"),
            bstack11l11ll_opy_ (u"ࠬࡒ࡯ࡨࡅࡵࡩࡦࡺࡥࡥࠩ࿌"): bstack11l11ll_opy_ (u"࠭ࡌࡰࡩࡢ࡙ࡵࡲ࡯ࡢࡦࠪ࿍"),
            bstack11l11ll_opy_ (u"ࠧࡉࡱࡲ࡯ࡗࡻ࡮ࡔࡶࡤࡶࡹ࡫ࡤࠨ࿎"): bstack11l11ll_opy_ (u"ࠨࡊࡲࡳࡰࡥࡓࡵࡣࡵࡸࡤ࡛ࡰ࡭ࡱࡤࡨࠬ࿏"),
            bstack11l11ll_opy_ (u"ࠩࡋࡳࡴࡱࡒࡶࡰࡉ࡭ࡳ࡯ࡳࡩࡧࡧࠫ࿐"): bstack11l11ll_opy_ (u"ࠪࡌࡴࡵ࡫ࡠࡇࡱࡨࡤ࡛ࡰ࡭ࡱࡤࡨࠬ࿑"),
            bstack11l11ll_opy_ (u"ࠫࡈࡈࡔࡔࡧࡶࡷ࡮ࡵ࡮ࡄࡴࡨࡥࡹ࡫ࡤࠨ࿒"): bstack11l11ll_opy_ (u"ࠬࡉࡂࡕࡡࡘࡴࡱࡵࡡࡥࠩ࿓")
        }.get(bstack1l11llll1_opy_)
        if bstack1l11ll1lll_opy_ == bstack11l11ll_opy_ (u"࠭ࡡࡱ࡫࠲ࡺ࠶࠵ࡢࡢࡶࡦ࡬ࠬ࿔"):
            cls.bstack1l1l11l1l1_opy_()
            cls.bstack1l11l11lll_opy_.add(bstack1l11ll111l_opy_)
        elif bstack1l11ll1lll_opy_ == bstack11l11ll_opy_ (u"ࠧࡢࡲ࡬࠳ࡻ࠷࠯ࡴࡥࡵࡩࡪࡴࡳࡩࡱࡷࡷࠬ࿕"):
            cls.bstack1l1l1111ll_opy_([bstack1l11ll111l_opy_], bstack1l11ll1lll_opy_)
    @classmethod
    @bstack1l1l11l1ll_opy_(class_method=True)
    def bstack1l1l1111ll_opy_(cls, bstack1l11ll111l_opy_, bstack1l11ll1lll_opy_=bstack11l11ll_opy_ (u"ࠨࡣࡳ࡭࠴ࡼ࠱࠰ࡤࡤࡸࡨ࡮ࠧ࿖")):
        config = {
            bstack11l11ll_opy_ (u"ࠩ࡫ࡩࡦࡪࡥࡳࡵࠪ࿗"): cls.default_headers()
        }
        response = bstack1l11l1l11_opy_(bstack11l11ll_opy_ (u"ࠪࡔࡔ࡙ࡔࠨ࿘"), cls.request_url(bstack1l11ll1lll_opy_), bstack1l11ll111l_opy_, config)
        bstack1l11ll1111_opy_ = response.json()
    @classmethod
    @bstack1l1l11l1ll_opy_(class_method=True)
    def bstack1l1l11llll_opy_(cls, bstack1l1l111l11_opy_):
        bstack1l11lll1l1_opy_ = []
        for log in bstack1l1l111l11_opy_:
            bstack1l1l1l1111_opy_ = {
                bstack11l11ll_opy_ (u"ࠫࡰ࡯࡮ࡥࠩ࿙"): bstack11l11ll_opy_ (u"࡚ࠬࡅࡔࡖࡢࡐࡔࡍࠧ࿚"),
                bstack11l11ll_opy_ (u"࠭࡬ࡦࡸࡨࡰࠬ࿛"): log[bstack11l11ll_opy_ (u"ࠧ࡭ࡧࡹࡩࡱ࠭࿜")],
                bstack11l11ll_opy_ (u"ࠨࡶ࡬ࡱࡪࡹࡴࡢ࡯ࡳࠫ࿝"): log[bstack11l11ll_opy_ (u"ࠩࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠬ࿞")],
                bstack11l11ll_opy_ (u"ࠪ࡬ࡹࡺࡰࡠࡴࡨࡷࡵࡵ࡮ࡴࡧࠪ࿟"): {},
                bstack11l11ll_opy_ (u"ࠫࡲ࡫ࡳࡴࡣࡪࡩࠬ࿠"): log[bstack11l11ll_opy_ (u"ࠬࡳࡥࡴࡵࡤ࡫ࡪ࠭࿡")],
            }
            if bstack11l11ll_opy_ (u"࠭ࡴࡦࡵࡷࡣࡷࡻ࡮ࡠࡷࡸ࡭ࡩ࠭࿢") in log:
                bstack1l1l1l1111_opy_[bstack11l11ll_opy_ (u"ࠧࡵࡧࡶࡸࡤࡸࡵ࡯ࡡࡸࡹ࡮ࡪࠧ࿣")] = log[bstack11l11ll_opy_ (u"ࠨࡶࡨࡷࡹࡥࡲࡶࡰࡢࡹࡺ࡯ࡤࠨ࿤")]
            elif bstack11l11ll_opy_ (u"ࠩ࡫ࡳࡴࡱ࡟ࡳࡷࡱࡣࡺࡻࡩࡥࠩ࿥") in log:
                bstack1l1l1l1111_opy_[bstack11l11ll_opy_ (u"ࠪ࡬ࡴࡵ࡫ࡠࡴࡸࡲࡤࡻࡵࡪࡦࠪ࿦")] = log[bstack11l11ll_opy_ (u"ࠫ࡭ࡵ࡯࡬ࡡࡵࡹࡳࡥࡵࡶ࡫ࡧࠫ࿧")]
            bstack1l11lll1l1_opy_.append(bstack1l1l1l1111_opy_)
        cls.bstack1l1l1l1l11_opy_({
            bstack11l11ll_opy_ (u"ࠬ࡫ࡶࡦࡰࡷࡣࡹࡿࡰࡦࠩ࿨"): bstack11l11ll_opy_ (u"࠭ࡌࡰࡩࡆࡶࡪࡧࡴࡦࡦࠪ࿩"),
            bstack11l11ll_opy_ (u"ࠧ࡭ࡱࡪࡷࠬ࿪"): bstack1l11lll1l1_opy_
        })
    @classmethod
    @bstack1l1l11l1ll_opy_(class_method=True)
    def bstack1l1l11lll1_opy_(cls, steps):
        bstack1l11llll1l_opy_ = []
        for step in steps:
            bstack1l1l111111_opy_ = {
                bstack11l11ll_opy_ (u"ࠨ࡭࡬ࡲࡩ࠭࿫"): bstack11l11ll_opy_ (u"ࠩࡗࡉࡘ࡚࡟ࡔࡖࡈࡔࠬ࿬"),
                bstack11l11ll_opy_ (u"ࠪࡰࡪࡼࡥ࡭ࠩ࿭"): step[bstack11l11ll_opy_ (u"ࠫࡱ࡫ࡶࡦ࡮ࠪ࿮")],
                bstack11l11ll_opy_ (u"ࠬࡺࡩ࡮ࡧࡶࡸࡦࡳࡰࠨ࿯"): step[bstack11l11ll_opy_ (u"࠭ࡴࡪ࡯ࡨࡷࡹࡧ࡭ࡱࠩ࿰")],
                bstack11l11ll_opy_ (u"ࠧ࡮ࡧࡶࡷࡦ࡭ࡥࠨ࿱"): step[bstack11l11ll_opy_ (u"ࠨ࡯ࡨࡷࡸࡧࡧࡦࠩ࿲")],
                bstack11l11ll_opy_ (u"ࠩࡧࡹࡷࡧࡴࡪࡱࡱࠫ࿳"): step[bstack11l11ll_opy_ (u"ࠪࡨࡺࡸࡡࡵ࡫ࡲࡲࠬ࿴")]
            }
            if bstack11l11ll_opy_ (u"ࠫࡹ࡫ࡳࡵࡡࡵࡹࡳࡥࡵࡶ࡫ࡧࠫ࿵") in step:
                bstack1l1l111111_opy_[bstack11l11ll_opy_ (u"ࠬࡺࡥࡴࡶࡢࡶࡺࡴ࡟ࡶࡷ࡬ࡨࠬ࿶")] = step[bstack11l11ll_opy_ (u"࠭ࡴࡦࡵࡷࡣࡷࡻ࡮ࡠࡷࡸ࡭ࡩ࠭࿷")]
            elif bstack11l11ll_opy_ (u"ࠧࡩࡱࡲ࡯ࡤࡸࡵ࡯ࡡࡸࡹ࡮ࡪࠧ࿸") in step:
                bstack1l1l111111_opy_[bstack11l11ll_opy_ (u"ࠨࡪࡲࡳࡰࡥࡲࡶࡰࡢࡹࡺ࡯ࡤࠨ࿹")] = step[bstack11l11ll_opy_ (u"ࠩ࡫ࡳࡴࡱ࡟ࡳࡷࡱࡣࡺࡻࡩࡥࠩ࿺")]
            bstack1l11llll1l_opy_.append(bstack1l1l111111_opy_)
        cls.bstack1l1l1l1l11_opy_({
            bstack11l11ll_opy_ (u"ࠪࡩࡻ࡫࡮ࡵࡡࡷࡽࡵ࡫ࠧ࿻"): bstack11l11ll_opy_ (u"ࠫࡑࡵࡧࡄࡴࡨࡥࡹ࡫ࡤࠨ࿼"),
            bstack11l11ll_opy_ (u"ࠬࡲ࡯ࡨࡵࠪ࿽"): bstack1l11llll1l_opy_
        })
    @classmethod
    @bstack1l1l11l1ll_opy_(class_method=True)
    def bstack1l11l1lll1_opy_(cls, screenshot):
        cls.bstack1l1l1l1l11_opy_({
            bstack11l11ll_opy_ (u"࠭ࡥࡷࡧࡱࡸࡤࡺࡹࡱࡧࠪ࿾"): bstack11l11ll_opy_ (u"ࠧࡍࡱࡪࡇࡷ࡫ࡡࡵࡧࡧࠫ࿿"),
            bstack11l11ll_opy_ (u"ࠨ࡮ࡲ࡫ࡸ࠭က"): [{
                bstack11l11ll_opy_ (u"ࠩ࡮࡭ࡳࡪࠧခ"): bstack11l11ll_opy_ (u"ࠪࡘࡊ࡙ࡔࡠࡕࡆࡖࡊࡋࡎࡔࡊࡒࡘࠬဂ"),
                bstack11l11ll_opy_ (u"ࠫࡹ࡯࡭ࡦࡵࡷࡥࡲࡶࠧဃ"): datetime.datetime.utcnow().isoformat() + bstack11l11ll_opy_ (u"ࠬࡠࠧင"),
                bstack11l11ll_opy_ (u"࠭࡭ࡦࡵࡶࡥ࡬࡫ࠧစ"): screenshot[bstack11l11ll_opy_ (u"ࠧࡪ࡯ࡤ࡫ࡪ࠭ဆ")],
                bstack11l11ll_opy_ (u"ࠨࡶࡨࡷࡹࡥࡲࡶࡰࡢࡹࡺ࡯ࡤࠨဇ"): screenshot[bstack11l11ll_opy_ (u"ࠩࡷࡩࡸࡺ࡟ࡳࡷࡱࡣࡺࡻࡩࡥࠩဈ")]
            }]
        }, bstack1l11ll1lll_opy_=bstack11l11ll_opy_ (u"ࠪࡥࡵ࡯࠯ࡷ࠳࠲ࡷࡨࡸࡥࡦࡰࡶ࡬ࡴࡺࡳࠨဉ"))
    @classmethod
    @bstack1l1l11l1ll_opy_(class_method=True)
    def bstack11111111l_opy_(cls, driver):
        current_test_uuid = cls.current_test_uuid()
        if not current_test_uuid:
            return
        cls.bstack1l1l1l1l11_opy_({
            bstack11l11ll_opy_ (u"ࠫࡪࡼࡥ࡯ࡶࡢࡸࡾࡶࡥࠨည"): bstack11l11ll_opy_ (u"ࠬࡉࡂࡕࡕࡨࡷࡸ࡯࡯࡯ࡅࡵࡩࡦࡺࡥࡥࠩဋ"),
            bstack11l11ll_opy_ (u"࠭ࡴࡦࡵࡷࡣࡷࡻ࡮ࠨဌ"): {
                bstack11l11ll_opy_ (u"ࠢࡶࡷ࡬ࡨࠧဍ"): cls.current_test_uuid(),
                bstack11l11ll_opy_ (u"ࠣ࡫ࡱࡸࡪ࡭ࡲࡢࡶ࡬ࡳࡳࡹࠢဎ"): cls.bstack1l1l111l1l_opy_(driver)
            }
        })
    @classmethod
    def on(cls):
        if os.environ.get(bstack11l11ll_opy_ (u"ࠩࡅࡗࡤ࡚ࡅࡔࡖࡒࡔࡘࡥࡊࡘࡖࠪဏ"), None) is None or os.environ[bstack11l11ll_opy_ (u"ࠪࡆࡘࡥࡔࡆࡕࡗࡓࡕ࡙࡟ࡋ࡙ࡗࠫတ")] == bstack11l11ll_opy_ (u"ࠦࡳࡻ࡬࡭ࠤထ"):
            return False
        return True
    @classmethod
    def bstack1l11l1llll_opy_(cls):
        return bstack1l1l11l111_opy_(cls.bs_config.get(bstack11l11ll_opy_ (u"ࠬࡺࡥࡴࡶࡒࡦࡸ࡫ࡲࡷࡣࡥ࡭ࡱ࡯ࡴࡺࠩဒ"), False))
    @staticmethod
    def request_url(url):
        return bstack11l11ll_opy_ (u"࠭ࡻࡾ࠱ࡾࢁࠬဓ").format(bstack1l11llllll_opy_, url)
    @staticmethod
    def default_headers():
        headers = {
            bstack11l11ll_opy_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭န"): bstack11l11ll_opy_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡪࡴࡱࡱࠫပ"),
            bstack11l11ll_opy_ (u"࡛ࠩ࠱ࡇ࡙ࡔࡂࡅࡎ࠱࡙ࡋࡓࡕࡑࡓࡗࠬဖ"): bstack11l11ll_opy_ (u"ࠪࡸࡷࡻࡥࠨဗ")
        }
        if os.environ.get(bstack11l11ll_opy_ (u"ࠫࡇ࡙࡟ࡕࡇࡖࡘࡔࡖࡓࡠࡌ࡚ࡘࠬဘ"), None):
            headers[bstack11l11ll_opy_ (u"ࠬࡇࡵࡵࡪࡲࡶ࡮ࢀࡡࡵ࡫ࡲࡲࠬမ")] = bstack11l11ll_opy_ (u"࠭ࡂࡦࡣࡵࡩࡷࠦࡻࡾࠩယ").format(os.environ[bstack11l11ll_opy_ (u"ࠢࡃࡕࡢࡘࡊ࡙ࡔࡐࡒࡖࡣࡏ࡝ࡔࠣရ")])
        return headers
    @staticmethod
    def current_test_uuid():
        return getattr(threading.current_thread(), bstack11l11ll_opy_ (u"ࠨࡥࡸࡶࡷ࡫࡮ࡵࡡࡷࡩࡸࡺ࡟ࡶࡷ࡬ࡨࠬလ"), None)
    @staticmethod
    def bstack1l1l111l1l_opy_(driver):
        return {
            bstack1l11lll1ll_opy_(): bstack1l11lll111_opy_(driver)
        }
    @staticmethod
    def bstack1l11lll11l_opy_(exception_info, report):
        return [{bstack11l11ll_opy_ (u"ࠩࡥࡥࡨࡱࡴࡳࡣࡦࡩࠬဝ"): [exception_info.exconly(), report.longreprtext]}]
    @staticmethod
    def bstack1l11l1l111_opy_(typename):
        if bstack11l11ll_opy_ (u"ࠥࡅࡸࡹࡥࡳࡶ࡬ࡳࡳࠨသ") in typename:
            return bstack11l11ll_opy_ (u"ࠦࡆࡹࡳࡦࡴࡷ࡭ࡴࡴࡅࡳࡴࡲࡶࠧဟ")
        return bstack11l11ll_opy_ (u"࡛ࠧ࡮ࡩࡣࡱࡨࡱ࡫ࡤࡆࡴࡵࡳࡷࠨဠ")
    @staticmethod
    def bstack1l11l1ll1l_opy_(func):
        def wrap(*args, **kwargs):
            if bstack1ll1lll1ll_opy_.on():
                return func(*args, **kwargs)
            return
        return wrap
    @staticmethod
    def bstack1l11ll11ll_opy_(test, hook_name=None):
        bstack1l1l11111l_opy_ = test.parent
        if hook_name in [bstack11l11ll_opy_ (u"࠭ࡳࡦࡶࡸࡴࡤࡩ࡬ࡢࡵࡶࠫအ"), bstack11l11ll_opy_ (u"ࠧࡵࡧࡤࡶࡩࡵࡷ࡯ࡡࡦࡰࡦࡹࡳࠨဢ"), bstack11l11ll_opy_ (u"ࠨࡵࡨࡸࡺࡶ࡟࡮ࡱࡧࡹࡱ࡫ࠧဣ"), bstack11l11ll_opy_ (u"ࠩࡷࡩࡦࡸࡤࡰࡹࡱࡣࡲࡵࡤࡶ࡮ࡨࠫဤ")]:
            bstack1l1l11111l_opy_ = test
        scope = []
        while bstack1l1l11111l_opy_ is not None:
            scope.append(bstack1l1l11111l_opy_.name)
            bstack1l1l11111l_opy_ = bstack1l1l11111l_opy_.parent
        scope.reverse()
        return scope[2:]
    @staticmethod
    def bstack1l1l11ll11_opy_(hook_type):
        if hook_type == bstack11l11ll_opy_ (u"ࠥࡆࡊࡌࡏࡓࡇࡢࡉࡆࡉࡈࠣဥ"):
            return bstack11l11ll_opy_ (u"ࠦࡘ࡫ࡴࡶࡲࠣ࡬ࡴࡵ࡫ࠣဦ")
        elif hook_type == bstack11l11ll_opy_ (u"ࠧࡇࡆࡕࡇࡕࡣࡊࡇࡃࡉࠤဧ"):
            return bstack11l11ll_opy_ (u"ࠨࡔࡦࡣࡵࡨࡴࡽ࡮ࠡࡪࡲࡳࡰࠨဨ")
    @staticmethod
    def bstack1l1l1l1l1l_opy_(bstack1ll1llll_opy_):
        try:
            if not bstack1ll1lll1ll_opy_.on():
                return bstack1ll1llll_opy_
            if os.environ.get(bstack11l11ll_opy_ (u"ࠢࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡒࡆࡔࡘࡒࠧဩ"), None) == bstack11l11ll_opy_ (u"ࠣࡶࡵࡹࡪࠨဪ"):
                tests = os.environ.get(bstack11l11ll_opy_ (u"ࠤࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡔࡈࡖ࡚ࡔ࡟ࡕࡇࡖࡘࡘࠨါ"), None)
                if tests is None or tests == bstack11l11ll_opy_ (u"ࠥࡲࡺࡲ࡬ࠣာ"):
                    return bstack1ll1llll_opy_
                bstack1ll1llll_opy_ = tests.split(bstack11l11ll_opy_ (u"ࠫ࠱࠭ိ"))
                return bstack1ll1llll_opy_
        except Exception as exc:
            print(bstack11l11ll_opy_ (u"ࠧࡋࡸࡤࡧࡳࡸ࡮ࡵ࡮ࠡ࡫ࡱࠤࡷ࡫ࡲࡶࡰࠣ࡬ࡦࡴࡤ࡭ࡧࡵ࠾ࠥࠨီ"), str(exc))
        return bstack1ll1llll_opy_
    @classmethod
    def bstack1l1l1111l1_opy_(cls, event: str, bstack1l11ll111l_opy_: bstack1l11l1l11l_opy_):
        bstack1l1l111lll_opy_ = {
            bstack11l11ll_opy_ (u"࠭ࡥࡷࡧࡱࡸࡤࡺࡹࡱࡧࠪု"): event,
            bstack1l11ll111l_opy_.bstack1l1l11ll1l_opy_(): bstack1l11ll111l_opy_.bstack1l1l1l111l_opy_(event)
        }
        bstack1ll1lll1ll_opy_.bstack1l1l1l1l11_opy_(bstack1l1l111lll_opy_)