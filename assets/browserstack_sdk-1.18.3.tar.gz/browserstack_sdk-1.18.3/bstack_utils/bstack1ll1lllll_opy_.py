# coding: UTF-8
import sys
bstack111llll_opy_ = sys.version_info [0] == 2
bstack1llllll_opy_ = 2048
bstack11ll1l_opy_ = 7
def bstack11l11ll_opy_ (bstack1l1ll11_opy_):
    global bstack1l11l_opy_
    bstack1l11ll_opy_ = ord (bstack1l1ll11_opy_ [-1])
    bstack111ll1_opy_ = bstack1l1ll11_opy_ [:-1]
    bstack1lllll_opy_ = bstack1l11ll_opy_ % len (bstack111ll1_opy_)
    bstack11l1l1l_opy_ = bstack111ll1_opy_ [:bstack1lllll_opy_] + bstack111ll1_opy_ [bstack1lllll_opy_:]
    if bstack111llll_opy_:
        bstack1ll1l_opy_ = unicode () .join ([unichr (ord (char) - bstack1llllll_opy_ - (bstack1l11l1_opy_ + bstack1l11ll_opy_) % bstack11ll1l_opy_) for bstack1l11l1_opy_, char in enumerate (bstack11l1l1l_opy_)])
    else:
        bstack1ll1l_opy_ = str () .join ([chr (ord (char) - bstack1llllll_opy_ - (bstack1l11l1_opy_ + bstack1l11ll_opy_) % bstack11ll1l_opy_) for bstack1l11l1_opy_, char in enumerate (bstack11l1l1l_opy_)])
    return eval (bstack1ll1l_opy_)
import os
import json
import requests
from selenium import webdriver
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
import logging
from urllib.parse import urlparse
from datetime import datetime
from bstack_utils.constants import bstack1l1ll1111l_opy_ as bstack11l111l1l1_opy_
from bstack_utils.helper import bstack11ll1llll_opy_, bstack11llllll1_opy_, bstack1l11l1l1l1_opy_, bstack1l11lllll1_opy_, bstack1lll11ll1l_opy_, get_host_info, bstack1l1l1l11l1_opy_, bstack1l11l1l11_opy_, bstack1l1l11l1ll_opy_
from browserstack_sdk._version import __version__
logger = logging.getLogger(__name__)
@bstack1l1l11l1ll_opy_(class_method=False)
def _11l11ll11l_opy_(driver):
  response = {}
  try:
    caps = driver.capabilities
    response = {
        bstack11l11ll_opy_ (u"࠭࡯ࡴࡡࡱࡥࡲ࡫ࠧኺ"): caps.get(bstack11l11ll_opy_ (u"ࠧࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡐࡤࡱࡪ࠭ኻ"), None),
        bstack11l11ll_opy_ (u"ࠨࡱࡶࡣࡻ࡫ࡲࡴ࡫ࡲࡲࠬኼ"): caps.get(bstack11l11ll_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰ࡚ࡪࡸࡳࡪࡱࡱࠫኽ"), None),
        bstack11l11ll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡣࡳࡧ࡭ࡦࠩኾ"): caps.get(bstack11l11ll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡓࡧ࡭ࡦࠩ኿"), None),
        bstack11l11ll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡥࡶࡦࡴࡶ࡭ࡴࡴࠧዀ"): caps.get(bstack11l11ll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡖࡦࡴࡶ࡭ࡴࡴࠧ዁"), None)
    }
  except Exception as error:
    logger.debug(bstack11l11ll_opy_ (u"ࠧࡆࡺࡦࡩࡵࡺࡩࡰࡰࠣ࡭ࡳࠦࡦࡦࡶࡦ࡬࡮ࡴࡧࠡࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࠣࡨࡪࡺࡡࡪ࡮ࡶࠤࡼ࡯ࡴࡩࠢࡨࡶࡷࡵࡲࠡ࠼ࠣࠫዂ") + str(error))
  return response
def bstack1111ll111_opy_(config):
  return config.get(bstack11l11ll_opy_ (u"ࠨࡣࡦࡧࡪࡹࡳࡪࡤ࡬ࡰ࡮ࡺࡹࠨዃ"), False) or any([p.get(bstack11l11ll_opy_ (u"ࠩࡤࡧࡨ࡫ࡳࡴ࡫ࡥ࡭ࡱ࡯ࡴࡺࠩዄ"), False) == True for p in config[bstack11l11ll_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱࡸ࠭ዅ")]])
def bstack1lllll11l1_opy_(config, bstack11lllllll_opy_):
  try:
    if not bstack11llllll1_opy_(config):
      return False
    bstack11l1111ll1_opy_ = config.get(bstack11l11ll_opy_ (u"ࠫࡦࡩࡣࡦࡵࡶ࡭ࡧ࡯࡬ࡪࡶࡼࠫ዆"), False)
    bstack11l1111lll_opy_ = config[bstack11l11ll_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡳࠨ዇")][bstack11lllllll_opy_].get(bstack11l11ll_opy_ (u"࠭ࡡࡤࡥࡨࡷࡸ࡯ࡢࡪ࡮࡬ࡸࡾ࠭ወ"), None)
    if bstack11l1111lll_opy_ != None:
      bstack11l1111ll1_opy_ = bstack11l1111lll_opy_
    bstack11l11l1lll_opy_ = os.getenv(bstack11l11ll_opy_ (u"ࠧࡃࡕࡢࡅ࠶࠷࡙ࡠࡌ࡚ࡘࠬዉ")) is not None and len(os.getenv(bstack11l11ll_opy_ (u"ࠨࡄࡖࡣࡆ࠷࠱࡚ࡡࡍ࡛࡙࠭ዊ"))) > 0 and os.getenv(bstack11l11ll_opy_ (u"ࠩࡅࡗࡤࡇ࠱࠲࡛ࡢࡎ࡜࡚ࠧዋ")) != bstack11l11ll_opy_ (u"ࠪࡲࡺࡲ࡬ࠨዌ")
    return bstack11l1111ll1_opy_ and bstack11l11l1lll_opy_
  except Exception as error:
    logger.debug(bstack11l11ll_opy_ (u"ࠫࡊࡾࡣࡦࡲࡷ࡭ࡴࡴࠠࡪࡰࠣࡺࡪࡸࡩࡧࡻ࡬ࡲ࡬ࠦࡴࡩࡧࠣࡅࡨࡩࡥࡴࡵ࡬ࡦ࡮ࡲࡩࡵࡻࠣࡷࡪࡹࡳࡪࡱࡱࠤࡼ࡯ࡴࡩࠢࡨࡶࡷࡵࡲࠡ࠼ࠣࠫው") + str(error))
  return False
def bstack11l11l1l1l_opy_(bstack11l11l11l1_opy_, test_tags):
  bstack11l11l11l1_opy_ = os.getenv(bstack11l11ll_opy_ (u"ࠬࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣ࡙ࡋࡓࡕࡡࡄࡇࡈࡋࡓࡔࡋࡅࡍࡑࡏࡔ࡚ࡡࡆࡓࡓࡌࡉࡈࡗࡕࡅ࡙ࡏࡏࡏࡡ࡜ࡑࡑ࠭ዎ"))
  if bstack11l11l11l1_opy_ is None:
    return True
  bstack11l11l11l1_opy_ = json.loads(bstack11l11l11l1_opy_)
  try:
    include_tags = bstack11l11l11l1_opy_[bstack11l11ll_opy_ (u"࠭ࡩ࡯ࡥ࡯ࡹࡩ࡫ࡔࡢࡩࡶࡍࡳ࡚ࡥࡴࡶ࡬ࡲ࡬࡙ࡣࡰࡲࡨࠫዏ")] if bstack11l11ll_opy_ (u"ࠧࡪࡰࡦࡰࡺࡪࡥࡕࡣࡪࡷࡎࡴࡔࡦࡵࡷ࡭ࡳ࡭ࡓࡤࡱࡳࡩࠬዐ") in bstack11l11l11l1_opy_ and isinstance(bstack11l11l11l1_opy_[bstack11l11ll_opy_ (u"ࠨ࡫ࡱࡧࡱࡻࡤࡦࡖࡤ࡫ࡸࡏ࡮ࡕࡧࡶࡸ࡮ࡴࡧࡔࡥࡲࡴࡪ࠭ዑ")], list) else []
    exclude_tags = bstack11l11l11l1_opy_[bstack11l11ll_opy_ (u"ࠩࡨࡼࡨࡲࡵࡥࡧࡗࡥ࡬ࡹࡉ࡯ࡖࡨࡷࡹ࡯࡮ࡨࡕࡦࡳࡵ࡫ࠧዒ")] if bstack11l11ll_opy_ (u"ࠪࡩࡽࡩ࡬ࡶࡦࡨࡘࡦ࡭ࡳࡊࡰࡗࡩࡸࡺࡩ࡯ࡩࡖࡧࡴࡶࡥࠨዓ") in bstack11l11l11l1_opy_ and isinstance(bstack11l11l11l1_opy_[bstack11l11ll_opy_ (u"ࠫࡪࡾࡣ࡭ࡷࡧࡩ࡙ࡧࡧࡴࡋࡱࡘࡪࡹࡴࡪࡰࡪࡗࡨࡵࡰࡦࠩዔ")], list) else []
    excluded = any(tag in exclude_tags for tag in test_tags)
    included = len(include_tags) == 0 or any(tag in include_tags for tag in test_tags)
    return not excluded and included
  except Exception as error:
    logger.debug(bstack11l11ll_opy_ (u"ࠧࡋࡲࡳࡱࡵࠤࡼ࡮ࡩ࡭ࡧࠣࡺࡦࡲࡩࡥࡣࡷ࡭ࡳ࡭ࠠࡵࡧࡶࡸࠥࡩࡡࡴࡧࠣࡪࡴࡸࠠࡢࡥࡦࡩࡸࡹࡩࡣ࡫࡯࡭ࡹࡿࠠࡣࡧࡩࡳࡷ࡫ࠠࡴࡥࡤࡲࡳ࡯࡮ࡨ࠰ࠣࡉࡷࡸ࡯ࡳࠢ࠽ࠤࠧዕ") + str(error))
  return False
def bstack11ll111l_opy_(config, frameworkName, bstack11l111lll1_opy_):
  bstack1l11l1l1ll_opy_ = bstack1l11l1l1l1_opy_(config)
  bstack1l11llll11_opy_ = bstack1l11lllll1_opy_(config)
  if bstack1l11l1l1ll_opy_ is None or bstack1l11llll11_opy_ is None:
    logger.error(bstack11l11ll_opy_ (u"࠭ࡅࡹࡥࡨࡴࡹ࡯࡯࡯ࠢࡺ࡬࡮ࡲࡥࠡࡥࡵࡩࡦࡺࡩ࡯ࡩࠣࡸࡪࡹࡴࠡࡴࡸࡲࠥ࡬࡯ࡳࠢࡅࡶࡴࡽࡳࡦࡴࡖࡸࡦࡩ࡫ࠡࡃࡦࡧࡪࡹࡳࡪࡤ࡬ࡰ࡮ࡺࡹࠡࡃࡸࡸࡴࡳࡡࡵ࡫ࡲࡲ࠿ࠦࡍࡪࡵࡶ࡭ࡳ࡭ࠠࡢࡷࡷ࡬ࡪࡴࡴࡪࡥࡤࡸ࡮ࡵ࡮ࠡࡶࡲ࡯ࡪࡴࠧዖ"))
    return [None, None]
  try:
    settings = json.loads(os.getenv(bstack11l11ll_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡔࡆࡕࡗࡣࡆࡉࡃࡆࡕࡖࡍࡇࡏࡌࡊࡖ࡜ࡣࡈࡕࡎࡇࡋࡊ࡙ࡗࡇࡔࡊࡑࡑࡣ࡞ࡓࡌࠨ዗"), bstack11l11ll_opy_ (u"ࠨࡽࢀࠫዘ")))
    data = {
        bstack11l11ll_opy_ (u"ࠩࡳࡶࡴࡰࡥࡤࡶࡑࡥࡲ࡫ࠧዙ"): config[bstack11l11ll_opy_ (u"ࠪࡴࡷࡵࡪࡦࡥࡷࡒࡦࡳࡥࠨዚ")],
        bstack11l11ll_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡑࡥࡲ࡫ࠧዛ"): config.get(bstack11l11ll_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡒࡦࡳࡥࠨዜ"), os.path.basename(os.getcwd())),
        bstack11l11ll_opy_ (u"࠭ࡳࡵࡣࡵࡸ࡙࡯࡭ࡦࠩዝ"): bstack11ll1llll_opy_(),
        bstack11l11ll_opy_ (u"ࠧࡥࡧࡶࡧࡷ࡯ࡰࡵ࡫ࡲࡲࠬዞ"): config.get(bstack11l11ll_opy_ (u"ࠨࡤࡸ࡭ࡱࡪࡄࡦࡵࡦࡶ࡮ࡶࡴࡪࡱࡱࠫዟ"), bstack11l11ll_opy_ (u"ࠩࠪዠ")),
        bstack11l11ll_opy_ (u"ࠪࡷࡴࡻࡲࡤࡧࠪዡ"): {
            bstack11l11ll_opy_ (u"ࠫ࡫ࡸࡡ࡮ࡧࡺࡳࡷࡱࡎࡢ࡯ࡨࠫዢ"): frameworkName,
            bstack11l11ll_opy_ (u"ࠬ࡬ࡲࡢ࡯ࡨࡻࡴࡸ࡫ࡗࡧࡵࡷ࡮ࡵ࡮ࠨዣ"): bstack11l111lll1_opy_,
            bstack11l11ll_opy_ (u"࠭ࡳࡥ࡭࡙ࡩࡷࡹࡩࡰࡰࠪዤ"): __version__
        },
        bstack11l11ll_opy_ (u"ࠧࡴࡧࡷࡸ࡮ࡴࡧࡴࠩዥ"): settings,
        bstack11l11ll_opy_ (u"ࠨࡸࡨࡶࡸ࡯࡯࡯ࡅࡲࡲࡹࡸ࡯࡭ࠩዦ"): bstack1l1l1l11l1_opy_(),
        bstack11l11ll_opy_ (u"ࠩࡦ࡭ࡎࡴࡦࡰࠩዧ"): bstack1lll11ll1l_opy_(),
        bstack11l11ll_opy_ (u"ࠪ࡬ࡴࡹࡴࡊࡰࡩࡳࠬየ"): get_host_info(),
        bstack11l11ll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡄࡹࡹࡵ࡭ࡢࡶ࡬ࡳࡳ࠭ዩ"): bstack11llllll1_opy_(config)
    }
    headers = {
        bstack11l11ll_opy_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫዪ"): bstack11l11ll_opy_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳࡯ࡹ࡯࡯ࠩያ"),
    }
    config = {
        bstack11l11ll_opy_ (u"ࠧࡢࡷࡷ࡬ࠬዬ"): (bstack1l11l1l1ll_opy_, bstack1l11llll11_opy_),
        bstack11l11ll_opy_ (u"ࠨࡪࡨࡥࡩ࡫ࡲࡴࠩይ"): headers
    }
    response = bstack1l11l1l11_opy_(bstack11l11ll_opy_ (u"ࠩࡓࡓࡘ࡚ࠧዮ"), bstack11l111l1l1_opy_ + bstack11l11ll_opy_ (u"ࠪ࠳ࡹ࡫ࡳࡵࡡࡵࡹࡳࡹࠧዯ"), data, config)
    bstack1l11ll1111_opy_ = response.json()
    if bstack1l11ll1111_opy_[bstack11l11ll_opy_ (u"ࠫࡸࡻࡣࡤࡧࡶࡷࠬደ")]:
      logger.info(bstack11l11ll_opy_ (u"ࠬࡹࡴࡢࡶࡸࡷࠥࡩ࡯ࡥࡧࠣࠫዱ") + str(response.status_code) + bstack11l11ll_opy_ (u"࠭࡜࡯ࠩዲ") + str(bstack1l11ll1111_opy_))
      parsed = json.loads(os.getenv(bstack11l11ll_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡔࡆࡕࡗࡣࡆࡉࡃࡆࡕࡖࡍࡇࡏࡌࡊࡖ࡜ࡣࡈࡕࡎࡇࡋࡊ࡙ࡗࡇࡔࡊࡑࡑࡣ࡞ࡓࡌࠨዳ"), bstack11l11ll_opy_ (u"ࠨࡽࢀࠫዴ")))
      parsed[bstack11l11ll_opy_ (u"ࠩࡶࡧࡦࡴ࡮ࡦࡴ࡙ࡩࡷࡹࡩࡰࡰࠪድ")] = bstack1l11ll1111_opy_[bstack11l11ll_opy_ (u"ࠪࡨࡦࡺࡡࠨዶ")][bstack11l11ll_opy_ (u"ࠫࡸࡩࡡ࡯ࡰࡨࡶ࡛࡫ࡲࡴ࡫ࡲࡲࠬዷ")]
      os.environ[bstack11l11ll_opy_ (u"ࠬࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣ࡙ࡋࡓࡕࡡࡄࡇࡈࡋࡓࡔࡋࡅࡍࡑࡏࡔ࡚ࡡࡆࡓࡓࡌࡉࡈࡗࡕࡅ࡙ࡏࡏࡏࡡ࡜ࡑࡑ࠭ዸ")] = json.dumps(parsed)
      return bstack1l11ll1111_opy_[bstack11l11ll_opy_ (u"࠭ࡤࡢࡶࡤࠫዹ")][bstack11l11ll_opy_ (u"ࠧࡢࡥࡦࡩࡸࡹࡩࡣ࡫࡯࡭ࡹࡿࡔࡰ࡭ࡨࡲࠬዺ")], bstack1l11ll1111_opy_[bstack11l11ll_opy_ (u"ࠨࡦࡤࡸࡦ࠭ዻ")][bstack11l11ll_opy_ (u"ࠩ࡬ࡨࠬዼ")]
    else:
      logger.error(bstack11l11ll_opy_ (u"ࠪࡉࡽࡩࡥࡱࡶ࡬ࡳࡳࠦࡷࡩ࡫࡯ࡩࠥࡸࡵ࡯ࡰ࡬ࡲ࡬ࠦࡂࡳࡱࡺࡷࡪࡸࡓࡵࡣࡦ࡯ࠥࡇࡣࡤࡧࡶࡷ࡮ࡨࡩ࡭࡫ࡷࡽࠥࡇࡵࡵࡱࡰࡥࡹ࡯࡯࡯࠼ࠣࠫዽ") + bstack1l11ll1111_opy_[bstack11l11ll_opy_ (u"ࠫࡲ࡫ࡳࡴࡣࡪࡩࠬዾ")])
      if bstack1l11ll1111_opy_[bstack11l11ll_opy_ (u"ࠬࡳࡥࡴࡵࡤ࡫ࡪ࠭ዿ")] == bstack11l11ll_opy_ (u"࠭ࡉ࡯ࡸࡤࡰ࡮ࡪࠠࡤࡱࡱࡪ࡮࡭ࡵࡳࡣࡷ࡭ࡴࡴࠠࡱࡣࡶࡷࡪࡪ࠮ࠨጀ"):
        for bstack11l11ll111_opy_ in bstack1l11ll1111_opy_[bstack11l11ll_opy_ (u"ࠧࡦࡴࡵࡳࡷࡹࠧጁ")]:
          logger.error(bstack11l11ll111_opy_[bstack11l11ll_opy_ (u"ࠨ࡯ࡨࡷࡸࡧࡧࡦࠩጂ")])
      return None, None
  except Exception as error:
    logger.error(bstack11l11ll_opy_ (u"ࠤࡈࡼࡨ࡫ࡰࡵ࡫ࡲࡲࠥࡽࡨࡪ࡮ࡨࠤࡨࡸࡥࡢࡶ࡬ࡲ࡬ࠦࡴࡦࡵࡷࠤࡷࡻ࡮ࠡࡨࡲࡶࠥࡈࡲࡰࡹࡶࡩࡷ࡙ࡴࡢࡥ࡮ࠤࡆࡩࡣࡦࡵࡶ࡭ࡧ࡯࡬ࡪࡶࡼࠤࡆࡻࡴࡰ࡯ࡤࡸ࡮ࡵ࡮࠻ࠢࠥጃ") +  str(error))
    return None, None
def bstack1llll1111l_opy_():
  if os.getenv(bstack11l11ll_opy_ (u"ࠪࡆࡘࡥࡁ࠲࠳࡜ࡣࡏ࡝ࡔࠨጄ")) is None:
    return {
        bstack11l11ll_opy_ (u"ࠫࡸࡺࡡࡵࡷࡶࠫጅ"): bstack11l11ll_opy_ (u"ࠬ࡫ࡲࡳࡱࡵࠫጆ"),
        bstack11l11ll_opy_ (u"࠭࡭ࡦࡵࡶࡥ࡬࡫ࠧጇ"): bstack11l11ll_opy_ (u"ࠧࡃࡷ࡬ࡰࡩࠦࡣࡳࡧࡤࡸ࡮ࡵ࡮ࠡࡪࡤࡨࠥ࡬ࡡࡪ࡮ࡨࡨ࠳࠭ገ")
    }
  data = {bstack11l11ll_opy_ (u"ࠨࡧࡱࡨ࡙࡯࡭ࡦࠩጉ"): bstack11ll1llll_opy_()}
  headers = {
      bstack11l11ll_opy_ (u"ࠩࡄࡹࡹ࡮࡯ࡳ࡫ࡽࡥࡹ࡯࡯࡯ࠩጊ"): bstack11l11ll_opy_ (u"ࠪࡆࡪࡧࡲࡦࡴࠣࠫጋ") + os.getenv(bstack11l11ll_opy_ (u"ࠦࡇ࡙࡟ࡂ࠳࠴࡝ࡤࡐࡗࡕࠤጌ")),
      bstack11l11ll_opy_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫግ"): bstack11l11ll_opy_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳࡯ࡹ࡯࡯ࠩጎ")
  }
  response = bstack1l11l1l11_opy_(bstack11l11ll_opy_ (u"ࠧࡑࡗࡗࠫጏ"), bstack11l111l1l1_opy_ + bstack11l11ll_opy_ (u"ࠨ࠱ࡷࡩࡸࡺ࡟ࡳࡷࡱࡷ࠴ࡹࡴࡰࡲࠪጐ"), data, { bstack11l11ll_opy_ (u"ࠩ࡫ࡩࡦࡪࡥࡳࡵࠪ጑"): headers })
  try:
    if response.status_code == 200:
      logger.info(bstack11l11ll_opy_ (u"ࠥࡆࡷࡵࡷࡴࡧࡵࡗࡹࡧࡣ࡬ࠢࡄࡧࡨ࡫ࡳࡴ࡫ࡥ࡭ࡱ࡯ࡴࡺࠢࡄࡹࡹࡵ࡭ࡢࡶ࡬ࡳࡳࠦࡔࡦࡵࡷࠤࡗࡻ࡮ࠡ࡯ࡤࡶࡰ࡫ࡤࠡࡣࡶࠤࡨࡵ࡭ࡱ࡮ࡨࡸࡪࡪࠠࡢࡶࠣࠦጒ") + datetime.utcnow().isoformat() + bstack11l11ll_opy_ (u"ࠫ࡟࠭ጓ"))
      return {bstack11l11ll_opy_ (u"ࠬࡹࡴࡢࡶࡸࡷࠬጔ"): bstack11l11ll_opy_ (u"࠭ࡳࡶࡥࡦࡩࡸࡹࠧጕ"), bstack11l11ll_opy_ (u"ࠧ࡮ࡧࡶࡷࡦ࡭ࡥࠨ጖"): bstack11l11ll_opy_ (u"ࠨࠩ጗")}
    else:
      response.raise_for_status()
  except requests.RequestException as error:
    logger.error(bstack11l11ll_opy_ (u"ࠤࡈࡼࡨ࡫ࡰࡵ࡫ࡲࡲࠥࡽࡨࡪ࡮ࡨࠤࡲࡧࡲ࡬࡫ࡱ࡫ࠥࡩ࡯࡮ࡲ࡯ࡩࡹ࡯࡯࡯ࠢࡲࡪࠥࡈࡲࡰࡹࡶࡩࡷ࡙ࡴࡢࡥ࡮ࠤࡆࡩࡣࡦࡵࡶ࡭ࡧ࡯࡬ࡪࡶࡼࠤࡆࡻࡴࡰ࡯ࡤࡸ࡮ࡵ࡮ࠡࡖࡨࡷࡹࠦࡒࡶࡰ࠽ࠤࠧጘ") + str(error))
    return {
        bstack11l11ll_opy_ (u"ࠪࡷࡹࡧࡴࡶࡵࠪጙ"): bstack11l11ll_opy_ (u"ࠫࡪࡸࡲࡰࡴࠪጚ"),
        bstack11l11ll_opy_ (u"ࠬࡳࡥࡴࡵࡤ࡫ࡪ࠭ጛ"): str(error)
    }
def bstack11l11lll1_opy_(caps, options):
  try:
    bstack11l11l111l_opy_ = caps.get(bstack11l11ll_opy_ (u"࠭ࡢࡴࡶࡤࡧࡰࡀ࡯ࡱࡶ࡬ࡳࡳࡹࠧጜ"), {}).get(bstack11l11ll_opy_ (u"ࠧࡥࡧࡹ࡭ࡨ࡫ࡎࡢ࡯ࡨࠫጝ"), caps.get(bstack11l11ll_opy_ (u"ࠨࡦࡨࡺ࡮ࡩࡥࠨጞ"), bstack11l11ll_opy_ (u"ࠩࠪጟ")))
    if bstack11l11l111l_opy_:
      logger.warn(bstack11l11ll_opy_ (u"ࠥࡅࡨࡩࡥࡴࡵ࡬ࡦ࡮ࡲࡩࡵࡻࠣࡅࡺࡺ࡯࡮ࡣࡷ࡭ࡴࡴࠠࡸ࡫࡯ࡰࠥࡸࡵ࡯ࠢࡲࡲࡱࡿࠠࡰࡰࠣࡈࡪࡹ࡫ࡵࡱࡳࠤࡧࡸ࡯ࡸࡵࡨࡶࡸ࠴ࠢጠ"))
      return False
    browser = caps.get(bstack11l11ll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡓࡧ࡭ࡦࠩጡ"), bstack11l11ll_opy_ (u"ࠬ࠭ጢ")).lower()
    if browser != bstack11l11ll_opy_ (u"࠭ࡣࡩࡴࡲࡱࡪ࠭ጣ"):
      logger.warn(bstack11l11ll_opy_ (u"ࠢࡂࡥࡦࡩࡸࡹࡩࡣ࡫࡯࡭ࡹࡿࠠࡂࡷࡷࡳࡲࡧࡴࡪࡱࡱࠤࡼ࡯࡬࡭ࠢࡵࡹࡳࠦ࡯࡯࡮ࡼࠤࡴࡴࠠࡄࡪࡵࡳࡲ࡫ࠠࡣࡴࡲࡻࡸ࡫ࡲࡴ࠰ࠥጤ"))
      return False
    browser_version = caps.get(bstack11l11ll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡘࡨࡶࡸ࡯࡯࡯ࠩጥ"), caps.get(bstack11l11ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡢࡺࡪࡸࡳࡪࡱࡱࠫጦ")))
    if browser_version and browser_version != bstack11l11ll_opy_ (u"ࠪࡰࡦࡺࡥࡴࡶࠪጧ") and int(browser_version) <= 94:
      logger.warn(bstack11l11ll_opy_ (u"ࠦࡆࡩࡣࡦࡵࡶ࡭ࡧ࡯࡬ࡪࡶࡼࠤࡆࡻࡴࡰ࡯ࡤࡸ࡮ࡵ࡮ࠡࡹ࡬ࡰࡱࠦࡲࡶࡰࠣࡳࡳࡲࡹࠡࡱࡱࠤࡈ࡮ࡲࡰ࡯ࡨࠤࡧࡸ࡯ࡸࡵࡨࡶࠥࡼࡥࡳࡵ࡬ࡳࡳࠦࡧࡳࡧࡤࡸࡪࡸࠠࡵࡪࡤࡲࠥ࠿࠴࠯ࠤጨ"))
      return False
    if not options is None:
      bstack11l11l11ll_opy_ = options.to_capabilities().get(bstack11l11ll_opy_ (u"ࠬ࡭࡯ࡰࡩ࠽ࡧ࡭ࡸ࡯࡮ࡧࡒࡴࡹ࡯࡯࡯ࡵࠪጩ"), {})
      if bstack11l11ll_opy_ (u"࠭࠭࠮ࡪࡨࡥࡩࡲࡥࡴࡵࠪጪ") in bstack11l11l11ll_opy_.get(bstack11l11ll_opy_ (u"ࠧࡢࡴࡪࡷࠬጫ"), []):
        logger.warn(bstack11l11ll_opy_ (u"ࠣࡃࡦࡧࡪࡹࡳࡪࡤ࡬ࡰ࡮ࡺࡹࠡࡃࡸࡸࡴࡳࡡࡵ࡫ࡲࡲࠥࡽࡩ࡭࡮ࠣࡲࡴࡺࠠࡳࡷࡱࠤࡴࡴࠠ࡭ࡧࡪࡥࡨࡿࠠࡩࡧࡤࡨࡱ࡫ࡳࡴࠢࡰࡳࡩ࡫࠮ࠡࡕࡺ࡭ࡹࡩࡨࠡࡶࡲࠤࡳ࡫ࡷࠡࡪࡨࡥࡩࡲࡥࡴࡵࠣࡱࡴࡪࡥࠡࡱࡵࠤࡦࡼ࡯ࡪࡦࠣࡹࡸ࡯࡮ࡨࠢ࡫ࡩࡦࡪ࡬ࡦࡵࡶࠤࡲࡵࡤࡦ࠰ࠥጬ"))
        return False
    return True
  except Exception as error:
    logger.debug(bstack11l11ll_opy_ (u"ࠤࡈࡼࡨ࡫ࡰࡵ࡫ࡲࡲࠥ࡯࡮ࠡࡸࡤࡰ࡮ࡪࡡࡵࡧࠣࡥ࠶࠷ࡹࠡࡵࡸࡴࡵࡵࡲࡵࠢ࠽ࠦጭ") + str(error))
    return False
def set_capabilities(caps, config):
  try:
    bstack11l111ll11_opy_ = config.get(bstack11l11ll_opy_ (u"ࠪࡥࡨࡩࡥࡴࡵ࡬ࡦ࡮ࡲࡩࡵࡻࡒࡴࡹ࡯࡯࡯ࡵࠪጮ"), {})
    bstack11l111ll11_opy_[bstack11l11ll_opy_ (u"ࠫࡦࡻࡴࡩࡖࡲ࡯ࡪࡴࠧጯ")] = os.getenv(bstack11l11ll_opy_ (u"ࠬࡈࡓࡠࡃ࠴࠵࡞ࡥࡊࡘࡖࠪጰ"))
    bstack11l11l1ll1_opy_ = json.loads(os.getenv(bstack11l11ll_opy_ (u"࠭ࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤ࡚ࡅࡔࡖࡢࡅࡈࡉࡅࡔࡕࡌࡆࡎࡒࡉࡕ࡛ࡢࡇࡔࡔࡆࡊࡉࡘࡖࡆ࡚ࡉࡐࡐࡢ࡝ࡒࡒࠧጱ"), bstack11l11ll_opy_ (u"ࠧࡼࡿࠪጲ"))).get(bstack11l11ll_opy_ (u"ࠨࡵࡦࡥࡳࡴࡥࡳࡘࡨࡶࡸ࡯࡯࡯ࠩጳ"))
    caps[bstack11l11ll_opy_ (u"ࠩࡤࡧࡨ࡫ࡳࡴ࡫ࡥ࡭ࡱ࡯ࡴࡺࠩጴ")] = True
    if bstack11l11ll_opy_ (u"ࠪࡦࡸࡺࡡࡤ࡭࠽ࡳࡵࡺࡩࡰࡰࡶࠫጵ") in caps:
      caps[bstack11l11ll_opy_ (u"ࠫࡧࡹࡴࡢࡥ࡮࠾ࡴࡶࡴࡪࡱࡱࡷࠬጶ")][bstack11l11ll_opy_ (u"ࠬࡧࡣࡤࡧࡶࡷ࡮ࡨࡩ࡭࡫ࡷࡽࡔࡶࡴࡪࡱࡱࡷࠬጷ")] = bstack11l111ll11_opy_
      caps[bstack11l11ll_opy_ (u"࠭ࡢࡴࡶࡤࡧࡰࡀ࡯ࡱࡶ࡬ࡳࡳࡹࠧጸ")][bstack11l11ll_opy_ (u"ࠧࡢࡥࡦࡩࡸࡹࡩࡣ࡫࡯࡭ࡹࡿࡏࡱࡶ࡬ࡳࡳࡹࠧጹ")][bstack11l11ll_opy_ (u"ࠨࡵࡦࡥࡳࡴࡥࡳࡘࡨࡶࡸ࡯࡯࡯ࠩጺ")] = bstack11l11l1ll1_opy_
    else:
      caps[bstack11l11ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫࠯ࡣࡦࡧࡪࡹࡳࡪࡤ࡬ࡰ࡮ࡺࡹࡐࡲࡷ࡭ࡴࡴࡳࠨጻ")] = bstack11l111ll11_opy_
      caps[bstack11l11ll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬࠰ࡤࡧࡨ࡫ࡳࡴ࡫ࡥ࡭ࡱ࡯ࡴࡺࡑࡳࡸ࡮ࡵ࡮ࡴࠩጼ")][bstack11l11ll_opy_ (u"ࠫࡸࡩࡡ࡯ࡰࡨࡶ࡛࡫ࡲࡴ࡫ࡲࡲࠬጽ")] = bstack11l11l1ll1_opy_
  except Exception as error:
    logger.debug(bstack11l11ll_opy_ (u"ࠧࡋࡸࡤࡧࡳࡸ࡮ࡵ࡮ࠡࡹ࡫࡭ࡱ࡫ࠠࡴࡧࡷࡸ࡮ࡴࡧࠡࡃࡦࡧࡪࡹࡳࡪࡤ࡬ࡰ࡮ࡺࡹࠡࡃࡸࡸࡴࡳࡡࡵ࡫ࡲࡲࠥࡩࡡࡱࡣࡥ࡭ࡱ࡯ࡴࡪࡧࡶ࠲ࠥࡋࡲࡳࡱࡵ࠾ࠥࠨጾ") +  str(error))
def bstack11l111l111_opy_(driver, bstack11l111l11l_opy_):
  try:
    session = driver.session_id
    if session:
      bstack11l111ll1l_opy_ = True
      current_url = driver.current_url
      try:
        url = urlparse(current_url)
      except Exception as e:
        bstack11l111ll1l_opy_ = False
      bstack11l111ll1l_opy_ = url.scheme in [bstack11l11ll_opy_ (u"ࠨࡨࡵࡶࡳࠦጿ"), bstack11l11ll_opy_ (u"ࠢࡩࡶࡷࡴࡸࠨፀ")]
      if bstack11l111ll1l_opy_:
        if bstack11l111l11l_opy_:
          logger.info(bstack11l11ll_opy_ (u"ࠣࡕࡨࡸࡺࡶࠠࡧࡱࡵࠤࡆࡩࡣࡦࡵࡶ࡭ࡧ࡯࡬ࡪࡶࡼࠤࡹ࡫ࡳࡵ࡫ࡱ࡫ࠥ࡮ࡡࡴࠢࡶࡸࡦࡸࡴࡦࡦ࠱ࠤࡆࡻࡴࡰ࡯ࡤࡸࡪࠦࡴࡦࡵࡷࠤࡨࡧࡳࡦࠢࡨࡼࡪࡩࡵࡵ࡫ࡲࡲࠥࡽࡩ࡭࡮ࠣࡦࡪ࡭ࡩ࡯ࠢࡰࡳࡲ࡫࡮ࡵࡣࡵ࡭ࡱࡿ࠮ࠣፁ"))
          driver.execute_async_script(bstack11l11ll_opy_ (u"ࠤࠥࠦࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡩ࡯࡯ࡵࡷࠤࡨࡧ࡬࡭ࡤࡤࡧࡰࠦ࠽ࠡࡣࡵ࡫ࡺࡳࡥ࡯ࡶࡶ࡟ࡦࡸࡧࡶ࡯ࡨࡲࡹࡹ࠮࡭ࡧࡱ࡫ࡹ࡮ࠠ࠮ࠢ࠴ࡡࡀࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡣࡰࡰࡶࡸࠥ࡬࡮ࠡ࠿ࠣࠬ࠮ࠦ࠽࠿ࠢࡾࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࡹ࡬ࡲࡩࡵࡷ࠯ࡣࡧࡨࡊࡼࡥ࡯ࡶࡏ࡭ࡸࡺࡥ࡯ࡧࡵࠬࠬࡇ࠱࠲࡛ࡢࡘࡆࡖ࡟ࡔࡖࡄࡖ࡙ࡋࡄࠨ࠮ࠣࡪࡳ࠸ࠩ࠼ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡣࡰࡰࡶࡸࠥ࡫ࠠ࠾ࠢࡱࡩࡼࠦࡃࡶࡵࡷࡳࡲࡋࡶࡦࡰࡷࠬࠬࡇ࠱࠲࡛ࡢࡊࡔࡘࡃࡆࡡࡖࡘࡆࡘࡔࠨࠫ࠾ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࡹ࡬ࡲࡩࡵࡷ࠯ࡦ࡬ࡷࡵࡧࡴࡤࡪࡈࡺࡪࡴࡴࠩࡧࠬ࠿ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࢃ࠻ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࡥࡲࡲࡸࡺࠠࡧࡰ࠵ࠤࡂࠦࠨࠪࠢࡀࡂࠥࢁࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡼ࡯࡮ࡥࡱࡺ࠲ࡷ࡫࡭ࡰࡸࡨࡉࡻ࡫࡮ࡵࡎ࡬ࡷࡹ࡫࡮ࡦࡴࠫࠫࡆ࠷࠱࡚ࡡࡗࡅࡕࡥࡓࡕࡃࡕࡘࡊࡊࠧ࠭ࠢࡩࡲ࠮ࡁࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡨࡧ࡬࡭ࡤࡤࡧࡰ࠮ࠩ࠼ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࢀࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤ࡫ࡴࠨࠪ࠽ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠢࠣࠤፂ"))
          logger.info(bstack11l11ll_opy_ (u"ࠥࡅࡺࡺ࡯࡮ࡣࡷࡩࠥࡺࡥࡴࡶࠣࡧࡦࡹࡥࠡࡧࡻࡩࡨࡻࡴࡪࡱࡱࠤ࡭ࡧࡳࠡࡵࡷࡥࡷࡺࡥࡥ࠰ࠥፃ"))
        else:
          driver.execute_script(bstack11l11ll_opy_ (u"ࠦࠧࠨࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࡤࡱࡱࡷࡹࠦࡥࠡ࠿ࠣࡲࡪࡽࠠࡄࡷࡶࡸࡴࡳࡅࡷࡧࡱࡸ࠭࠭ࡁ࠲࠳࡜ࡣࡋࡕࡒࡄࡇࡢࡗ࡙ࡕࡐࠨࠫ࠾ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡼ࡯࡮ࡥࡱࡺ࠲ࡩ࡯ࡳࡱࡣࡷࡧ࡭ࡋࡶࡦࡰࡷࠬࡪ࠯࠻ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠧࠨࠢፄ"))
      return bstack11l111l11l_opy_
  except Exception as e:
    logger.error(bstack11l11ll_opy_ (u"ࠧࡋࡸࡤࡧࡳࡸ࡮ࡵ࡮ࠡ࡫ࡱࠤࡸࡺࡡࡳࡶ࡬ࡲ࡬ࠦࡡࡤࡥࡨࡷࡸ࡯ࡢࡪ࡮࡬ࡸࡾࠦࡡࡶࡶࡲࡱࡦࡺࡩࡰࡰࠣࡷࡨࡧ࡮ࠡࡨࡲࡶࠥࡺࡨࡪࡵࠣࡸࡪࡹࡴࠡࡥࡤࡷࡪࡀࠠࠣፅ") + str(e))
    return False
def bstack11l111l1ll_opy_(driver, item):
  try:
    bstack11l111llll_opy_ = [item.cls.__name__] if not item.cls is None else []
    bstack11l11l1111_opy_ = {
        bstack11l11ll_opy_ (u"ࠨࡳࡢࡸࡨࡖࡪࡹࡵ࡭ࡶࡶࠦፆ"): True,
        bstack11l11ll_opy_ (u"ࠢࡵࡧࡶࡸࡉ࡫ࡴࡢ࡫࡯ࡷࠧፇ"): {
            bstack11l11ll_opy_ (u"ࠣࡰࡤࡱࡪࠨፈ"): item.name,
            bstack11l11ll_opy_ (u"ࠤࡷࡩࡸࡺࡒࡶࡰࡌࡨࠧፉ"): os.environ.get(bstack11l11ll_opy_ (u"ࠪࡆࡘࡥࡁ࠲࠳࡜ࡣ࡙ࡋࡓࡕࡡࡕ࡙ࡓࡥࡉࡅࠩፊ")),
            bstack11l11ll_opy_ (u"ࠦ࡫࡯࡬ࡦࡒࡤࡸ࡭ࠨፋ"): str(item.path),
            bstack11l11ll_opy_ (u"ࠧࡹࡣࡰࡲࡨࡐ࡮ࡹࡴࠣፌ"): [item.module.__name__, *bstack11l111llll_opy_, item.name],
        },
        bstack11l11ll_opy_ (u"ࠨࡰ࡭ࡣࡷࡪࡴࡸ࡭ࠣፍ"): _11l11ll11l_opy_(driver)
    }
    driver.execute_async_script(bstack11l11ll_opy_ (u"ࠢࠣࠤࠍࠤࠥࠦࠠࠡࠢࠣࠤࡨࡵ࡮ࡴࡶࠣࡧࡦࡲ࡬ࡣࡣࡦ࡯ࠥࡃࠠࡢࡴࡪࡹࡲ࡫࡮ࡵࡵ࡞ࡥࡷ࡭ࡵ࡮ࡧࡱࡸࡸ࠴࡬ࡦࡰࡪࡸ࡭ࠦ࠭ࠡ࠳ࡠ࠿ࠏࠦࠠࠡࠢࠣࠤࠥࠦࡴࡩ࡫ࡶ࠲ࡷ࡫ࡳࠡ࠿ࠣࡲࡺࡲ࡬࠼ࠌࠣࠤࠥࠦࠠࠡࠢࠣ࡭࡫ࠦࠨࡢࡴࡪࡹࡲ࡫࡮ࡵࡵ࡞࠴ࡢ࠴ࡳࡢࡸࡨࡖࡪࡹࡵ࡭ࡶࡶ࠭ࠥࢁࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡽࡩ࡯ࡦࡲࡻ࠳ࡧࡤࡥࡇࡹࡩࡳࡺࡌࡪࡵࡷࡩࡳ࡫ࡲࠩࠩࡄ࠵࠶࡟࡟ࡕࡃࡓࡣ࡙ࡘࡁࡏࡕࡓࡓࡗ࡚ࡅࡓࠩ࠯ࠤ࠭࡫ࡶࡦࡰࡷ࠭ࠥࡃ࠾ࠡࡽࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡽࡩ࡯ࡦࡲࡻ࠳ࡺࡡࡱࡖࡵࡥࡳࡹࡰࡰࡴࡷࡩࡷࡊࡡࡵࡣࠣࡁࠥ࡫ࡶࡦࡰࡷ࠲ࡩ࡫ࡴࡢ࡫࡯࠿ࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࡵࡪ࡬ࡷ࠳ࡸࡥࡴࠢࡀࠤࡼ࡯࡮ࡥࡱࡺ࠲ࡹࡧࡰࡕࡴࡤࡲࡸࡶ࡯ࡳࡶࡨࡶࡉࡧࡴࡢ࠽ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡩࡡ࡭࡮ࡥࡥࡨࡱࠨࡵࡪ࡬ࡷ࠳ࡸࡥࡴࠫ࠾ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࢀ࠭ࡀࠐࠠࠡࠢࠣࠤࠥࠦࠠࡾࠌࠣࠤࠥࠦࠠࠡࠢࠣࡧࡴࡴࡳࡵࠢࡨࠤࡂࠦ࡮ࡦࡹࠣࡇࡺࡹࡴࡰ࡯ࡈࡺࡪࡴࡴࠩࠩࡄ࠵࠶࡟࡟ࡕࡇࡖࡘࡤࡋࡎࡅࠩ࠯ࠤࢀࠦࡤࡦࡶࡤ࡭ࡱࡀࠠࡢࡴࡪࡹࡲ࡫࡮ࡵࡵ࡞࠴ࡢࠦࡽࠪ࠽ࠍࠤࠥࠦࠠࠡࠢࠣࠤࡼ࡯࡮ࡥࡱࡺ࠲ࡩ࡯ࡳࡱࡣࡷࡧ࡭ࡋࡶࡦࡰࡷࠬࡪ࠯࠻ࠋࠢࠣࠤࠥࠦࠠࠡࠢ࡬ࡪࠥ࠮ࠡࡢࡴࡪࡹࡲ࡫࡮ࡵࡵ࡞࠴ࡢ࠴ࡳࡢࡸࡨࡖࡪࡹࡵ࡭ࡶࡶ࠭ࠥࢁࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡩࡡ࡭࡮ࡥࡥࡨࡱࠨࠪ࠽ࠍࠤࠥࠦࠠࠡࠢࠣࠤࢂࠐࠠࠡࠢࠣࠦࠧࠨፎ"), bstack11l11l1111_opy_)
    logger.info(bstack11l11ll_opy_ (u"ࠣࡃࡦࡧࡪࡹࡳࡪࡤ࡬ࡰ࡮ࡺࡹࠡࡶࡨࡷࡹ࡯࡮ࡨࠢࡩࡳࡷࠦࡴࡩ࡫ࡶࠤࡹ࡫ࡳࡵࠢࡦࡥࡸ࡫ࠠࡩࡣࡶࠤࡪࡴࡤࡦࡦ࠱ࠦፏ"))
  except Exception as bstack11l11l1l11_opy_:
    logger.error(bstack11l11ll_opy_ (u"ࠤࡄࡧࡨ࡫ࡳࡴ࡫ࡥ࡭ࡱ࡯ࡴࡺࠢࡵࡩࡸࡻ࡬ࡵࡵࠣࡧࡴࡻ࡬ࡥࠢࡱࡳࡹࠦࡢࡦࠢࡳࡶࡴࡩࡥࡴࡵࡨࡨࠥ࡬࡯ࡳࠢࡷ࡬ࡪࠦࡴࡦࡵࡷࠤࡨࡧࡳࡦ࠼ࠣࠦፐ") + item.path + bstack11l11ll_opy_ (u"ࠥࠤࡊࡸࡲࡰࡴࠣ࠾ࠧፑ") + str(bstack11l11l1l11_opy_))