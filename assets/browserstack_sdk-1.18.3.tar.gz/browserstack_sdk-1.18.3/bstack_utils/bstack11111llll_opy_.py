# coding: UTF-8
import sys
bstack111llll_opy_ = sys.version_info [0] == 2
bstack1llllll_opy_ = 2048
bstack11ll1l_opy_ = 7
def bstack11l11ll_opy_ (bstack1l1ll11_opy_):
    global bstack1l11l_opy_
    bstack1l11ll_opy_ = ord (bstack1l1ll11_opy_ [-1])
    bstack111ll1_opy_ = bstack1l1ll11_opy_ [:-1]
    bstack1lllll_opy_ = bstack1l11ll_opy_ % len (bstack111ll1_opy_)
    bstack11l1l1l_opy_ = bstack111ll1_opy_ [:bstack1lllll_opy_] + bstack111ll1_opy_ [bstack1lllll_opy_:]
    if bstack111llll_opy_:
        bstack1ll1l_opy_ = unicode () .join ([unichr (ord (char) - bstack1llllll_opy_ - (bstack1l11l1_opy_ + bstack1l11ll_opy_) % bstack11ll1l_opy_) for bstack1l11l1_opy_, char in enumerate (bstack11l1l1l_opy_)])
    else:
        bstack1ll1l_opy_ = str () .join ([chr (ord (char) - bstack1llllll_opy_ - (bstack1l11l1_opy_ + bstack1l11ll_opy_) % bstack11ll1l_opy_) for bstack1l11l1_opy_, char in enumerate (bstack11l1l1l_opy_)])
    return eval (bstack1ll1l_opy_)
import re
from bstack_utils.bstack1ll11111ll_opy_ import bstack1l1lllll11_opy_
def bstack1l111llll1_opy_(fixture_name):
    if fixture_name.startswith(bstack11l11ll_opy_ (u"ࠧࡠࡺࡸࡲ࡮ࡺ࡟ࡴࡧࡷࡹࡵࡥࡦࡶࡰࡦࡸ࡮ࡵ࡮ࡠࡨ࡬ࡼࡹࡻࡲࡦࠩူ")):
        return bstack11l11ll_opy_ (u"ࠨࡵࡨࡸࡺࡶ࠭ࡧࡷࡱࡧࡹ࡯࡯࡯ࠩေ")
    elif fixture_name.startswith(bstack11l11ll_opy_ (u"ࠩࡢࡼࡺࡴࡩࡵࡡࡶࡩࡹࡻࡰࡠ࡯ࡲࡨࡺࡲࡥࡠࡨ࡬ࡼࡹࡻࡲࡦࠩဲ")):
        return bstack11l11ll_opy_ (u"ࠪࡷࡪࡺࡵࡱ࠯ࡰࡳࡩࡻ࡬ࡦࠩဳ")
    elif fixture_name.startswith(bstack11l11ll_opy_ (u"ࠫࡤࡾࡵ࡯࡫ࡷࡣࡹ࡫ࡡࡳࡦࡲࡻࡳࡥࡦࡶࡰࡦࡸ࡮ࡵ࡮ࡠࡨ࡬ࡼࡹࡻࡲࡦࠩဴ")):
        return bstack11l11ll_opy_ (u"ࠬࡺࡥࡢࡴࡧࡳࡼࡴ࠭ࡧࡷࡱࡧࡹ࡯࡯࡯ࠩဵ")
    elif fixture_name.startswith(bstack11l11ll_opy_ (u"࠭࡟ࡹࡷࡱ࡭ࡹࡥࡴࡦࡣࡵࡨࡴࡽ࡮ࡠࡨࡸࡲࡨࡺࡩࡰࡰࡢࡪ࡮ࡾࡴࡶࡴࡨࠫံ")):
        return bstack11l11ll_opy_ (u"ࠧࡵࡧࡤࡶࡩࡵࡷ࡯࠯ࡰࡳࡩࡻ࡬ࡦ့ࠩ")
def bstack1l111lll11_opy_(fixture_name):
    return bool(re.match(bstack11l11ll_opy_ (u"ࠨࡠࡢࡼࡺࡴࡩࡵࡡࠫࡷࡪࡺࡵࡱࡾࡷࡩࡦࡸࡤࡰࡹࡱ࠭ࡤ࠮ࡦࡶࡰࡦࡸ࡮ࡵ࡮ࡽ࡯ࡲࡨࡺࡲࡥࠪࡡࡩ࡭ࡽࡺࡵࡳࡧࡢ࠲࠯࠭း"), fixture_name))
def bstack1l11l1111l_opy_(fixture_name):
    return bool(re.match(bstack11l11ll_opy_ (u"ࠩࡡࡣࡽࡻ࡮ࡪࡶࡢࠬࡸ࡫ࡴࡶࡲࡿࡸࡪࡧࡲࡥࡱࡺࡲ࠮ࡥ࡭ࡰࡦࡸࡰࡪࡥࡦࡪࡺࡷࡹࡷ࡫࡟࠯္ࠬࠪ"), fixture_name))
def bstack1l11l11111_opy_(fixture_name):
    return bool(re.match(bstack11l11ll_opy_ (u"ࠪࡢࡤࡾࡵ࡯࡫ࡷࡣ࠭ࡹࡥࡵࡷࡳࢀࡹ࡫ࡡࡳࡦࡲࡻࡳ࠯࡟ࡤ࡮ࡤࡷࡸࡥࡦࡪࡺࡷࡹࡷ࡫࡟࠯်ࠬࠪ"), fixture_name))
def bstack1l111lll1l_opy_(fixture_name):
    if fixture_name.startswith(bstack11l11ll_opy_ (u"ࠫࡤࡾࡵ࡯࡫ࡷࡣࡸ࡫ࡴࡶࡲࡢࡪࡺࡴࡣࡵ࡫ࡲࡲࡤ࡬ࡩࡹࡶࡸࡶࡪ࠭ျ")):
        return bstack11l11ll_opy_ (u"ࠬࡹࡥࡵࡷࡳ࠱࡫ࡻ࡮ࡤࡶ࡬ࡳࡳ࠭ြ"), bstack11l11ll_opy_ (u"࠭ࡂࡆࡈࡒࡖࡊࡥࡅࡂࡅࡋࠫွ")
    elif fixture_name.startswith(bstack11l11ll_opy_ (u"ࠧࡠࡺࡸࡲ࡮ࡺ࡟ࡴࡧࡷࡹࡵࡥ࡭ࡰࡦࡸࡰࡪࡥࡦࡪࡺࡷࡹࡷ࡫ࠧှ")):
        return bstack11l11ll_opy_ (u"ࠨࡵࡨࡸࡺࡶ࠭࡮ࡱࡧࡹࡱ࡫ࠧဿ"), bstack11l11ll_opy_ (u"ࠩࡅࡉࡋࡕࡒࡆࡡࡄࡐࡑ࠭၀")
    elif fixture_name.startswith(bstack11l11ll_opy_ (u"ࠪࡣࡽࡻ࡮ࡪࡶࡢࡸࡪࡧࡲࡥࡱࡺࡲࡤ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴ࡟ࡧ࡫ࡻࡸࡺࡸࡥࠨ၁")):
        return bstack11l11ll_opy_ (u"ࠫࡹ࡫ࡡࡳࡦࡲࡻࡳ࠳ࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠨ၂"), bstack11l11ll_opy_ (u"ࠬࡇࡆࡕࡇࡕࡣࡊࡇࡃࡉࠩ၃")
    elif fixture_name.startswith(bstack11l11ll_opy_ (u"࠭࡟ࡹࡷࡱ࡭ࡹࡥࡴࡦࡣࡵࡨࡴࡽ࡮ࡠ࡯ࡲࡨࡺࡲࡥࡠࡨ࡬ࡼࡹࡻࡲࡦࠩ၄")):
        return bstack11l11ll_opy_ (u"ࠧࡵࡧࡤࡶࡩࡵࡷ࡯࠯ࡰࡳࡩࡻ࡬ࡦࠩ၅"), bstack11l11ll_opy_ (u"ࠨࡃࡉࡘࡊࡘ࡟ࡂࡎࡏࠫ၆")
    return None, None
def bstack1l111ll11l_opy_(hook_name):
    if hook_name in [bstack11l11ll_opy_ (u"ࠩࡶࡩࡹࡻࡰࠨ၇"), bstack11l11ll_opy_ (u"ࠪࡸࡪࡧࡲࡥࡱࡺࡲࠬ၈")]:
        return hook_name.capitalize()
    return hook_name
def bstack1l111lllll_opy_(hook_name):
    if hook_name in [bstack11l11ll_opy_ (u"ࠫࡸ࡫ࡴࡶࡲࡢࡪࡺࡴࡣࡵ࡫ࡲࡲࠬ၉"), bstack11l11ll_opy_ (u"ࠬࡹࡥࡵࡷࡳࡣࡲ࡫ࡴࡩࡱࡧࠫ၊")]:
        return bstack11l11ll_opy_ (u"࠭ࡂࡆࡈࡒࡖࡊࡥࡅࡂࡅࡋࠫ။")
    elif hook_name in [bstack11l11ll_opy_ (u"ࠧࡴࡧࡷࡹࡵࡥ࡭ࡰࡦࡸࡰࡪ࠭၌"), bstack11l11ll_opy_ (u"ࠨࡵࡨࡸࡺࡶ࡟ࡤ࡮ࡤࡷࡸ࠭၍")]:
        return bstack11l11ll_opy_ (u"ࠩࡅࡉࡋࡕࡒࡆࡡࡄࡐࡑ࠭၎")
    elif hook_name in [bstack11l11ll_opy_ (u"ࠪࡸࡪࡧࡲࡥࡱࡺࡲࡤ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠧ၏"), bstack11l11ll_opy_ (u"ࠫࡹ࡫ࡡࡳࡦࡲࡻࡳࡥ࡭ࡦࡶ࡫ࡳࡩ࠭ၐ")]:
        return bstack11l11ll_opy_ (u"ࠬࡇࡆࡕࡇࡕࡣࡊࡇࡃࡉࠩၑ")
    elif hook_name in [bstack11l11ll_opy_ (u"࠭ࡴࡦࡣࡵࡨࡴࡽ࡮ࡠ࡯ࡲࡨࡺࡲࡥࠨၒ"), bstack11l11ll_opy_ (u"ࠧࡵࡧࡤࡶࡩࡵࡷ࡯ࡡࡦࡰࡦࡹࡳࠨၓ")]:
        return bstack11l11ll_opy_ (u"ࠨࡃࡉࡘࡊࡘ࡟ࡂࡎࡏࠫၔ")
    return hook_name
def bstack1l111ll1l1_opy_(node, scenario):
    if hasattr(node, bstack11l11ll_opy_ (u"ࠩࡦࡥࡱࡲࡳࡱࡧࡦࠫၕ")):
        parts = node.nodeid.rsplit(bstack11l11ll_opy_ (u"ࠥ࡟ࠧၖ"))
        params = parts[-1]
        return bstack11l11ll_opy_ (u"ࠦࢀࢃࠠ࡜ࡽࢀࠦၗ").format(scenario.name, params)
    return scenario.name
def bstack1l11l111ll_opy_(node):
    try:
        examples = []
        if hasattr(node, bstack11l11ll_opy_ (u"ࠬࡩࡡ࡭࡮ࡶࡴࡪࡩࠧၘ")):
            examples = list(node.callspec.params[bstack11l11ll_opy_ (u"࠭࡟ࡱࡻࡷࡩࡸࡺ࡟ࡣࡦࡧࡣࡪࡾࡡ࡮ࡲ࡯ࡩࠬၙ")].values())
        return examples
    except:
        return []
def bstack1l111l1lll_opy_(feature, scenario):
    return list(feature.tags) + list(scenario.tags)
def bstack1l111ll1ll_opy_(report):
    try:
        status = bstack11l11ll_opy_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧၚ")
        if report.passed or (report.failed and hasattr(report, bstack11l11ll_opy_ (u"ࠣࡹࡤࡷࡽ࡬ࡡࡪ࡮ࠥၛ"))):
            status = bstack11l11ll_opy_ (u"ࠩࡳࡥࡸࡹࡥࡥࠩၜ")
        elif report.skipped:
            status = bstack11l11ll_opy_ (u"ࠪࡷࡰ࡯ࡰࡱࡧࡧࠫၝ")
        bstack1l1lllll11_opy_(status)
    except:
        pass
def bstack1lll1l1l1l_opy_(status):
    try:
        bstack1l111ll111_opy_ = bstack11l11ll_opy_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫၞ")
        if status == bstack11l11ll_opy_ (u"ࠬࡶࡡࡴࡵࡨࡨࠬၟ"):
            bstack1l111ll111_opy_ = bstack11l11ll_opy_ (u"࠭ࡰࡢࡵࡶࡩࡩ࠭ၠ")
        elif status == bstack11l11ll_opy_ (u"ࠧࡴ࡭࡬ࡴࡵ࡫ࡤࠨၡ"):
            bstack1l111ll111_opy_ = bstack11l11ll_opy_ (u"ࠨࡵ࡮࡭ࡵࡶࡥࡥࠩၢ")
        bstack1l1lllll11_opy_(bstack1l111ll111_opy_)
    except:
        pass
def bstack1l11l111l1_opy_(item=None, report=None, summary=None, extra=None):
    return