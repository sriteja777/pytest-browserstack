# coding: UTF-8
import sys
bstack1ll_opy_ = sys.version_info [0] == 2
bstack11ll_opy_ = 2048
bstack11l1ll_opy_ = 7
def bstack11l1111_opy_ (bstack1lll11_opy_):
    global bstack1lllll_opy_
    bstack1111lll_opy_ = ord (bstack1lll11_opy_ [-1])
    bstack1lll1l_opy_ = bstack1lll11_opy_ [:-1]
    bstack1llll1l_opy_ = bstack1111lll_opy_ % len (bstack1lll1l_opy_)
    bstack1l11_opy_ = bstack1lll1l_opy_ [:bstack1llll1l_opy_] + bstack1lll1l_opy_ [bstack1llll1l_opy_:]
    if bstack1ll_opy_:
        bstack1l1l1ll_opy_ = unicode () .join ([unichr (ord (char) - bstack11ll_opy_ - (bstack1l1l11_opy_ + bstack1111lll_opy_) % bstack11l1ll_opy_) for bstack1l1l11_opy_, char in enumerate (bstack1l11_opy_)])
    else:
        bstack1l1l1ll_opy_ = str () .join ([chr (ord (char) - bstack11ll_opy_ - (bstack1l1l11_opy_ + bstack1111lll_opy_) % bstack11l1ll_opy_) for bstack1l1l11_opy_, char in enumerate (bstack1l11_opy_)])
    return eval (bstack1l1l1ll_opy_)