# coding: UTF-8
import sys
bstack1ll_opy_ = sys.version_info [0] == 2
bstack11ll_opy_ = 2048
bstack11l1ll_opy_ = 7
def bstack11l1111_opy_ (bstack1lll11_opy_):
    global bstack1lllll_opy_
    bstack1111lll_opy_ = ord (bstack1lll11_opy_ [-1])
    bstack1lll1l_opy_ = bstack1lll11_opy_ [:-1]
    bstack1llll1l_opy_ = bstack1111lll_opy_ % len (bstack1lll1l_opy_)
    bstack1l11_opy_ = bstack1lll1l_opy_ [:bstack1llll1l_opy_] + bstack1lll1l_opy_ [bstack1llll1l_opy_:]
    if bstack1ll_opy_:
        bstack1l1l1ll_opy_ = unicode () .join ([unichr (ord (char) - bstack11ll_opy_ - (bstack1l1l11_opy_ + bstack1111lll_opy_) % bstack11l1ll_opy_) for bstack1l1l11_opy_, char in enumerate (bstack1l11_opy_)])
    else:
        bstack1l1l1ll_opy_ = str () .join ([chr (ord (char) - bstack11ll_opy_ - (bstack1l1l11_opy_ + bstack1111lll_opy_) % bstack11l1ll_opy_) for bstack1l1l11_opy_, char in enumerate (bstack1l11_opy_)])
    return eval (bstack1l1l1ll_opy_)
import datetime
import json
import logging
import os
import threading
from bstack_utils.helper import bstack1l1l1lllll_opy_, bstack1l1ll11lll_opy_, get_host_info, bstack1l1ll11l11_opy_, bstack1l1lllll11_opy_, bstack1l1ll1lll1_opy_, \
    bstack1l1ll111l1_opy_, bstack1l1ll111ll_opy_, bstack1lll1llll_opy_, bstack1l1lll111l_opy_, bstack1l1l1lll11_opy_, bstack1l1l1lll1l_opy_
from bstack_utils.bstack1l1ll1l1ll_opy_ import bstack1l1l1ll1ll_opy_
bstack1l1lllll1l_opy_ = [
    bstack11l1111_opy_ (u"ࠫࡑࡵࡧࡄࡴࡨࡥࡹ࡫ࡤࠨཆ"), bstack11l1111_opy_ (u"ࠬࡉࡂࡕࡕࡨࡷࡸ࡯࡯࡯ࡅࡵࡩࡦࡺࡥࡥࠩཇ"), bstack11l1111_opy_ (u"࠭ࡔࡦࡵࡷࡖࡺࡴࡆࡪࡰ࡬ࡷ࡭࡫ࡤࠨ཈"), bstack11l1111_opy_ (u"ࠧࡕࡧࡶࡸࡗࡻ࡮ࡔ࡭࡬ࡴࡵ࡫ࡤࠨཉ"),
    bstack11l1111_opy_ (u"ࠨࡊࡲࡳࡰࡘࡵ࡯ࡈ࡬ࡲ࡮ࡹࡨࡦࡦࠪཊ"), bstack11l1111_opy_ (u"ࠩࡗࡩࡸࡺࡒࡶࡰࡖࡸࡦࡸࡴࡦࡦࠪཋ"), bstack11l1111_opy_ (u"ࠪࡌࡴࡵ࡫ࡓࡷࡱࡗࡹࡧࡲࡵࡧࡧࠫཌ")
]
bstack1l1ll1l111_opy_ = bstack11l1111_opy_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡩ࡯࡭࡮ࡨࡧࡹࡵࡲ࠮ࡱࡥࡷࡪࡸࡶࡢࡤ࡬ࡰ࡮ࡺࡹ࠯ࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࠮ࡤࡱࡰࠫཌྷ")
logger = logging.getLogger(__name__)
class bstack11ll1l11l_opy_:
    bstack1l1ll1l1ll_opy_ = None
    bs_config = None
    @classmethod
    @bstack1l1l1lll1l_opy_(bstack1l1l1l1l1l_opy_=True)
    def launch(cls, bs_config, bstack1l1lll11ll_opy_):
        cls.bs_config = bs_config
        if not cls.bstack1l1lll1l1l_opy_():
            return
        cls.bstack1l1ll1l1ll_opy_ = bstack1l1l1ll1ll_opy_(cls.bstack1l1ll1ll1l_opy_)
        cls.bstack1l1ll1l1ll_opy_.start()
        bstack1l1lllllll_opy_ = bstack1l1ll11l11_opy_(bs_config)
        bstack1l1ll1ll11_opy_ = bstack1l1lllll11_opy_(bs_config)
        data = {
            bstack11l1111_opy_ (u"ࠬ࡬࡯ࡳ࡯ࡤࡸࠬཎ"): bstack11l1111_opy_ (u"࠭ࡪࡴࡱࡱࠫཏ"),
            bstack11l1111_opy_ (u"ࠧࡱࡴࡲ࡮ࡪࡩࡴࡠࡰࡤࡱࡪ࠭ཐ"): bs_config.get(bstack11l1111_opy_ (u"ࠨࡲࡵࡳ࡯࡫ࡣࡵࡐࡤࡱࡪ࠭ད"), bstack11l1111_opy_ (u"ࠩࠪདྷ")),
            bstack11l1111_opy_ (u"ࠪࡲࡦࡳࡥࠨན"): bs_config.get(bstack11l1111_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡑࡥࡲ࡫ࠧཔ"), os.path.basename(os.path.abspath(os.getcwd()))),
            bstack11l1111_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡣ࡮ࡪࡥ࡯ࡶ࡬ࡪ࡮࡫ࡲࠨཕ"): bs_config.get(bstack11l1111_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡎࡪࡥ࡯ࡶ࡬ࡪ࡮࡫ࡲࠨབ")),
            bstack11l1111_opy_ (u"ࠧࡥࡧࡶࡧࡷ࡯ࡰࡵ࡫ࡲࡲࠬབྷ"): bs_config.get(bstack11l1111_opy_ (u"ࠨࡤࡸ࡭ࡱࡪࡄࡦࡵࡦࡶ࡮ࡶࡴࡪࡱࡱࠫམ"), bstack11l1111_opy_ (u"ࠩࠪཙ")),
            bstack11l1111_opy_ (u"ࠪࡷࡹࡧࡲࡵࡡࡷ࡭ࡲ࡫ࠧཚ"): datetime.datetime.now().isoformat(),
            bstack11l1111_opy_ (u"ࠫࡹࡧࡧࡴࠩཛ"): bstack1l1ll1lll1_opy_(bs_config),
            bstack11l1111_opy_ (u"ࠬ࡮࡯ࡴࡶࡢ࡭ࡳ࡬࡯ࠨཛྷ"): get_host_info(),
            bstack11l1111_opy_ (u"࠭ࡣࡪࡡ࡬ࡲ࡫ࡵࠧཝ"): bstack1l1ll11lll_opy_(),
            bstack11l1111_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡥࡲࡶࡰࡢ࡭ࡩ࡫࡮ࡵ࡫ࡩ࡭ࡪࡸࠧཞ"): os.environ.get(bstack11l1111_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡃࡗࡌࡐࡉࡥࡒࡖࡐࡢࡍࡉࡋࡎࡕࡋࡉࡍࡊࡘࠧཟ")),
            bstack11l1111_opy_ (u"ࠩࡩࡥ࡮ࡲࡥࡥࡡࡷࡩࡸࡺࡳࡠࡴࡨࡶࡺࡴࠧའ"): os.environ.get(bstack11l1111_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡕࡉࡗ࡛ࡎࠨཡ"), False),
            bstack11l1111_opy_ (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲࡤࡩ࡯࡯ࡶࡵࡳࡱ࠭ར"): bstack1l1l1lllll_opy_(),
            bstack11l1111_opy_ (u"ࠬࡵࡢࡴࡧࡵࡺࡦࡨࡩ࡭࡫ࡷࡽࡤࡼࡥࡳࡵ࡬ࡳࡳ࠭ལ"): {
                bstack11l1111_opy_ (u"࠭ࡦࡳࡣࡰࡩࡼࡵࡲ࡬ࡐࡤࡱࡪ࠭ཤ"): bstack1l1lll11ll_opy_.get(bstack11l1111_opy_ (u"ࠧࡧࡴࡤࡱࡪࡽ࡯ࡳ࡭ࡢࡲࡦࡳࡥࠨཥ"), bstack11l1111_opy_ (u"ࠨࡒࡼࡸࡪࡹࡴࠨས")),
                bstack11l1111_opy_ (u"ࠩࡩࡶࡦࡳࡥࡸࡱࡵ࡯࡛࡫ࡲࡴ࡫ࡲࡲࠬཧ"): bstack1l1lll11ll_opy_.get(bstack11l1111_opy_ (u"ࠪࡪࡷࡧ࡭ࡦࡹࡲࡶࡰࡥࡶࡦࡴࡶ࡭ࡴࡴࠧཨ")),
                bstack11l1111_opy_ (u"ࠫࡸࡪ࡫ࡗࡧࡵࡷ࡮ࡵ࡮ࠨཀྵ"): bstack1l1lll11ll_opy_.get(bstack11l1111_opy_ (u"ࠬࡹࡤ࡬ࡡࡹࡩࡷࡹࡩࡰࡰࠪཪ"))
            }
        }
        config = {
            bstack11l1111_opy_ (u"࠭ࡡࡶࡶ࡫ࠫཫ"): (bstack1l1lllllll_opy_, bstack1l1ll1ll11_opy_),
            bstack11l1111_opy_ (u"ࠧࡩࡧࡤࡨࡪࡸࡳࠨཬ"): cls.default_headers()
        }
        response = bstack1lll1llll_opy_(bstack11l1111_opy_ (u"ࠨࡒࡒࡗ࡙࠭཭"), cls.request_url(bstack11l1111_opy_ (u"ࠩࡤࡴ࡮࠵ࡶ࠲࠱ࡥࡹ࡮ࡲࡤࡴࠩ཮")), data, config)
        if response.status_code != 200:
            os.environ[bstack11l1111_opy_ (u"ࠪࡆࡘࡥࡔࡆࡕࡗࡓࡕ࡙࡟ࡃࡗࡌࡐࡉࡥࡃࡐࡏࡓࡐࡊ࡚ࡅࡅࠩ཯")] = bstack11l1111_opy_ (u"ࠫ࡫ࡧ࡬ࡴࡧࠪ཰")
            os.environ[bstack11l1111_opy_ (u"ࠬࡈࡓࡠࡖࡈࡗ࡙ࡕࡐࡔࡡࡍཱ࡛࡙࠭")] = bstack11l1111_opy_ (u"࠭࡮ࡶ࡮࡯ིࠫ")
            os.environ[bstack11l1111_opy_ (u"ࠧࡃࡕࡢࡘࡊ࡙ࡔࡐࡒࡖࡣࡇ࡛ࡉࡍࡆࡢࡌࡆ࡙ࡈࡆࡆࡢࡍࡉཱི࠭")] = bstack11l1111_opy_ (u"ࠣࡰࡸࡰࡱࠨུ")
            os.environ[bstack11l1111_opy_ (u"ࠩࡅࡗࡤ࡚ࡅࡔࡖࡒࡔࡘࡥࡁࡍࡎࡒ࡛ࡤ࡙ࡃࡓࡇࡈࡒࡘࡎࡏࡕࡕཱུࠪ")] = bstack11l1111_opy_ (u"ࠥࡲࡺࡲ࡬ࠣྲྀ")
            bstack1l1l1l1ll1_opy_ = response.json()
            if bstack1l1l1l1ll1_opy_ and bstack1l1l1l1ll1_opy_[bstack11l1111_opy_ (u"ࠫࡲ࡫ࡳࡴࡣࡪࡩࠬཷ")]:
                error_message = bstack1l1l1l1ll1_opy_[bstack11l1111_opy_ (u"ࠬࡳࡥࡴࡵࡤ࡫ࡪ࠭ླྀ")]
                if bstack1l1l1l1ll1_opy_[bstack11l1111_opy_ (u"࠭ࡥࡳࡴࡲࡶ࡙ࡿࡰࡦࠩཹ")] == bstack11l1111_opy_ (u"ࠧࡆࡔࡕࡓࡗࡥࡉࡏࡘࡄࡐࡎࡊ࡟ࡄࡔࡈࡈࡊࡔࡔࡊࡃࡏࡗེࠬ"):
                    logger.error(error_message)
                elif bstack1l1l1l1ll1_opy_[bstack11l1111_opy_ (u"ࠨࡧࡵࡶࡴࡸࡔࡺࡲࡨཻࠫ")] == bstack11l1111_opy_ (u"ࠩࡈࡖࡗࡕࡒࡠࡃࡆࡇࡊ࡙ࡓࡠࡆࡈࡒࡎࡋࡄࠨོ"):
                    logger.info(error_message)
                elif bstack1l1l1l1ll1_opy_[bstack11l1111_opy_ (u"ࠪࡩࡷࡸ࡯ࡳࡖࡼࡴࡪཽ࠭")] == bstack11l1111_opy_ (u"ࠫࡊࡘࡒࡐࡔࡢࡗࡉࡑ࡟ࡅࡇࡓࡖࡊࡉࡁࡕࡇࡇࠫཾ"):
                    logger.error(error_message)
                else:
                    logger.error(error_message)
            else:
                logger.error(bstack1l1l1l1l11_opy_ (u"ࠧࡊࡡࡵࡣࠣࡹࡵࡲ࡯ࡢࡦࠣࡸࡴࠦࡂࡳࡱࡺࡷࡪࡸࡓࡵࡣࡦ࡯࡚ࠥࡥࡴࡶࠣࡓࡧࡹࡥࡳࡸࡤࡦ࡮ࡲࡩࡵࡻࠣࡪࡦ࡯࡬ࡦࡦࠣࡨࡺ࡫ࠠࡵࡱࠣࡷࡴࡳࡥࠡࡧࡵࡶࡴࡸࠢཿ"))
            return [None, None, None]
        os.environ[bstack11l1111_opy_ (u"࠭ࡂࡔࡡࡗࡉࡘ࡚ࡏࡑࡕࡢࡆ࡚ࡏࡌࡅࡡࡆࡓࡒࡖࡌࡆࡖࡈࡈྀࠬ")] = bstack11l1111_opy_ (u"ࠧࡵࡴࡸࡩཱྀࠬ")
        bstack1l1l1l1ll1_opy_ = response.json()
        if bstack1l1l1l1ll1_opy_.get(bstack11l1111_opy_ (u"ࠨ࡬ࡺࡸࠬྂ")):
            os.environ[bstack11l1111_opy_ (u"ࠩࡅࡗࡤ࡚ࡅࡔࡖࡒࡔࡘࡥࡊࡘࡖࠪྃ")] = bstack1l1l1l1ll1_opy_[bstack11l1111_opy_ (u"ࠪ࡮ࡼࡺ྄ࠧ")]
            os.environ[bstack11l1111_opy_ (u"ࠫࡈࡘࡅࡅࡇࡑࡘࡎࡇࡌࡔࡡࡉࡓࡗࡥࡃࡓࡃࡖࡌࡤࡘࡅࡑࡑࡕࡘࡎࡔࡇࠨ྅")] = json.dumps({
                bstack11l1111_opy_ (u"ࠬࡻࡳࡦࡴࡱࡥࡲ࡫ࠧ྆"): bstack1l1lllllll_opy_,
                bstack11l1111_opy_ (u"࠭ࡰࡢࡵࡶࡻࡴࡸࡤࠨ྇"): bstack1l1ll1ll11_opy_
            })
        if bstack1l1l1l1ll1_opy_.get(bstack11l1111_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡥࡨࡢࡵ࡫ࡩࡩࡥࡩࡥࠩྈ")):
            os.environ[bstack11l1111_opy_ (u"ࠨࡄࡖࡣ࡙ࡋࡓࡕࡑࡓࡗࡤࡈࡕࡊࡎࡇࡣࡍࡇࡓࡉࡇࡇࡣࡎࡊࠧྉ")] = bstack1l1l1l1ll1_opy_[bstack11l1111_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡠࡪࡤࡷ࡭࡫ࡤࡠ࡫ࡧࠫྊ")]
        if bstack1l1l1l1ll1_opy_.get(bstack11l1111_opy_ (u"ࠪࡥࡱࡲ࡯ࡸࡡࡶࡧࡷ࡫ࡥ࡯ࡵ࡫ࡳࡹࡹࠧྋ")):
            os.environ[bstack11l1111_opy_ (u"ࠫࡇ࡙࡟ࡕࡇࡖࡘࡔࡖࡓࡠࡃࡏࡐࡔ࡝࡟ࡔࡅࡕࡉࡊࡔࡓࡉࡑࡗࡗࠬྌ")] = str(bstack1l1l1l1ll1_opy_[bstack11l1111_opy_ (u"ࠬࡧ࡬࡭ࡱࡺࡣࡸࡩࡲࡦࡧࡱࡷ࡭ࡵࡴࡴࠩྍ")])
        return [bstack1l1l1l1ll1_opy_[bstack11l1111_opy_ (u"࠭ࡪࡸࡶࠪྎ")], bstack1l1l1l1ll1_opy_[bstack11l1111_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡥࡨࡢࡵ࡫ࡩࡩࡥࡩࡥࠩྏ")], bstack1l1l1l1ll1_opy_[bstack11l1111_opy_ (u"ࠨࡣ࡯ࡰࡴࡽ࡟ࡴࡥࡵࡩࡪࡴࡳࡩࡱࡷࡷࠬྐ")]]
    @classmethod
    @bstack1l1l1lll1l_opy_(bstack1l1l1l1l1l_opy_=True)
    def stop(cls):
        if not cls.on():
            return
        if os.environ[bstack11l1111_opy_ (u"ࠩࡅࡗࡤ࡚ࡅࡔࡖࡒࡔࡘࡥࡊࡘࡖࠪྑ")] == bstack11l1111_opy_ (u"ࠥࡲࡺࡲ࡬ࠣྒ") or os.environ[bstack11l1111_opy_ (u"ࠫࡇ࡙࡟ࡕࡇࡖࡘࡔࡖࡓࡠࡄࡘࡍࡑࡊ࡟ࡉࡃࡖࡌࡊࡊ࡟ࡊࡆࠪྒྷ")] == bstack11l1111_opy_ (u"ࠧࡴࡵ࡭࡮ࠥྔ"):
            print(bstack11l1111_opy_ (u"࠭ࡅ࡙ࡅࡈࡔ࡙ࡏࡏࡏࠢࡌࡒࠥࡹࡴࡰࡲࡅࡹ࡮ࡲࡤࡖࡲࡶࡸࡷ࡫ࡡ࡮ࠢࡕࡉࡖ࡛ࡅࡔࡖࠣࡘࡔࠦࡔࡆࡕࡗࠤࡔࡈࡓࡆࡔ࡙ࡅࡇࡏࡌࡊࡖ࡜ࠤ࠿ࠦࡍࡪࡵࡶ࡭ࡳ࡭ࠠࡢࡷࡷ࡬ࡪࡴࡴࡪࡥࡤࡸ࡮ࡵ࡮ࠡࡶࡲ࡯ࡪࡴࠧྕ"))
            return {
                bstack11l1111_opy_ (u"ࠧࡴࡶࡤࡸࡺࡹࠧྖ"): bstack11l1111_opy_ (u"ࠨࡧࡵࡶࡴࡸࠧྗ"),
                bstack11l1111_opy_ (u"ࠩࡰࡩࡸࡹࡡࡨࡧࠪ྘"): bstack11l1111_opy_ (u"ࠪࡘࡴࡱࡥ࡯࠱ࡥࡹ࡮ࡲࡤࡊࡆࠣ࡭ࡸࠦࡵ࡯ࡦࡨࡪ࡮ࡴࡥࡥ࠮ࠣࡦࡺ࡯࡬ࡥࠢࡦࡶࡪࡧࡴࡪࡱࡱࠤࡲ࡯ࡧࡩࡶࠣ࡬ࡦࡼࡥࠡࡨࡤ࡭ࡱ࡫ࡤࠨྙ")
            }
        else:
            cls.bstack1l1ll1l1ll_opy_.shutdown()
            data = {
                bstack11l1111_opy_ (u"ࠫࡸࡺ࡯ࡱࡡࡷ࡭ࡲ࡫ࠧྚ"): datetime.datetime.now().isoformat()
            }
            config = {
                bstack11l1111_opy_ (u"ࠬ࡮ࡥࡢࡦࡨࡶࡸ࠭ྛ"): cls.default_headers()
            }
            bstack1l1lll1ll1_opy_ = bstack11l1111_opy_ (u"࠭ࡡࡱ࡫࠲ࡺ࠶࠵ࡢࡶ࡫࡯ࡨࡸ࠵ࡻࡾ࠱ࡶࡸࡴࡶࠧྜ").format(os.environ[bstack11l1111_opy_ (u"ࠢࡃࡕࡢࡘࡊ࡙ࡔࡐࡒࡖࡣࡇ࡛ࡉࡍࡆࡢࡌࡆ࡙ࡈࡆࡆࡢࡍࡉࠨྜྷ")])
            bstack1l1ll1llll_opy_ = cls.request_url(bstack1l1lll1ll1_opy_)
            response = bstack1lll1llll_opy_(bstack11l1111_opy_ (u"ࠨࡒࡘࡘࠬྞ"), bstack1l1ll1llll_opy_, data, config)
            if not response.ok:
                raise Exception(bstack11l1111_opy_ (u"ࠤࡖࡸࡴࡶࠠࡳࡧࡴࡹࡪࡹࡴࠡࡰࡲࡸࠥࡵ࡫ࠣྟ"))
    @classmethod
    def bstack1l1l1l111l_opy_(cls):
        if cls.bstack1l1ll1l1ll_opy_ is None:
            return
        cls.bstack1l1ll1l1ll_opy_.shutdown()
    @classmethod
    def bstack1llll1l1l_opy_(cls):
        if cls.on():
            print(
                bstack11l1111_opy_ (u"࡚ࠪ࡮ࡹࡩࡵࠢ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡳࡧࡹࡥࡳࡸࡤࡦ࡮ࡲࡩࡵࡻ࠱ࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬࠰ࡦࡳࡲ࠵ࡢࡶ࡫࡯ࡨࡸ࠵ࡻࡾࠢࡷࡳࠥࡼࡩࡦࡹࠣࡦࡺ࡯࡬ࡥࠢࡵࡩࡵࡵࡲࡵ࠮ࠣ࡭ࡳࡹࡩࡨࡪࡷࡷ࠱ࠦࡡ࡯ࡦࠣࡱࡦࡴࡹࠡ࡯ࡲࡶࡪࠦࡤࡦࡤࡸ࡫࡬࡯࡮ࡨࠢ࡬ࡲ࡫ࡵࡲ࡮ࡣࡷ࡭ࡴࡴࠠࡢ࡮࡯ࠤࡦࡺࠠࡰࡰࡨࠤࡵࡲࡡࡤࡧࠤࡠࡳ࠭ྠ").format(os.environ[bstack11l1111_opy_ (u"ࠦࡇ࡙࡟ࡕࡇࡖࡘࡔࡖࡓࡠࡄࡘࡍࡑࡊ࡟ࡉࡃࡖࡌࡊࡊ࡟ࡊࡆࠥྡ")]))
    @classmethod
    def bstack1l1ll11111_opy_(cls):
        if cls.bstack1l1ll1l1ll_opy_ is not None:
            return
        cls.bstack1l1ll1l1ll_opy_ = bstack1l1l1ll1ll_opy_(cls.bstack1l1ll1ll1l_opy_)
        cls.bstack1l1ll1l1ll_opy_.start()
    @classmethod
    def bstack1l1llll11l_opy_(cls, bstack1l1ll11l1l_opy_, bstack1l1llllll1_opy_=bstack11l1111_opy_ (u"ࠬࡧࡰࡪ࠱ࡹ࠵࠴ࡨࡡࡵࡥ࡫ࠫྡྷ")):
        if not cls.on():
            return
        bstack1lll111lll_opy_ = bstack1l1ll11l1l_opy_[bstack11l1111_opy_ (u"࠭ࡥࡷࡧࡱࡸࡤࡺࡹࡱࡧࠪྣ")]
        bstack1l1l1l11ll_opy_ = {
            bstack11l1111_opy_ (u"ࠧࡕࡧࡶࡸࡗࡻ࡮ࡔࡶࡤࡶࡹ࡫ࡤࠨྤ"): bstack11l1111_opy_ (u"ࠨࡖࡨࡷࡹࡥࡓࡵࡣࡵࡸࡤ࡛ࡰ࡭ࡱࡤࡨࠬྥ"),
            bstack11l1111_opy_ (u"ࠩࡗࡩࡸࡺࡒࡶࡰࡉ࡭ࡳ࡯ࡳࡩࡧࡧࠫྦ"): bstack11l1111_opy_ (u"ࠪࡘࡪࡹࡴࡠࡇࡱࡨࡤ࡛ࡰ࡭ࡱࡤࡨࠬྦྷ"),
            bstack11l1111_opy_ (u"࡙ࠫ࡫ࡳࡵࡔࡸࡲࡘࡱࡩࡱࡲࡨࡨࠬྨ"): bstack11l1111_opy_ (u"࡚ࠬࡥࡴࡶࡢࡗࡰ࡯ࡰࡱࡧࡧࡣ࡚ࡶ࡬ࡰࡣࡧࠫྩ"),
            bstack11l1111_opy_ (u"࠭ࡌࡰࡩࡆࡶࡪࡧࡴࡦࡦࠪྪ"): bstack11l1111_opy_ (u"ࠧࡍࡱࡪࡣ࡚ࡶ࡬ࡰࡣࡧࠫྫ"),
            bstack11l1111_opy_ (u"ࠨࡊࡲࡳࡰࡘࡵ࡯ࡕࡷࡥࡷࡺࡥࡥࠩྫྷ"): bstack11l1111_opy_ (u"ࠩࡋࡳࡴࡱ࡟ࡔࡶࡤࡶࡹࡥࡕࡱ࡮ࡲࡥࡩ࠭ྭ"),
            bstack11l1111_opy_ (u"ࠪࡌࡴࡵ࡫ࡓࡷࡱࡊ࡮ࡴࡩࡴࡪࡨࡨࠬྮ"): bstack11l1111_opy_ (u"ࠫࡍࡵ࡯࡬ࡡࡈࡲࡩࡥࡕࡱ࡮ࡲࡥࡩ࠭ྯ"),
            bstack11l1111_opy_ (u"ࠬࡉࡂࡕࡕࡨࡷࡸ࡯࡯࡯ࡅࡵࡩࡦࡺࡥࡥࠩྰ"): bstack11l1111_opy_ (u"࠭ࡃࡃࡖࡢ࡙ࡵࡲ࡯ࡢࡦࠪྱ")
        }.get(bstack1lll111lll_opy_)
        if bstack1l1llllll1_opy_ == bstack11l1111_opy_ (u"ࠧࡢࡲ࡬࠳ࡻ࠷࠯ࡣࡣࡷࡧ࡭࠭ྲ"):
            cls.bstack1l1ll11111_opy_()
            cls.bstack1l1ll1l1ll_opy_.add(bstack1l1ll11l1l_opy_)
        elif bstack1l1llllll1_opy_ == bstack11l1111_opy_ (u"ࠨࡣࡳ࡭࠴ࡼ࠱࠰ࡵࡦࡶࡪ࡫࡮ࡴࡪࡲࡸࡸ࠭ླ"):
            cls.bstack1l1ll1ll1l_opy_([bstack1l1ll11l1l_opy_], bstack1l1llllll1_opy_)
    @classmethod
    @bstack1l1l1lll1l_opy_(bstack1l1l1l1l1l_opy_=True)
    def bstack1l1ll1ll1l_opy_(cls, bstack1l1ll11l1l_opy_, bstack1l1llllll1_opy_=bstack11l1111_opy_ (u"ࠩࡤࡴ࡮࠵ࡶ࠲࠱ࡥࡥࡹࡩࡨࠨྴ")):
        config = {
            bstack11l1111_opy_ (u"ࠪ࡬ࡪࡧࡤࡦࡴࡶࠫྵ"): cls.default_headers()
        }
        response = bstack1lll1llll_opy_(bstack11l1111_opy_ (u"ࠫࡕࡕࡓࡕࠩྶ"), cls.request_url(bstack1l1llllll1_opy_), bstack1l1ll11l1l_opy_, config)
        bstack1l1lll1lll_opy_ = response.json()
    @classmethod
    @bstack1l1l1lll1l_opy_(bstack1l1l1l1l1l_opy_=True)
    def bstack1l1llll1ll_opy_(cls, bstack1l1ll1l1l1_opy_):
        bstack1l1lll1111_opy_ = []
        for log in bstack1l1ll1l1l1_opy_:
            bstack1l1lll1111_opy_.append({
                bstack11l1111_opy_ (u"ࠬࡱࡩ࡯ࡦࠪྷ"): bstack11l1111_opy_ (u"࠭ࡔࡆࡕࡗࡣࡑࡕࡇࠨྸ"),
                bstack11l1111_opy_ (u"ࠧ࡭ࡧࡹࡩࡱ࠭ྐྵ"): log[bstack11l1111_opy_ (u"ࠨ࡮ࡨࡺࡪࡲࠧྺ")],
                bstack11l1111_opy_ (u"ࠩࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠬྻ"): log[bstack11l1111_opy_ (u"ࠪࡸ࡮ࡳࡥࡴࡶࡤࡱࡵ࠭ྼ")],
                bstack11l1111_opy_ (u"ࠫ࡭ࡺࡴࡱࡡࡵࡩࡸࡶ࡯࡯ࡵࡨࠫ྽"): {},
                bstack11l1111_opy_ (u"ࠬࡳࡥࡴࡵࡤ࡫ࡪ࠭྾"): log[bstack11l1111_opy_ (u"࠭࡭ࡦࡵࡶࡥ࡬࡫ࠧ྿")],
                bstack11l1111_opy_ (u"ࠧࡵࡧࡶࡸࡤࡸࡵ࡯ࡡࡸࡹ࡮ࡪࠧ࿀"): log[bstack11l1111_opy_ (u"ࠨࡶࡨࡷࡹࡥࡲࡶࡰࡢࡹࡺ࡯ࡤࠨ࿁")]
            })
        cls.bstack1l1llll11l_opy_({
            bstack11l1111_opy_ (u"ࠩࡨࡺࡪࡴࡴࡠࡶࡼࡴࡪ࠭࿂"): bstack11l1111_opy_ (u"ࠪࡐࡴ࡭ࡃࡳࡧࡤࡸࡪࡪࠧ࿃"),
            bstack11l1111_opy_ (u"ࠫࡱࡵࡧࡴࠩ࿄"): bstack1l1lll1111_opy_
        })
    @classmethod
    @bstack1l1l1lll1l_opy_(bstack1l1l1l1l1l_opy_=True)
    def bstack1l1lll11l1_opy_(cls, steps):
        bstack1l1ll11ll1_opy_ = []
        for step in steps:
            bstack1l1l1ll11l_opy_ = {
                bstack11l1111_opy_ (u"ࠬࡱࡩ࡯ࡦࠪ࿅"): bstack11l1111_opy_ (u"࠭ࡔࡆࡕࡗࡣࡘ࡚ࡅࡑ࿆ࠩ"),
                bstack11l1111_opy_ (u"ࠧ࡭ࡧࡹࡩࡱ࠭࿇"): step[bstack11l1111_opy_ (u"ࠨ࡮ࡨࡺࡪࡲࠧ࿈")],
                bstack11l1111_opy_ (u"ࠩࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠬ࿉"): step[bstack11l1111_opy_ (u"ࠪࡸ࡮ࡳࡥࡴࡶࡤࡱࡵ࠭࿊")],
                bstack11l1111_opy_ (u"ࠫࡲ࡫ࡳࡴࡣࡪࡩࠬ࿋"): step[bstack11l1111_opy_ (u"ࠬࡳࡥࡴࡵࡤ࡫ࡪ࠭࿌")],
                bstack11l1111_opy_ (u"࠭ࡤࡶࡴࡤࡸ࡮ࡵ࡮ࠨ࿍"): step[bstack11l1111_opy_ (u"ࠧࡥࡷࡵࡥࡹ࡯࡯࡯ࠩ࿎")]
            }
            if bstack11l1111_opy_ (u"ࠨࡶࡨࡷࡹࡥࡲࡶࡰࡢࡹࡺ࡯ࡤࠨ࿏") in step:
                bstack1l1l1ll11l_opy_[bstack11l1111_opy_ (u"ࠩࡷࡩࡸࡺ࡟ࡳࡷࡱࡣࡺࡻࡩࡥࠩ࿐")] = step[bstack11l1111_opy_ (u"ࠪࡸࡪࡹࡴࡠࡴࡸࡲࡤࡻࡵࡪࡦࠪ࿑")]
            elif bstack11l1111_opy_ (u"ࠫ࡭ࡵ࡯࡬ࡡࡵࡹࡳࡥࡵࡶ࡫ࡧࠫ࿒") in step:
                bstack1l1l1ll11l_opy_[bstack11l1111_opy_ (u"ࠬ࡮࡯ࡰ࡭ࡢࡶࡺࡴ࡟ࡶࡷ࡬ࡨࠬ࿓")] = step[bstack11l1111_opy_ (u"࠭ࡨࡰࡱ࡮ࡣࡷࡻ࡮ࡠࡷࡸ࡭ࡩ࠭࿔")]
            bstack1l1ll11ll1_opy_.append(bstack1l1l1ll11l_opy_)
        cls.bstack1l1llll11l_opy_({
            bstack11l1111_opy_ (u"ࠧࡦࡸࡨࡲࡹࡥࡴࡺࡲࡨࠫ࿕"): bstack11l1111_opy_ (u"ࠨࡎࡲ࡫ࡈࡸࡥࡢࡶࡨࡨࠬ࿖"),
            bstack11l1111_opy_ (u"ࠩ࡯ࡳ࡬ࡹࠧ࿗"): bstack1l1ll11ll1_opy_
        })
    @classmethod
    @bstack1l1l1lll1l_opy_(bstack1l1l1l1l1l_opy_=True)
    def bstack1l1lll1l11_opy_(cls, screenshot):
        cls.bstack1l1llll11l_opy_({
            bstack11l1111_opy_ (u"ࠪࡩࡻ࡫࡮ࡵࡡࡷࡽࡵ࡫ࠧ࿘"): bstack11l1111_opy_ (u"ࠫࡑࡵࡧࡄࡴࡨࡥࡹ࡫ࡤࠨ࿙"),
            bstack11l1111_opy_ (u"ࠬࡲ࡯ࡨࡵࠪ࿚"): [{
                bstack11l1111_opy_ (u"࠭࡫ࡪࡰࡧࠫ࿛"): bstack11l1111_opy_ (u"ࠧࡕࡇࡖࡘࡤ࡙ࡃࡓࡇࡈࡒࡘࡎࡏࡕࠩ࿜"),
                bstack11l1111_opy_ (u"ࠨࡶ࡬ࡱࡪࡹࡴࡢ࡯ࡳࠫ࿝"): datetime.datetime.utcnow().isoformat() + bstack11l1111_opy_ (u"ࠩ࡝ࠫ࿞"),
                bstack11l1111_opy_ (u"ࠪࡱࡪࡹࡳࡢࡩࡨࠫ࿟"): screenshot[bstack11l1111_opy_ (u"ࠫ࡮ࡳࡡࡨࡧࠪ࿠")],
                bstack11l1111_opy_ (u"ࠬࡺࡥࡴࡶࡢࡶࡺࡴ࡟ࡶࡷ࡬ࡨࠬ࿡"): screenshot[bstack11l1111_opy_ (u"࠭ࡴࡦࡵࡷࡣࡷࡻ࡮ࡠࡷࡸ࡭ࡩ࠭࿢")]
            }]
        }, bstack1l1llllll1_opy_=bstack11l1111_opy_ (u"ࠧࡢࡲ࡬࠳ࡻ࠷࠯ࡴࡥࡵࡩࡪࡴࡳࡩࡱࡷࡷࠬ࿣"))
    @classmethod
    @bstack1l1l1lll1l_opy_(bstack1l1l1l1l1l_opy_=True)
    def bstack1llll1llll_opy_(cls, driver):
        bstack1l1ll1l11l_opy_ = cls.bstack1l1ll1l11l_opy_()
        if not bstack1l1ll1l11l_opy_:
            return
        cls.bstack1l1llll11l_opy_({
            bstack11l1111_opy_ (u"ࠨࡧࡹࡩࡳࡺ࡟ࡵࡻࡳࡩࠬ࿤"): bstack11l1111_opy_ (u"ࠩࡆࡆ࡙࡙ࡥࡴࡵ࡬ࡳࡳࡉࡲࡦࡣࡷࡩࡩ࠭࿥"),
            bstack11l1111_opy_ (u"ࠪࡸࡪࡹࡴࡠࡴࡸࡲࠬ࿦"): {
                bstack11l1111_opy_ (u"ࠦࡺࡻࡩࡥࠤ࿧"): cls.bstack1l1ll1l11l_opy_(),
                bstack11l1111_opy_ (u"ࠧ࡯࡮ࡵࡧࡪࡶࡦࡺࡩࡰࡰࡶࠦ࿨"): cls.bstack1l1llll1l1_opy_(driver)
            }
        })
    @classmethod
    def on(cls):
        if os.environ.get(bstack11l1111_opy_ (u"࠭ࡂࡔࡡࡗࡉࡘ࡚ࡏࡑࡕࡢࡎ࡜࡚ࠧ࿩"), None) is None or os.environ[bstack11l1111_opy_ (u"ࠧࡃࡕࡢࡘࡊ࡙ࡔࡐࡒࡖࡣࡏ࡝ࡔࠨ࿪")] == bstack11l1111_opy_ (u"ࠣࡰࡸࡰࡱࠨ࿫"):
            return False
        return True
    @classmethod
    def bstack1l1lll1l1l_opy_(cls):
        return bstack1l1l1lll11_opy_(cls.bs_config.get(bstack11l1111_opy_ (u"ࠩࡷࡩࡸࡺࡏࡣࡵࡨࡶࡻࡧࡢࡪ࡮࡬ࡸࡾ࠭࿬"), False))
    @staticmethod
    def request_url(url):
        return bstack11l1111_opy_ (u"ࠪࡿࢂ࠵ࡻࡾࠩ࿭").format(bstack1l1ll1l111_opy_, url)
    @staticmethod
    def default_headers():
        headers = {
            bstack11l1111_opy_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ࿮"): bstack11l1111_opy_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲࡮ࡸࡵ࡮ࠨ࿯"),
            bstack11l1111_opy_ (u"࠭ࡘ࠮ࡄࡖࡘࡆࡉࡋ࠮ࡖࡈࡗ࡙ࡕࡐࡔࠩ࿰"): bstack11l1111_opy_ (u"ࠧࡵࡴࡸࡩࠬ࿱")
        }
        if os.environ.get(bstack11l1111_opy_ (u"ࠨࡄࡖࡣ࡙ࡋࡓࡕࡑࡓࡗࡤࡐࡗࡕࠩ࿲"), None):
            headers[bstack11l1111_opy_ (u"ࠩࡄࡹࡹ࡮࡯ࡳ࡫ࡽࡥࡹ࡯࡯࡯ࠩ࿳")] = bstack11l1111_opy_ (u"ࠪࡆࡪࡧࡲࡦࡴࠣࡿࢂ࠭࿴").format(os.environ[bstack11l1111_opy_ (u"ࠦࡇ࡙࡟ࡕࡇࡖࡘࡔࡖࡓࡠࡌ࡚ࡘࠧ࿵")])
        return headers
    @staticmethod
    def bstack1l1ll1l11l_opy_():
        return getattr(threading.current_thread(), bstack11l1111_opy_ (u"ࠬࡩࡵࡳࡴࡨࡲࡹࡥࡴࡦࡵࡷࡣࡺࡻࡩࡥࠩ࿶"), None)
    @staticmethod
    def bstack1l1llll1l1_opy_(driver):
        return {
            bstack1l1ll111ll_opy_(): bstack1l1ll111l1_opy_(driver)
        }
    @staticmethod
    def bstack1l1l1l11l1_opy_(exception_info, report):
        return [{bstack11l1111_opy_ (u"࠭ࡢࡢࡥ࡮ࡸࡷࡧࡣࡦࠩ࿷"): [exception_info.exconly(), report.longreprtext]}]
    @staticmethod
    def bstack1l1llll111_opy_(typename):
        if bstack11l1111_opy_ (u"ࠢࡂࡵࡶࡩࡷࡺࡩࡰࡰࠥ࿸") in typename:
            return bstack11l1111_opy_ (u"ࠣࡃࡶࡷࡪࡸࡴࡪࡱࡱࡉࡷࡸ࡯ࡳࠤ࿹")
        return bstack11l1111_opy_ (u"ࠤࡘࡲ࡭ࡧ࡮ࡥ࡮ࡨࡨࡊࡸࡲࡰࡴࠥ࿺")
    @staticmethod
    def bstack1l1l1ll1l1_opy_(func):
        def wrap(*args, **kwargs):
            if bstack11ll1l11l_opy_.on():
                return func(*args, **kwargs)
            return
        return wrap
    @staticmethod
    def bstack1l1l1llll1_opy_(test):
        bstack1l1ll1111l_opy_ = test.parent
        scope = []
        while bstack1l1ll1111l_opy_ is not None:
            scope.append(bstack1l1ll1111l_opy_.name)
            bstack1l1ll1111l_opy_ = bstack1l1ll1111l_opy_.parent
        scope.reverse()
        return scope[2:]
    @staticmethod
    def bstack1l1l1l1lll_opy_(hook_type):
        if hook_type == bstack11l1111_opy_ (u"ࠥࡆࡊࡌࡏࡓࡇࡢࡉࡆࡉࡈࠣ࿻"):
            return bstack11l1111_opy_ (u"ࠦࡘ࡫ࡴࡶࡲࠣ࡬ࡴࡵ࡫ࠣ࿼")
        elif hook_type == bstack11l1111_opy_ (u"ࠧࡇࡆࡕࡇࡕࡣࡊࡇࡃࡉࠤ࿽"):
            return bstack11l1111_opy_ (u"ࠨࡔࡦࡣࡵࡨࡴࡽ࡮ࠡࡪࡲࡳࡰࠨ࿾")
    @staticmethod
    def bstack1l1l1ll111_opy_(bstack1llll11l_opy_):
        try:
            if not bstack11ll1l11l_opy_.on():
                return bstack1llll11l_opy_
            if os.environ.get(bstack11l1111_opy_ (u"ࠢࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡒࡆࡔࡘࡒࠧ࿿"), None) == bstack11l1111_opy_ (u"ࠣࡶࡵࡹࡪࠨက"):
                tests = os.environ.get(bstack11l1111_opy_ (u"ࠤࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡔࡈࡖ࡚ࡔ࡟ࡕࡇࡖࡘࡘࠨခ"), None)
                if tests is None or tests == bstack11l1111_opy_ (u"ࠥࡲࡺࡲ࡬ࠣဂ"):
                    return bstack1llll11l_opy_
                bstack1llll11l_opy_ = tests.split(bstack11l1111_opy_ (u"ࠫ࠱࠭ဃ"))
                return bstack1llll11l_opy_
        except Exception as exc:
            print(bstack11l1111_opy_ (u"ࠧࡋࡸࡤࡧࡳࡸ࡮ࡵ࡮ࠡ࡫ࡱࠤࡷ࡫ࡲࡶࡰࠣ࡬ࡦࡴࡤ࡭ࡧࡵ࠾ࠥࠨင"), str(exc))
        return bstack1llll11l_opy_