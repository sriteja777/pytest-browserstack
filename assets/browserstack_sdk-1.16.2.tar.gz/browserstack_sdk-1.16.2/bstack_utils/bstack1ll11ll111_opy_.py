# coding: UTF-8
import sys
bstack1ll_opy_ = sys.version_info [0] == 2
bstack11ll_opy_ = 2048
bstack11l1ll_opy_ = 7
def bstack11l1111_opy_ (bstack1lll11_opy_):
    global bstack1lllll_opy_
    bstack1111lll_opy_ = ord (bstack1lll11_opy_ [-1])
    bstack1lll1l_opy_ = bstack1lll11_opy_ [:-1]
    bstack1llll1l_opy_ = bstack1111lll_opy_ % len (bstack1lll1l_opy_)
    bstack1l11_opy_ = bstack1lll1l_opy_ [:bstack1llll1l_opy_] + bstack1lll1l_opy_ [bstack1llll1l_opy_:]
    if bstack1ll_opy_:
        bstack1l1l1ll_opy_ = unicode () .join ([unichr (ord (char) - bstack11ll_opy_ - (bstack1l1l11_opy_ + bstack1111lll_opy_) % bstack11l1ll_opy_) for bstack1l1l11_opy_, char in enumerate (bstack1l11_opy_)])
    else:
        bstack1l1l1ll_opy_ = str () .join ([chr (ord (char) - bstack11ll_opy_ - (bstack1l1l11_opy_ + bstack1111lll_opy_) % bstack11l1ll_opy_) for bstack1l1l11_opy_, char in enumerate (bstack1l11_opy_)])
    return eval (bstack1l1l1ll_opy_)
import json
import os
from bstack_utils.helper import bstack1ll11l1l1l_opy_, bstack11111l1l1_opy_, bstack1l1l1l111_opy_, \
    bstack1ll11l1ll1_opy_
def bstack111111l1_opy_(bstack1ll11l1l11_opy_):
    for driver in bstack1ll11l1l11_opy_:
        try:
            driver.quit()
        except Exception as e:
            pass
def bstack1l1l1111l_opy_(type, name, status, reason, bstack1111ll1l1_opy_, bstack1l1lllll1_opy_):
    bstack1ll1ll11l_opy_ = {
        bstack11l1111_opy_ (u"ࠩࡤࡧࡹ࡯࡯࡯ࠩ೎"): type,
        bstack11l1111_opy_ (u"ࠪࡥࡷ࡭ࡵ࡮ࡧࡱࡸࡸ࠭೏"): {}
    }
    if type == bstack11l1111_opy_ (u"ࠫࡦࡴ࡮ࡰࡶࡤࡸࡪ࠭೐"):
        bstack1ll1ll11l_opy_[bstack11l1111_opy_ (u"ࠬࡧࡲࡨࡷࡰࡩࡳࡺࡳࠨ೑")][bstack11l1111_opy_ (u"࠭࡬ࡦࡸࡨࡰࠬ೒")] = bstack1111ll1l1_opy_
        bstack1ll1ll11l_opy_[bstack11l1111_opy_ (u"ࠧࡢࡴࡪࡹࡲ࡫࡮ࡵࡵࠪ೓")][bstack11l1111_opy_ (u"ࠨࡦࡤࡸࡦ࠭೔")] = json.dumps(str(bstack1l1lllll1_opy_))
    if type == bstack11l1111_opy_ (u"ࠩࡶࡩࡹ࡙ࡥࡴࡵ࡬ࡳࡳࡔࡡ࡮ࡧࠪೕ"):
        bstack1ll1ll11l_opy_[bstack11l1111_opy_ (u"ࠪࡥࡷ࡭ࡵ࡮ࡧࡱࡸࡸ࠭ೖ")][bstack11l1111_opy_ (u"ࠫࡳࡧ࡭ࡦࠩ೗")] = name
    if type == bstack11l1111_opy_ (u"ࠬࡹࡥࡵࡕࡨࡷࡸ࡯࡯࡯ࡕࡷࡥࡹࡻࡳࠨ೘"):
        bstack1ll1ll11l_opy_[bstack11l1111_opy_ (u"࠭ࡡࡳࡩࡸࡱࡪࡴࡴࡴࠩ೙")][bstack11l1111_opy_ (u"ࠧࡴࡶࡤࡸࡺࡹࠧ೚")] = status
        if status == bstack11l1111_opy_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨ೛"):
            bstack1ll1ll11l_opy_[bstack11l1111_opy_ (u"ࠩࡤࡶ࡬ࡻ࡭ࡦࡰࡷࡷࠬ೜")][bstack11l1111_opy_ (u"ࠪࡶࡪࡧࡳࡰࡰࠪೝ")] = json.dumps(str(reason))
    bstack1ll11lllll_opy_ = bstack11l1111_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡢࡩࡽ࡫ࡣࡶࡶࡲࡶ࠿ࠦࡻࡾࠩೞ").format(json.dumps(bstack1ll1ll11l_opy_))
    return bstack1ll11lllll_opy_
def bstack1111l11l_opy_(url, config, logger, bstack1lll1ll11_opy_=False):
    hostname = bstack11111l1l1_opy_(url)
    is_private = bstack1l1l1l111_opy_(hostname)
    try:
        if is_private or bstack1lll1ll11_opy_:
            file_path = bstack1ll11l1l1l_opy_(bstack11l1111_opy_ (u"ࠬ࠴ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࠬ೟"), bstack11l1111_opy_ (u"࠭࠮ࡣࡵࡷࡥࡨࡱ࠭ࡤࡱࡱࡪ࡮࡭࠮࡫ࡵࡲࡲࠬೠ"), logger)
            if os.environ.get(bstack11l1111_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡌࡐࡅࡄࡐࡤࡔࡏࡕࡡࡖࡉ࡙ࡥࡅࡓࡔࡒࡖࠬೡ")) and eval(
                    os.environ.get(bstack11l1111_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡍࡑࡆࡅࡑࡥࡎࡐࡖࡢࡗࡊ࡚࡟ࡆࡔࡕࡓࡗ࠭ೢ"))):
                return
            if (bstack11l1111_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡍࡱࡦࡥࡱ࠭ೣ") in config and not config[bstack11l1111_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡎࡲࡧࡦࡲࠧ೤")]):
                os.environ[bstack11l1111_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡐࡔࡉࡁࡍࡡࡑࡓ࡙ࡥࡓࡆࡖࡢࡉࡗࡘࡏࡓࠩ೥")] = str(True)
                bstack1ll11l1lll_opy_ = {bstack11l1111_opy_ (u"ࠬ࡮࡯ࡴࡶࡱࡥࡲ࡫ࠧ೦"): hostname}
                bstack1ll11l1ll1_opy_(bstack11l1111_opy_ (u"࠭࠮ࡣࡵࡷࡥࡨࡱ࠭ࡤࡱࡱࡪ࡮࡭࠮࡫ࡵࡲࡲࠬ೧"), bstack11l1111_opy_ (u"ࠧ࡯ࡷࡧ࡫ࡪࡥ࡬ࡰࡥࡤࡰࠬ೨"), bstack1ll11l1lll_opy_, logger)
    except Exception as e:
        pass
def bstack11l1llll1_opy_(caps, bstack1ll11l11ll_opy_):
    if bstack11l1111_opy_ (u"ࠨࡤࡶࡸࡦࡩ࡫࠻ࡱࡳࡸ࡮ࡵ࡮ࡴࠩ೩") in caps:
        caps[bstack11l1111_opy_ (u"ࠩࡥࡷࡹࡧࡣ࡬࠼ࡲࡴࡹ࡯࡯࡯ࡵࠪ೪")][bstack11l1111_opy_ (u"ࠪࡰࡴࡩࡡ࡭ࠩ೫")] = True
        if bstack1ll11l11ll_opy_:
            caps[bstack11l1111_opy_ (u"ࠫࡧࡹࡴࡢࡥ࡮࠾ࡴࡶࡴࡪࡱࡱࡷࠬ೬")][bstack11l1111_opy_ (u"ࠬࡲ࡯ࡤࡣ࡯ࡍࡩ࡫࡮ࡵ࡫ࡩ࡭ࡪࡸࠧ೭")] = bstack1ll11l11ll_opy_
    else:
        caps[bstack11l1111_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯࠳ࡲ࡯ࡤࡣ࡯ࠫ೮")] = True
        if bstack1ll11l11ll_opy_:
            caps[bstack11l1111_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠴࡬ࡰࡥࡤࡰࡎࡪࡥ࡯ࡶ࡬ࡪ࡮࡫ࡲࠨ೯")] = bstack1ll11l11ll_opy_