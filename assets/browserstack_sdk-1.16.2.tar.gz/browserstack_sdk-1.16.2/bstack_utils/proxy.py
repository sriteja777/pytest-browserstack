# coding: UTF-8
import sys
bstack1ll_opy_ = sys.version_info [0] == 2
bstack11ll_opy_ = 2048
bstack11l1ll_opy_ = 7
def bstack11l1111_opy_ (bstack1lll11_opy_):
    global bstack1lllll_opy_
    bstack1111lll_opy_ = ord (bstack1lll11_opy_ [-1])
    bstack1lll1l_opy_ = bstack1lll11_opy_ [:-1]
    bstack1llll1l_opy_ = bstack1111lll_opy_ % len (bstack1lll1l_opy_)
    bstack1l11_opy_ = bstack1lll1l_opy_ [:bstack1llll1l_opy_] + bstack1lll1l_opy_ [bstack1llll1l_opy_:]
    if bstack1ll_opy_:
        bstack1l1l1ll_opy_ = unicode () .join ([unichr (ord (char) - bstack11ll_opy_ - (bstack1l1l11_opy_ + bstack1111lll_opy_) % bstack11l1ll_opy_) for bstack1l1l11_opy_, char in enumerate (bstack1l11_opy_)])
    else:
        bstack1l1l1ll_opy_ = str () .join ([chr (ord (char) - bstack11ll_opy_ - (bstack1l1l11_opy_ + bstack1111lll_opy_) % bstack11l1ll_opy_) for bstack1l1l11_opy_, char in enumerate (bstack1l11_opy_)])
    return eval (bstack1l1l1ll_opy_)
import os
from urllib.parse import urlparse
from bstack_utils.messages import bstack1ll111llll_opy_
def bstack1ll11l1111_opy_(url):
    try:
        result = urlparse(url)
        return all([result.scheme, result.netloc])
    except:
        return False
def bstack1ll111lll1_opy_(bstack1ll111ll11_opy_, bstack1ll111ll1l_opy_):
    from pypac import get_pac
    from pypac import PACSession
    from pypac.parser import PACFile
    import socket
    if os.path.isfile(bstack1ll111ll11_opy_):
        with open(bstack1ll111ll11_opy_) as f:
            pac = PACFile(f.read())
    elif bstack1ll11l1111_opy_(bstack1ll111ll11_opy_):
        pac = get_pac(url=bstack1ll111ll11_opy_)
    else:
        raise Exception(bstack11l1111_opy_ (u"ࠨࡒࡤࡧࠥ࡬ࡩ࡭ࡧࠣࡨࡴ࡫ࡳࠡࡰࡲࡸࠥ࡫ࡸࡪࡵࡷ࠾ࠥࢁࡽࠨ೰").format(bstack1ll111ll11_opy_))
    session = PACSession(pac)
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect((bstack11l1111_opy_ (u"ࠤ࠻࠲࠽࠴࠸࠯࠺ࠥೱ"), 80))
        bstack1ll11l11l1_opy_ = s.getsockname()[0]
        s.close()
    except:
        bstack1ll11l11l1_opy_ = bstack11l1111_opy_ (u"ࠪ࠴࠳࠶࠮࠱࠰࠳ࠫೲ")
    proxy_url = session.get_pac().find_proxy_for_url(bstack1ll111ll1l_opy_, bstack1ll11l11l1_opy_)
    return proxy_url
def bstack11l1l1ll1_opy_(config):
    return bstack11l1111_opy_ (u"ࠫ࡭ࡺࡴࡱࡒࡵࡳࡽࡿࠧೳ") in config or bstack11l1111_opy_ (u"ࠬ࡮ࡴࡵࡲࡶࡔࡷࡵࡸࡺࠩ೴") in config
def bstack1lll1l11ll_opy_(config):
    if not bstack11l1l1ll1_opy_(config):
        return
    if config.get(bstack11l1111_opy_ (u"࠭ࡨࡵࡶࡳࡔࡷࡵࡸࡺࠩ೵")):
        return config.get(bstack11l1111_opy_ (u"ࠧࡩࡶࡷࡴࡕࡸ࡯ࡹࡻࠪ೶"))
    if config.get(bstack11l1111_opy_ (u"ࠨࡪࡷࡸࡵࡹࡐࡳࡱࡻࡽࠬ೷")):
        return config.get(bstack11l1111_opy_ (u"ࠩ࡫ࡸࡹࡶࡳࡑࡴࡲࡼࡾ࠭೸"))
def bstack11111111_opy_(config, bstack1ll111ll1l_opy_):
    proxy = bstack1lll1l11ll_opy_(config)
    proxies = {}
    if config.get(bstack11l1111_opy_ (u"ࠪ࡬ࡹࡺࡰࡑࡴࡲࡼࡾ࠭೹")) or config.get(bstack11l1111_opy_ (u"ࠫ࡭ࡺࡴࡱࡵࡓࡶࡴࡾࡹࠨ೺")):
        if proxy.endswith(bstack11l1111_opy_ (u"ࠬ࠴ࡰࡢࡥࠪ೻")):
            proxies = bstack1lll111l1l_opy_(proxy, bstack1ll111ll1l_opy_)
        else:
            proxies = {
                bstack11l1111_opy_ (u"࠭ࡨࡵࡶࡳࡷࠬ೼"): proxy
            }
    return proxies
def bstack1lll111l1l_opy_(bstack1ll111ll11_opy_, bstack1ll111ll1l_opy_):
    proxies = {}
    global bstack1ll11l111l_opy_
    if bstack11l1111_opy_ (u"ࠧࡑࡃࡆࡣࡕࡘࡏ࡙࡛ࠪ೽") in globals():
        return bstack1ll11l111l_opy_
    try:
        proxy = bstack1ll111lll1_opy_(bstack1ll111ll11_opy_, bstack1ll111ll1l_opy_)
        if bstack11l1111_opy_ (u"ࠣࡆࡌࡖࡊࡉࡔࠣ೾") in proxy:
            proxies = {}
        elif bstack11l1111_opy_ (u"ࠤࡋࡘ࡙ࡖࠢ೿") in proxy or bstack11l1111_opy_ (u"ࠥࡌ࡙࡚ࡐࡔࠤഀ") in proxy or bstack11l1111_opy_ (u"ࠦࡘࡕࡃࡌࡕࠥഁ") in proxy:
            bstack1ll111l1ll_opy_ = proxy.split(bstack11l1111_opy_ (u"ࠧࠦࠢം"))
            if bstack11l1111_opy_ (u"ࠨ࠺࠰࠱ࠥഃ") in bstack11l1111_opy_ (u"ࠢࠣഄ").join(bstack1ll111l1ll_opy_[1:]):
                proxies = {
                    bstack11l1111_opy_ (u"ࠨࡪࡷࡸࡵࡹࠧഅ"): bstack11l1111_opy_ (u"ࠤࠥആ").join(bstack1ll111l1ll_opy_[1:])
                }
            else:
                proxies = {
                    bstack11l1111_opy_ (u"ࠪ࡬ࡹࡺࡰࡴࠩഇ"): str(bstack1ll111l1ll_opy_[0]).lower() + bstack11l1111_opy_ (u"ࠦ࠿࠵࠯ࠣഈ") + bstack11l1111_opy_ (u"ࠧࠨഉ").join(bstack1ll111l1ll_opy_[1:])
                }
        elif bstack11l1111_opy_ (u"ࠨࡐࡓࡑ࡛࡝ࠧഊ") in proxy:
            bstack1ll111l1ll_opy_ = proxy.split(bstack11l1111_opy_ (u"ࠢࠡࠤഋ"))
            if bstack11l1111_opy_ (u"ࠣ࠼࠲࠳ࠧഌ") in bstack11l1111_opy_ (u"ࠤࠥ഍").join(bstack1ll111l1ll_opy_[1:]):
                proxies = {
                    bstack11l1111_opy_ (u"ࠪ࡬ࡹࡺࡰࡴࠩഎ"): bstack11l1111_opy_ (u"ࠦࠧഏ").join(bstack1ll111l1ll_opy_[1:])
                }
            else:
                proxies = {
                    bstack11l1111_opy_ (u"ࠬ࡮ࡴࡵࡲࡶࠫഐ"): bstack11l1111_opy_ (u"ࠨࡨࡵࡶࡳ࠾࠴࠵ࠢ഑") + bstack11l1111_opy_ (u"ࠢࠣഒ").join(bstack1ll111l1ll_opy_[1:])
                }
        else:
            proxies = {
                bstack11l1111_opy_ (u"ࠨࡪࡷࡸࡵࡹࠧഓ"): proxy
            }
    except Exception as e:
        print(bstack11l1111_opy_ (u"ࠤࡶࡳࡲ࡫ࠠࡦࡴࡵࡳࡷࠨഔ"), bstack1ll111llll_opy_.format(bstack1ll111ll11_opy_, str(e)))
    bstack1ll11l111l_opy_ = proxies
    return proxies