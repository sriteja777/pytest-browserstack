# coding: UTF-8
import sys
bstack1ll_opy_ = sys.version_info [0] == 2
bstack11ll_opy_ = 2048
bstack11l1ll_opy_ = 7
def bstack11l1111_opy_ (bstack1lll11_opy_):
    global bstack1lllll_opy_
    bstack1111lll_opy_ = ord (bstack1lll11_opy_ [-1])
    bstack1lll1l_opy_ = bstack1lll11_opy_ [:-1]
    bstack1llll1l_opy_ = bstack1111lll_opy_ % len (bstack1lll1l_opy_)
    bstack1l11_opy_ = bstack1lll1l_opy_ [:bstack1llll1l_opy_] + bstack1lll1l_opy_ [bstack1llll1l_opy_:]
    if bstack1ll_opy_:
        bstack1l1l1ll_opy_ = unicode () .join ([unichr (ord (char) - bstack11ll_opy_ - (bstack1l1l11_opy_ + bstack1111lll_opy_) % bstack11l1ll_opy_) for bstack1l1l11_opy_, char in enumerate (bstack1l11_opy_)])
    else:
        bstack1l1l1ll_opy_ = str () .join ([chr (ord (char) - bstack11ll_opy_ - (bstack1l1l11_opy_ + bstack1111lll_opy_) % bstack11l1ll_opy_) for bstack1l1l11_opy_, char in enumerate (bstack1l11_opy_)])
    return eval (bstack1l1l1ll_opy_)
class bstack1ll111111l_opy_:
    def __init__(self, handler):
        self._1ll1111l11_opy_ = None
        self.handler = handler
        self._1ll1111111_opy_ = self.bstack1ll11111l1_opy_()
        self.patch()
    def patch(self):
        self._1ll1111l11_opy_ = self._1ll1111111_opy_.execute
        self._1ll1111111_opy_.execute = self.bstack1ll11111ll_opy_()
    def bstack1ll11111ll_opy_(self):
        def execute(this, driver_command, *args, **kwargs):
            response = self._1ll1111l11_opy_(this, driver_command, *args, **kwargs)
            self.handler(driver_command, response)
            return response
        return execute
    def reset(self):
        self._1ll1111111_opy_.execute = self._1ll1111l11_opy_
    @staticmethod
    def bstack1ll11111l1_opy_():
        from selenium.webdriver.remote.webdriver import WebDriver
        return WebDriver