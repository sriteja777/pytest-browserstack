# coding: UTF-8
import sys
bstack1ll_opy_ = sys.version_info [0] == 2
bstack11ll_opy_ = 2048
bstack11l1ll_opy_ = 7
def bstack11l1111_opy_ (bstack1lll11_opy_):
    global bstack1lllll_opy_
    bstack1111lll_opy_ = ord (bstack1lll11_opy_ [-1])
    bstack1lll1l_opy_ = bstack1lll11_opy_ [:-1]
    bstack1llll1l_opy_ = bstack1111lll_opy_ % len (bstack1lll1l_opy_)
    bstack1l11_opy_ = bstack1lll1l_opy_ [:bstack1llll1l_opy_] + bstack1lll1l_opy_ [bstack1llll1l_opy_:]
    if bstack1ll_opy_:
        bstack1l1l1ll_opy_ = unicode () .join ([unichr (ord (char) - bstack11ll_opy_ - (bstack1l1l11_opy_ + bstack1111lll_opy_) % bstack11l1ll_opy_) for bstack1l1l11_opy_, char in enumerate (bstack1l11_opy_)])
    else:
        bstack1l1l1ll_opy_ = str () .join ([chr (ord (char) - bstack11ll_opy_ - (bstack1l1l11_opy_ + bstack1111lll_opy_) % bstack11l1ll_opy_) for bstack1l1l11_opy_, char in enumerate (bstack1l11_opy_)])
    return eval (bstack1l1l1ll_opy_)
import sys
class bstack1l1l11llll_opy_:
    def __init__(self, handler):
        self._1l1l11ll1l_opy_ = sys.stdout.write
        self._1l1l11lll1_opy_ = sys.stderr.write
        self.handler = handler
        self._started = False
    def start(self):
        if self._started:
            return
        self._started = True
        sys.stdout.write = self.bstack1l1l1l1111_opy_
        sys.stdout.error = self.bstack1l1l11ll11_opy_
    def bstack1l1l1l1111_opy_(self, _str):
        self._1l1l11ll1l_opy_(_str)
        if self.handler:
            self.handler({bstack11l1111_opy_ (u"࠭࡬ࡦࡸࡨࡰࠬစ"): bstack11l1111_opy_ (u"ࠧࡊࡐࡉࡓࠬဆ"), bstack11l1111_opy_ (u"ࠨ࡯ࡨࡷࡸࡧࡧࡦࠩဇ"): _str})
    def bstack1l1l11ll11_opy_(self, _str):
        self._1l1l11lll1_opy_(_str)
        if self.handler:
            self.handler({bstack11l1111_opy_ (u"ࠩ࡯ࡩࡻ࡫࡬ࠨဈ"): bstack11l1111_opy_ (u"ࠪࡉࡗࡘࡏࡓࠩဉ"), bstack11l1111_opy_ (u"ࠫࡲ࡫ࡳࡴࡣࡪࡩࠬည"): _str})
    def reset(self):
        if not self._started:
            return
        self._started = False
        sys.stdout.write = self._1l1l11ll1l_opy_
        sys.stderr.write = self._1l1l11lll1_opy_