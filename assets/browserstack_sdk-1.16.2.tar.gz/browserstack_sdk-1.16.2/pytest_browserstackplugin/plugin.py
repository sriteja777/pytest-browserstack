# coding: UTF-8
import sys
bstack1ll_opy_ = sys.version_info [0] == 2
bstack11ll_opy_ = 2048
bstack11l1ll_opy_ = 7
def bstack11l1111_opy_ (bstack1lll11_opy_):
    global bstack1lllll_opy_
    bstack1111lll_opy_ = ord (bstack1lll11_opy_ [-1])
    bstack1lll1l_opy_ = bstack1lll11_opy_ [:-1]
    bstack1llll1l_opy_ = bstack1111lll_opy_ % len (bstack1lll1l_opy_)
    bstack1l11_opy_ = bstack1lll1l_opy_ [:bstack1llll1l_opy_] + bstack1lll1l_opy_ [bstack1llll1l_opy_:]
    if bstack1ll_opy_:
        bstack1l1l1ll_opy_ = unicode () .join ([unichr (ord (char) - bstack11ll_opy_ - (bstack1l1l11_opy_ + bstack1111lll_opy_) % bstack11l1ll_opy_) for bstack1l1l11_opy_, char in enumerate (bstack1l11_opy_)])
    else:
        bstack1l1l1ll_opy_ = str () .join ([chr (ord (char) - bstack11ll_opy_ - (bstack1l1l11_opy_ + bstack1111lll_opy_) % bstack11l1ll_opy_) for bstack1l1l11_opy_, char in enumerate (bstack1l11_opy_)])
    return eval (bstack1l1l1ll_opy_)
import atexit
import datetime
import inspect
import logging
import os
import sys
import threading
from uuid import uuid4
import pytest
from packaging import version
from browserstack_sdk.__init__ import (bstack1l11111l_opy_, bstack11l1lll11_opy_, update, bstack1l11l1lll_opy_,
                                       bstack11l1lll1l_opy_, bstack1111111ll_opy_, bstack1111l11ll_opy_, bstack111lllll1_opy_,
                                       bstack1llll1lll1_opy_, bstack1lllll1l11_opy_, bstack111ll11l1_opy_, bstack1l1lll1ll_opy_,
                                       bstack1lll11ll1l_opy_)
from browserstack_sdk._version import __version__
from bstack_utils.capture import bstack1l1l11llll_opy_
from bstack_utils.constants import bstack1lll11l1l_opy_, bstack1l111lll_opy_, bstack1lll1ll1ll_opy_, bstack1ll1lll1l_opy_, \
    bstack1ll11l1l_opy_
from bstack_utils.helper import bstack1l1l11111l_opy_, bstack1l11llllll_opy_, bstack11l1ll1l1_opy_, bstack1l11ll1l1l_opy_, \
    bstack1l11ll1l11_opy_, bstack1lll1l1l1_opy_, bstack1111lll1_opy_, bstack1l11llll1l_opy_, bstack1l11lllll1_opy_, Notset, \
    bstack11ll11l1_opy_, bstack1l1lll111l_opy_
from bstack_utils.messages import bstack1lll1l11l1_opy_, bstack1llll111l1_opy_, bstack1111llll1_opy_, bstack1ll11l1l1_opy_, bstack1ll11ll1_opy_, \
    bstack1ll1l1llll_opy_, bstack1lll111l1_opy_, bstack1ll11ll1l_opy_, bstack1l1lll11_opy_, bstack1llllll11l_opy_, \
    bstack1l1l11ll_opy_, bstack11l1l111l_opy_
from bstack_utils.proxy import bstack1lll1l11ll_opy_, bstack1lll111l1l_opy_
from bstack_utils.bstack1ll1111l1l_opy_ import bstack1ll111111l_opy_
from bstack_utils.bstack1ll11ll111_opy_ import bstack1l1l1111l_opy_, bstack1111l11l_opy_, bstack11l1llll1_opy_
from bstack_utils.bstack1l1l111l_opy_ import bstack11ll1l11l_opy_
bstack111ll1lll_opy_ = None
bstack11l1l1l11_opy_ = None
bstack11llll111_opy_ = None
bstack1lllll1l1l_opy_ = None
bstack111l111l_opy_ = None
bstack11l1ll11l_opy_ = None
bstack1ll1l11l1l_opy_ = None
bstack1l111lll1_opy_ = None
bstack11ll1ll1l_opy_ = None
bstack11l1l1l1l_opy_ = None
bstack1l11ll11l_opy_ = None
bstack111llll1_opy_ = None
bstack1l1lll1l1_opy_ = None
bstack11lll11l1_opy_ = bstack11l1111_opy_ (u"࠭ࠧᄤ")
CONFIG = {}
bstack111lll1l_opy_ = False
bstack11ll1l1ll_opy_ = bstack11l1111_opy_ (u"ࠧࠨᄥ")
bstack1l1l11l1l_opy_ = bstack11l1111_opy_ (u"ࠨࠩᄦ")
bstack1lll1l1lll_opy_ = False
bstack1ll111111_opy_ = []
bstack1lll1l1ll_opy_ = bstack1l111lll_opy_
logger = logging.getLogger(__name__)
logging.basicConfig(level=bstack1lll1l1ll_opy_,
                    format=bstack11l1111_opy_ (u"ࠩ࡟ࡲࠪ࠮ࡡࡴࡥࡷ࡭ࡲ࡫ࠩࡴࠢ࡞ࠩ࠭ࡴࡡ࡮ࡧࠬࡷࡢࡡࠥࠩ࡮ࡨࡺࡪࡲ࡮ࡢ࡯ࡨ࠭ࡸࡣࠠ࠮ࠢࠨࠬࡲ࡫ࡳࡴࡣࡪࡩ࠮ࡹࠧᄧ"),
                    datefmt=bstack11l1111_opy_ (u"ࠪࠩࡍࡀࠥࡎ࠼ࠨࡗࠬᄨ"),
                    stream=sys.stdout)
def bstack1llll11l1_opy_():
    global CONFIG
    global bstack1lll1l1ll_opy_
    if bstack11l1111_opy_ (u"ࠫࡱࡵࡧࡍࡧࡹࡩࡱ࠭ᄩ") in CONFIG:
        bstack1lll1l1ll_opy_ = bstack1lll11l1l_opy_[CONFIG[bstack11l1111_opy_ (u"ࠬࡲ࡯ࡨࡎࡨࡺࡪࡲࠧᄪ")]]
        logging.getLogger().setLevel(bstack1lll1l1ll_opy_)
try:
    from playwright.sync_api import (
        BrowserContext,
        Page
    )
except:
    pass
import json
_1l11l11l1l_opy_ = {}
bstack1l1ll1l11l_opy_ = None
_1l111l1l1l_opy_ = {}
def bstack111l11l11_opy_(page, bstack1l11ll111_opy_):
    try:
        page.evaluate(bstack11l1111_opy_ (u"ࠨ࡟ࠡ࠿ࡁࠤࢀࢃࠢᄫ"),
                      bstack11l1111_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡥࡥࡹࡧࡦࡹࡹࡵࡲ࠻ࠢࡾࠦࡦࡩࡴࡪࡱࡱࠦ࠿ࠦࠢࡴࡧࡷࡗࡪࡹࡳࡪࡱࡱࡒࡦࡳࡥࠣ࠮ࠣࠦࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠢ࠻ࠢࡾࠦࡳࡧ࡭ࡦࠤ࠽ࠫᄬ") + json.dumps(
                          bstack1l11ll111_opy_) + bstack11l1111_opy_ (u"ࠣࡿࢀࠦᄭ"))
    except Exception as e:
        print(bstack11l1111_opy_ (u"ࠤࡨࡼࡨ࡫ࡰࡵ࡫ࡲࡲࠥ࡯࡮ࠡࡲ࡯ࡥࡾࡽࡲࡪࡩ࡫ࡸࠥࡹࡥࡴࡵ࡬ࡳࡳࠦ࡮ࡢ࡯ࡨࠤࢀࢃࠢᄮ"), e)
def bstack1l1ll1111_opy_(page, message, level):
    try:
        page.evaluate(bstack11l1111_opy_ (u"ࠥࡣࠥࡃ࠾ࠡࡽࢀࠦᄯ"), bstack11l1111_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡢࡩࡽ࡫ࡣࡶࡶࡲࡶ࠿ࠦࡻࠣࡣࡦࡸ࡮ࡵ࡮ࠣ࠼ࠣࠦࡦࡴ࡮ࡰࡶࡤࡸࡪࠨࠬࠡࠤࡤࡶ࡬ࡻ࡭ࡦࡰࡷࡷࠧࡀࠠࡼࠤࡧࡥࡹࡧࠢ࠻ࠩᄰ") + json.dumps(
            message) + bstack11l1111_opy_ (u"ࠬ࠲ࠢ࡭ࡧࡹࡩࡱࠨ࠺ࠨᄱ") + json.dumps(level) + bstack11l1111_opy_ (u"࠭ࡽࡾࠩᄲ"))
    except Exception as e:
        print(bstack11l1111_opy_ (u"ࠢࡦࡺࡦࡩࡵࡺࡩࡰࡰࠣ࡭ࡳࠦࡰ࡭ࡣࡼࡻࡷ࡯ࡧࡩࡶࠣࡥࡳࡴ࡯ࡵࡣࡷ࡭ࡴࡴࠠࡼࡿࠥᄳ"), e)
def bstack1ll1l1l1l1_opy_(page, status, message=bstack11l1111_opy_ (u"ࠣࠤᄴ")):
    try:
        if (status == bstack11l1111_opy_ (u"ࠤࡩࡥ࡮ࡲࡥࡥࠤᄵ")):
            page.evaluate(bstack11l1111_opy_ (u"ࠥࡣࠥࡃ࠾ࠡࡽࢀࠦᄶ"),
                          bstack11l1111_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡢࡩࡽ࡫ࡣࡶࡶࡲࡶ࠿ࠦࡻࠣࡣࡦࡸ࡮ࡵ࡮ࠣ࠼ࠣࠦࡸ࡫ࡴࡔࡧࡶࡷ࡮ࡵ࡮ࡔࡶࡤࡸࡺࡹࠢ࠭ࠢࠥࡥࡷ࡭ࡵ࡮ࡧࡱࡸࡸࠨ࠺ࠡࡽࠥࡶࡪࡧࡳࡰࡰࠥ࠾ࠬᄷ") + json.dumps(
                              bstack11l1111_opy_ (u"࡙ࠧࡣࡦࡰࡤࡶ࡮ࡵࠠࡧࡣ࡬ࡰࡪࡪࠠࡸ࡫ࡷ࡬࠿ࠦࠢᄸ") + str(message)) + bstack11l1111_opy_ (u"࠭ࠬࠣࡵࡷࡥࡹࡻࡳࠣ࠼ࠪᄹ") + json.dumps(status) + bstack11l1111_opy_ (u"ࠢࡾࡿࠥᄺ"))
        else:
            page.evaluate(bstack11l1111_opy_ (u"ࠣࡡࠣࡁࡃࠦࡻࡾࠤᄻ"),
                          bstack11l1111_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡠࡧࡻࡩࡨࡻࡴࡰࡴ࠽ࠤࢀࠨࡡࡤࡶ࡬ࡳࡳࠨ࠺ࠡࠤࡶࡩࡹ࡙ࡥࡴࡵ࡬ࡳࡳ࡙ࡴࡢࡶࡸࡷࠧ࠲ࠠࠣࡣࡵ࡫ࡺࡳࡥ࡯ࡶࡶࠦ࠿ࠦࡻࠣࡵࡷࡥࡹࡻࡳࠣ࠼ࠪᄼ") + json.dumps(
                              status) + bstack11l1111_opy_ (u"ࠥࢁࢂࠨᄽ"))
    except Exception as e:
        print(bstack11l1111_opy_ (u"ࠦࡪࡾࡣࡦࡲࡷ࡭ࡴࡴࠠࡪࡰࠣࡴࡱࡧࡹࡸࡴ࡬࡫࡭ࡺࠠࡴࡧࡷࠤࡸ࡫ࡳࡴ࡫ࡲࡲࠥࡹࡴࡢࡶࡸࡷࠥࢁࡽࠣᄾ"), e)
def pytest_configure(config):
    config.args = bstack11ll1l11l_opy_.bstack1l1l1ll111_opy_(config.args)
@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    bstack1l11l111ll_opy_ = item.config.getoption(bstack11l1111_opy_ (u"ࠬࡹ࡫ࡪࡲࡖࡩࡸࡹࡩࡰࡰࡑࡥࡲ࡫ࠧᄿ"))
    plugins = item.config.getoption(bstack11l1111_opy_ (u"ࠨࡰ࡭ࡷࡪ࡭ࡳࡹࠢᅀ"))
    report = outcome.get_result()
    bstack1l11l111l1_opy_(item, call, report)
    if bstack11l1111_opy_ (u"ࠢࡱࡻࡷࡩࡸࡺ࡟ࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡶ࡬ࡶࡩ࡬ࡲࠧᅁ") not in plugins or bstack1l11lllll1_opy_():
        return
    summary = []
    driver = getattr(item, bstack11l1111_opy_ (u"ࠣࡡࡧࡶ࡮ࡼࡥࡳࠤᅂ"), None)
    page = getattr(item, bstack11l1111_opy_ (u"ࠤࡢࡴࡦ࡭ࡥࠣᅃ"), None)
    try:
        if (driver == None):
            driver = threading.current_thread().bstackSessionDriver
    except:
        pass
    item._driver = driver
    if (driver is not None):
        bstack1l111lllll_opy_(item, report, summary, bstack1l11l111ll_opy_)
    if (page is not None):
        bstack1l11l1l111_opy_(item, report, summary, bstack1l11l111ll_opy_)
def bstack1l111lllll_opy_(item, report, summary, bstack1l11l111ll_opy_):
    if report.when in [bstack11l1111_opy_ (u"ࠥࡷࡪࡺࡵࡱࠤᅄ"), bstack11l1111_opy_ (u"ࠦࡹ࡫ࡡࡳࡦࡲࡻࡳࠨᅅ")]:
        return
    if not bstack1l11llllll_opy_():
        return
    if (str(bstack1l11l111ll_opy_).lower() != bstack11l1111_opy_ (u"ࠬࡺࡲࡶࡧࠪᅆ")):
        item._driver.execute_script(
            bstack11l1111_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡤ࡫ࡸࡦࡥࡸࡸࡴࡸ࠺ࠡࡽࠥࡥࡨࡺࡩࡰࡰࠥ࠾ࠥࠨࡳࡦࡶࡖࡩࡸࡹࡩࡰࡰࡑࡥࡲ࡫ࠢ࠭ࠢࠥࡥࡷ࡭ࡵ࡮ࡧࡱࡸࡸࠨ࠺ࠡࡽࠥࡲࡦࡳࡥࠣ࠼ࠣࠫᅇ") + json.dumps(
                report.nodeid) + bstack11l1111_opy_ (u"ࠧࡾࡿࠪᅈ"))
    passed = report.passed or (report.failed and hasattr(report, bstack11l1111_opy_ (u"ࠣࡹࡤࡷࡽ࡬ࡡࡪ࡮ࠥᅉ")))
    bstack1lll1l111l_opy_ = bstack11l1111_opy_ (u"ࠤࠥᅊ")
    if not passed:
        try:
            bstack1lll1l111l_opy_ = report.longrepr.reprcrash
        except Exception as e:
            summary.append(
                bstack11l1111_opy_ (u"࡛ࠥࡆࡘࡎࡊࡐࡊ࠾ࠥࡌࡡࡪ࡮ࡨࡨࠥࡺ࡯ࠡࡦࡨࡸࡪࡸ࡭ࡪࡰࡨࠤ࡫ࡧࡩ࡭ࡷࡵࡩࠥࡸࡥࡢࡵࡲࡲ࠿ࠦࡻ࠱ࡿࠥᅋ").format(e)
            )
    if (bstack1lll1l111l_opy_ != bstack11l1111_opy_ (u"ࠦࠧᅌ")):
        try:
            if (threading.current_thread().bstackTestErrorMessages == None):
                threading.current_thread().bstackTestErrorMessages = []
        except Exception as e:
            threading.current_thread().bstackTestErrorMessages = []
        threading.current_thread().bstackTestErrorMessages.append(str(bstack1lll1l111l_opy_))
    try:
        if (passed):
            item._driver.execute_script(
                bstack11l1111_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡣࡪࡾࡥࡤࡷࡷࡳࡷࡀࠠࡼ࡞ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠢࡢࡥࡷ࡭ࡴࡴࠢ࠻ࠢࠥࡥࡳࡴ࡯ࡵࡣࡷࡩࠧ࠲ࠠ࡝ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠨࡡࡳࡩࡸࡱࡪࡴࡴࡴࠤ࠽ࠤࢀࡢࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠣ࡮ࡨࡺࡪࡲࠢ࠻ࠢࠥ࡭ࡳ࡬࡯ࠣ࠮ࠣࡠࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠨࡤࡢࡶࡤࠦ࠿ࠦࠧᅍ")
                + json.dumps(bstack11l1111_opy_ (u"ࠨࡰࡢࡵࡶࡩࡩࠧࠢᅎ"))
                + bstack11l1111_opy_ (u"ࠢ࡝ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࢃ࡜ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࡾࠤᅏ")
            )
        else:
            item._driver.execute_script(
                bstack11l1111_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࡟ࡦࡺࡨࡧࡺࡺ࡯ࡳ࠼ࠣࡿࡡࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠥࡥࡨࡺࡩࡰࡰࠥ࠾ࠥࠨࡡ࡯ࡰࡲࡸࡦࡺࡥࠣ࠮ࠣࡠࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠤࡤࡶ࡬ࡻ࡭ࡦࡰࡷࡷࠧࡀࠠࡼ࡞ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠦࡱ࡫ࡶࡦ࡮ࠥ࠾ࠥࠨࡥࡳࡴࡲࡶࠧ࠲ࠠ࡝ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠥࡨࡦࡺࡡࠣ࠼ࠣࠫᅐ")
                + json.dumps(str(bstack1lll1l111l_opy_))
                + bstack11l1111_opy_ (u"ࠤ࡟ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࡾ࡞ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࢀࠦᅑ")
            )
    except Exception as e:
        summary.append(bstack11l1111_opy_ (u"࡛ࠥࡆࡘࡎࡊࡐࡊ࠾ࠥࡌࡡࡪ࡮ࡨࡨࠥࡺ࡯ࠡࡣࡱࡲࡴࡺࡡࡵࡧ࠽ࠤࢀ࠶ࡽࠣᅒ").format(e))
def bstack1l11l1l111_opy_(item, report, summary, bstack1l11l111ll_opy_):
    if report.when in [bstack11l1111_opy_ (u"ࠦࡸ࡫ࡴࡶࡲࠥᅓ"), bstack11l1111_opy_ (u"ࠧࡺࡥࡢࡴࡧࡳࡼࡴࠢᅔ")]:
        return
    if (str(bstack1l11l111ll_opy_).lower() != bstack11l1111_opy_ (u"࠭ࡴࡳࡷࡨࠫᅕ")):
        bstack111l11l11_opy_(item._page, report.nodeid)
    passed = report.passed or (report.failed and hasattr(report, bstack11l1111_opy_ (u"ࠢࡸࡣࡶࡼ࡫ࡧࡩ࡭ࠤᅖ")))
    bstack1lll1l111l_opy_ = bstack11l1111_opy_ (u"ࠣࠤᅗ")
    if not passed:
        try:
            bstack1lll1l111l_opy_ = report.longrepr.reprcrash
        except Exception as e:
            summary.append(
                bstack11l1111_opy_ (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉ࠽ࠤࡋࡧࡩ࡭ࡧࡧࠤࡹࡵࠠࡥࡧࡷࡩࡷࡳࡩ࡯ࡧࠣࡪࡦ࡯࡬ࡶࡴࡨࠤࡷ࡫ࡡࡴࡱࡱ࠾ࠥࢁ࠰ࡾࠤᅘ").format(e)
            )
    try:
        if passed:
            bstack1ll1l1l1l1_opy_(item._page, bstack11l1111_opy_ (u"ࠥࡴࡦࡹࡳࡦࡦࠥᅙ"))
        else:
            if bstack1lll1l111l_opy_:
                bstack1l1ll1111_opy_(item._page, str(bstack1lll1l111l_opy_), bstack11l1111_opy_ (u"ࠦࡪࡸࡲࡰࡴࠥᅚ"))
                bstack1ll1l1l1l1_opy_(item._page, bstack11l1111_opy_ (u"ࠧ࡬ࡡࡪ࡮ࡨࡨࠧᅛ"), str(bstack1lll1l111l_opy_))
            else:
                bstack1ll1l1l1l1_opy_(item._page, bstack11l1111_opy_ (u"ࠨࡦࡢ࡫࡯ࡩࡩࠨᅜ"))
    except Exception as e:
        summary.append(bstack11l1111_opy_ (u"ࠢࡘࡃࡕࡒࡎࡔࡇ࠻ࠢࡉࡥ࡮ࡲࡥࡥࠢࡷࡳࠥࡻࡰࡥࡣࡷࡩࠥࡹࡥࡴࡵ࡬ࡳࡳࠦࡳࡵࡣࡷࡹࡸࡀࠠࡼ࠲ࢀࠦᅝ").format(e))
try:
    from typing import Generator
    import pytest_playwright.pytest_playwright as p
    @pytest.fixture
    def page(context: BrowserContext, request: pytest.FixtureRequest) -> Generator[Page, None, None]:
        page = context.new_page()
        request.node._page = page
        yield page
except:
    pass
def pytest_addoption(parser):
    parser.addoption(bstack11l1111_opy_ (u"ࠣ࠯࠰ࡷࡰ࡯ࡰࡔࡧࡶࡷ࡮ࡵ࡮ࡏࡣࡰࡩࠧᅞ"), default=bstack11l1111_opy_ (u"ࠤࡉࡥࡱࡹࡥࠣᅟ"), help=bstack11l1111_opy_ (u"ࠥࡅࡺࡺ࡯࡮ࡣࡷ࡭ࡨࠦࡳࡦࡶࠣࡷࡪࡹࡳࡪࡱࡱࠤࡳࡧ࡭ࡦࠤᅠ"))
    try:
        import pytest_selenium.pytest_selenium
    except:
        parser.addoption(bstack11l1111_opy_ (u"ࠦ࠲࠳ࡤࡳ࡫ࡹࡩࡷࠨᅡ"), action=bstack11l1111_opy_ (u"ࠧࡹࡴࡰࡴࡨࠦᅢ"), default=bstack11l1111_opy_ (u"ࠨࡣࡩࡴࡲࡱࡪࠨᅣ"),
                         help=bstack11l1111_opy_ (u"ࠢࡅࡴ࡬ࡺࡪࡸࠠࡵࡱࠣࡶࡺࡴࠠࡵࡧࡶࡸࡸࠨᅤ"))
def bstack1l111ll1ll_opy_(log):
    if log[bstack11l1111_opy_ (u"ࠨ࡯ࡨࡷࡸࡧࡧࡦࠩᅥ")] == bstack11l1111_opy_ (u"ࠩ࡟ࡲࠬᅦ"):
        return
    bstack11ll1l11l_opy_.bstack1l1llll1ll_opy_([{
        bstack11l1111_opy_ (u"ࠪࡰࡪࡼࡥ࡭ࠩᅧ"): log[bstack11l1111_opy_ (u"ࠫࡱ࡫ࡶࡦ࡮ࠪᅨ")],
        bstack11l1111_opy_ (u"ࠬࡺࡩ࡮ࡧࡶࡸࡦࡳࡰࠨᅩ"): datetime.datetime.utcnow().isoformat() + bstack11l1111_opy_ (u"࡚࠭ࠨᅪ"),
        bstack11l1111_opy_ (u"ࠧ࡮ࡧࡶࡷࡦ࡭ࡥࠨᅫ"): log[bstack11l1111_opy_ (u"ࠨ࡯ࡨࡷࡸࡧࡧࡦࠩᅬ")],
        bstack11l1111_opy_ (u"ࠩࡷࡩࡸࡺ࡟ࡳࡷࡱࡣࡺࡻࡩࡥࠩᅭ"): bstack1l1ll1l11l_opy_
    }])
bstack1l111llll1_opy_ = bstack1l1l11llll_opy_(bstack1l111ll1ll_opy_)
def pytest_runtest_call(item):
    try:
        if not bstack11ll1l11l_opy_.on():
            return
        global bstack1l1ll1l11l_opy_, bstack1l111llll1_opy_
        bstack1l111llll1_opy_.start()
        bstack1l11l1l11l_opy_ = {
            bstack11l1111_opy_ (u"ࠪࡹࡺ࡯ࡤࠨᅮ"): uuid4().__str__(),
            bstack11l1111_opy_ (u"ࠫࡸࡺࡡࡳࡶࡨࡨࡤࡧࡴࠨᅯ"): datetime.datetime.utcnow().isoformat() + bstack11l1111_opy_ (u"ࠬࡠࠧᅰ")
        }
        bstack1l1ll1l11l_opy_ = bstack1l11l1l11l_opy_[bstack11l1111_opy_ (u"࠭ࡵࡶ࡫ࡧࠫᅱ")]
        threading.current_thread().bstack1l1ll1l11l_opy_ = bstack1l1ll1l11l_opy_
        _1l11l11l1l_opy_[item.nodeid] = {**_1l11l11l1l_opy_[item.nodeid], **bstack1l11l1l11l_opy_}
        bstack1l111lll1l_opy_(item, _1l11l11l1l_opy_[item.nodeid], bstack11l1111_opy_ (u"ࠧࡕࡧࡶࡸࡗࡻ࡮ࡔࡶࡤࡶࡹ࡫ࡤࠨᅲ"))
    except Exception as err:
        print(bstack11l1111_opy_ (u"ࠨࡇࡻࡧࡪࡶࡴࡪࡱࡱࠤ࡮ࡴࠠࡱࡻࡷࡩࡸࡺ࡟ࡳࡷࡱࡸࡪࡹࡴࡠࡥࡤࡰࡱࡀࠠࡼࡿࠪᅳ"), str(err))
def pytest_runtest_setup(item):
    if bstack1l11llll1l_opy_():
        atexit.register(bstack111111l1_opy_)
    try:
        if not bstack11ll1l11l_opy_.on():
            return
        uuid = uuid4().__str__()
        bstack1l11l1l11l_opy_ = {
            bstack11l1111_opy_ (u"ࠩࡸࡹ࡮ࡪࠧᅴ"): uuid,
            bstack11l1111_opy_ (u"ࠪࡷࡹࡧࡲࡵࡧࡧࡣࡦࡺࠧᅵ"): datetime.datetime.utcnow().isoformat() + bstack11l1111_opy_ (u"ࠫ࡟࠭ᅶ"),
            bstack11l1111_opy_ (u"ࠬࡺࡹࡱࡧࠪᅷ"): bstack11l1111_opy_ (u"࠭ࡨࡰࡱ࡮ࠫᅸ"),
            bstack11l1111_opy_ (u"ࠧࡩࡱࡲ࡯ࡤࡺࡹࡱࡧࠪᅹ"): bstack11l1111_opy_ (u"ࠨࡄࡈࡊࡔࡘࡅࡠࡇࡄࡇࡍ࠭ᅺ")
        }
        threading.current_thread().bstack1l111ll1l1_opy_ = uuid
        if not _1l11l11l1l_opy_.get(item.nodeid, None):
            _1l11l11l1l_opy_[item.nodeid] = {bstack11l1111_opy_ (u"ࠩ࡫ࡳࡴࡱࡳࠨᅻ"): []}
        _1l11l11l1l_opy_[item.nodeid][bstack11l1111_opy_ (u"ࠪ࡬ࡴࡵ࡫ࡴࠩᅼ")].append(bstack1l11l1l11l_opy_[bstack11l1111_opy_ (u"ࠫࡺࡻࡩࡥࠩᅽ")])
        _1l11l11l1l_opy_[item.nodeid + bstack11l1111_opy_ (u"ࠬ࠳ࡳࡦࡶࡸࡴࠬᅾ")] = bstack1l11l1l11l_opy_
        bstack1l11l1111l_opy_(item, bstack1l11l1l11l_opy_, bstack11l1111_opy_ (u"࠭ࡈࡰࡱ࡮ࡖࡺࡴࡓࡵࡣࡵࡸࡪࡪࠧᅿ"))
    except Exception as err:
        print(bstack11l1111_opy_ (u"ࠧࡆࡺࡦࡩࡵࡺࡩࡰࡰࠣ࡭ࡳࠦࡰࡺࡶࡨࡷࡹࡥࡲࡶࡰࡷࡩࡸࡺ࡟ࡴࡧࡷࡹࡵࡀࠠࡼࡿࠪᆀ"), str(err))
def pytest_runtest_teardown(item):
    try:
        if not bstack11ll1l11l_opy_.on():
            return
        bstack1l11l1l11l_opy_ = {
            bstack11l1111_opy_ (u"ࠨࡷࡸ࡭ࡩ࠭ᆁ"): uuid4().__str__(),
            bstack11l1111_opy_ (u"ࠩࡶࡸࡦࡸࡴࡦࡦࡢࡥࡹ࠭ᆂ"): datetime.datetime.utcnow().isoformat() + bstack11l1111_opy_ (u"ࠪ࡞ࠬᆃ"),
            bstack11l1111_opy_ (u"ࠫࡹࡿࡰࡦࠩᆄ"): bstack11l1111_opy_ (u"ࠬ࡮࡯ࡰ࡭ࠪᆅ"),
            bstack11l1111_opy_ (u"࠭ࡨࡰࡱ࡮ࡣࡹࡿࡰࡦࠩᆆ"): bstack11l1111_opy_ (u"ࠧࡂࡈࡗࡉࡗࡥࡅࡂࡅࡋࠫᆇ")
        }
        _1l11l11l1l_opy_[item.nodeid + bstack11l1111_opy_ (u"ࠨ࠯ࡷࡩࡦࡸࡤࡰࡹࡱࠫᆈ")] = bstack1l11l1l11l_opy_
        bstack1l11l1111l_opy_(item, bstack1l11l1l11l_opy_, bstack11l1111_opy_ (u"ࠩࡋࡳࡴࡱࡒࡶࡰࡖࡸࡦࡸࡴࡦࡦࠪᆉ"))
    except Exception as err:
        print(bstack11l1111_opy_ (u"ࠪࡉࡽࡩࡥࡱࡶ࡬ࡳࡳࠦࡩ࡯ࠢࡳࡽࡹ࡫ࡳࡵࡡࡵࡹࡳࡺࡥࡴࡶࡢࡸࡪࡧࡲࡥࡱࡺࡲ࠿ࠦࡻࡾࠩᆊ"), str(err))
@pytest.hookimpl(hookwrapper=True)
def pytest_fixture_setup(fixturedef):
    start_time = datetime.datetime.now()
    outcome = yield
    try:
        if not bstack11ll1l11l_opy_.on():
            return
        bstack1l111l1l11_opy_ = threading.current_thread().bstack1l111ll1l1_opy_
        log = {
            bstack11l1111_opy_ (u"ࠫࡰ࡯࡮ࡥࠩᆋ"): bstack11l1111_opy_ (u"࡚ࠬࡅࡔࡖࡢࡗ࡙ࡋࡐࠨᆌ"),
            bstack11l1111_opy_ (u"࠭࡭ࡦࡵࡶࡥ࡬࡫ࠧᆍ"): fixturedef.argname,
            bstack11l1111_opy_ (u"ࠧࡩࡱࡲ࡯ࡤࡸࡵ࡯ࡡࡸࡹ࡮ࡪࠧᆎ"): threading.current_thread().bstack1l111ll1l1_opy_,
            bstack11l1111_opy_ (u"ࠨࡶ࡬ࡱࡪࡹࡴࡢ࡯ࡳࠫᆏ"): bstack11l1ll1l1_opy_(),
            bstack11l1111_opy_ (u"ࠩ࡯ࡩࡻ࡫࡬ࠨᆐ"): bstack1l11ll1l1l_opy_(outcome),
            bstack11l1111_opy_ (u"ࠪࡨࡺࡸࡡࡵ࡫ࡲࡲࠬᆑ"): (datetime.datetime.now() - start_time).total_seconds() * 1000,
        }
        if log[bstack11l1111_opy_ (u"ࠫࡱ࡫ࡶࡦ࡮ࠪᆒ")] == bstack11l1111_opy_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬᆓ"):
            log[bstack11l1111_opy_ (u"࠭ࡦࡢ࡫࡯ࡹࡷ࡫࡟ࡵࡻࡳࡩࠬᆔ")] = bstack11l1111_opy_ (u"ࠧࡖࡰ࡫ࡥࡳࡪ࡬ࡦࡦࡈࡶࡷࡵࡲࠨᆕ")
            log[bstack11l1111_opy_ (u"ࠨࡨࡤ࡭ࡱࡻࡲࡦࠩᆖ")] = outcome.exception.__str__()
        if not _1l111l1l1l_opy_.get(bstack1l111l1l11_opy_, None):
            _1l111l1l1l_opy_[bstack1l111l1l11_opy_] = []
        _1l111l1l1l_opy_[bstack1l111l1l11_opy_].append(log)
    except Exception as err:
        print(bstack11l1111_opy_ (u"ࠩࡈࡼࡨ࡫ࡰࡵ࡫ࡲࡲࠥ࡯࡮ࠡࡲࡼࡸࡪࡹࡴࡠࡨ࡬ࡼࡹࡻࡲࡦࡡࡶࡩࡹࡻࡰ࠻ࠢࡾࢁࠬᆗ"), str(err))
@bstack11ll1l11l_opy_.bstack1l1l1ll1l1_opy_
def bstack1l11l111l1_opy_(item, call, report):
    try:
        if report.when == bstack11l1111_opy_ (u"ࠪࡧࡦࡲ࡬ࠨᆘ"):
            bstack1l111llll1_opy_.reset()
        if report.when == bstack11l1111_opy_ (u"ࠫࡨࡧ࡬࡭ࠩᆙ"):
            _1l11l11l1l_opy_[item.nodeid][bstack11l1111_opy_ (u"ࠬ࡬ࡩ࡯࡫ࡶ࡬ࡪࡪ࡟ࡢࡶࠪᆚ")] = datetime.datetime.utcfromtimestamp(report.stop).isoformat() + bstack11l1111_opy_ (u"࡚࠭ࠨᆛ")
            bstack1l111lll1l_opy_(item, _1l11l11l1l_opy_[item.nodeid], bstack11l1111_opy_ (u"ࠧࡕࡧࡶࡸࡗࡻ࡮ࡇ࡫ࡱ࡭ࡸ࡮ࡥࡥࠩᆜ"), report, call)
        elif report.when in [bstack11l1111_opy_ (u"ࠨࡵࡨࡸࡺࡶࠧᆝ"), bstack11l1111_opy_ (u"ࠩࡷࡩࡦࡸࡤࡰࡹࡱࠫᆞ")]:
            bstack1l11l11l11_opy_ = item.nodeid + bstack11l1111_opy_ (u"ࠪ࠱ࠬᆟ") + report.when
            if report.skipped:
                hook_type = bstack11l1111_opy_ (u"ࠫࡇࡋࡆࡐࡔࡈࡣࡊࡇࡃࡉࠩᆠ") if report.when == bstack11l1111_opy_ (u"ࠬࡹࡥࡵࡷࡳࠫᆡ") else bstack11l1111_opy_ (u"࠭ࡁࡇࡖࡈࡖࡤࡋࡁࡄࡊࠪᆢ")
                _1l11l11l1l_opy_[bstack1l11l11l11_opy_] = {
                    bstack11l1111_opy_ (u"ࠧࡶࡷ࡬ࡨࠬᆣ"): uuid4().__str__(),
                    bstack11l1111_opy_ (u"ࠨࡵࡷࡥࡷࡺࡥࡥࡡࡤࡸࠬᆤ"): datetime.datetime.utcfromtimestamp(report.start).isoformat() + bstack11l1111_opy_ (u"ࠩ࡝ࠫᆥ"),
                    bstack11l1111_opy_ (u"ࠪ࡬ࡴࡵ࡫ࡠࡶࡼࡴࡪ࠭ᆦ"): hook_type
                }
            _1l11l11l1l_opy_[bstack1l11l11l11_opy_][bstack11l1111_opy_ (u"ࠫ࡫࡯࡮ࡪࡵ࡫ࡩࡩࡥࡡࡵࠩᆧ")] = datetime.datetime.utcfromtimestamp(report.stop).isoformat() + bstack11l1111_opy_ (u"ࠬࡠࠧᆨ")
            if report.when == bstack11l1111_opy_ (u"࠭ࡳࡦࡶࡸࡴࠬᆩ"):
                bstack1l111l1l11_opy_ = _1l11l11l1l_opy_[bstack1l11l11l11_opy_][bstack11l1111_opy_ (u"ࠧࡶࡷ࡬ࡨࠬᆪ")]
                if _1l111l1l1l_opy_.get(bstack1l111l1l11_opy_, None):
                    bstack11ll1l11l_opy_.bstack1l1lll11l1_opy_(_1l111l1l1l_opy_[bstack1l111l1l11_opy_])
            bstack1l11l1111l_opy_(item, _1l11l11l1l_opy_[bstack1l11l11l11_opy_], bstack11l1111_opy_ (u"ࠨࡊࡲࡳࡰࡘࡵ࡯ࡈ࡬ࡲ࡮ࡹࡨࡦࡦࠪᆫ"), report, call)
            if report.when == bstack11l1111_opy_ (u"ࠩࡶࡩࡹࡻࡰࠨᆬ"):
                if report.outcome == bstack11l1111_opy_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪᆭ"):
                    bstack1l11l1l11l_opy_ = {
                        bstack11l1111_opy_ (u"ࠫࡺࡻࡩࡥࠩᆮ"): uuid4().__str__(),
                        bstack11l1111_opy_ (u"ࠬࡹࡴࡢࡴࡷࡩࡩࡥࡡࡵࠩᆯ"): bstack11l1ll1l1_opy_(),
                        bstack11l1111_opy_ (u"࠭ࡦࡪࡰ࡬ࡷ࡭࡫ࡤࡠࡣࡷࠫᆰ"): bstack11l1ll1l1_opy_()
                    }
                    _1l11l11l1l_opy_[item.nodeid] = {**_1l11l11l1l_opy_[item.nodeid], **bstack1l11l1l11l_opy_}
                    bstack1l111lll1l_opy_(item, _1l11l11l1l_opy_[item.nodeid], bstack11l1111_opy_ (u"ࠧࡕࡧࡶࡸࡗࡻ࡮ࡔࡶࡤࡶࡹ࡫ࡤࠨᆱ"))
                    bstack1l111lll1l_opy_(item, _1l11l11l1l_opy_[item.nodeid], bstack11l1111_opy_ (u"ࠨࡖࡨࡷࡹࡘࡵ࡯ࡈ࡬ࡲ࡮ࡹࡨࡦࡦࠪᆲ"), report, call)
    except Exception as err:
        print(bstack11l1111_opy_ (u"ࠩࡈࡼࡨ࡫ࡰࡵ࡫ࡲࡲࠥ࡯࡮ࠡࡪࡤࡲࡩࡲࡥࡠࡱ࠴࠵ࡾࡥࡴࡦࡵࡷࡣࡪࡼࡥ࡯ࡶ࠽ࠤࢀࢃࠧᆳ"), str(err))
def bstack1l11l11ll1_opy_(test, bstack1l11l1l11l_opy_, result=None, call=None, bstack1lll111lll_opy_=None):
    file_path = os.path.relpath(test.fspath.strpath, start=os.getcwd())
    bstack1l111ll11l_opy_ = {
        bstack11l1111_opy_ (u"ࠪࡹࡺ࡯ࡤࠨᆴ"): bstack1l11l1l11l_opy_[bstack11l1111_opy_ (u"ࠫࡺࡻࡩࡥࠩᆵ")],
        bstack11l1111_opy_ (u"ࠬࡺࡹࡱࡧࠪᆶ"): bstack11l1111_opy_ (u"࠭ࡴࡦࡵࡷࠫᆷ"),
        bstack11l1111_opy_ (u"ࠧ࡯ࡣࡰࡩࠬᆸ"): test.name,
        bstack11l1111_opy_ (u"ࠨࡤࡲࡨࡾ࠭ᆹ"): {
            bstack11l1111_opy_ (u"ࠩ࡯ࡥࡳ࡭ࠧᆺ"): bstack11l1111_opy_ (u"ࠪࡴࡾࡺࡨࡰࡰࠪᆻ"),
            bstack11l1111_opy_ (u"ࠫࡨࡵࡤࡦࠩᆼ"): inspect.getsource(test.obj)
        },
        bstack11l1111_opy_ (u"ࠬ࡯ࡤࡦࡰࡷ࡭࡫࡯ࡥࡳࠩᆽ"): test.name,
        bstack11l1111_opy_ (u"࠭ࡳࡤࡱࡳࡩࠬᆾ"): test.name,
        bstack11l1111_opy_ (u"ࠧࡴࡥࡲࡴࡪࡹࠧᆿ"): bstack11ll1l11l_opy_.bstack1l1l1llll1_opy_(test),
        bstack11l1111_opy_ (u"ࠨࡨ࡬ࡰࡪࡥ࡮ࡢ࡯ࡨࠫᇀ"): file_path,
        bstack11l1111_opy_ (u"ࠩ࡯ࡳࡨࡧࡴࡪࡱࡱࠫᇁ"): file_path,
        bstack11l1111_opy_ (u"ࠪࡶࡪࡹࡵ࡭ࡶࠪᇂ"): bstack11l1111_opy_ (u"ࠫࡵ࡫࡮ࡥ࡫ࡱ࡫ࠬᇃ"),
        bstack11l1111_opy_ (u"ࠬࡼࡣࡠࡨ࡬ࡰࡪࡶࡡࡵࡪࠪᇄ"): file_path,
        bstack11l1111_opy_ (u"࠭ࡳࡵࡣࡵࡸࡪࡪ࡟ࡢࡶࠪᇅ"): bstack1l11l1l11l_opy_[bstack11l1111_opy_ (u"ࠧࡴࡶࡤࡶࡹ࡫ࡤࡠࡣࡷࠫᇆ")],
        bstack11l1111_opy_ (u"ࠨࡨࡵࡥࡲ࡫ࡷࡰࡴ࡮ࠫᇇ"): bstack11l1111_opy_ (u"ࠩࡓࡽࡹ࡫ࡳࡵࠩᇈ"),
        bstack11l1111_opy_ (u"ࠪࡧࡺࡹࡴࡰ࡯ࡕࡩࡷࡻ࡮ࡑࡣࡵࡥࡲ࠭ᇉ"): {
            bstack11l1111_opy_ (u"ࠫࡷ࡫ࡲࡶࡰࡢࡲࡦࡳࡥࠨᇊ"): test.nodeid
        },
        bstack11l1111_opy_ (u"ࠬࡺࡡࡨࡵࠪᇋ"): bstack1l11ll1l11_opy_(test.own_markers)
    }
    if bstack1lll111lll_opy_ == bstack11l1111_opy_ (u"࠭ࡔࡦࡵࡷࡖࡺࡴࡓ࡬࡫ࡳࡴࡪࡪࠧᇌ"):
        bstack1l111ll11l_opy_[bstack11l1111_opy_ (u"ࠧࡳࡧࡶࡹࡱࡺࠧᇍ")] = bstack11l1111_opy_ (u"ࠨࡵ࡮࡭ࡵࡶࡥࡥࠩᇎ")
        bstack1l111ll11l_opy_[bstack11l1111_opy_ (u"ࠩ࡫ࡳࡴࡱࡳࠨᇏ")] = bstack1l11l1l11l_opy_[bstack11l1111_opy_ (u"ࠪ࡬ࡴࡵ࡫ࡴࠩᇐ")]
        bstack1l111ll11l_opy_[bstack11l1111_opy_ (u"ࠫ࡫࡯࡮ࡪࡵ࡫ࡩࡩࡥࡡࡵࠩᇑ")] = bstack1l11l1l11l_opy_[bstack11l1111_opy_ (u"ࠬ࡬ࡩ࡯࡫ࡶ࡬ࡪࡪ࡟ࡢࡶࠪᇒ")]
    if result:
        bstack1l111ll11l_opy_[bstack11l1111_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭ᇓ")] = result.outcome
        bstack1l111ll11l_opy_[bstack11l1111_opy_ (u"ࠧࡥࡷࡵࡥࡹ࡯࡯࡯ࡡ࡬ࡲࡤࡳࡳࠨᇔ")] = result.duration * 1000
        bstack1l111ll11l_opy_[bstack11l1111_opy_ (u"ࠨࡨ࡬ࡲ࡮ࡹࡨࡦࡦࡢࡥࡹ࠭ᇕ")] = bstack1l11l1l11l_opy_[bstack11l1111_opy_ (u"ࠩࡩ࡭ࡳ࡯ࡳࡩࡧࡧࡣࡦࡺࠧᇖ")]
        if result.failed:
            bstack1l111ll11l_opy_[bstack11l1111_opy_ (u"ࠪࡪࡦ࡯࡬ࡶࡴࡨࡣࡹࡿࡰࡦࠩᇗ")] = bstack11ll1l11l_opy_.bstack1l1llll111_opy_(call.excinfo.typename)
            bstack1l111ll11l_opy_[bstack11l1111_opy_ (u"ࠫ࡫ࡧࡩ࡭ࡷࡵࡩࠬᇘ")] = bstack11ll1l11l_opy_.bstack1l1l1l11l1_opy_(call.excinfo, result)
        bstack1l111ll11l_opy_[bstack11l1111_opy_ (u"ࠬ࡮࡯ࡰ࡭ࡶࠫᇙ")] = bstack1l11l1l11l_opy_[bstack11l1111_opy_ (u"࠭ࡨࡰࡱ࡮ࡷࠬᇚ")]
    return bstack1l111ll11l_opy_
def bstack1l111l1lll_opy_(test, bstack1l111lll11_opy_, bstack1lll111lll_opy_, result, call):
    file_path = os.path.relpath(test.fspath.strpath, start=os.getcwd())
    hook_type = bstack1l111lll11_opy_[bstack11l1111_opy_ (u"ࠧࡩࡱࡲ࡯ࡤࡺࡹࡱࡧࠪᇛ")]
    hook_data = {
        bstack11l1111_opy_ (u"ࠨࡷࡸ࡭ࡩ࠭ᇜ"): bstack1l111lll11_opy_[bstack11l1111_opy_ (u"ࠩࡸࡹ࡮ࡪࠧᇝ")],
        bstack11l1111_opy_ (u"ࠪࡸࡾࡶࡥࠨᇞ"): bstack11l1111_opy_ (u"ࠫ࡭ࡵ࡯࡬ࠩᇟ"),
        bstack11l1111_opy_ (u"ࠬࡴࡡ࡮ࡧࠪᇠ"): bstack11l1111_opy_ (u"࠭ࡻࡾࠢࡩࡳࡷࠦࡻࡾࠩᇡ").format(bstack11ll1l11l_opy_.bstack1l1l1l1lll_opy_(hook_type), test.name),
        bstack11l1111_opy_ (u"ࠧࡣࡱࡧࡽࠬᇢ"): {
            bstack11l1111_opy_ (u"ࠨ࡮ࡤࡲ࡬࠭ᇣ"): bstack11l1111_opy_ (u"ࠩࡳࡽࡹ࡮࡯࡯ࠩᇤ"),
            bstack11l1111_opy_ (u"ࠪࡧࡴࡪࡥࠨᇥ"): None
        },
        bstack11l1111_opy_ (u"ࠫࡸࡩ࡯ࡱࡧࠪᇦ"): test.name,
        bstack11l1111_opy_ (u"ࠬࡹࡣࡰࡲࡨࡷࠬᇧ"): bstack11ll1l11l_opy_.bstack1l1l1llll1_opy_(test),
        bstack11l1111_opy_ (u"࠭ࡦࡪ࡮ࡨࡣࡳࡧ࡭ࡦࠩᇨ"): file_path,
        bstack11l1111_opy_ (u"ࠧ࡭ࡱࡦࡥࡹ࡯࡯࡯ࠩᇩ"): file_path,
        bstack11l1111_opy_ (u"ࠨࡴࡨࡷࡺࡲࡴࠨᇪ"): bstack11l1111_opy_ (u"ࠩࡳࡩࡳࡪࡩ࡯ࡩࠪᇫ"),
        bstack11l1111_opy_ (u"ࠪࡺࡨࡥࡦࡪ࡮ࡨࡴࡦࡺࡨࠨᇬ"): file_path,
        bstack11l1111_opy_ (u"ࠫࡸࡺࡡࡳࡶࡨࡨࡤࡧࡴࠨᇭ"): bstack1l111lll11_opy_[bstack11l1111_opy_ (u"ࠬࡹࡴࡢࡴࡷࡩࡩࡥࡡࡵࠩᇮ")],
        bstack11l1111_opy_ (u"࠭ࡦࡳࡣࡰࡩࡼࡵࡲ࡬ࠩᇯ"): bstack11l1111_opy_ (u"ࠧࡑࡻࡷࡩࡸࡺࠧᇰ"),
        bstack11l1111_opy_ (u"ࠨࡪࡲࡳࡰࡥࡴࡺࡲࡨࠫᇱ"): bstack1l111lll11_opy_[bstack11l1111_opy_ (u"ࠩ࡫ࡳࡴࡱ࡟ࡵࡻࡳࡩࠬᇲ")]
    }
    if _1l11l11l1l_opy_.get(test.nodeid, None) is not None and _1l11l11l1l_opy_[test.nodeid].get(bstack11l1111_opy_ (u"ࠪࡹࡺ࡯ࡤࠨᇳ"), None):
        hook_data[bstack11l1111_opy_ (u"ࠫࡹ࡫ࡳࡵࡡࡵࡹࡳࡥࡩࡥࠩᇴ")] = _1l11l11l1l_opy_[test.nodeid][bstack11l1111_opy_ (u"ࠬࡻࡵࡪࡦࠪᇵ")]
    if result:
        hook_data[bstack11l1111_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭ᇶ")] = result.outcome
        hook_data[bstack11l1111_opy_ (u"ࠧࡥࡷࡵࡥࡹ࡯࡯࡯ࡡ࡬ࡲࡤࡳࡳࠨᇷ")] = result.duration * 1000
        hook_data[bstack11l1111_opy_ (u"ࠨࡨ࡬ࡲ࡮ࡹࡨࡦࡦࡢࡥࡹ࠭ᇸ")] = bstack1l111lll11_opy_[bstack11l1111_opy_ (u"ࠩࡩ࡭ࡳ࡯ࡳࡩࡧࡧࡣࡦࡺࠧᇹ")]
        if result.failed:
            hook_data[bstack11l1111_opy_ (u"ࠪࡪࡦ࡯࡬ࡶࡴࡨࡣࡹࡿࡰࡦࠩᇺ")] = bstack11ll1l11l_opy_.bstack1l1llll111_opy_(call.excinfo.typename)
            hook_data[bstack11l1111_opy_ (u"ࠫ࡫ࡧࡩ࡭ࡷࡵࡩࠬᇻ")] = bstack11ll1l11l_opy_.bstack1l1l1l11l1_opy_(call.excinfo, result)
    return hook_data
def bstack1l111lll1l_opy_(test, bstack1l11l1l11l_opy_, bstack1lll111lll_opy_, result=None, call=None):
    bstack1l111ll11l_opy_ = bstack1l11l11ll1_opy_(test, bstack1l11l1l11l_opy_, result, call, bstack1lll111lll_opy_)
    driver = getattr(test, bstack11l1111_opy_ (u"ࠬࡥࡤࡳ࡫ࡹࡩࡷ࠭ᇼ"), None)
    if bstack1lll111lll_opy_ == bstack11l1111_opy_ (u"࠭ࡔࡦࡵࡷࡖࡺࡴࡓࡵࡣࡵࡸࡪࡪࠧᇽ") and driver:
        bstack1l111ll11l_opy_[bstack11l1111_opy_ (u"ࠧࡪࡰࡷࡩ࡬ࡸࡡࡵ࡫ࡲࡲࡸ࠭ᇾ")] = bstack11ll1l11l_opy_.bstack1l1llll1l1_opy_(driver)
    if bstack1lll111lll_opy_ == bstack11l1111_opy_ (u"ࠨࡖࡨࡷࡹࡘࡵ࡯ࡕ࡮࡭ࡵࡶࡥࡥࠩᇿ"):
        bstack1lll111lll_opy_ = bstack11l1111_opy_ (u"ࠩࡗࡩࡸࡺࡒࡶࡰࡉ࡭ࡳ࡯ࡳࡩࡧࡧࠫሀ")
    bstack1l111ll111_opy_ = {
        bstack11l1111_opy_ (u"ࠪࡩࡻ࡫࡮ࡵࡡࡷࡽࡵ࡫ࠧሁ"): bstack1lll111lll_opy_,
        bstack11l1111_opy_ (u"ࠫࡹ࡫ࡳࡵࡡࡵࡹࡳ࠭ሂ"): bstack1l111ll11l_opy_
    }
    bstack11ll1l11l_opy_.bstack1l1llll11l_opy_(bstack1l111ll111_opy_)
def bstack1l11l1111l_opy_(test, bstack1l11l1l11l_opy_, bstack1lll111lll_opy_, result=None, call=None):
    hook_data = bstack1l111l1lll_opy_(test, bstack1l11l1l11l_opy_, bstack1lll111lll_opy_, result, call)
    bstack1l111ll111_opy_ = {
        bstack11l1111_opy_ (u"ࠬ࡫ࡶࡦࡰࡷࡣࡹࡿࡰࡦࠩሃ"): bstack1lll111lll_opy_,
        bstack11l1111_opy_ (u"࠭ࡨࡰࡱ࡮ࡣࡷࡻ࡮ࠨሄ"): hook_data
    }
    bstack11ll1l11l_opy_.bstack1l1llll11l_opy_(bstack1l111ll111_opy_)
@pytest.fixture(autouse=True)
def second_fixture(caplog, request):
    yield
    try:
        if not bstack11ll1l11l_opy_.on():
            return
        records = caplog.get_records(bstack11l1111_opy_ (u"ࠧࡤࡣ࡯ࡰࠬህ"))
        bstack1l1ll1l1l1_opy_ = []
        for record in records:
            if record.message == bstack11l1111_opy_ (u"ࠨ࡞ࡱࠫሆ"):
                continue
            bstack1l1ll1l1l1_opy_.append({
                bstack11l1111_opy_ (u"ࠩࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠬሇ"): datetime.datetime.utcfromtimestamp(record.created).isoformat() + bstack11l1111_opy_ (u"ࠪ࡞ࠬለ"),
                bstack11l1111_opy_ (u"ࠫࡱ࡫ࡶࡦ࡮ࠪሉ"): record.levelname,
                bstack11l1111_opy_ (u"ࠬࡳࡥࡴࡵࡤ࡫ࡪ࠭ሊ"): record.message,
                bstack11l1111_opy_ (u"࠭ࡴࡦࡵࡷࡣࡷࡻ࡮ࡠࡷࡸ࡭ࡩ࠭ላ"): _1l11l11l1l_opy_.get(request.node.nodeid).get(bstack11l1111_opy_ (u"ࠧࡶࡷ࡬ࡨࠬሌ"))
            })
        bstack11ll1l11l_opy_.bstack1l1llll1ll_opy_(bstack1l1ll1l1l1_opy_)
    except Exception as err:
        print(bstack11l1111_opy_ (u"ࠨࡇࡻࡧࡪࡶࡴࡪࡱࡱࠤ࡮ࡴࠠࡴࡧࡦࡳࡳࡪ࡟ࡧ࡫ࡻࡸࡺࡸࡥ࠻ࠢࡾࢁࠬል"), str(err))
def bstack1l11l11lll_opy_(driver_command, response):
    if driver_command == bstack11l1111_opy_ (u"ࠩࡶࡧࡷ࡫ࡥ࡯ࡵ࡫ࡳࡹ࠭ሎ"):
        bstack11ll1l11l_opy_.bstack1l1lll1l11_opy_({
            bstack11l1111_opy_ (u"ࠪ࡭ࡲࡧࡧࡦࠩሏ"): response[bstack11l1111_opy_ (u"ࠫࡻࡧ࡬ࡶࡧࠪሐ")],
            bstack11l1111_opy_ (u"ࠬࡺࡥࡴࡶࡢࡶࡺࡴ࡟ࡶࡷ࡬ࡨࠬሑ"): bstack1l1ll1l11l_opy_
        })
@bstack11ll1l11l_opy_.bstack1l1l1ll1l1_opy_
def bstack1l11l11111_opy_():
    if bstack1l1l11111l_opy_():
        bstack1ll111111l_opy_(bstack1l11l11lll_opy_)
bstack1l11l11111_opy_()
def bstack111111l1_opy_():
    global bstack1ll111111_opy_
    bstack11ll1l11l_opy_.bstack1l1l1l111l_opy_()
    for driver in bstack1ll111111_opy_:
        try:
            driver.quit()
        except Exception as e:
            pass
def bstack11lll111_opy_(self, *args, **kwargs):
    bstack1ll111l1l_opy_ = bstack111ll1lll_opy_(self, *args, **kwargs)
    bstack11ll1l11l_opy_.bstack1llll1llll_opy_(self)
    return bstack1ll111l1l_opy_
def bstack11llllll1_opy_(framework_name):
    global bstack11lll11l1_opy_
    global bstack111l111ll_opy_
    bstack11lll11l1_opy_ = framework_name
    logger.info(bstack11l1l111l_opy_.format(bstack11lll11l1_opy_.split(bstack11l1111_opy_ (u"࠭࠭ࠨሒ"))[0]))
    try:
        from selenium import webdriver
        from selenium.webdriver.common.service import Service
        from selenium.webdriver.remote.webdriver import WebDriver
        if bstack1l11llllll_opy_():
            Service.start = bstack1111l11ll_opy_
            Service.stop = bstack111lllll1_opy_
            webdriver.Remote.__init__ = bstack11l11l1l_opy_
            webdriver.Remote.get = bstack111l11l1l_opy_
            if not isinstance(os.getenv(bstack11l1111_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡐ࡚ࡖࡈࡗ࡙ࡥࡐࡂࡔࡄࡐࡑࡋࡌࠨሓ")), str):
                return
            WebDriver.close = bstack1llll1lll1_opy_
            WebDriver.quit = bstack1ll1ll111l_opy_
        if not bstack1l11llllll_opy_() and bstack11ll1l11l_opy_.on():
            webdriver.Remote.__init__ = bstack11lll111_opy_
        bstack111l111ll_opy_ = True
    except Exception as e:
        pass
    bstack1ll1l1111_opy_()
    if os.environ.get(bstack11l1111_opy_ (u"ࠨࡕࡈࡐࡊࡔࡉࡖࡏࡢࡓࡗࡥࡐࡍࡃ࡜࡛ࡗࡏࡇࡉࡖࡢࡍࡓ࡙ࡔࡂࡎࡏࡉࡉ࠭ሔ")):
        bstack111l111ll_opy_ = eval(os.environ.get(bstack11l1111_opy_ (u"ࠩࡖࡉࡑࡋࡎࡊࡗࡐࡣࡔࡘ࡟ࡑࡎࡄ࡝࡜ࡘࡉࡈࡊࡗࡣࡎࡔࡓࡕࡃࡏࡐࡊࡊࠧሕ")))
    if not bstack111l111ll_opy_:
        bstack111ll11l1_opy_(bstack11l1111_opy_ (u"ࠥࡔࡦࡩ࡫ࡢࡩࡨࡷࠥࡴ࡯ࡵࠢ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࠧሖ"), bstack1l1l11ll_opy_)
    if bstack1111lllll_opy_():
        try:
            from selenium.webdriver.remote.remote_connection import RemoteConnection
            RemoteConnection._get_proxy_url = bstack1ll11lll11_opy_
        except Exception as e:
            logger.error(bstack1ll1l1llll_opy_.format(str(e)))
    if bstack11l1111_opy_ (u"ࠫࡵࡿࡴࡦࡵࡷࠫሗ") in str(framework_name).lower():
        if not bstack1l11llllll_opy_():
            return
        try:
            from pytest_selenium import pytest_selenium
            from _pytest.config import Config
            pytest_selenium.pytest_report_header = bstack11l1lll1l_opy_
            from pytest_selenium.drivers import browserstack
            browserstack.pytest_selenium_runtest_makereport = bstack1111111ll_opy_
            Config.getoption = bstack1111l111_opy_
        except Exception as e:
            pass
        try:
            from pytest_bdd import reporting
            reporting.runtest_makereport = bstack1ll1l1l1ll_opy_
        except Exception as e:
            pass
def bstack1ll1ll111l_opy_(self):
    global bstack11lll11l1_opy_
    global bstack111ll11ll_opy_
    global bstack11l1l1l11_opy_
    try:
        if bstack11l1111_opy_ (u"ࠬࡶࡹࡵࡧࡶࡸࠬመ") in bstack11lll11l1_opy_ and self.session_id != None:
            bstack1lll1lll11_opy_ = bstack11l1111_opy_ (u"࠭ࡰࡢࡵࡶࡩࡩ࠭ሙ") if len(threading.current_thread().bstackTestErrorMessages) == 0 else bstack11l1111_opy_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧሚ")
            bstack1llll1l1ll_opy_ = bstack1l1l1111l_opy_(bstack11l1111_opy_ (u"ࠨࡵࡨࡸࡘ࡫ࡳࡴ࡫ࡲࡲࡘࡺࡡࡵࡷࡶࠫማ"), bstack11l1111_opy_ (u"ࠩࠪሜ"), bstack1lll1lll11_opy_, bstack11l1111_opy_ (u"ࠪ࠰ࠥ࠭ም").join(
                threading.current_thread().bstackTestErrorMessages), bstack11l1111_opy_ (u"ࠫࠬሞ"), bstack11l1111_opy_ (u"ࠬ࠭ሟ"))
            if self != None:
                self.execute_script(bstack1llll1l1ll_opy_)
    except Exception as e:
        logger.debug(bstack11l1111_opy_ (u"ࠨࡅࡳࡴࡲࡶࠥࡽࡨࡪ࡮ࡨࠤࡲࡧࡲ࡬࡫ࡱ࡫ࠥࡹࡴࡢࡶࡸࡷ࠿ࠦࠢሠ") + str(e))
    bstack11l1l1l11_opy_(self)
    self.session_id = None
def bstack11l11l1l_opy_(self, command_executor,
             desired_capabilities=None, browser_profile=None, proxy=None,
             keep_alive=True, file_detector=None, options=None):
    global CONFIG
    global bstack111ll11ll_opy_
    global bstack1111l1l1l_opy_
    global bstack1lll1l1lll_opy_
    global bstack11lll11l1_opy_
    global bstack111ll1lll_opy_
    global bstack1ll111111_opy_
    global bstack11ll1l1ll_opy_
    global bstack1l1l11l1l_opy_
    CONFIG[bstack11l1111_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࡙ࡄࡌࠩሡ")] = str(bstack11lll11l1_opy_) + str(__version__)
    command_executor = bstack1111lll1_opy_(bstack11ll1l1ll_opy_)
    logger.debug(bstack1ll11l1l1_opy_.format(command_executor))
    proxy = bstack1lll11ll1l_opy_(CONFIG, proxy)
    bstack11ll1111l_opy_ = 0
    try:
        if bstack1lll1l1lll_opy_ is True:
            bstack11ll1111l_opy_ = int(os.environ.get(bstack11l1111_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡑࡎࡄࡘࡋࡕࡒࡎࡡࡌࡒࡉࡋࡘࠨሢ")))
    except:
        bstack11ll1111l_opy_ = 0
    bstack1111l111l_opy_ = bstack1l11111l_opy_(CONFIG, bstack11ll1111l_opy_)
    logger.debug(bstack1ll11ll1l_opy_.format(str(bstack1111l111l_opy_)))
    if bstack11l1111_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡍࡱࡦࡥࡱ࠭ሣ") in CONFIG and CONFIG[bstack11l1111_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡎࡲࡧࡦࡲࠧሤ")]:
        bstack11l1llll1_opy_(bstack1111l111l_opy_, bstack1l1l11l1l_opy_)
    if desired_capabilities:
        bstack11l1111l1_opy_ = bstack11l1lll11_opy_(desired_capabilities)
        bstack11l1111l1_opy_[bstack11l1111_opy_ (u"ࠫࡺࡹࡥࡘ࠵ࡆࠫሥ")] = bstack11ll11l1_opy_(CONFIG)
        bstack1ll1ll1l11_opy_ = bstack1l11111l_opy_(bstack11l1111l1_opy_)
        if bstack1ll1ll1l11_opy_:
            bstack1111l111l_opy_ = update(bstack1ll1ll1l11_opy_, bstack1111l111l_opy_)
        desired_capabilities = None
    if options:
        bstack1lllll1l11_opy_(options, bstack1111l111l_opy_)
    if not options:
        options = bstack1l11l1lll_opy_(bstack1111l111l_opy_)
    if proxy and bstack1lll1l1l1_opy_() >= version.parse(bstack11l1111_opy_ (u"ࠬ࠺࠮࠲࠲࠱࠴ࠬሦ")):
        options.proxy(proxy)
    if options and bstack1lll1l1l1_opy_() >= version.parse(bstack11l1111_opy_ (u"࠭࠳࠯࠺࠱࠴ࠬሧ")):
        desired_capabilities = None
    if (
            not options and not desired_capabilities
    ) or (
            bstack1lll1l1l1_opy_() < version.parse(bstack11l1111_opy_ (u"ࠧ࠴࠰࠻࠲࠵࠭ረ")) and not desired_capabilities
    ):
        desired_capabilities = {}
        desired_capabilities.update(bstack1111l111l_opy_)
    logger.info(bstack1111llll1_opy_)
    if bstack1lll1l1l1_opy_() >= version.parse(bstack11l1111_opy_ (u"ࠨ࠶࠱࠵࠵࠴࠰ࠨሩ")):
        bstack111ll1lll_opy_(self, command_executor=command_executor,
                  options=options, keep_alive=keep_alive, file_detector=file_detector)
    elif bstack1lll1l1l1_opy_() >= version.parse(bstack11l1111_opy_ (u"ࠩ࠶࠲࠽࠴࠰ࠨሪ")):
        bstack111ll1lll_opy_(self, command_executor=command_executor,
                  desired_capabilities=desired_capabilities, options=options,
                  browser_profile=browser_profile, proxy=proxy,
                  keep_alive=keep_alive, file_detector=file_detector)
    elif bstack1lll1l1l1_opy_() >= version.parse(bstack11l1111_opy_ (u"ࠪ࠶࠳࠻࠳࠯࠲ࠪራ")):
        bstack111ll1lll_opy_(self, command_executor=command_executor,
                  desired_capabilities=desired_capabilities,
                  browser_profile=browser_profile, proxy=proxy,
                  keep_alive=keep_alive, file_detector=file_detector)
    else:
        bstack111ll1lll_opy_(self, command_executor=command_executor,
                  desired_capabilities=desired_capabilities,
                  browser_profile=browser_profile, proxy=proxy,
                  keep_alive=keep_alive)
    try:
        bstack11ll111l1_opy_ = bstack11l1111_opy_ (u"ࠫࠬሬ")
        if bstack1lll1l1l1_opy_() >= version.parse(bstack11l1111_opy_ (u"ࠬ࠺࠮࠱࠰࠳ࡦ࠶࠭ር")):
            bstack11ll111l1_opy_ = self.caps.get(bstack11l1111_opy_ (u"ࠨ࡯ࡱࡶ࡬ࡱࡦࡲࡈࡶࡤࡘࡶࡱࠨሮ"))
        else:
            bstack11ll111l1_opy_ = self.capabilities.get(bstack11l1111_opy_ (u"ࠢࡰࡲࡷ࡭ࡲࡧ࡬ࡉࡷࡥ࡙ࡷࡲࠢሯ"))
        if bstack11ll111l1_opy_:
            if bstack1lll1l1l1_opy_() <= version.parse(bstack11l1111_opy_ (u"ࠨ࠵࠱࠵࠸࠴࠰ࠨሰ")):
                self.command_executor._url = bstack11l1111_opy_ (u"ࠤ࡫ࡸࡹࡶ࠺࠰࠱ࠥሱ") + bstack11ll1l1ll_opy_ + bstack11l1111_opy_ (u"ࠥ࠾࠽࠶࠯ࡸࡦ࠲࡬ࡺࡨࠢሲ")
            else:
                self.command_executor._url = bstack11l1111_opy_ (u"ࠦ࡭ࡺࡴࡱࡵ࠽࠳࠴ࠨሳ") + bstack11ll111l1_opy_ + bstack11l1111_opy_ (u"ࠧ࠵ࡷࡥ࠱࡫ࡹࡧࠨሴ")
            logger.debug(bstack1llll111l1_opy_.format(bstack11ll111l1_opy_))
        else:
            logger.debug(bstack1lll1l11l1_opy_.format(bstack11l1111_opy_ (u"ࠨࡏࡱࡶ࡬ࡱࡦࡲࠠࡉࡷࡥࠤࡳࡵࡴࠡࡨࡲࡹࡳࡪࠢስ")))
    except Exception as e:
        logger.debug(bstack1lll1l11l1_opy_.format(e))
    bstack111ll11ll_opy_ = self.session_id
    if bstack11l1111_opy_ (u"ࠧࡱࡻࡷࡩࡸࡺࠧሶ") in bstack11lll11l1_opy_:
        threading.current_thread().bstack1lllllll11_opy_ = self.session_id
        threading.current_thread().bstackSessionDriver = self
        threading.current_thread().bstackTestErrorMessages = []
        bstack11ll1l11l_opy_.bstack1llll1llll_opy_(self)
    bstack1ll111111_opy_.append(self)
    if bstack11l1111_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠫሷ") in CONFIG and bstack11l1111_opy_ (u"ࠩࡶࡩࡸࡹࡩࡰࡰࡑࡥࡲ࡫ࠧሸ") in CONFIG[bstack11l1111_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱࡸ࠭ሹ")][bstack11ll1111l_opy_]:
        bstack1111l1l1l_opy_ = CONFIG[bstack11l1111_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡹࠧሺ")][bstack11ll1111l_opy_][bstack11l1111_opy_ (u"ࠬࡹࡥࡴࡵ࡬ࡳࡳࡔࡡ࡮ࡧࠪሻ")]
    logger.debug(bstack1llllll11l_opy_.format(bstack111ll11ll_opy_))
def bstack111l11l1l_opy_(self, url):
    global bstack11ll1ll1l_opy_
    global CONFIG
    try:
        bstack1111l11l_opy_(url, CONFIG, logger)
    except Exception as err:
        logger.debug(bstack1l1lll11_opy_.format(str(err)))
    try:
        bstack11ll1ll1l_opy_(self, url)
    except Exception as e:
        try:
            bstack1l1llllll_opy_ = str(e)
            if any(err_msg in bstack1l1llllll_opy_ for err_msg in bstack1ll1lll1l_opy_):
                bstack1111l11l_opy_(url, CONFIG, logger, True)
        except Exception as err:
            logger.debug(bstack1l1lll11_opy_.format(str(err)))
        raise e
def bstack1llll11l11_opy_(item, when):
    global bstack111llll1_opy_
    try:
        bstack111llll1_opy_(item, when)
    except Exception as e:
        pass
def bstack1ll1l1l1ll_opy_(item, call, rep):
    global bstack1l1lll1l1_opy_
    global bstack1ll111111_opy_
    name = bstack11l1111_opy_ (u"࠭ࠧሼ")
    try:
        if rep.when == bstack11l1111_opy_ (u"ࠧࡤࡣ࡯ࡰࠬሽ"):
            bstack111ll11ll_opy_ = threading.current_thread().bstack1lllllll11_opy_
            bstack1l11l111ll_opy_ = item.config.getoption(bstack11l1111_opy_ (u"ࠨࡵ࡮࡭ࡵ࡙ࡥࡴࡵ࡬ࡳࡳࡔࡡ࡮ࡧࠪሾ"))
            try:
                if (str(bstack1l11l111ll_opy_).lower() != bstack11l1111_opy_ (u"ࠩࡷࡶࡺ࡫ࠧሿ")):
                    name = str(rep.nodeid)
                    bstack1llll1l1ll_opy_ = bstack1l1l1111l_opy_(bstack11l1111_opy_ (u"ࠪࡷࡪࡺࡓࡦࡵࡶ࡭ࡴࡴࡎࡢ࡯ࡨࠫቀ"), name, bstack11l1111_opy_ (u"ࠫࠬቁ"), bstack11l1111_opy_ (u"ࠬ࠭ቂ"), bstack11l1111_opy_ (u"࠭ࠧቃ"), bstack11l1111_opy_ (u"ࠧࠨቄ"))
                    for driver in bstack1ll111111_opy_:
                        if bstack111ll11ll_opy_ == driver.session_id:
                            driver.execute_script(bstack1llll1l1ll_opy_)
            except Exception as e:
                logger.debug(bstack11l1111_opy_ (u"ࠨࡇࡵࡶࡴࡸࠠࡪࡰࠣࡷࡪࡺࡴࡪࡰࡪࠤࡸ࡫ࡳࡴ࡫ࡲࡲࡓࡧ࡭ࡦࠢࡩࡳࡷࠦࡰࡺࡶࡨࡷࡹ࠳ࡢࡥࡦࠣࡷࡪࡹࡳࡪࡱࡱ࠾ࠥࢁࡽࠨቅ").format(str(e)))
            try:
                status = bstack11l1111_opy_ (u"ࠩࡩࡥ࡮ࡲࡥࡥࠩቆ") if rep.outcome.lower() == bstack11l1111_opy_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪቇ") else bstack11l1111_opy_ (u"ࠫࡵࡧࡳࡴࡧࡧࠫቈ")
                reason = bstack11l1111_opy_ (u"ࠬ࠭቉")
                if (reason != bstack11l1111_opy_ (u"ࠨࠢቊ")):
                    try:
                        if (threading.current_thread().bstackTestErrorMessages == None):
                            threading.current_thread().bstackTestErrorMessages = []
                    except Exception as e:
                        threading.current_thread().bstackTestErrorMessages = []
                    threading.current_thread().bstackTestErrorMessages.append(str(reason))
                if status == bstack11l1111_opy_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧቋ"):
                    reason = rep.longrepr.reprcrash.message
                    if (not threading.current_thread().bstackTestErrorMessages):
                        threading.current_thread().bstackTestErrorMessages = []
                    threading.current_thread().bstackTestErrorMessages.append(reason)
                level = bstack11l1111_opy_ (u"ࠨ࡫ࡱࡪࡴ࠭ቌ") if status == bstack11l1111_opy_ (u"ࠩࡳࡥࡸࡹࡥࡥࠩቍ") else bstack11l1111_opy_ (u"ࠪࡩࡷࡸ࡯ࡳࠩ቎")
                data = name + bstack11l1111_opy_ (u"ࠫࠥࡶࡡࡴࡵࡨࡨࠦ࠭቏") if status == bstack11l1111_opy_ (u"ࠬࡶࡡࡴࡵࡨࡨࠬቐ") else name + bstack11l1111_opy_ (u"࠭ࠠࡧࡣ࡬ࡰࡪࡪࠡࠡࠩቑ") + reason
                bstack11111111l_opy_ = bstack1l1l1111l_opy_(bstack11l1111_opy_ (u"ࠧࡢࡰࡱࡳࡹࡧࡴࡦࠩቒ"), bstack11l1111_opy_ (u"ࠨࠩቓ"), bstack11l1111_opy_ (u"ࠩࠪቔ"), bstack11l1111_opy_ (u"ࠪࠫቕ"), level, data)
                for driver in bstack1ll111111_opy_:
                    if bstack111ll11ll_opy_ == driver.session_id:
                        driver.execute_script(bstack11111111l_opy_)
            except Exception as e:
                logger.debug(bstack11l1111_opy_ (u"ࠫࡊࡸࡲࡰࡴࠣ࡭ࡳࠦࡳࡦࡶࡷ࡭ࡳ࡭ࠠࡴࡧࡶࡷ࡮ࡵ࡮ࠡࡥࡲࡲࡹ࡫ࡸࡵࠢࡩࡳࡷࠦࡰࡺࡶࡨࡷࡹ࠳ࡢࡥࡦࠣࡷࡪࡹࡳࡪࡱࡱ࠾ࠥࢁࡽࠨቖ").format(str(e)))
    except Exception as e:
        logger.debug(bstack11l1111_opy_ (u"ࠬࡋࡲࡳࡱࡵࠤ࡮ࡴࠠࡨࡧࡷࡸ࡮ࡴࡧࠡࡵࡷࡥࡹ࡫ࠠࡪࡰࠣࡴࡾࡺࡥࡴࡶ࠰ࡦࡩࡪࠠࡵࡧࡶࡸࠥࡹࡴࡢࡶࡸࡷ࠿ࠦࡻࡾࠩ቗").format(str(e)))
    bstack1l1lll1l1_opy_(item, call, rep)
notset = Notset()
def bstack1111l111_opy_(self, name: str, default=notset, skip: bool = False):
    global bstack1l11ll11l_opy_
    if str(name).lower() == bstack11l1111_opy_ (u"࠭ࡤࡳ࡫ࡹࡩࡷ࠭ቘ"):
        return bstack11l1111_opy_ (u"ࠢࡃࡴࡲࡻࡸ࡫ࡲࡔࡶࡤࡧࡰࠨ቙")
    else:
        return bstack1l11ll11l_opy_(self, name, default, skip)
def bstack1ll11lll11_opy_(self):
    global CONFIG
    global bstack1ll1l11l1l_opy_
    try:
        proxy = bstack1lll1l11ll_opy_(CONFIG)
        if proxy:
            if proxy.endswith(bstack11l1111_opy_ (u"ࠨ࠰ࡳࡥࡨ࠭ቚ")):
                proxies = bstack1lll111l1l_opy_(proxy, bstack1111lll1_opy_())
                if len(proxies) > 0:
                    protocol, bstack1l111l1l1_opy_ = proxies.popitem()
                    if bstack11l1111_opy_ (u"ࠤ࠽࠳࠴ࠨቛ") in bstack1l111l1l1_opy_:
                        return bstack1l111l1l1_opy_
                    else:
                        return bstack11l1111_opy_ (u"ࠥ࡬ࡹࡺࡰ࠻࠱࠲ࠦቜ") + bstack1l111l1l1_opy_
            else:
                return proxy
    except Exception as e:
        logger.error(bstack11l1111_opy_ (u"ࠦࡊࡸࡲࡰࡴࠣ࡭ࡳࠦࡳࡦࡶࡷ࡭ࡳ࡭ࠠࡱࡴࡲࡼࡾࠦࡵࡳ࡮ࠣ࠾ࠥࢁࡽࠣቝ").format(str(e)))
    return bstack1ll1l11l1l_opy_(self)
def bstack1111lllll_opy_():
    return bstack11l1111_opy_ (u"ࠬ࡮ࡴࡵࡲࡓࡶࡴࡾࡹࠨ቞") in CONFIG or bstack11l1111_opy_ (u"࠭ࡨࡵࡶࡳࡷࡕࡸ࡯ࡹࡻࠪ቟") in CONFIG and bstack1lll1l1l1_opy_() >= version.parse(
        bstack1lll1ll1ll_opy_)
def bstack1111l1lll_opy_(self,
               executablePath=None,
               channel=None,
               args=None,
               ignoreDefaultArgs=None,
               handleSIGINT=None,
               handleSIGTERM=None,
               handleSIGHUP=None,
               timeout=None,
               env=None,
               headless=None,
               devtools=None,
               proxy=None,
               downloadsPath=None,
               slowMo=None,
               tracesDir=None,
               chromiumSandbox=None,
               firefoxUserPrefs=None
               ):
    global CONFIG
    global bstack1111l1l1l_opy_
    global bstack1lll1l1lll_opy_
    global bstack11lll11l1_opy_
    CONFIG[bstack11l1111_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࡙ࡄࡌࠩበ")] = str(bstack11lll11l1_opy_) + str(__version__)
    bstack11ll1111l_opy_ = 0
    try:
        if bstack1lll1l1lll_opy_ is True:
            bstack11ll1111l_opy_ = int(os.environ.get(bstack11l1111_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡑࡎࡄࡘࡋࡕࡒࡎࡡࡌࡒࡉࡋࡘࠨቡ")))
    except:
        bstack11ll1111l_opy_ = 0
    CONFIG[bstack11l1111_opy_ (u"ࠤ࡬ࡷࡕࡲࡡࡺࡹࡵ࡭࡬࡮ࡴࠣቢ")] = True
    bstack1111l111l_opy_ = bstack1l11111l_opy_(CONFIG, bstack11ll1111l_opy_)
    logger.debug(bstack1ll11ll1l_opy_.format(str(bstack1111l111l_opy_)))
    if CONFIG[bstack11l1111_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡎࡲࡧࡦࡲࠧባ")]:
        bstack11l1llll1_opy_(bstack1111l111l_opy_, bstack1l1l11l1l_opy_)
    if bstack11l1111_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡹࠧቤ") in CONFIG and bstack11l1111_opy_ (u"ࠬࡹࡥࡴࡵ࡬ࡳࡳࡔࡡ࡮ࡧࠪብ") in CONFIG[bstack11l1111_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩቦ")][bstack11ll1111l_opy_]:
        bstack1111l1l1l_opy_ = CONFIG[bstack11l1111_opy_ (u"ࠧࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡵࠪቧ")][bstack11ll1111l_opy_][bstack11l1111_opy_ (u"ࠨࡵࡨࡷࡸ࡯࡯࡯ࡐࡤࡱࡪ࠭ቨ")]
    import urllib
    import json
    bstack11ll11111_opy_ = bstack11l1111_opy_ (u"ࠩࡺࡷࡸࡀ࠯࠰ࡥࡧࡴ࠳ࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮࠲ࡨࡵ࡭࠰ࡲ࡯ࡥࡾࡽࡲࡪࡩ࡫ࡸࡄࡩࡡࡱࡵࡀࠫቩ") + urllib.parse.quote(json.dumps(bstack1111l111l_opy_))
    browser = self.connect(bstack11ll11111_opy_)
    return browser
def bstack1ll1l1111_opy_():
    global bstack111l111ll_opy_
    try:
        from playwright._impl._browser_type import BrowserType
        BrowserType.launch = bstack1111l1lll_opy_
        bstack111l111ll_opy_ = True
    except Exception as e:
        pass
def bstack1l111l1ll1_opy_():
    global CONFIG
    global bstack111lll1l_opy_
    global bstack11ll1l1ll_opy_
    global bstack1l1l11l1l_opy_
    global bstack1lll1l1lll_opy_
    CONFIG = json.loads(os.environ.get(bstack11l1111_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡆࡓࡓࡌࡉࡈࠩቪ")))
    bstack111lll1l_opy_ = eval(os.environ.get(bstack11l1111_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡍࡘࡥࡁࡑࡒࡢࡅ࡚࡚ࡏࡎࡃࡗࡉࠬቫ")))
    bstack11ll1l1ll_opy_ = os.environ.get(bstack11l1111_opy_ (u"ࠬࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣࡍ࡛ࡂࡠࡗࡕࡐࠬቬ"))
    bstack1l1lll1ll_opy_(CONFIG, bstack111lll1l_opy_)
    bstack1llll11l1_opy_()
    global bstack111ll1lll_opy_
    global bstack11l1l1l11_opy_
    global bstack11llll111_opy_
    global bstack1lllll1l1l_opy_
    global bstack111l111l_opy_
    global bstack11l1ll11l_opy_
    global bstack1l111lll1_opy_
    global bstack11ll1ll1l_opy_
    global bstack1ll1l11l1l_opy_
    global bstack1l11ll11l_opy_
    global bstack111llll1_opy_
    global bstack1l1lll1l1_opy_
    try:
        from selenium import webdriver
        from selenium.webdriver.remote.webdriver import WebDriver
        bstack111ll1lll_opy_ = webdriver.Remote.__init__
        bstack11l1l1l11_opy_ = WebDriver.quit
        bstack1l111lll1_opy_ = WebDriver.close
        bstack11ll1ll1l_opy_ = WebDriver.get
    except Exception as e:
        pass
    if bstack11l1111_opy_ (u"࠭ࡨࡵࡶࡳࡔࡷࡵࡸࡺࠩቭ") in CONFIG or bstack11l1111_opy_ (u"ࠧࡩࡶࡷࡴࡸࡖࡲࡰࡺࡼࠫቮ") in CONFIG:
        if bstack1lll1l1l1_opy_() < version.parse(bstack1lll1ll1ll_opy_):
            logger.error(bstack1lll111l1_opy_.format(bstack1lll1l1l1_opy_()))
        else:
            try:
                from selenium.webdriver.remote.remote_connection import RemoteConnection
                bstack1ll1l11l1l_opy_ = RemoteConnection._get_proxy_url
            except Exception as e:
                logger.error(bstack1ll1l1llll_opy_.format(str(e)))
    try:
        from _pytest.config import Config
        bstack1l11ll11l_opy_ = Config.getoption
        from _pytest import runner
        bstack111llll1_opy_ = runner._update_current_test_var
    except Exception as e:
        logger.warn(e, bstack1ll11ll1_opy_)
    try:
        from pytest_bdd import reporting
        bstack1l1lll1l1_opy_ = reporting.runtest_makereport
    except Exception as e:
        logger.debug(bstack11l1111_opy_ (u"ࠨࡒ࡯ࡩࡦࡹࡥࠡ࡫ࡱࡷࡹࡧ࡬࡭ࠢࡳࡽࡹ࡫ࡳࡵ࠯ࡥࡨࡩࠦࡴࡰࠢࡵࡹࡳࠦࡰࡺࡶࡨࡷࡹ࠳ࡢࡥࡦࠣࡸࡪࡹࡴࡴࠩቯ"))
    bstack1l1l11l1l_opy_ = CONFIG.get(bstack11l1111_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡖࡸࡦࡩ࡫ࡍࡱࡦࡥࡱࡕࡰࡵ࡫ࡲࡲࡸ࠭ተ"), {}).get(bstack11l1111_opy_ (u"ࠪࡰࡴࡩࡡ࡭ࡋࡧࡩࡳࡺࡩࡧ࡫ࡨࡶࠬቱ"))
    bstack1lll1l1lll_opy_ = True
    bstack11llllll1_opy_(bstack1ll11l1l_opy_)
if (bstack1l11llll1l_opy_()):
    bstack1l111l1ll1_opy_()