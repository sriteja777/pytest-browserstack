# coding: UTF-8
import sys
bstack1111l1l_opy_ = sys.version_info [0] == 2
bstack1l111l_opy_ = 2048
bstack1lllll1l_opy_ = 7
def bstack11l1l1l_opy_ (bstack111l1l_opy_):
    global bstack1ll111_opy_
    bstack1111111_opy_ = ord (bstack111l1l_opy_ [-1])
    bstack1l1111_opy_ = bstack111l1l_opy_ [:-1]
    bstack1lll111_opy_ = bstack1111111_opy_ % len (bstack1l1111_opy_)
    bstack11ll1l_opy_ = bstack1l1111_opy_ [:bstack1lll111_opy_] + bstack1l1111_opy_ [bstack1lll111_opy_:]
    if bstack1111l1l_opy_:
        bstack11111l1_opy_ = unicode () .join ([unichr (ord (char) - bstack1l111l_opy_ - (bstack1l1lll_opy_ + bstack1111111_opy_) % bstack1lllll1l_opy_) for bstack1l1lll_opy_, char in enumerate (bstack11ll1l_opy_)])
    else:
        bstack11111l1_opy_ = str () .join ([chr (ord (char) - bstack1l111l_opy_ - (bstack1l1lll_opy_ + bstack1111111_opy_) % bstack1lllll1l_opy_) for bstack1l1lll_opy_, char in enumerate (bstack11ll1l_opy_)])
    return eval (bstack11111l1_opy_)
import datetime
import inspect
import os
import threading
from uuid import uuid4
import pytest
from bstack_utils.capture import bstack1l1l1ll11l_opy_
from bstack_utils.bstack1ll111ll1l_opy_ import bstack1ll111l1ll_opy_
from bstack_utils.helper import bstack1l11llllll_opy_, bstack1l1l111l1l_opy_, bstack11llll1ll_opy_, bstack1l1l111ll1_opy_, \
    bstack1l1l111111_opy_
from bstack_utils.bstack1ll1ll11l_opy_ import bstack1llll1ll1l_opy_
try:
    from playwright.sync_api import (
        BrowserContext,
        Page
    )
except:
    pass
import json
_1l11l11l1l_opy_ = {}
bstack1l1l1lll1l_opy_ = None
_1l11ll1l1l_opy_ = {}
def bstack11l111ll_opy_(page, bstack1lll1l11l1_opy_):
    try:
        page.evaluate(bstack11l1l1l_opy_ (u"ࠧࡥࠠ࠾ࡀࠣࡿࢂࠨზ"),
                      bstack11l1l1l_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡤ࡫ࡸࡦࡥࡸࡸࡴࡸ࠺ࠡࡽࠥࡥࡨࡺࡩࡰࡰࠥ࠾ࠥࠨࡳࡦࡶࡖࡩࡸࡹࡩࡰࡰࡑࡥࡲ࡫ࠢ࠭ࠢࠥࡥࡷ࡭ࡵ࡮ࡧࡱࡸࡸࠨ࠺ࠡࡽࠥࡲࡦࡳࡥࠣ࠼ࠪთ") + json.dumps(
                          bstack1lll1l11l1_opy_) + bstack11l1l1l_opy_ (u"ࠢࡾࡿࠥი"))
    except Exception as e:
        print(bstack11l1l1l_opy_ (u"ࠣࡧࡻࡧࡪࡶࡴࡪࡱࡱࠤ࡮ࡴࠠࡱ࡮ࡤࡽࡼࡸࡩࡨࡪࡷࠤࡸ࡫ࡳࡴ࡫ࡲࡲࠥࡴࡡ࡮ࡧࠣࡿࢂࠨკ"), e)
def bstack111ll1111_opy_(page, message, level):
    try:
        page.evaluate(bstack11l1l1l_opy_ (u"ࠤࡢࠤࡂࡄࠠࡼࡿࠥლ"), bstack11l1l1l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡡࡨࡼࡪࡩࡵࡵࡱࡵ࠾ࠥࢁࠢࡢࡥࡷ࡭ࡴࡴࠢ࠻ࠢࠥࡥࡳࡴ࡯ࡵࡣࡷࡩࠧ࠲ࠠࠣࡣࡵ࡫ࡺࡳࡥ࡯ࡶࡶࠦ࠿ࠦࡻࠣࡦࡤࡸࡦࠨ࠺ࠨმ") + json.dumps(
            message) + bstack11l1l1l_opy_ (u"ࠫ࠱ࠨ࡬ࡦࡸࡨࡰࠧࡀࠧნ") + json.dumps(level) + bstack11l1l1l_opy_ (u"ࠬࢃࡽࠨო"))
    except Exception as e:
        print(bstack11l1l1l_opy_ (u"ࠨࡥࡹࡥࡨࡴࡹ࡯࡯࡯ࠢ࡬ࡲࠥࡶ࡬ࡢࡻࡺࡶ࡮࡭ࡨࡵࠢࡤࡲࡳࡵࡴࡢࡶ࡬ࡳࡳࠦࡻࡾࠤპ"), e)
def bstack1llll1llll_opy_(page, status, message=bstack11l1l1l_opy_ (u"ࠢࠣჟ")):
    try:
        if (status == bstack11l1l1l_opy_ (u"ࠣࡨࡤ࡭ࡱ࡫ࡤࠣრ")):
            page.evaluate(bstack11l1l1l_opy_ (u"ࠤࡢࠤࡂࡄࠠࡼࡿࠥს"),
                          bstack11l1l1l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡡࡨࡼࡪࡩࡵࡵࡱࡵ࠾ࠥࢁࠢࡢࡥࡷ࡭ࡴࡴࠢ࠻ࠢࠥࡷࡪࡺࡓࡦࡵࡶ࡭ࡴࡴࡓࡵࡣࡷࡹࡸࠨࠬࠡࠤࡤࡶ࡬ࡻ࡭ࡦࡰࡷࡷࠧࡀࠠࡼࠤࡵࡩࡦࡹ࡯࡯ࠤ࠽ࠫტ") + json.dumps(
                              bstack11l1l1l_opy_ (u"ࠦࡘࡩࡥ࡯ࡣࡵ࡭ࡴࠦࡦࡢ࡫࡯ࡩࡩࠦࡷࡪࡶ࡫࠾ࠥࠨუ") + str(message)) + bstack11l1l1l_opy_ (u"ࠬ࠲ࠢࡴࡶࡤࡸࡺࡹࠢ࠻ࠩფ") + json.dumps(status) + bstack11l1l1l_opy_ (u"ࠨࡽࡾࠤქ"))
        else:
            page.evaluate(bstack11l1l1l_opy_ (u"ࠢࡠࠢࡀࡂࠥࢁࡽࠣღ"),
                          bstack11l1l1l_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࡟ࡦࡺࡨࡧࡺࡺ࡯ࡳ࠼ࠣࡿࠧࡧࡣࡵ࡫ࡲࡲࠧࡀࠠࠣࡵࡨࡸࡘ࡫ࡳࡴ࡫ࡲࡲࡘࡺࡡࡵࡷࡶࠦ࠱ࠦࠢࡢࡴࡪࡹࡲ࡫࡮ࡵࡵࠥ࠾ࠥࢁࠢࡴࡶࡤࡸࡺࡹࠢ࠻ࠩყ") + json.dumps(
                              status) + bstack11l1l1l_opy_ (u"ࠤࢀࢁࠧშ"))
    except Exception as e:
        print(bstack11l1l1l_opy_ (u"ࠥࡩࡽࡩࡥࡱࡶ࡬ࡳࡳࠦࡩ࡯ࠢࡳࡰࡦࡿࡷࡳ࡫ࡪ࡬ࡹࠦࡳࡦࡶࠣࡷࡪࡹࡳࡪࡱࡱࠤࡸࡺࡡࡵࡷࡶࠤࢀࢃࠢჩ"), e)
@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    bstack1l11ll1111_opy_ = item.config.getoption(bstack11l1l1l_opy_ (u"ࠫࡸࡱࡩࡱࡕࡨࡷࡸ࡯࡯࡯ࡐࡤࡱࡪ࠭ც"))
    plugins = item.config.getoption(bstack11l1l1l_opy_ (u"ࠧࡶ࡬ࡶࡩ࡬ࡲࡸࠨძ"))
    report = outcome.get_result()
    bstack1l11l1l1ll_opy_(item, call, report)
    if bstack11l1l1l_opy_ (u"ࠨࡰࡺࡶࡨࡷࡹࡥࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡵࡲࡵࡨ࡫ࡱࠦწ") not in plugins:
        return
    summary = []
    driver = getattr(item, bstack11l1l1l_opy_ (u"ࠢࡠࡦࡵ࡭ࡻ࡫ࡲࠣჭ"), None)
    page = getattr(item, bstack11l1l1l_opy_ (u"ࠣࡡࡳࡥ࡬࡫ࠢხ"), None)
    try:
        if (driver == None):
            driver = threading.current_thread().bstackSessionDriver
    except:
        pass
    item._driver = driver
    if (driver is not None):
        bstack1l11l11l11_opy_(item, report, summary, bstack1l11ll1111_opy_)
    if (page is not None):
        bstack1l11ll1l11_opy_(item, report, summary, bstack1l11ll1111_opy_)
def bstack1l11l11l11_opy_(item, report, summary, bstack1l11ll1111_opy_):
    if report.when in [bstack11l1l1l_opy_ (u"ࠤࡶࡩࡹࡻࡰࠣჯ"), bstack11l1l1l_opy_ (u"ࠥࡸࡪࡧࡲࡥࡱࡺࡲࠧჰ")]:
        return
    if not bstack1l1l111l1l_opy_():
        return
    if (str(bstack1l11ll1111_opy_).lower() != bstack11l1l1l_opy_ (u"ࠫࡹࡸࡵࡦࠩჱ")):
        item._driver.execute_script(
            bstack11l1l1l_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡣࡪࡾࡥࡤࡷࡷࡳࡷࡀࠠࡼࠤࡤࡧࡹ࡯࡯࡯ࠤ࠽ࠤࠧࡹࡥࡵࡕࡨࡷࡸ࡯࡯࡯ࡐࡤࡱࡪࠨࠬࠡࠤࡤࡶ࡬ࡻ࡭ࡦࡰࡷࡷࠧࡀࠠࡼࠤࡱࡥࡲ࡫ࠢ࠻ࠢࠪჲ") + json.dumps(
                report.nodeid) + bstack11l1l1l_opy_ (u"࠭ࡽࡾࠩჳ"))
    passed = report.passed or (report.failed and hasattr(report, bstack11l1l1l_opy_ (u"ࠢࡸࡣࡶࡼ࡫ࡧࡩ࡭ࠤჴ")))
    bstack1llllllll1_opy_ = bstack11l1l1l_opy_ (u"ࠣࠤჵ")
    if not passed:
        try:
            bstack1llllllll1_opy_ = report.longrepr.reprcrash
        except Exception as e:
            summary.append(
                bstack11l1l1l_opy_ (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉ࠽ࠤࡋࡧࡩ࡭ࡧࡧࠤࡹࡵࠠࡥࡧࡷࡩࡷࡳࡩ࡯ࡧࠣࡪࡦ࡯࡬ࡶࡴࡨࠤࡷ࡫ࡡࡴࡱࡱ࠾ࠥࢁ࠰ࡾࠤჶ").format(e)
            )
    if (bstack1llllllll1_opy_ != bstack11l1l1l_opy_ (u"ࠥࠦჷ")):
        try:
            if (threading.current_thread().bstackTestErrorMessages == None):
                threading.current_thread().bstackTestErrorMessages = []
        except Exception as e:
            threading.current_thread().bstackTestErrorMessages = []
        threading.current_thread().bstackTestErrorMessages.append(str(bstack1llllllll1_opy_))
    try:
        if (passed):
            item._driver.execute_script(
                bstack11l1l1l_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡢࡩࡽ࡫ࡣࡶࡶࡲࡶ࠿ࠦࡻ࡝ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠨࡡࡤࡶ࡬ࡳࡳࠨ࠺ࠡࠤࡤࡲࡳࡵࡴࡢࡶࡨࠦ࠱ࠦ࡜ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠧࡧࡲࡨࡷࡰࡩࡳࡺࡳࠣ࠼ࠣࡿࡡࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠢ࡭ࡧࡹࡩࡱࠨ࠺ࠡࠤ࡬ࡲ࡫ࡵࠢ࠭ࠢ࡟ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠧࡪࡡࡵࡣࠥ࠾ࠥ࠭ჸ")
                + json.dumps(bstack11l1l1l_opy_ (u"ࠧࡶࡡࡴࡵࡨࡨࠦࠨჹ"))
                + bstack11l1l1l_opy_ (u"ࠨ࡜ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࢂࡢࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡽࠣჺ")
            )
        else:
            item._driver.execute_script(
                bstack11l1l1l_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡥࡥࡹࡧࡦࡹࡹࡵࡲ࠻ࠢࡾࡠࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠤࡤࡧࡹ࡯࡯࡯ࠤ࠽ࠤࠧࡧ࡮࡯ࡱࡷࡥࡹ࡫ࠢ࠭ࠢ࡟ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠣࡣࡵ࡫ࡺࡳࡥ࡯ࡶࡶࠦ࠿ࠦࡻ࡝ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠥࡰࡪࡼࡥ࡭ࠤ࠽ࠤࠧ࡫ࡲࡳࡱࡵࠦ࠱ࠦ࡜ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠤࡧࡥࡹࡧࠢ࠻ࠢࠪ჻")
                + json.dumps(str(bstack1llllllll1_opy_))
                + bstack11l1l1l_opy_ (u"ࠣ࡞ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࡽ࡝ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࡿࠥჼ")
            )
    except Exception as e:
        summary.append(bstack11l1l1l_opy_ (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉ࠽ࠤࡋࡧࡩ࡭ࡧࡧࠤࡹࡵࠠࡢࡰࡱࡳࡹࡧࡴࡦ࠼ࠣࡿ࠵ࢃࠢჽ").format(e))
def bstack1l11ll1l11_opy_(item, report, summary, bstack1l11ll1111_opy_):
    if report.when in [bstack11l1l1l_opy_ (u"ࠥࡷࡪࡺࡵࡱࠤჾ"), bstack11l1l1l_opy_ (u"ࠦࡹ࡫ࡡࡳࡦࡲࡻࡳࠨჿ")]:
        return
    if (str(bstack1l11ll1111_opy_).lower() != bstack11l1l1l_opy_ (u"ࠬࡺࡲࡶࡧࠪᄀ")):
        bstack11l111ll_opy_(item._page, report.nodeid)
    passed = report.passed or (report.failed and hasattr(report, bstack11l1l1l_opy_ (u"ࠨࡷࡢࡵࡻࡪࡦ࡯࡬ࠣᄁ")))
    bstack1llllllll1_opy_ = bstack11l1l1l_opy_ (u"ࠢࠣᄂ")
    if not passed:
        try:
            bstack1llllllll1_opy_ = report.longrepr.reprcrash
        except Exception as e:
            summary.append(
                bstack11l1l1l_opy_ (u"࡙ࠣࡄࡖࡓࡏࡎࡈ࠼ࠣࡊࡦ࡯࡬ࡦࡦࠣࡸࡴࠦࡤࡦࡶࡨࡶࡲ࡯࡮ࡦࠢࡩࡥ࡮ࡲࡵࡳࡧࠣࡶࡪࡧࡳࡰࡰ࠽ࠤࢀ࠶ࡽࠣᄃ").format(e)
            )
    try:
        if passed:
            bstack1llll1llll_opy_(item._page, bstack11l1l1l_opy_ (u"ࠤࡳࡥࡸࡹࡥࡥࠤᄄ"))
        else:
            if bstack1llllllll1_opy_:
                bstack111ll1111_opy_(item._page, str(bstack1llllllll1_opy_), bstack11l1l1l_opy_ (u"ࠥࡩࡷࡸ࡯ࡳࠤᄅ"))
                bstack1llll1llll_opy_(item._page, bstack11l1l1l_opy_ (u"ࠦ࡫ࡧࡩ࡭ࡧࡧࠦᄆ"), str(bstack1llllllll1_opy_))
            else:
                bstack1llll1llll_opy_(item._page, bstack11l1l1l_opy_ (u"ࠧ࡬ࡡࡪ࡮ࡨࡨࠧᄇ"))
    except Exception as e:
        summary.append(bstack11l1l1l_opy_ (u"ࠨࡗࡂࡔࡑࡍࡓࡍ࠺ࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡶࡲࠤࡺࡶࡤࡢࡶࡨࠤࡸ࡫ࡳࡴ࡫ࡲࡲࠥࡹࡴࡢࡶࡸࡷ࠿ࠦࡻ࠱ࡿࠥᄈ").format(e))
try:
    from typing import Generator
    import pytest_playwright.pytest_playwright as p
    @pytest.fixture
    def page(context: BrowserContext, request: pytest.FixtureRequest) -> Generator[Page, None, None]:
        page = context.new_page()
        request.node._page = page
        yield page
except:
    pass
def pytest_addoption(parser):
    parser.addoption(bstack11l1l1l_opy_ (u"ࠢ࠮࠯ࡶ࡯࡮ࡶࡓࡦࡵࡶ࡭ࡴࡴࡎࡢ࡯ࡨࠦᄉ"), default=bstack11l1l1l_opy_ (u"ࠣࡈࡤࡰࡸ࡫ࠢᄊ"), help=bstack11l1l1l_opy_ (u"ࠤࡄࡹࡹࡵ࡭ࡢࡶ࡬ࡧࠥࡹࡥࡵࠢࡶࡩࡸࡹࡩࡰࡰࠣࡲࡦࡳࡥࠣᄋ"))
    try:
        import pytest_selenium.pytest_selenium
    except:
        parser.addoption(bstack11l1l1l_opy_ (u"ࠥ࠱࠲ࡪࡲࡪࡸࡨࡶࠧᄌ"), action=bstack11l1l1l_opy_ (u"ࠦࡸࡺ࡯ࡳࡧࠥᄍ"), default=bstack11l1l1l_opy_ (u"ࠧࡩࡨࡳࡱࡰࡩࠧᄎ"),
                         help=bstack11l1l1l_opy_ (u"ࠨࡄࡳ࡫ࡹࡩࡷࠦࡴࡰࠢࡵࡹࡳࠦࡴࡦࡵࡷࡷࠧᄏ"))
def bstack1l11l1ll1l_opy_(log):
    if log[bstack11l1l1l_opy_ (u"ࠧ࡮ࡧࡶࡷࡦ࡭ࡥࠨᄐ")] == bstack11l1l1l_opy_ (u"ࠨ࡞ࡱࠫᄑ"):
        return
    bstack1llll1ll1l_opy_.bstack1l1ll1ll1l_opy_([{
        bstack11l1l1l_opy_ (u"ࠩ࡯ࡩࡻ࡫࡬ࠨᄒ"): log[bstack11l1l1l_opy_ (u"ࠪࡰࡪࡼࡥ࡭ࠩᄓ")],
        bstack11l1l1l_opy_ (u"ࠫࡹ࡯࡭ࡦࡵࡷࡥࡲࡶࠧᄔ"): datetime.datetime.utcnow().isoformat() + bstack11l1l1l_opy_ (u"ࠬࡠࠧᄕ"),
        bstack11l1l1l_opy_ (u"࠭࡭ࡦࡵࡶࡥ࡬࡫ࠧᄖ"): log[bstack11l1l1l_opy_ (u"ࠧ࡮ࡧࡶࡷࡦ࡭ࡥࠨᄗ")],
        bstack11l1l1l_opy_ (u"ࠨࡶࡨࡷࡹࡥࡲࡶࡰࡢࡹࡺ࡯ࡤࠨᄘ"): bstack1l1l1lll1l_opy_
    }])
bstack1l11l1ll11_opy_ = bstack1l1l1ll11l_opy_(bstack1l11l1ll1l_opy_)
def pytest_runtest_call(item):
    try:
        if not bstack1llll1ll1l_opy_.on():
            return
        global bstack1l1l1lll1l_opy_, bstack1l11l1ll11_opy_
        bstack1l11l1ll11_opy_.start()
        bstack1l11ll1lll_opy_ = {
            bstack11l1l1l_opy_ (u"ࠩࡸࡹ࡮ࡪࠧᄙ"): uuid4().__str__(),
            bstack11l1l1l_opy_ (u"ࠪࡷࡹࡧࡲࡵࡧࡧࡣࡦࡺࠧᄚ"): datetime.datetime.utcnow().isoformat() + bstack11l1l1l_opy_ (u"ࠫ࡟࠭ᄛ")
        }
        bstack1l1l1lll1l_opy_ = bstack1l11ll1lll_opy_[bstack11l1l1l_opy_ (u"ࠬࡻࡵࡪࡦࠪᄜ")]
        threading.current_thread().bstack1l1l1lll1l_opy_ = bstack1l1l1lll1l_opy_
        _1l11l11l1l_opy_[item.nodeid] = {**_1l11l11l1l_opy_[item.nodeid], **bstack1l11ll1lll_opy_}
        bstack1l11l111ll_opy_(item, _1l11l11l1l_opy_[item.nodeid], bstack11l1l1l_opy_ (u"࠭ࡔࡦࡵࡷࡖࡺࡴࡓࡵࡣࡵࡸࡪࡪࠧᄝ"))
    except Exception as err:
        print(bstack11l1l1l_opy_ (u"ࠧࡆࡺࡦࡩࡵࡺࡩࡰࡰࠣ࡭ࡳࠦࡰࡺࡶࡨࡷࡹࡥࡲࡶࡰࡷࡩࡸࡺ࡟ࡤࡣ࡯ࡰ࠿ࠦࡻࡾࠩᄞ"), str(err))
def pytest_runtest_setup(item):
    try:
        if not bstack1llll1ll1l_opy_.on():
            return
        uuid = uuid4().__str__()
        bstack1l11ll1lll_opy_ = {
            bstack11l1l1l_opy_ (u"ࠨࡷࡸ࡭ࡩ࠭ᄟ"): uuid,
            bstack11l1l1l_opy_ (u"ࠩࡶࡸࡦࡸࡴࡦࡦࡢࡥࡹ࠭ᄠ"): datetime.datetime.utcnow().isoformat() + bstack11l1l1l_opy_ (u"ࠪ࡞ࠬᄡ"),
            bstack11l1l1l_opy_ (u"ࠫࡹࡿࡰࡦࠩᄢ"): bstack11l1l1l_opy_ (u"ࠬ࡮࡯ࡰ࡭ࠪᄣ"),
            bstack11l1l1l_opy_ (u"࠭ࡨࡰࡱ࡮ࡣࡹࡿࡰࡦࠩᄤ"): bstack11l1l1l_opy_ (u"ࠧࡃࡇࡉࡓࡗࡋ࡟ࡆࡃࡆࡌࠬᄥ")
        }
        threading.current_thread().bstack1l11l1lll1_opy_ = uuid
        if not _1l11l11l1l_opy_.get(item.nodeid, None):
            _1l11l11l1l_opy_[item.nodeid] = {bstack11l1l1l_opy_ (u"ࠨࡪࡲࡳࡰࡹࠧᄦ"): []}
        _1l11l11l1l_opy_[item.nodeid][bstack11l1l1l_opy_ (u"ࠩ࡫ࡳࡴࡱࡳࠨᄧ")].append(bstack1l11ll1lll_opy_[bstack11l1l1l_opy_ (u"ࠪࡹࡺ࡯ࡤࠨᄨ")])
        _1l11l11l1l_opy_[item.nodeid + bstack11l1l1l_opy_ (u"ࠫ࠲ࡹࡥࡵࡷࡳࠫᄩ")] = bstack1l11ll1lll_opy_
        bstack1l11l11lll_opy_(item, bstack1l11ll1lll_opy_, bstack11l1l1l_opy_ (u"ࠬࡎ࡯ࡰ࡭ࡕࡹࡳ࡙ࡴࡢࡴࡷࡩࡩ࠭ᄪ"))
    except Exception as err:
        print(bstack11l1l1l_opy_ (u"࠭ࡅࡹࡥࡨࡴࡹ࡯࡯࡯ࠢ࡬ࡲࠥࡶࡹࡵࡧࡶࡸࡤࡸࡵ࡯ࡶࡨࡷࡹࡥࡳࡦࡶࡸࡴ࠿ࠦࡻࡾࠩᄫ"), str(err))
def pytest_runtest_teardown(item):
    try:
        if not bstack1llll1ll1l_opy_.on():
            return
        bstack1l11ll1lll_opy_ = {
            bstack11l1l1l_opy_ (u"ࠧࡶࡷ࡬ࡨࠬᄬ"): uuid4().__str__(),
            bstack11l1l1l_opy_ (u"ࠨࡵࡷࡥࡷࡺࡥࡥࡡࡤࡸࠬᄭ"): datetime.datetime.utcnow().isoformat() + bstack11l1l1l_opy_ (u"ࠩ࡝ࠫᄮ"),
            bstack11l1l1l_opy_ (u"ࠪࡸࡾࡶࡥࠨᄯ"): bstack11l1l1l_opy_ (u"ࠫ࡭ࡵ࡯࡬ࠩᄰ"),
            bstack11l1l1l_opy_ (u"ࠬ࡮࡯ࡰ࡭ࡢࡸࡾࡶࡥࠨᄱ"): bstack11l1l1l_opy_ (u"࠭ࡁࡇࡖࡈࡖࡤࡋࡁࡄࡊࠪᄲ")
        }
        _1l11l11l1l_opy_[item.nodeid + bstack11l1l1l_opy_ (u"ࠧ࠮ࡶࡨࡥࡷࡪ࡯ࡸࡰࠪᄳ")] = bstack1l11ll1lll_opy_
        bstack1l11l11lll_opy_(item, bstack1l11ll1lll_opy_, bstack11l1l1l_opy_ (u"ࠨࡊࡲࡳࡰࡘࡵ࡯ࡕࡷࡥࡷࡺࡥࡥࠩᄴ"))
    except Exception as err:
        print(bstack11l1l1l_opy_ (u"ࠩࡈࡼࡨ࡫ࡰࡵ࡫ࡲࡲࠥ࡯࡮ࠡࡲࡼࡸࡪࡹࡴࡠࡴࡸࡲࡹ࡫ࡳࡵࡡࡷࡩࡦࡸࡤࡰࡹࡱ࠾ࠥࢁࡽࠨᄵ"), str(err))
@pytest.hookimpl(hookwrapper=True)
def pytest_fixture_setup(fixturedef):
    start_time = datetime.datetime.now()
    outcome = yield
    try:
        if not bstack1llll1ll1l_opy_.on():
            return
        bstack1l11l1llll_opy_ = threading.current_thread().bstack1l11l1lll1_opy_
        log = {
            bstack11l1l1l_opy_ (u"ࠪ࡯࡮ࡴࡤࠨᄶ"): bstack11l1l1l_opy_ (u"࡙ࠫࡋࡓࡕࡡࡖࡘࡊࡖࠧᄷ"),
            bstack11l1l1l_opy_ (u"ࠬࡳࡥࡴࡵࡤ࡫ࡪ࠭ᄸ"): fixturedef.argname,
            bstack11l1l1l_opy_ (u"࠭ࡨࡰࡱ࡮ࡣࡷࡻ࡮ࡠࡷࡸ࡭ࡩ࠭ᄹ"): threading.current_thread().bstack1l11l1lll1_opy_,
            bstack11l1l1l_opy_ (u"ࠧࡵ࡫ࡰࡩࡸࡺࡡ࡮ࡲࠪᄺ"): bstack11llll1ll_opy_(),
            bstack11l1l1l_opy_ (u"ࠨ࡮ࡨࡺࡪࡲࠧᄻ"): bstack1l1l111ll1_opy_(outcome),
            bstack11l1l1l_opy_ (u"ࠩࡧࡹࡷࡧࡴࡪࡱࡱࠫᄼ"): (datetime.datetime.now() - start_time).total_seconds() * 1000,
        }
        if log[bstack11l1l1l_opy_ (u"ࠪࡰࡪࡼࡥ࡭ࠩᄽ")] == bstack11l1l1l_opy_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫᄾ"):
            log[bstack11l1l1l_opy_ (u"ࠬ࡬ࡡࡪ࡮ࡸࡶࡪࡥࡴࡺࡲࡨࠫᄿ")] = bstack11l1l1l_opy_ (u"࠭ࡕ࡯ࡪࡤࡲࡩࡲࡥࡥࡇࡵࡶࡴࡸࠧᅀ")
            log[bstack11l1l1l_opy_ (u"ࠧࡧࡣ࡬ࡰࡺࡸࡥࠨᅁ")] = outcome.exception.__str__()
        if not _1l11ll1l1l_opy_.get(bstack1l11l1llll_opy_, None):
            _1l11ll1l1l_opy_[bstack1l11l1llll_opy_] = []
        _1l11ll1l1l_opy_[bstack1l11l1llll_opy_].append(log)
    except Exception as err:
        print(bstack11l1l1l_opy_ (u"ࠨࡇࡻࡧࡪࡶࡴࡪࡱࡱࠤ࡮ࡴࠠࡱࡻࡷࡩࡸࡺ࡟ࡧ࡫ࡻࡸࡺࡸࡥࡠࡵࡨࡸࡺࡶ࠺ࠡࡽࢀࠫᅂ"), str(err))
@bstack1llll1ll1l_opy_.bstack1l1lll111l_opy_
def bstack1l11l1l1ll_opy_(item, call, report):
    try:
        if report.when == bstack11l1l1l_opy_ (u"ࠩࡦࡥࡱࡲࠧᅃ"):
            bstack1l11l1ll11_opy_.reset()
        if report.when == bstack11l1l1l_opy_ (u"ࠪࡧࡦࡲ࡬ࠨᅄ"):
            _1l11l11l1l_opy_[item.nodeid][bstack11l1l1l_opy_ (u"ࠫ࡫࡯࡮ࡪࡵ࡫ࡩࡩࡥࡡࡵࠩᅅ")] = datetime.datetime.utcfromtimestamp(report.stop).isoformat() + bstack11l1l1l_opy_ (u"ࠬࡠࠧᅆ")
            bstack1l11l111ll_opy_(item, _1l11l11l1l_opy_[item.nodeid], bstack11l1l1l_opy_ (u"࠭ࡔࡦࡵࡷࡖࡺࡴࡆࡪࡰ࡬ࡷ࡭࡫ࡤࠨᅇ"), report, call)
        elif report.when in [bstack11l1l1l_opy_ (u"ࠧࡴࡧࡷࡹࡵ࠭ᅈ"), bstack11l1l1l_opy_ (u"ࠨࡶࡨࡥࡷࡪ࡯ࡸࡰࠪᅉ")]:
            bstack1l11ll11l1_opy_ = item.nodeid + bstack11l1l1l_opy_ (u"ࠩ࠰ࠫᅊ") + report.when
            if report.skipped:
                hook_type = bstack11l1l1l_opy_ (u"ࠪࡆࡊࡌࡏࡓࡇࡢࡉࡆࡉࡈࠨᅋ") if report.when == bstack11l1l1l_opy_ (u"ࠫࡸ࡫ࡴࡶࡲࠪᅌ") else bstack11l1l1l_opy_ (u"ࠬࡇࡆࡕࡇࡕࡣࡊࡇࡃࡉࠩᅍ")
                _1l11l11l1l_opy_[bstack1l11ll11l1_opy_] = {
                    bstack11l1l1l_opy_ (u"࠭ࡵࡶ࡫ࡧࠫᅎ"): uuid4().__str__(),
                    bstack11l1l1l_opy_ (u"ࠧࡴࡶࡤࡶࡹ࡫ࡤࡠࡣࡷࠫᅏ"): datetime.datetime.utcfromtimestamp(report.start).isoformat() + bstack11l1l1l_opy_ (u"ࠨ࡜ࠪᅐ"),
                    bstack11l1l1l_opy_ (u"ࠩ࡫ࡳࡴࡱ࡟ࡵࡻࡳࡩࠬᅑ"): hook_type
                }
            _1l11l11l1l_opy_[bstack1l11ll11l1_opy_][bstack11l1l1l_opy_ (u"ࠪࡪ࡮ࡴࡩࡴࡪࡨࡨࡤࡧࡴࠨᅒ")] = datetime.datetime.utcfromtimestamp(report.stop).isoformat() + bstack11l1l1l_opy_ (u"ࠫ࡟࠭ᅓ")
            if report.when == bstack11l1l1l_opy_ (u"ࠬࡹࡥࡵࡷࡳࠫᅔ"):
                bstack1l11l1llll_opy_ = _1l11l11l1l_opy_[bstack1l11ll11l1_opy_][bstack11l1l1l_opy_ (u"࠭ࡵࡶ࡫ࡧࠫᅕ")]
                if _1l11ll1l1l_opy_.get(bstack1l11l1llll_opy_, None):
                    bstack1llll1ll1l_opy_.bstack1l1ll1llll_opy_(_1l11ll1l1l_opy_[bstack1l11l1llll_opy_])
            bstack1l11l11lll_opy_(item, _1l11l11l1l_opy_[bstack1l11ll11l1_opy_], bstack11l1l1l_opy_ (u"ࠧࡉࡱࡲ࡯ࡗࡻ࡮ࡇ࡫ࡱ࡭ࡸ࡮ࡥࡥࠩᅖ"), report, call)
            if report.when == bstack11l1l1l_opy_ (u"ࠨࡵࡨࡸࡺࡶࠧᅗ"):
                if report.outcome == bstack11l1l1l_opy_ (u"ࠩࡩࡥ࡮ࡲࡥࡥࠩᅘ"):
                    bstack1l11ll1lll_opy_ = {
                        bstack11l1l1l_opy_ (u"ࠪࡹࡺ࡯ࡤࠨᅙ"): uuid4().__str__(),
                        bstack11l1l1l_opy_ (u"ࠫࡸࡺࡡࡳࡶࡨࡨࡤࡧࡴࠨᅚ"): bstack11llll1ll_opy_(),
                        bstack11l1l1l_opy_ (u"ࠬ࡬ࡩ࡯࡫ࡶ࡬ࡪࡪ࡟ࡢࡶࠪᅛ"): bstack11llll1ll_opy_()
                    }
                    _1l11l11l1l_opy_[item.nodeid] = {**_1l11l11l1l_opy_[item.nodeid], **bstack1l11ll1lll_opy_}
                    bstack1l11l111ll_opy_(item, _1l11l11l1l_opy_[item.nodeid], bstack11l1l1l_opy_ (u"࠭ࡔࡦࡵࡷࡖࡺࡴࡓࡵࡣࡵࡸࡪࡪࠧᅜ"))
                    bstack1l11l111ll_opy_(item, _1l11l11l1l_opy_[item.nodeid], bstack11l1l1l_opy_ (u"ࠧࡕࡧࡶࡸࡗࡻ࡮ࡇ࡫ࡱ࡭ࡸ࡮ࡥࡥࠩᅝ"), report, call)
    except Exception as err:
        print(bstack11l1l1l_opy_ (u"ࠨࡇࡻࡧࡪࡶࡴࡪࡱࡱࠤ࡮ࡴࠠࡩࡣࡱࡨࡱ࡫࡟ࡰ࠳࠴ࡽࡤࡺࡥࡴࡶࡢࡩࡻ࡫࡮ࡵ࠼ࠣࡿࢂ࠭ᅞ"), str(err))
def bstack1l11ll11ll_opy_(test, bstack1l11ll1lll_opy_, result=None, call=None, bstack1l111ll11_opy_=None):
    file_path = os.path.relpath(test.fspath.strpath, start=os.getcwd())
    bstack1l11l1l111_opy_ = {
        bstack11l1l1l_opy_ (u"ࠩࡸࡹ࡮ࡪࠧᅟ"): bstack1l11ll1lll_opy_[bstack11l1l1l_opy_ (u"ࠪࡹࡺ࡯ࡤࠨᅠ")],
        bstack11l1l1l_opy_ (u"ࠫࡹࡿࡰࡦࠩᅡ"): bstack11l1l1l_opy_ (u"ࠬࡺࡥࡴࡶࠪᅢ"),
        bstack11l1l1l_opy_ (u"࠭࡮ࡢ࡯ࡨࠫᅣ"): test.name,
        bstack11l1l1l_opy_ (u"ࠧࡣࡱࡧࡽࠬᅤ"): {
            bstack11l1l1l_opy_ (u"ࠨ࡮ࡤࡲ࡬࠭ᅥ"): bstack11l1l1l_opy_ (u"ࠩࡳࡽࡹ࡮࡯࡯ࠩᅦ"),
            bstack11l1l1l_opy_ (u"ࠪࡧࡴࡪࡥࠨᅧ"): inspect.getsource(test.obj)
        },
        bstack11l1l1l_opy_ (u"ࠫ࡮ࡪࡥ࡯ࡶ࡬ࡪ࡮࡫ࡲࠨᅨ"): test.name,
        bstack11l1l1l_opy_ (u"ࠬࡹࡣࡰࡲࡨࠫᅩ"): test.name,
        bstack11l1l1l_opy_ (u"࠭ࡳࡤࡱࡳࡩࡸ࠭ᅪ"): bstack1llll1ll1l_opy_.bstack1l1ll111l1_opy_(test),
        bstack11l1l1l_opy_ (u"ࠧࡧ࡫࡯ࡩࡤࡴࡡ࡮ࡧࠪᅫ"): file_path,
        bstack11l1l1l_opy_ (u"ࠨ࡮ࡲࡧࡦࡺࡩࡰࡰࠪᅬ"): file_path,
        bstack11l1l1l_opy_ (u"ࠩࡵࡩࡸࡻ࡬ࡵࠩᅭ"): bstack11l1l1l_opy_ (u"ࠪࡴࡪࡴࡤࡪࡰࡪࠫᅮ"),
        bstack11l1l1l_opy_ (u"ࠫࡻࡩ࡟ࡧ࡫࡯ࡩࡵࡧࡴࡩࠩᅯ"): file_path,
        bstack11l1l1l_opy_ (u"ࠬࡹࡴࡢࡴࡷࡩࡩࡥࡡࡵࠩᅰ"): bstack1l11ll1lll_opy_[bstack11l1l1l_opy_ (u"࠭ࡳࡵࡣࡵࡸࡪࡪ࡟ࡢࡶࠪᅱ")],
        bstack11l1l1l_opy_ (u"ࠧࡧࡴࡤࡱࡪࡽ࡯ࡳ࡭ࠪᅲ"): bstack11l1l1l_opy_ (u"ࠨࡒࡼࡸࡪࡹࡴࠨᅳ"),
        bstack11l1l1l_opy_ (u"ࠩࡦࡹࡸࡺ࡯࡮ࡔࡨࡶࡺࡴࡐࡢࡴࡤࡱࠬᅴ"): {
            bstack11l1l1l_opy_ (u"ࠪࡶࡪࡸࡵ࡯ࡡࡱࡥࡲ࡫ࠧᅵ"): test.nodeid
        },
        bstack11l1l1l_opy_ (u"ࠫࡹࡧࡧࡴࠩᅶ"): bstack1l1l111111_opy_(test.own_markers)
    }
    if bstack1l111ll11_opy_ == bstack11l1l1l_opy_ (u"࡚ࠬࡥࡴࡶࡕࡹࡳ࡙࡫ࡪࡲࡳࡩࡩ࠭ᅷ"):
        bstack1l11l1l111_opy_[bstack11l1l1l_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭ᅸ")] = bstack11l1l1l_opy_ (u"ࠧࡴ࡭࡬ࡴࡵ࡫ࡤࠨᅹ")
        bstack1l11l1l111_opy_[bstack11l1l1l_opy_ (u"ࠨࡪࡲࡳࡰࡹࠧᅺ")] = bstack1l11ll1lll_opy_[bstack11l1l1l_opy_ (u"ࠩ࡫ࡳࡴࡱࡳࠨᅻ")]
        bstack1l11l1l111_opy_[bstack11l1l1l_opy_ (u"ࠪࡪ࡮ࡴࡩࡴࡪࡨࡨࡤࡧࡴࠨᅼ")] = bstack1l11ll1lll_opy_[bstack11l1l1l_opy_ (u"ࠫ࡫࡯࡮ࡪࡵ࡫ࡩࡩࡥࡡࡵࠩᅽ")]
    if result:
        bstack1l11l1l111_opy_[bstack11l1l1l_opy_ (u"ࠬࡸࡥࡴࡷ࡯ࡸࠬᅾ")] = result.outcome
        bstack1l11l1l111_opy_[bstack11l1l1l_opy_ (u"࠭ࡤࡶࡴࡤࡸ࡮ࡵ࡮ࡠ࡫ࡱࡣࡲࡹࠧᅿ")] = result.duration * 1000
        bstack1l11l1l111_opy_[bstack11l1l1l_opy_ (u"ࠧࡧ࡫ࡱ࡭ࡸ࡮ࡥࡥࡡࡤࡸࠬᆀ")] = bstack1l11ll1lll_opy_[bstack11l1l1l_opy_ (u"ࠨࡨ࡬ࡲ࡮ࡹࡨࡦࡦࡢࡥࡹ࠭ᆁ")]
        if result.failed:
            bstack1l11l1l111_opy_[bstack11l1l1l_opy_ (u"ࠩࡩࡥ࡮ࡲࡵࡳࡧࡢࡸࡾࡶࡥࠨᆂ")] = bstack1llll1ll1l_opy_.bstack1ll1111l11_opy_(call.excinfo.typename)
            bstack1l11l1l111_opy_[bstack11l1l1l_opy_ (u"ࠪࡪࡦ࡯࡬ࡶࡴࡨࠫᆃ")] = bstack1llll1ll1l_opy_.bstack1l1ll1l111_opy_(call.excinfo, result)
        bstack1l11l1l111_opy_[bstack11l1l1l_opy_ (u"ࠫ࡭ࡵ࡯࡬ࡵࠪᆄ")] = bstack1l11ll1lll_opy_[bstack11l1l1l_opy_ (u"ࠬ࡮࡯ࡰ࡭ࡶࠫᆅ")]
    return bstack1l11l1l111_opy_
def bstack1l11ll1ll1_opy_(test, bstack1l11l11ll1_opy_, bstack1l111ll11_opy_, result, call):
    file_path = os.path.relpath(test.fspath.strpath, start=os.getcwd())
    hook_type = bstack1l11l11ll1_opy_[bstack11l1l1l_opy_ (u"࠭ࡨࡰࡱ࡮ࡣࡹࡿࡰࡦࠩᆆ")]
    hook_data = {
        bstack11l1l1l_opy_ (u"ࠧࡶࡷ࡬ࡨࠬᆇ"): bstack1l11l11ll1_opy_[bstack11l1l1l_opy_ (u"ࠨࡷࡸ࡭ࡩ࠭ᆈ")],
        bstack11l1l1l_opy_ (u"ࠩࡷࡽࡵ࡫ࠧᆉ"): bstack11l1l1l_opy_ (u"ࠪ࡬ࡴࡵ࡫ࠨᆊ"),
        bstack11l1l1l_opy_ (u"ࠫࡳࡧ࡭ࡦࠩᆋ"): bstack11l1l1l_opy_ (u"ࠬࢁࡽࠡࡨࡲࡶࠥࢁࡽࠨᆌ").format(bstack1llll1ll1l_opy_.bstack1l1lllll1l_opy_(hook_type), test.name),
        bstack11l1l1l_opy_ (u"࠭ࡢࡰࡦࡼࠫᆍ"): {
            bstack11l1l1l_opy_ (u"ࠧ࡭ࡣࡱ࡫ࠬᆎ"): bstack11l1l1l_opy_ (u"ࠨࡲࡼࡸ࡭ࡵ࡮ࠨᆏ"),
            bstack11l1l1l_opy_ (u"ࠩࡦࡳࡩ࡫ࠧᆐ"): None
        },
        bstack11l1l1l_opy_ (u"ࠪࡷࡨࡵࡰࡦࠩᆑ"): test.name,
        bstack11l1l1l_opy_ (u"ࠫࡸࡩ࡯ࡱࡧࡶࠫᆒ"): bstack1llll1ll1l_opy_.bstack1l1ll111l1_opy_(test),
        bstack11l1l1l_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡢࡲࡦࡳࡥࠨᆓ"): file_path,
        bstack11l1l1l_opy_ (u"࠭࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠨᆔ"): file_path,
        bstack11l1l1l_opy_ (u"ࠧࡳࡧࡶࡹࡱࡺࠧᆕ"): bstack11l1l1l_opy_ (u"ࠨࡲࡨࡲࡩ࡯࡮ࡨࠩᆖ"),
        bstack11l1l1l_opy_ (u"ࠩࡹࡧࡤ࡬ࡩ࡭ࡧࡳࡥࡹ࡮ࠧᆗ"): file_path,
        bstack11l1l1l_opy_ (u"ࠪࡷࡹࡧࡲࡵࡧࡧࡣࡦࡺࠧᆘ"): bstack1l11l11ll1_opy_[bstack11l1l1l_opy_ (u"ࠫࡸࡺࡡࡳࡶࡨࡨࡤࡧࡴࠨᆙ")],
        bstack11l1l1l_opy_ (u"ࠬ࡬ࡲࡢ࡯ࡨࡻࡴࡸ࡫ࠨᆚ"): bstack11l1l1l_opy_ (u"࠭ࡐࡺࡶࡨࡷࡹ࠭ᆛ"),
        bstack11l1l1l_opy_ (u"ࠧࡩࡱࡲ࡯ࡤࡺࡹࡱࡧࠪᆜ"): bstack1l11l11ll1_opy_[bstack11l1l1l_opy_ (u"ࠨࡪࡲࡳࡰࡥࡴࡺࡲࡨࠫᆝ")]
    }
    if _1l11l11l1l_opy_.get(test.nodeid, None) is not None and _1l11l11l1l_opy_[test.nodeid].get(bstack11l1l1l_opy_ (u"ࠩࡸࡹ࡮ࡪࠧᆞ"), None):
        hook_data[bstack11l1l1l_opy_ (u"ࠪࡸࡪࡹࡴࡠࡴࡸࡲࡤ࡯ࡤࠨᆟ")] = _1l11l11l1l_opy_[test.nodeid][bstack11l1l1l_opy_ (u"ࠫࡺࡻࡩࡥࠩᆠ")]
    if result:
        hook_data[bstack11l1l1l_opy_ (u"ࠬࡸࡥࡴࡷ࡯ࡸࠬᆡ")] = result.outcome
        hook_data[bstack11l1l1l_opy_ (u"࠭ࡤࡶࡴࡤࡸ࡮ࡵ࡮ࡠ࡫ࡱࡣࡲࡹࠧᆢ")] = result.duration * 1000
        hook_data[bstack11l1l1l_opy_ (u"ࠧࡧ࡫ࡱ࡭ࡸ࡮ࡥࡥࡡࡤࡸࠬᆣ")] = bstack1l11l11ll1_opy_[bstack11l1l1l_opy_ (u"ࠨࡨ࡬ࡲ࡮ࡹࡨࡦࡦࡢࡥࡹ࠭ᆤ")]
        if result.failed:
            hook_data[bstack11l1l1l_opy_ (u"ࠩࡩࡥ࡮ࡲࡵࡳࡧࡢࡸࡾࡶࡥࠨᆥ")] = bstack1llll1ll1l_opy_.bstack1ll1111l11_opy_(call.excinfo.typename)
            hook_data[bstack11l1l1l_opy_ (u"ࠪࡪࡦ࡯࡬ࡶࡴࡨࠫᆦ")] = bstack1llll1ll1l_opy_.bstack1l1ll1l111_opy_(call.excinfo, result)
    return hook_data
def bstack1l11l111ll_opy_(test, bstack1l11ll1lll_opy_, bstack1l111ll11_opy_, result=None, call=None):
    bstack1l11l1l111_opy_ = bstack1l11ll11ll_opy_(test, bstack1l11ll1lll_opy_, result, call, bstack1l111ll11_opy_)
    driver = getattr(test, bstack11l1l1l_opy_ (u"ࠫࡤࡪࡲࡪࡸࡨࡶࠬᆧ"), None)
    if bstack1l111ll11_opy_ == bstack11l1l1l_opy_ (u"࡚ࠬࡥࡴࡶࡕࡹࡳ࡙ࡴࡢࡴࡷࡩࡩ࠭ᆨ") and driver:
        bstack1l11l1l111_opy_[bstack11l1l1l_opy_ (u"࠭ࡩ࡯ࡶࡨ࡫ࡷࡧࡴࡪࡱࡱࡷࠬᆩ")] = bstack1llll1ll1l_opy_.bstack1l1lll1ll1_opy_(driver)
    if bstack1l111ll11_opy_ == bstack11l1l1l_opy_ (u"ࠧࡕࡧࡶࡸࡗࡻ࡮ࡔ࡭࡬ࡴࡵ࡫ࡤࠨᆪ"):
        bstack1l111ll11_opy_ = bstack11l1l1l_opy_ (u"ࠨࡖࡨࡷࡹࡘࡵ࡯ࡈ࡬ࡲ࡮ࡹࡨࡦࡦࠪᆫ")
    bstack1l11ll111l_opy_ = {
        bstack11l1l1l_opy_ (u"ࠩࡨࡺࡪࡴࡴࡠࡶࡼࡴࡪ࠭ᆬ"): bstack1l111ll11_opy_,
        bstack11l1l1l_opy_ (u"ࠪࡸࡪࡹࡴࡠࡴࡸࡲࠬᆭ"): bstack1l11l1l111_opy_
    }
    bstack1llll1ll1l_opy_.bstack1l1ll11l11_opy_(bstack1l11ll111l_opy_)
def bstack1l11l11lll_opy_(test, bstack1l11ll1lll_opy_, bstack1l111ll11_opy_, result=None, call=None):
    hook_data = bstack1l11ll1ll1_opy_(test, bstack1l11ll1lll_opy_, bstack1l111ll11_opy_, result, call)
    bstack1l11ll111l_opy_ = {
        bstack11l1l1l_opy_ (u"ࠫࡪࡼࡥ࡯ࡶࡢࡸࡾࡶࡥࠨᆮ"): bstack1l111ll11_opy_,
        bstack11l1l1l_opy_ (u"ࠬ࡮࡯ࡰ࡭ࡢࡶࡺࡴࠧᆯ"): hook_data
    }
    bstack1llll1ll1l_opy_.bstack1l1ll11l11_opy_(bstack1l11ll111l_opy_)
@pytest.fixture(autouse=True)
def second_fixture(caplog, request):
    yield
    try:
        if not bstack1llll1ll1l_opy_.on():
            return
        records = caplog.get_records(bstack11l1l1l_opy_ (u"࠭ࡣࡢ࡮࡯ࠫᆰ"))
        bstack1l1llll111_opy_ = []
        for record in records:
            if record.message == bstack11l1l1l_opy_ (u"ࠧ࡝ࡰࠪᆱ"):
                continue
            bstack1l1llll111_opy_.append({
                bstack11l1l1l_opy_ (u"ࠨࡶ࡬ࡱࡪࡹࡴࡢ࡯ࡳࠫᆲ"): datetime.datetime.utcfromtimestamp(record.created).isoformat() + bstack11l1l1l_opy_ (u"ࠩ࡝ࠫᆳ"),
                bstack11l1l1l_opy_ (u"ࠪࡰࡪࡼࡥ࡭ࠩᆴ"): record.levelname,
                bstack11l1l1l_opy_ (u"ࠫࡲ࡫ࡳࡴࡣࡪࡩࠬᆵ"): record.message,
                bstack11l1l1l_opy_ (u"ࠬࡺࡥࡴࡶࡢࡶࡺࡴ࡟ࡶࡷ࡬ࡨࠬᆶ"): _1l11l11l1l_opy_.get(request.node.nodeid).get(bstack11l1l1l_opy_ (u"࠭ࡵࡶ࡫ࡧࠫᆷ"))
            })
        bstack1llll1ll1l_opy_.bstack1l1ll1ll1l_opy_(bstack1l1llll111_opy_)
    except Exception as err:
        print(bstack11l1l1l_opy_ (u"ࠧࡆࡺࡦࡩࡵࡺࡩࡰࡰࠣ࡭ࡳࠦࡳࡦࡥࡲࡲࡩࡥࡦࡪࡺࡷࡹࡷ࡫࠺ࠡࡽࢀࠫᆸ"), str(err))
def bstack1l11l1l1l1_opy_(driver_command, response):
    if driver_command == bstack11l1l1l_opy_ (u"ࠨࡵࡦࡶࡪ࡫࡮ࡴࡪࡲࡸࠬᆹ"):
        bstack1llll1ll1l_opy_.bstack1l1llll1ll_opy_({
            bstack11l1l1l_opy_ (u"ࠩ࡬ࡱࡦ࡭ࡥࠨᆺ"): response[bstack11l1l1l_opy_ (u"ࠪࡺࡦࡲࡵࡦࠩᆻ")],
            bstack11l1l1l_opy_ (u"ࠫࡹ࡫ࡳࡵࡡࡵࡹࡳࡥࡵࡶ࡫ࡧࠫᆼ"): bstack1l1l1lll1l_opy_
        })
@bstack1llll1ll1l_opy_.bstack1l1lll111l_opy_
def bstack1l11l1l11l_opy_():
    if bstack1l11llllll_opy_():
        bstack1ll111l1ll_opy_(bstack1l11l1l1l1_opy_)
bstack1l11l1l11l_opy_()