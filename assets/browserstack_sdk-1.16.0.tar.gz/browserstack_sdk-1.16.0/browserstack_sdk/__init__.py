# coding: UTF-8
import sys
bstack1111l1l_opy_ = sys.version_info [0] == 2
bstack1l111l_opy_ = 2048
bstack1lllll1l_opy_ = 7
def bstack11l1l1l_opy_ (bstack111l1l_opy_):
    global bstack1ll111_opy_
    bstack1111111_opy_ = ord (bstack111l1l_opy_ [-1])
    bstack1l1111_opy_ = bstack111l1l_opy_ [:-1]
    bstack1lll111_opy_ = bstack1111111_opy_ % len (bstack1l1111_opy_)
    bstack11ll1l_opy_ = bstack1l1111_opy_ [:bstack1lll111_opy_] + bstack1l1111_opy_ [bstack1lll111_opy_:]
    if bstack1111l1l_opy_:
        bstack11111l1_opy_ = unicode () .join ([unichr (ord (char) - bstack1l111l_opy_ - (bstack1l1lll_opy_ + bstack1111111_opy_) % bstack1lllll1l_opy_) for bstack1l1lll_opy_, char in enumerate (bstack11ll1l_opy_)])
    else:
        bstack11111l1_opy_ = str () .join ([chr (ord (char) - bstack1l111l_opy_ - (bstack1l1lll_opy_ + bstack1111111_opy_) % bstack1lllll1l_opy_) for bstack1l1lll_opy_, char in enumerate (bstack11ll1l_opy_)])
    return eval (bstack11111l1_opy_)
import atexit
import os
import signal
import sys
import yaml
import requests
import logging
import threading
import socket
import datetime
import string
import random
import json
import collections.abc
import re
import multiprocessing
import traceback
import copy
from packaging import version
from browserstack.local import Local
from urllib.parse import urlparse
from bstack_utils.constants import *
def bstack11lll11ll_opy_():
  global CONFIG
  headers = {
        bstack11l1l1l_opy_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡷࡽࡵ࡫ࠧ࢞"): bstack11l1l1l_opy_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯࡫ࡵࡲࡲࠬ࢟"),
      }
  proxies = bstack1111l1lll_opy_(CONFIG, bstack1lll111l11_opy_)
  try:
    response = requests.get(bstack1lll111l11_opy_, headers=headers, proxies=proxies, timeout=5)
    if response.json():
      bstack1ll1ll1lll_opy_ = response.json()[bstack11l1l1l_opy_ (u"ࠪ࡬ࡺࡨࡳࠨࢠ")]
      logger.debug(bstack111l1ll1l_opy_.format(response.json()))
      return bstack1ll1ll1lll_opy_
    else:
      logger.debug(bstack1lll1l1ll_opy_.format(bstack11l1l1l_opy_ (u"ࠦࡗ࡫ࡳࡱࡱࡱࡷࡪࠦࡊࡔࡑࡑࠤࡵࡧࡲࡴࡧࠣࡩࡷࡸ࡯ࡳࠢࠥࢡ")))
  except Exception as e:
    logger.debug(bstack1lll1l1ll_opy_.format(e))
def bstack11111111l_opy_(hub_url):
  global CONFIG
  url = bstack11l1l1l_opy_ (u"ࠧ࡮ࡴࡵࡲࡶ࠾࠴࠵ࠢࢢ")+  hub_url + bstack11l1l1l_opy_ (u"ࠨ࠯ࡤࡪࡨࡧࡰࠨࢣ")
  headers = {
        bstack11l1l1l_opy_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡶࡼࡴࡪ࠭ࢤ"): bstack11l1l1l_opy_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡪࡴࡱࡱࠫࢥ"),
      }
  proxies = bstack1111l1lll_opy_(CONFIG, url)
  try:
    start_time = time.perf_counter()
    requests.get(url, headers=headers, proxies=proxies, timeout=5)
    latency = time.perf_counter() - start_time
    logger.debug(bstack111ll111l_opy_.format(hub_url, latency))
    return dict(hub_url=hub_url, latency=latency)
  except Exception as e:
    logger.debug(bstack11l1ll11_opy_.format(hub_url, e))
def bstack1111111ll_opy_():
  try:
    global bstack1lll1l111_opy_
    bstack1ll1ll1lll_opy_ = bstack11lll11ll_opy_()
    bstack1l11ll11l_opy_ = []
    results = []
    for bstack1111l1ll1_opy_ in bstack1ll1ll1lll_opy_:
      bstack1l11ll11l_opy_.append(bstack1ll1l11l_opy_(target=bstack11111111l_opy_,args=(bstack1111l1ll1_opy_,)))
    for t in bstack1l11ll11l_opy_:
      t.start()
    for t in bstack1l11ll11l_opy_:
      results.append(t.join())
    bstack111l1l1ll_opy_ = {}
    for item in results:
      hub_url = item[bstack11l1l1l_opy_ (u"ࠩ࡫ࡹࡧࡥࡵࡳ࡮ࠪࢦ")]
      latency = item[bstack11l1l1l_opy_ (u"ࠪࡰࡦࡺࡥ࡯ࡥࡼࠫࢧ")]
      bstack111l1l1ll_opy_[hub_url] = latency
    bstack1l111111l_opy_ = min(bstack111l1l1ll_opy_, key= lambda x: bstack111l1l1ll_opy_[x])
    bstack1lll1l111_opy_ = bstack1l111111l_opy_
    logger.debug(bstack1l1llllll_opy_.format(bstack1l111111l_opy_))
  except Exception as e:
    logger.debug(bstack11111lll_opy_.format(e))
from bstack_utils.messages import *
from bstack_utils.config import Config
from bstack_utils.helper import bstack11llll11l_opy_, bstack1llll111l1_opy_, bstack1ll1ll111l_opy_
from bstack_utils.bstack1ll1ll11l_opy_ import bstack1llll1ll1l_opy_
from bstack_utils.proxy import bstack11lll1ll1_opy_, bstack1111l1lll_opy_, bstack1l111l11l_opy_, bstack1lll11l1l_opy_
from browserstack_sdk.bstack1ll11ll1_opy_ import *
from browserstack_sdk.bstack1ll11l11_opy_ import *
bstack1lll1ll1l1_opy_ = bstack11l1l1l_opy_ (u"ࠫࠥࠦ࠯ࠫࠢࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࠦࠪ࠰࡞ࡱࠤࠥ࡯ࡦࠩࡲࡤ࡫ࡪࠦ࠽࠾࠿ࠣࡺࡴ࡯ࡤࠡ࠲ࠬࠤࢀࡢ࡮ࠡࠢࠣࡸࡷࡿࡻ࡝ࡰࠣࡧࡴࡴࡳࡵࠢࡩࡷࠥࡃࠠࡳࡧࡴࡹ࡮ࡸࡥࠩ࡞ࠪࡪࡸࡢࠧࠪ࠽࡟ࡲࠥࠦࠠࠡࠢࡩࡷ࠳ࡧࡰࡱࡧࡱࡨࡋ࡯࡬ࡦࡕࡼࡲࡨ࠮ࡢࡴࡶࡤࡧࡰࡥࡰࡢࡶ࡫࠰ࠥࡐࡓࡐࡐ࠱ࡷࡹࡸࡩ࡯ࡩ࡬ࡪࡾ࠮ࡰࡠ࡫ࡱࡨࡪࡾࠩࠡ࠭ࠣࠦ࠿ࠨࠠࠬࠢࡍࡗࡔࡔ࠮ࡴࡶࡵ࡭ࡳ࡭ࡩࡧࡻࠫࡎࡘࡕࡎ࠯ࡲࡤࡶࡸ࡫ࠨࠩࡣࡺࡥ࡮ࡺࠠ࡯ࡧࡺࡔࡦ࡭ࡥ࠳࠰ࡨࡺࡦࡲࡵࡢࡶࡨࠬࠧ࠮ࠩࠡ࠿ࡁࠤࢀࢃࠢ࠭ࠢ࡟ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡢࡩࡽ࡫ࡣࡶࡶࡲࡶ࠿ࠦࡻࠣࡣࡦࡸ࡮ࡵ࡮ࠣ࠼ࠣࠦ࡬࡫ࡴࡔࡧࡶࡷ࡮ࡵ࡮ࡅࡧࡷࡥ࡮ࡲࡳࠣࡿ࡟ࠫ࠮࠯ࠩ࡜ࠤ࡫ࡥࡸ࡮ࡥࡥࡡ࡬ࡨࠧࡣࠩࠡ࠭ࠣࠦ࠱ࡢ࡜࡯ࠤࠬࡠࡳࠦࠠࠡࠢࢀࡧࡦࡺࡣࡩࠪࡨࡼ࠮ࢁ࡜࡯ࠢࠣࠤࠥࢃ࡜࡯ࠢࠣࢁࡡࡴࠠࠡ࠱࠭ࠤࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽ࠡࠬ࠲ࠫࢨ")
bstack1lll111l1l_opy_ = bstack11l1l1l_opy_ (u"ࠬࡢ࡮࠰ࠬࠣࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃࠠࠫ࠱࡟ࡲࡨࡵ࡮ࡴࡶࠣࡦࡸࡺࡡࡤ࡭ࡢࡴࡦࡺࡨࠡ࠿ࠣࡴࡷࡵࡣࡦࡵࡶ࠲ࡦࡸࡧࡷ࡝ࡳࡶࡴࡩࡥࡴࡵ࠱ࡥࡷ࡭ࡶ࠯࡮ࡨࡲ࡬ࡺࡨࠡ࠯ࠣ࠷ࡢࡢ࡮ࡤࡱࡱࡷࡹࠦࡢࡴࡶࡤࡧࡰࡥࡣࡢࡲࡶࠤࡂࠦࡰࡳࡱࡦࡩࡸࡹ࠮ࡢࡴࡪࡺࡠࡶࡲࡰࡥࡨࡷࡸ࠴ࡡࡳࡩࡹ࠲ࡱ࡫࡮ࡨࡶ࡫ࠤ࠲ࠦ࠱࡞࡞ࡱࡧࡴࡴࡳࡵࠢࡳࡣ࡮ࡴࡤࡦࡺࠣࡁࠥࡶࡲࡰࡥࡨࡷࡸ࠴ࡡࡳࡩࡹ࡟ࡵࡸ࡯ࡤࡧࡶࡷ࠳ࡧࡲࡨࡸ࠱ࡰࡪࡴࡧࡵࡪࠣ࠱ࠥ࠸࡝࡝ࡰࡳࡶࡴࡩࡥࡴࡵ࠱ࡥࡷ࡭ࡶࠡ࠿ࠣࡴࡷࡵࡣࡦࡵࡶ࠲ࡦࡸࡧࡷ࠰ࡶࡰ࡮ࡩࡥࠩ࠲࠯ࠤࡵࡸ࡯ࡤࡧࡶࡷ࠳ࡧࡲࡨࡸ࠱ࡰࡪࡴࡧࡵࡪࠣ࠱ࠥ࠹ࠩ࡝ࡰࡦࡳࡳࡹࡴࠡ࡫ࡰࡴࡴࡸࡴࡠࡲ࡯ࡥࡾࡽࡲࡪࡩ࡫ࡸ࠹ࡥࡢࡴࡶࡤࡧࡰࠦ࠽ࠡࡴࡨࡵࡺ࡯ࡲࡦࠪࠥࡴࡱࡧࡹࡸࡴ࡬࡫࡭ࡺࠢࠪ࠽࡟ࡲ࡮ࡳࡰࡰࡴࡷࡣࡵࡲࡡࡺࡹࡵ࡭࡬࡮ࡴ࠵ࡡࡥࡷࡹࡧࡣ࡬࠰ࡦ࡬ࡷࡵ࡭ࡪࡷࡰ࠲ࡱࡧࡵ࡯ࡥ࡫ࠤࡂࠦࡡࡴࡻࡱࡧࠥ࠮࡬ࡢࡷࡱࡧ࡭ࡕࡰࡵ࡫ࡲࡲࡸ࠯ࠠ࠾ࡀࠣࡿࡡࡴ࡬ࡦࡶࠣࡧࡦࡶࡳ࠼࡞ࡱࡸࡷࡿࠠࡼ࡞ࡱࡧࡦࡶࡳࠡ࠿ࠣࡎࡘࡕࡎ࠯ࡲࡤࡶࡸ࡫ࠨࡣࡵࡷࡥࡨࡱ࡟ࡤࡣࡳࡷ࠮ࡢ࡮ࠡࠢࢀࠤࡨࡧࡴࡤࡪࠫࡩࡽ࠯ࠠࡼ࡞ࡱࠤࠥࠦࠠࡾ࡞ࡱࠤࠥࡸࡥࡵࡷࡵࡲࠥࡧࡷࡢ࡫ࡷࠤ࡮ࡳࡰࡰࡴࡷࡣࡵࡲࡡࡺࡹࡵ࡭࡬࡮ࡴ࠵ࡡࡥࡷࡹࡧࡣ࡬࠰ࡦ࡬ࡷࡵ࡭ࡪࡷࡰ࠲ࡨࡵ࡮࡯ࡧࡦࡸ࠭ࢁ࡜࡯ࠢࠣࠤࠥࡽࡳࡆࡰࡧࡴࡴ࡯࡮ࡵ࠼ࠣࡤࡼࡹࡳ࠻࠱࠲ࡧࡩࡶ࠮ࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠴ࡣࡰ࡯࠲ࡴࡱࡧࡹࡸࡴ࡬࡫࡭ࡺ࠿ࡤࡣࡳࡷࡂࠪࡻࡦࡰࡦࡳࡩ࡫ࡕࡓࡋࡆࡳࡲࡶ࡯࡯ࡧࡱࡸ࠭ࡐࡓࡐࡐ࠱ࡷࡹࡸࡩ࡯ࡩ࡬ࡪࡾ࠮ࡣࡢࡲࡶ࠭࠮ࢃࡠ࠭࡞ࡱࠤࠥࠦࠠ࠯࠰࠱ࡰࡦࡻ࡮ࡤࡪࡒࡴࡹ࡯࡯࡯ࡵ࡟ࡲࠥࠦࡽࠪ࡞ࡱࢁࡡࡴ࠯ࠫࠢࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࠦࠪ࠰࡞ࡱࠫࢩ")
from ._version import __version__
bstack1lll11l11l_opy_ = None
CONFIG = {}
bstack1ll11lll1l_opy_ = {}
bstack1lll1lll11_opy_ = {}
bstack11l1ll11l_opy_ = None
bstack1llll11l1l_opy_ = None
bstack1111l1l1_opy_ = None
bstack111111l11_opy_ = -1
bstack11l11111_opy_ = bstack11l11l111_opy_
bstack1111lll1_opy_ = 1
bstack11l11l1ll_opy_ = False
bstack11ll1l1l_opy_ = False
bstack1l11ll11_opy_ = bstack11l1l1l_opy_ (u"࠭ࠧࢪ")
bstack1l1111111_opy_ = bstack11l1l1l_opy_ (u"ࠧࠨࢫ")
bstack1ll11l11l_opy_ = False
bstack1lllll11l1_opy_ = True
bstack1ll1l11ll1_opy_ = bstack11l1l1l_opy_ (u"ࠨࠩࢬ")
bstack1ll1l111l1_opy_ = []
bstack1lll1l111_opy_ = bstack11l1l1l_opy_ (u"ࠩࠪࢭ")
bstack1l111l11_opy_ = False
bstack1l1l11lll_opy_ = None
bstack1lll11lll1_opy_ = None
bstack1l1111ll_opy_ = -1
bstack1lll1ll11l_opy_ = os.path.join(os.path.expanduser(bstack11l1l1l_opy_ (u"ࠪࢂࠬࢮ")), bstack11l1l1l_opy_ (u"ࠫ࠳ࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࠫࢯ"), bstack11l1l1l_opy_ (u"ࠬ࠴ࡲࡰࡤࡲࡸ࠲ࡸࡥࡱࡱࡵࡸ࠲࡮ࡥ࡭ࡲࡨࡶ࠳ࡰࡳࡰࡰࠪࢰ"))
bstack11llllll1_opy_ = []
bstack1lllllll1_opy_ = False
bstack11lll1l1_opy_ = False
bstack1l11ll1ll_opy_ = None
bstack1ll111ll1_opy_ = None
bstack11l1l11l_opy_ = None
bstack1l1lll1l1_opy_ = None
bstack1l11lll11_opy_ = None
bstack1llllll11_opy_ = None
bstack1l1l1l1ll_opy_ = None
bstack11lllllll_opy_ = None
bstack1ll11lllll_opy_ = None
bstack111ll1l11_opy_ = None
bstack11ll1111l_opy_ = None
bstack1l1lll1ll_opy_ = None
bstack1ll1ll11ll_opy_ = None
bstack111l1l1l_opy_ = None
bstack1lll1ll11_opy_ = None
bstack1llll111ll_opy_ = None
bstack1ll1lll1ll_opy_ = None
bstack1ll1l1111_opy_ = None
bstack1l11l11l_opy_ = bstack11l1l1l_opy_ (u"ࠨࠢࢱ")
logger = logging.getLogger(__name__)
logging.basicConfig(level=bstack11l11111_opy_,
                    format=bstack11l1l1l_opy_ (u"ࠧ࡝ࡰࠨࠬࡦࡹࡣࡵ࡫ࡰࡩ࠮ࡹࠠ࡜ࠧࠫࡲࡦࡳࡥࠪࡵࡠ࡟ࠪ࠮࡬ࡦࡸࡨࡰࡳࡧ࡭ࡦࠫࡶࡡࠥ࠳ࠠࠦࠪࡰࡩࡸࡹࡡࡨࡧࠬࡷࠬࢲ"),
                    datefmt=bstack11l1l1l_opy_ (u"ࠨࠧࡋ࠾ࠪࡓ࠺ࠦࡕࠪࢳ"),
                    stream=sys.stdout)
bstack111111ll_opy_ = Config.get_instance()
def bstack11lll1l1l_opy_():
  global CONFIG
  global bstack11l11111_opy_
  if bstack11l1l1l_opy_ (u"ࠩ࡯ࡳ࡬ࡒࡥࡷࡧ࡯ࠫࢴ") in CONFIG:
    bstack11l11111_opy_ = bstack1l1l1111_opy_[CONFIG[bstack11l1l1l_opy_ (u"ࠪࡰࡴ࡭ࡌࡦࡸࡨࡰࠬࢵ")]]
    logging.getLogger().setLevel(bstack11l11111_opy_)
def bstack11l1llll_opy_():
  global CONFIG
  global bstack1lllllll1_opy_
  bstack1l1l11l1_opy_ = bstack1lll111lll_opy_(CONFIG)
  if (bstack11l1l1l_opy_ (u"ࠫࡸࡱࡩࡱࡕࡨࡷࡸ࡯࡯࡯ࡐࡤࡱࡪ࠭ࢶ") in bstack1l1l11l1_opy_ and str(bstack1l1l11l1_opy_[bstack11l1l1l_opy_ (u"ࠬࡹ࡫ࡪࡲࡖࡩࡸࡹࡩࡰࡰࡑࡥࡲ࡫ࠧࢷ")]).lower() == bstack11l1l1l_opy_ (u"࠭ࡴࡳࡷࡨࠫࢸ")):
    bstack1lllllll1_opy_ = True
def bstack11l1llll1_opy_():
  from appium.version import version as appium_version
  return version.parse(appium_version)
def bstack1ll1ll1l1_opy_():
  from selenium import webdriver
  return version.parse(webdriver.__version__)
def bstack1111ll1ll_opy_():
  args = sys.argv
  for i in range(len(args)):
    if bstack11l1l1l_opy_ (u"ࠢ࠮࠯ࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡤࡱࡱࡪ࡮࡭ࡦࡪ࡮ࡨࠦࢹ") == args[i].lower() or bstack11l1l1l_opy_ (u"ࠣ࠯࠰ࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬࠰ࡦࡳࡳ࡬ࡩࡨࠤࢺ") == args[i].lower():
      path = args[i + 1]
      sys.argv.remove(args[i])
      sys.argv.remove(path)
      global bstack1ll1l11ll1_opy_
      bstack1ll1l11ll1_opy_ += bstack11l1l1l_opy_ (u"ࠩ࠰࠱ࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡆࡳࡳ࡬ࡩࡨࡈ࡬ࡰࡪࠦࠧࢻ") + path
      return path
  return None
bstack111l111l_opy_ = re.compile(bstack11l1l1l_opy_ (u"ࡵࠦ࠳࠰࠿࡝ࠦࡾࠬ࠳࠰࠿ࠪࡿ࠱࠮ࡄࠨࢼ"))
def bstack1lll11ll11_opy_(loader, node):
  value = loader.construct_scalar(node)
  for group in bstack111l111l_opy_.findall(value):
    if group is not None and os.environ.get(group) is not None:
      value = value.replace(bstack11l1l1l_opy_ (u"ࠦࠩࢁࠢࢽ") + group + bstack11l1l1l_opy_ (u"ࠧࢃࠢࢾ"), os.environ.get(group))
  return value
def bstack1111l11l_opy_():
  bstack11ll1l11_opy_ = bstack1111ll1ll_opy_()
  if bstack11ll1l11_opy_ and os.path.exists(os.path.abspath(bstack11ll1l11_opy_)):
    fileName = bstack11ll1l11_opy_
  if bstack11l1l1l_opy_ (u"࠭ࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤࡉࡏࡏࡈࡌࡋࡤࡌࡉࡍࡇࠪࢿ") in os.environ and os.path.exists(
          os.path.abspath(os.environ[bstack11l1l1l_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡃࡐࡐࡉࡍࡌࡥࡆࡊࡎࡈࠫࣀ")])) and not bstack11l1l1l_opy_ (u"ࠨࡨ࡬ࡰࡪࡔࡡ࡮ࡧࠪࣁ") in locals():
    fileName = os.environ[bstack11l1l1l_opy_ (u"ࠩࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡅࡒࡒࡋࡏࡇࡠࡈࡌࡐࡊ࠭ࣂ")]
  if bstack11l1l1l_opy_ (u"ࠪࡪ࡮ࡲࡥࡏࡣࡰࡩࠬࣃ") in locals():
    bstack111llll_opy_ = os.path.abspath(fileName)
  else:
    bstack111llll_opy_ = bstack11l1l1l_opy_ (u"ࠫࠬࣄ")
  bstack1111llll_opy_ = os.getcwd()
  bstack1l11lllll_opy_ = bstack11l1l1l_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮࠲ࡾࡳ࡬ࠨࣅ")
  bstack11111ll1_opy_ = bstack11l1l1l_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯࠳ࡿࡡ࡮࡮ࠪࣆ")
  while (not os.path.exists(bstack111llll_opy_)) and bstack1111llll_opy_ != bstack11l1l1l_opy_ (u"ࠢࠣࣇ"):
    bstack111llll_opy_ = os.path.join(bstack1111llll_opy_, bstack1l11lllll_opy_)
    if not os.path.exists(bstack111llll_opy_):
      bstack111llll_opy_ = os.path.join(bstack1111llll_opy_, bstack11111ll1_opy_)
    if bstack1111llll_opy_ != os.path.dirname(bstack1111llll_opy_):
      bstack1111llll_opy_ = os.path.dirname(bstack1111llll_opy_)
    else:
      bstack1111llll_opy_ = bstack11l1l1l_opy_ (u"ࠣࠤࣈ")
  if not os.path.exists(bstack111llll_opy_):
    bstack11ll1l1l1_opy_(
      bstack11lll1111_opy_.format(os.getcwd()))
  try:
    with open(bstack111llll_opy_, bstack11l1l1l_opy_ (u"ࠩࡵࠫࣉ")) as stream:
      yaml.add_implicit_resolver(bstack11l1l1l_opy_ (u"ࠥࠥࡵࡧࡴࡩࡧࡻࠦ࣊"), bstack111l111l_opy_)
      yaml.add_constructor(bstack11l1l1l_opy_ (u"ࠦࠦࡶࡡࡵࡪࡨࡼࠧ࣋"), bstack1lll11ll11_opy_)
      config = yaml.load(stream, yaml.FullLoader)
      return config
  except:
    with open(bstack111llll_opy_, bstack11l1l1l_opy_ (u"ࠬࡸࠧ࣌")) as stream:
      try:
        config = yaml.safe_load(stream)
        return config
      except yaml.YAMLError as exc:
        bstack11ll1l1l1_opy_(bstack11lll1lll_opy_.format(str(exc)))
def bstack1lll111l1_opy_(config):
  bstack1llll1ll11_opy_ = bstack1ll1ll11l1_opy_(config)
  for option in list(bstack1llll1ll11_opy_):
    if option.lower() in bstack1111l111_opy_ and option != bstack1111l111_opy_[option.lower()]:
      bstack1llll1ll11_opy_[bstack1111l111_opy_[option.lower()]] = bstack1llll1ll11_opy_[option]
      del bstack1llll1ll11_opy_[option]
  return config
def bstack1l11l1ll_opy_():
  global bstack1lll1lll11_opy_
  for key, bstack1111111l1_opy_ in bstack11ll1lll_opy_.items():
    if isinstance(bstack1111111l1_opy_, list):
      for var in bstack1111111l1_opy_:
        if var in os.environ and os.environ[var] and str(os.environ[var]).strip():
          bstack1lll1lll11_opy_[key] = os.environ[var]
          break
    elif bstack1111111l1_opy_ in os.environ and os.environ[bstack1111111l1_opy_] and str(os.environ[bstack1111111l1_opy_]).strip():
      bstack1lll1lll11_opy_[key] = os.environ[bstack1111111l1_opy_]
  if bstack11l1l1l_opy_ (u"࠭ࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤࡒࡏࡄࡃࡏࡣࡎࡊࡅࡏࡖࡌࡊࡎࡋࡒࠨ࣍") in os.environ:
    bstack1lll1lll11_opy_[bstack11l1l1l_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡔࡶࡤࡧࡰࡒ࡯ࡤࡣ࡯ࡓࡵࡺࡩࡰࡰࡶࠫ࣎")] = {}
    bstack1lll1lll11_opy_[bstack11l1l1l_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡕࡷࡥࡨࡱࡌࡰࡥࡤࡰࡔࡶࡴࡪࡱࡱࡷ࣏ࠬ")][bstack11l1l1l_opy_ (u"ࠩ࡯ࡳࡨࡧ࡬ࡊࡦࡨࡲࡹ࡯ࡦࡪࡧࡵ࣐ࠫ")] = os.environ[bstack11l1l1l_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡏࡓࡈࡇࡌࡠࡋࡇࡉࡓ࡚ࡉࡇࡋࡈࡖ࣑ࠬ")]
def bstack1ll1l11l11_opy_():
  global bstack1ll11lll1l_opy_
  global bstack1ll1l11ll1_opy_
  for idx, val in enumerate(sys.argv):
    if idx < len(sys.argv) and bstack11l1l1l_opy_ (u"ࠫ࠲࠳ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯࠳ࡲ࡯ࡤࡣ࡯ࡍࡩ࡫࡮ࡵ࡫ࡩ࡭ࡪࡸ࣒ࠧ").lower() == val.lower():
      bstack1ll11lll1l_opy_[bstack11l1l1l_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷ࡙ࡴࡢࡥ࡮ࡐࡴࡩࡡ࡭ࡑࡳࡸ࡮ࡵ࡮ࡴ࣓ࠩ")] = {}
      bstack1ll11lll1l_opy_[bstack11l1l1l_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡓࡵࡣࡦ࡯ࡑࡵࡣࡢ࡮ࡒࡴࡹ࡯࡯࡯ࡵࠪࣔ")][bstack11l1l1l_opy_ (u"ࠧ࡭ࡱࡦࡥࡱࡏࡤࡦࡰࡷ࡭࡫࡯ࡥࡳࠩࣕ")] = sys.argv[idx + 1]
      del sys.argv[idx:idx + 2]
      break
  for key, bstack111l1111l_opy_ in bstack1lllll1l11_opy_.items():
    if isinstance(bstack111l1111l_opy_, list):
      for idx, val in enumerate(sys.argv):
        for var in bstack111l1111l_opy_:
          if idx < len(sys.argv) and bstack11l1l1l_opy_ (u"ࠨ࠯࠰ࠫࣖ") + var.lower() == val.lower() and not key in bstack1ll11lll1l_opy_:
            bstack1ll11lll1l_opy_[key] = sys.argv[idx + 1]
            bstack1ll1l11ll1_opy_ += bstack11l1l1l_opy_ (u"ࠩࠣ࠱࠲࠭ࣗ") + var + bstack11l1l1l_opy_ (u"ࠪࠤࠬࣘ") + sys.argv[idx + 1]
            del sys.argv[idx:idx + 2]
            break
    else:
      for idx, val in enumerate(sys.argv):
        if idx < len(sys.argv) and bstack11l1l1l_opy_ (u"ࠫ࠲࠳ࠧࣙ") + bstack111l1111l_opy_.lower() == val.lower() and not key in bstack1ll11lll1l_opy_:
          bstack1ll11lll1l_opy_[key] = sys.argv[idx + 1]
          bstack1ll1l11ll1_opy_ += bstack11l1l1l_opy_ (u"ࠬࠦ࠭࠮ࠩࣚ") + bstack111l1111l_opy_ + bstack11l1l1l_opy_ (u"࠭ࠠࠨࣛ") + sys.argv[idx + 1]
          del sys.argv[idx:idx + 2]
def bstack1ll1l111ll_opy_(config):
  bstack11ll11l11_opy_ = config.keys()
  for bstack1l11l11ll_opy_, bstack1l1111l1l_opy_ in bstack1l111l1l1_opy_.items():
    if bstack1l1111l1l_opy_ in bstack11ll11l11_opy_:
      config[bstack1l11l11ll_opy_] = config[bstack1l1111l1l_opy_]
      del config[bstack1l1111l1l_opy_]
  for bstack1l11l11ll_opy_, bstack1l1111l1l_opy_ in bstack1lllllll1l_opy_.items():
    if isinstance(bstack1l1111l1l_opy_, list):
      for bstack1lll11lll_opy_ in bstack1l1111l1l_opy_:
        if bstack1lll11lll_opy_ in bstack11ll11l11_opy_:
          config[bstack1l11l11ll_opy_] = config[bstack1lll11lll_opy_]
          del config[bstack1lll11lll_opy_]
          break
    elif bstack1l1111l1l_opy_ in bstack11ll11l11_opy_:
      config[bstack1l11l11ll_opy_] = config[bstack1l1111l1l_opy_]
      del config[bstack1l1111l1l_opy_]
  for bstack1lll11lll_opy_ in list(config):
    for bstack1ll1l1l11_opy_ in bstack1llllllll_opy_:
      if bstack1lll11lll_opy_.lower() == bstack1ll1l1l11_opy_.lower() and bstack1lll11lll_opy_ != bstack1ll1l1l11_opy_:
        config[bstack1ll1l1l11_opy_] = config[bstack1lll11lll_opy_]
        del config[bstack1lll11lll_opy_]
  bstack111111ll1_opy_ = []
  if bstack11l1l1l_opy_ (u"ࠧࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡵࠪࣜ") in config:
    bstack111111ll1_opy_ = config[bstack11l1l1l_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠫࣝ")]
  for platform in bstack111111ll1_opy_:
    for bstack1lll11lll_opy_ in list(platform):
      for bstack1ll1l1l11_opy_ in bstack1llllllll_opy_:
        if bstack1lll11lll_opy_.lower() == bstack1ll1l1l11_opy_.lower() and bstack1lll11lll_opy_ != bstack1ll1l1l11_opy_:
          platform[bstack1ll1l1l11_opy_] = platform[bstack1lll11lll_opy_]
          del platform[bstack1lll11lll_opy_]
  for bstack1l11l11ll_opy_, bstack1l1111l1l_opy_ in bstack1lllllll1l_opy_.items():
    for platform in bstack111111ll1_opy_:
      if isinstance(bstack1l1111l1l_opy_, list):
        for bstack1lll11lll_opy_ in bstack1l1111l1l_opy_:
          if bstack1lll11lll_opy_ in platform:
            platform[bstack1l11l11ll_opy_] = platform[bstack1lll11lll_opy_]
            del platform[bstack1lll11lll_opy_]
            break
      elif bstack1l1111l1l_opy_ in platform:
        platform[bstack1l11l11ll_opy_] = platform[bstack1l1111l1l_opy_]
        del platform[bstack1l1111l1l_opy_]
  for bstack1lll1l1lll_opy_ in bstack11l1l1111_opy_:
    if bstack1lll1l1lll_opy_ in config:
      if not bstack11l1l1111_opy_[bstack1lll1l1lll_opy_] in config:
        config[bstack11l1l1111_opy_[bstack1lll1l1lll_opy_]] = {}
      config[bstack11l1l1111_opy_[bstack1lll1l1lll_opy_]].update(config[bstack1lll1l1lll_opy_])
      del config[bstack1lll1l1lll_opy_]
  for platform in bstack111111ll1_opy_:
    for bstack1lll1l1lll_opy_ in bstack11l1l1111_opy_:
      if bstack1lll1l1lll_opy_ in list(platform):
        if not bstack11l1l1111_opy_[bstack1lll1l1lll_opy_] in platform:
          platform[bstack11l1l1111_opy_[bstack1lll1l1lll_opy_]] = {}
        platform[bstack11l1l1111_opy_[bstack1lll1l1lll_opy_]].update(platform[bstack1lll1l1lll_opy_])
        del platform[bstack1lll1l1lll_opy_]
  config = bstack1lll111l1_opy_(config)
  return config
def bstack111ll111_opy_(config):
  global bstack1l1111111_opy_
  if bstack11l1l1l_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡍࡱࡦࡥࡱ࠭ࣞ") in config and str(config[bstack11l1l1l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡎࡲࡧࡦࡲࠧࣟ")]).lower() != bstack11l1l1l_opy_ (u"ࠫ࡫ࡧ࡬ࡴࡧࠪ࣠"):
    if not bstack11l1l1l_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷ࡙ࡴࡢࡥ࡮ࡐࡴࡩࡡ࡭ࡑࡳࡸ࡮ࡵ࡮ࡴࠩ࣡") in config:
      config[bstack11l1l1l_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡓࡵࡣࡦ࡯ࡑࡵࡣࡢ࡮ࡒࡴࡹ࡯࡯࡯ࡵࠪ࣢")] = {}
    if not bstack11l1l1l_opy_ (u"ࠧ࡭ࡱࡦࡥࡱࡏࡤࡦࡰࡷ࡭࡫࡯ࡥࡳࣣࠩ") in config[bstack11l1l1l_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡕࡷࡥࡨࡱࡌࡰࡥࡤࡰࡔࡶࡴࡪࡱࡱࡷࠬࣤ")]:
      bstack11llll1ll_opy_ = datetime.datetime.now()
      bstack1l11l1lll_opy_ = bstack11llll1ll_opy_.strftime(bstack11l1l1l_opy_ (u"ࠩࠨࡨࡤࠫࡢࡠࠧࡋࠩࡒ࠭ࣥ"))
      hostname = socket.gethostname()
      bstack111lll11l_opy_ = bstack11l1l1l_opy_ (u"ࣦࠪࠫ").join(random.choices(string.ascii_lowercase + string.digits, k=4))
      identifier = bstack11l1l1l_opy_ (u"ࠫࢀࢃ࡟ࡼࡿࡢࡿࢂ࠭ࣧ").format(bstack1l11l1lll_opy_, hostname, bstack111lll11l_opy_)
      config[bstack11l1l1l_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷ࡙ࡴࡢࡥ࡮ࡐࡴࡩࡡ࡭ࡑࡳࡸ࡮ࡵ࡮ࡴࠩࣨ")][bstack11l1l1l_opy_ (u"࠭࡬ࡰࡥࡤࡰࡎࡪࡥ࡯ࡶ࡬ࡪ࡮࡫ࡲࠨࣩ")] = identifier
    bstack1l1111111_opy_ = config[bstack11l1l1l_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡔࡶࡤࡧࡰࡒ࡯ࡤࡣ࡯ࡓࡵࡺࡩࡰࡰࡶࠫ࣪")][bstack11l1l1l_opy_ (u"ࠨ࡮ࡲࡧࡦࡲࡉࡥࡧࡱࡸ࡮࡬ࡩࡦࡴࠪ࣫")]
  return config
def bstack1llll11111_opy_():
  if (
          isinstance(os.getenv(bstack11l1l1l_opy_ (u"ࠩࡍࡉࡓࡑࡉࡏࡕࡢ࡙ࡗࡒࠧ࣬")), str) and len(os.getenv(bstack11l1l1l_opy_ (u"ࠪࡎࡊࡔࡋࡊࡐࡖࡣ࡚ࡘࡌࠨ࣭"))) > 0
  ) or (
          isinstance(os.getenv(bstack11l1l1l_opy_ (u"ࠫࡏࡋࡎࡌࡋࡑࡗࡤࡎࡏࡎࡇ࣮ࠪ")), str) and len(os.getenv(bstack11l1l1l_opy_ (u"ࠬࡐࡅࡏࡍࡌࡒࡘࡥࡈࡐࡏࡈ࣯ࠫ"))) > 0
  ):
    return os.getenv(bstack11l1l1l_opy_ (u"࠭ࡂࡖࡋࡏࡈࡤࡔࡕࡎࡄࡈࡖࣰࠬ"), 0)
  if str(os.getenv(bstack11l1l1l_opy_ (u"ࠧࡄࡋࣱࠪ"))).lower() == bstack11l1l1l_opy_ (u"ࠨࡶࡵࡹࡪࣲ࠭") and str(os.getenv(bstack11l1l1l_opy_ (u"ࠩࡆࡍࡗࡉࡌࡆࡅࡌࠫࣳ"))).lower() == bstack11l1l1l_opy_ (u"ࠪࡸࡷࡻࡥࠨࣴ"):
    return os.getenv(bstack11l1l1l_opy_ (u"ࠫࡈࡏࡒࡄࡎࡈࡣࡇ࡛ࡉࡍࡆࡢࡒ࡚ࡓࠧࣵ"), 0)
  if str(os.getenv(bstack11l1l1l_opy_ (u"ࠬࡉࡉࠨࣶ"))).lower() == bstack11l1l1l_opy_ (u"࠭ࡴࡳࡷࡨࠫࣷ") and str(os.getenv(bstack11l1l1l_opy_ (u"ࠧࡕࡔࡄ࡚ࡎ࡙ࠧࣸ"))).lower() == bstack11l1l1l_opy_ (u"ࠨࡶࡵࡹࡪࣹ࠭"):
    return os.getenv(bstack11l1l1l_opy_ (u"ࠩࡗࡖࡆ࡜ࡉࡔࡡࡅ࡙ࡎࡒࡄࡠࡐࡘࡑࡇࡋࡒࠨࣺ"), 0)
  if str(os.getenv(bstack11l1l1l_opy_ (u"ࠪࡇࡎ࠭ࣻ"))).lower() == bstack11l1l1l_opy_ (u"ࠫࡹࡸࡵࡦࠩࣼ") and str(os.getenv(bstack11l1l1l_opy_ (u"ࠬࡉࡉࡠࡐࡄࡑࡊ࠭ࣽ"))).lower() == bstack11l1l1l_opy_ (u"࠭ࡣࡰࡦࡨࡷ࡭࡯ࡰࠨࣾ"):
    return 0
  if os.getenv(bstack11l1l1l_opy_ (u"ࠧࡃࡋࡗࡆ࡚ࡉࡋࡆࡖࡢࡆࡗࡇࡎࡄࡊࠪࣿ")) and os.getenv(bstack11l1l1l_opy_ (u"ࠨࡄࡌࡘࡇ࡛ࡃࡌࡇࡗࡣࡈࡕࡍࡎࡋࡗࠫऀ")):
    return os.getenv(bstack11l1l1l_opy_ (u"ࠩࡅࡍ࡙ࡈࡕࡄࡍࡈࡘࡤࡈࡕࡊࡎࡇࡣࡓ࡛ࡍࡃࡇࡕࠫँ"), 0)
  if str(os.getenv(bstack11l1l1l_opy_ (u"ࠪࡇࡎ࠭ं"))).lower() == bstack11l1l1l_opy_ (u"ࠫࡹࡸࡵࡦࠩः") and str(os.getenv(bstack11l1l1l_opy_ (u"ࠬࡊࡒࡐࡐࡈࠫऄ"))).lower() == bstack11l1l1l_opy_ (u"࠭ࡴࡳࡷࡨࠫअ"):
    return os.getenv(bstack11l1l1l_opy_ (u"ࠧࡅࡔࡒࡒࡊࡥࡂࡖࡋࡏࡈࡤࡔࡕࡎࡄࡈࡖࠬआ"), 0)
  if str(os.getenv(bstack11l1l1l_opy_ (u"ࠨࡅࡌࠫइ"))).lower() == bstack11l1l1l_opy_ (u"ࠩࡷࡶࡺ࡫ࠧई") and str(os.getenv(bstack11l1l1l_opy_ (u"ࠪࡗࡊࡓࡁࡑࡊࡒࡖࡊ࠭उ"))).lower() == bstack11l1l1l_opy_ (u"ࠫࡹࡸࡵࡦࠩऊ"):
    return os.getenv(bstack11l1l1l_opy_ (u"࡙ࠬࡅࡎࡃࡓࡌࡔࡘࡅࡠࡌࡒࡆࡤࡏࡄࠨऋ"), 0)
  if str(os.getenv(bstack11l1l1l_opy_ (u"࠭ࡃࡊࠩऌ"))).lower() == bstack11l1l1l_opy_ (u"ࠧࡵࡴࡸࡩࠬऍ") and str(os.getenv(bstack11l1l1l_opy_ (u"ࠨࡉࡌࡘࡑࡇࡂࡠࡅࡌࠫऎ"))).lower() == bstack11l1l1l_opy_ (u"ࠩࡷࡶࡺ࡫ࠧए"):
    return os.getenv(bstack11l1l1l_opy_ (u"ࠪࡇࡎࡥࡊࡐࡄࡢࡍࡉ࠭ऐ"), 0)
  if str(os.getenv(bstack11l1l1l_opy_ (u"ࠫࡈࡏࠧऑ"))).lower() == bstack11l1l1l_opy_ (u"ࠬࡺࡲࡶࡧࠪऒ") and str(os.getenv(bstack11l1l1l_opy_ (u"࠭ࡂࡖࡋࡏࡈࡐࡏࡔࡆࠩओ"))).lower() == bstack11l1l1l_opy_ (u"ࠧࡵࡴࡸࡩࠬऔ"):
    return os.getenv(bstack11l1l1l_opy_ (u"ࠨࡄࡘࡍࡑࡊࡋࡊࡖࡈࡣࡇ࡛ࡉࡍࡆࡢࡒ࡚ࡓࡂࡆࡔࠪक"), 0)
  if str(os.getenv(bstack11l1l1l_opy_ (u"ࠩࡗࡊࡤࡈࡕࡊࡎࡇࠫख"))).lower() == bstack11l1l1l_opy_ (u"ࠪࡸࡷࡻࡥࠨग"):
    return os.getenv(bstack11l1l1l_opy_ (u"ࠫࡇ࡛ࡉࡍࡆࡢࡆ࡚ࡏࡌࡅࡋࡇࠫघ"), 0)
  return -1
def bstack1lll1l111l_opy_(bstack1ll1l11l1l_opy_):
  global CONFIG
  if not bstack11l1l1l_opy_ (u"ࠬࠪࡻࡃࡗࡌࡐࡉࡥࡎࡖࡏࡅࡉࡗࢃࠧङ") in CONFIG[bstack11l1l1l_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡎࡪࡥ࡯ࡶ࡬ࡪ࡮࡫ࡲࠨच")]:
    return
  CONFIG[bstack11l1l1l_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡏࡤࡦࡰࡷ࡭࡫࡯ࡥࡳࠩछ")] = CONFIG[bstack11l1l1l_opy_ (u"ࠨࡤࡸ࡭ࡱࡪࡉࡥࡧࡱࡸ࡮࡬ࡩࡦࡴࠪज")].replace(
    bstack11l1l1l_opy_ (u"ࠩࠧࡿࡇ࡛ࡉࡍࡆࡢࡒ࡚ࡓࡂࡆࡔࢀࠫझ"),
    str(bstack1ll1l11l1l_opy_)
  )
def bstack1llll111l_opy_():
  global CONFIG
  if not bstack11l1l1l_opy_ (u"ࠪࠨࢀࡊࡁࡕࡇࡢࡘࡎࡓࡅࡾࠩञ") in CONFIG[bstack11l1l1l_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡌࡨࡪࡴࡴࡪࡨ࡬ࡩࡷ࠭ट")]:
    return
  bstack11llll1ll_opy_ = datetime.datetime.now()
  bstack1l11l1lll_opy_ = bstack11llll1ll_opy_.strftime(bstack11l1l1l_opy_ (u"ࠬࠫࡤ࠮ࠧࡥ࠱ࠪࡎ࠺ࠦࡏࠪठ"))
  CONFIG[bstack11l1l1l_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡎࡪࡥ࡯ࡶ࡬ࡪ࡮࡫ࡲࠨड")] = CONFIG[bstack11l1l1l_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡏࡤࡦࡰࡷ࡭࡫࡯ࡥࡳࠩढ")].replace(
    bstack11l1l1l_opy_ (u"ࠨࠦࡾࡈࡆ࡚ࡅࡠࡖࡌࡑࡊࢃࠧण"),
    bstack1l11l1lll_opy_
  )
def bstack1l1l1l1l_opy_():
  global CONFIG
  if bstack11l1l1l_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡊࡦࡨࡲࡹ࡯ࡦࡪࡧࡵࠫत") in CONFIG and not bool(CONFIG[bstack11l1l1l_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡋࡧࡩࡳࡺࡩࡧ࡫ࡨࡶࠬथ")]):
    del CONFIG[bstack11l1l1l_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡌࡨࡪࡴࡴࡪࡨ࡬ࡩࡷ࠭द")]
    return
  if not bstack11l1l1l_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡍࡩ࡫࡮ࡵ࡫ࡩ࡭ࡪࡸࠧध") in CONFIG:
    CONFIG[bstack11l1l1l_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡎࡪࡥ࡯ࡶ࡬ࡪ࡮࡫ࡲࠨन")] = bstack11l1l1l_opy_ (u"ࠧࠤࠦࡾࡆ࡚ࡏࡌࡅࡡࡑ࡙ࡒࡈࡅࡓࡿࠪऩ")
  if bstack11l1l1l_opy_ (u"ࠨࠦࡾࡈࡆ࡚ࡅࡠࡖࡌࡑࡊࢃࠧप") in CONFIG[bstack11l1l1l_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡊࡦࡨࡲࡹ࡯ࡦࡪࡧࡵࠫफ")]:
    bstack1llll111l_opy_()
    os.environ[bstack11l1l1l_opy_ (u"ࠪࡆࡘ࡚ࡁࡄࡍࡢࡇࡔࡓࡂࡊࡐࡈࡈࡤࡈࡕࡊࡎࡇࡣࡎࡊࠧब")] = CONFIG[bstack11l1l1l_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡌࡨࡪࡴࡴࡪࡨ࡬ࡩࡷ࠭भ")]
  if not bstack11l1l1l_opy_ (u"ࠬࠪࡻࡃࡗࡌࡐࡉࡥࡎࡖࡏࡅࡉࡗࢃࠧम") in CONFIG[bstack11l1l1l_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡎࡪࡥ࡯ࡶ࡬ࡪ࡮࡫ࡲࠨय")]:
    return
  bstack1ll1l11l1l_opy_ = bstack11l1l1l_opy_ (u"ࠧࠨर")
  bstack111l111l1_opy_ = bstack1llll11111_opy_()
  if bstack111l111l1_opy_ != -1:
    bstack1ll1l11l1l_opy_ = bstack11l1l1l_opy_ (u"ࠨࡅࡌࠤࠬऱ") + str(bstack111l111l1_opy_)
  if bstack1ll1l11l1l_opy_ == bstack11l1l1l_opy_ (u"ࠩࠪल"):
    bstack1lllll111l_opy_ = bstack111lll11_opy_(CONFIG[bstack11l1l1l_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡐࡤࡱࡪ࠭ळ")])
    if bstack1lllll111l_opy_ != -1:
      bstack1ll1l11l1l_opy_ = str(bstack1lllll111l_opy_)
  if bstack1ll1l11l1l_opy_:
    bstack1lll1l111l_opy_(bstack1ll1l11l1l_opy_)
    os.environ[bstack11l1l1l_opy_ (u"ࠫࡇ࡙ࡔࡂࡅࡎࡣࡈࡕࡍࡃࡋࡑࡉࡉࡥࡂࡖࡋࡏࡈࡤࡏࡄࠨऴ")] = CONFIG[bstack11l1l1l_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡍࡩ࡫࡮ࡵ࡫ࡩ࡭ࡪࡸࠧव")]
def bstack1l1ll11ll_opy_(bstack1ll11111l_opy_, bstack11ll1ll11_opy_, path):
  bstack1lll1ll1ll_opy_ = {
    bstack11l1l1l_opy_ (u"࠭ࡩࡥࡧࡱࡸ࡮࡬ࡩࡦࡴࠪश"): bstack11ll1ll11_opy_
  }
  if os.path.exists(path):
    bstack11l111l11_opy_ = json.load(open(path, bstack11l1l1l_opy_ (u"ࠧࡳࡤࠪष")))
  else:
    bstack11l111l11_opy_ = {}
  bstack11l111l11_opy_[bstack1ll11111l_opy_] = bstack1lll1ll1ll_opy_
  with open(path, bstack11l1l1l_opy_ (u"ࠣࡹ࠮ࠦस")) as outfile:
    json.dump(bstack11l111l11_opy_, outfile)
def bstack111lll11_opy_(bstack1ll11111l_opy_):
  bstack1ll11111l_opy_ = str(bstack1ll11111l_opy_)
  bstack1ll1l1ll1_opy_ = os.path.join(os.path.expanduser(bstack11l1l1l_opy_ (u"ࠩࢁࠫह")), bstack11l1l1l_opy_ (u"ࠪ࠲ࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࠪऺ"))
  try:
    if not os.path.exists(bstack1ll1l1ll1_opy_):
      os.makedirs(bstack1ll1l1ll1_opy_)
    file_path = os.path.join(os.path.expanduser(bstack11l1l1l_opy_ (u"ࠫࢃ࠭ऻ")), bstack11l1l1l_opy_ (u"ࠬ࠴ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯़ࠬ"), bstack11l1l1l_opy_ (u"࠭࠮ࡣࡷ࡬ࡰࡩ࠳࡮ࡢ࡯ࡨ࠱ࡨࡧࡣࡩࡧ࠱࡮ࡸࡵ࡮ࠨऽ"))
    if not os.path.isfile(file_path):
      with open(file_path, bstack11l1l1l_opy_ (u"ࠧࡸࠩा")):
        pass
      with open(file_path, bstack11l1l1l_opy_ (u"ࠣࡹ࠮ࠦि")) as outfile:
        json.dump({}, outfile)
    with open(file_path, bstack11l1l1l_opy_ (u"ࠩࡵࠫी")) as bstack11ll11ll1_opy_:
      bstack11ll11111_opy_ = json.load(bstack11ll11ll1_opy_)
    if bstack1ll11111l_opy_ in bstack11ll11111_opy_:
      bstack1lll1l1l1l_opy_ = bstack11ll11111_opy_[bstack1ll11111l_opy_][bstack11l1l1l_opy_ (u"ࠪ࡭ࡩ࡫࡮ࡵ࡫ࡩ࡭ࡪࡸࠧु")]
      bstack11ll11lll_opy_ = int(bstack1lll1l1l1l_opy_) + 1
      bstack1l1ll11ll_opy_(bstack1ll11111l_opy_, bstack11ll11lll_opy_, file_path)
      return bstack11ll11lll_opy_
    else:
      bstack1l1ll11ll_opy_(bstack1ll11111l_opy_, 1, file_path)
      return 1
  except Exception as e:
    logger.warn(bstack1llllll1l_opy_.format(str(e)))
    return -1
def bstack11ll11ll_opy_(config):
  if not config[bstack11l1l1l_opy_ (u"ࠫࡺࡹࡥࡳࡐࡤࡱࡪ࠭ू")] or not config[bstack11l1l1l_opy_ (u"ࠬࡧࡣࡤࡧࡶࡷࡐ࡫ࡹࠨृ")]:
    return True
  else:
    return False
def bstack1llll1l111_opy_(config):
  if bstack11l1l1l_opy_ (u"࠭ࡩࡴࡒ࡯ࡥࡾࡽࡲࡪࡩ࡫ࡸࠬॄ") in config:
    del (config[bstack11l1l1l_opy_ (u"ࠧࡪࡵࡓࡰࡦࡿࡷࡳ࡫ࡪ࡬ࡹ࠭ॅ")])
    return False
  if bstack1ll1ll1l1_opy_() < version.parse(bstack11l1l1l_opy_ (u"ࠨ࠵࠱࠸࠳࠶ࠧॆ")):
    return False
  if bstack1ll1ll1l1_opy_() >= version.parse(bstack11l1l1l_opy_ (u"ࠩ࠷࠲࠶࠴࠵ࠨे")):
    return True
  if bstack11l1l1l_opy_ (u"ࠪࡹࡸ࡫ࡗ࠴ࡅࠪै") in config and config[bstack11l1l1l_opy_ (u"ࠫࡺࡹࡥࡘ࠵ࡆࠫॉ")] == False:
    return False
  else:
    return True
def bstack11111l1l_opy_(config, index=0):
  global bstack1ll11l11l_opy_
  bstack11l1l1ll_opy_ = {}
  caps = bstack1l1111l1_opy_ + bstack1lll111ll_opy_
  if bstack1ll11l11l_opy_:
    caps += bstack1lllll1ll_opy_
  for key in config:
    if key in caps + [bstack11l1l1l_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡳࠨॊ")]:
      continue
    bstack11l1l1ll_opy_[key] = config[key]
  if bstack11l1l1l_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩो") in config:
    for bstack1ll1l1111l_opy_ in config[bstack11l1l1l_opy_ (u"ࠧࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡵࠪौ")][index]:
      if bstack1ll1l1111l_opy_ in caps + [bstack11l1l1l_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡐࡤࡱࡪ्࠭"), bstack11l1l1l_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴ࡙ࡩࡷࡹࡩࡰࡰࠪॎ")]:
        continue
      bstack11l1l1ll_opy_[bstack1ll1l1111l_opy_] = config[bstack11l1l1l_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱࡸ࠭ॏ")][index][bstack1ll1l1111l_opy_]
  bstack11l1l1ll_opy_[bstack11l1l1l_opy_ (u"ࠫ࡭ࡵࡳࡵࡐࡤࡱࡪ࠭ॐ")] = socket.gethostname()
  if bstack11l1l1l_opy_ (u"ࠬࡼࡥࡳࡵ࡬ࡳࡳ࠭॑") in bstack11l1l1ll_opy_:
    del (bstack11l1l1ll_opy_[bstack11l1l1l_opy_ (u"࠭ࡶࡦࡴࡶ࡭ࡴࡴ॒ࠧ")])
  return bstack11l1l1ll_opy_
def bstack11l111111_opy_(config):
  global bstack1ll11l11l_opy_
  bstack1ll111111_opy_ = {}
  caps = bstack1lll111ll_opy_
  if bstack1ll11l11l_opy_:
    caps += bstack1lllll1ll_opy_
  for key in caps:
    if key in config:
      bstack1ll111111_opy_[key] = config[key]
  return bstack1ll111111_opy_
def bstack1ll111l1l_opy_(bstack11l1l1ll_opy_, bstack1ll111111_opy_):
  bstack1ll1lll11l_opy_ = {}
  for key in bstack11l1l1ll_opy_.keys():
    if key in bstack1l111l1l1_opy_:
      bstack1ll1lll11l_opy_[bstack1l111l1l1_opy_[key]] = bstack11l1l1ll_opy_[key]
    else:
      bstack1ll1lll11l_opy_[key] = bstack11l1l1ll_opy_[key]
  for key in bstack1ll111111_opy_:
    if key in bstack1l111l1l1_opy_:
      bstack1ll1lll11l_opy_[bstack1l111l1l1_opy_[key]] = bstack1ll111111_opy_[key]
    else:
      bstack1ll1lll11l_opy_[key] = bstack1ll111111_opy_[key]
  return bstack1ll1lll11l_opy_
def bstack1ll11l1ll_opy_(config, index=0):
  global bstack1ll11l11l_opy_
  config = copy.deepcopy(config)
  caps = {}
  bstack1ll111111_opy_ = bstack11l111111_opy_(config)
  bstack1lll1111ll_opy_ = bstack1lll111ll_opy_
  bstack1lll1111ll_opy_ += bstack1ll111lll_opy_
  if bstack1ll11l11l_opy_:
    bstack1lll1111ll_opy_ += bstack1lllll1ll_opy_
  if bstack11l1l1l_opy_ (u"ࠧࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡵࠪ॓") in config:
    if bstack11l1l1l_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡐࡤࡱࡪ࠭॔") in config[bstack11l1l1l_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࡷࠬॕ")][index]:
      caps[bstack11l1l1l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡒࡦࡳࡥࠨॖ")] = config[bstack11l1l1l_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡹࠧॗ")][index][bstack11l1l1l_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡔࡡ࡮ࡧࠪक़")]
    if bstack11l1l1l_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡖࡦࡴࡶ࡭ࡴࡴࠧख़") in config[bstack11l1l1l_opy_ (u"ࠧࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡵࠪग़")][index]:
      caps[bstack11l1l1l_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡘࡨࡶࡸ࡯࡯࡯ࠩज़")] = str(config[bstack11l1l1l_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࡷࠬड़")][index][bstack11l1l1l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵ࡚ࡪࡸࡳࡪࡱࡱࠫढ़")])
    bstack11l1l1ll1_opy_ = {}
    for bstack111ll11l1_opy_ in bstack1lll1111ll_opy_:
      if bstack111ll11l1_opy_ in config[bstack11l1l1l_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡹࠧफ़")][index]:
        if bstack111ll11l1_opy_ == bstack11l1l1l_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡖࡦࡴࡶ࡭ࡴࡴࠧय़"):
          try:
            bstack11l1l1ll1_opy_[bstack111ll11l1_opy_] = str(config[bstack11l1l1l_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩॠ")][index][bstack111ll11l1_opy_] * 1.0)
          except:
            bstack11l1l1ll1_opy_[bstack111ll11l1_opy_] = str(config[bstack11l1l1l_opy_ (u"ࠧࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡵࠪॡ")][index][bstack111ll11l1_opy_])
        else:
          bstack11l1l1ll1_opy_[bstack111ll11l1_opy_] = config[bstack11l1l1l_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠫॢ")][index][bstack111ll11l1_opy_]
        del (config[bstack11l1l1l_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࡷࠬॣ")][index][bstack111ll11l1_opy_])
    bstack1ll111111_opy_ = update(bstack1ll111111_opy_, bstack11l1l1ll1_opy_)
  bstack11l1l1ll_opy_ = bstack11111l1l_opy_(config, index)
  for bstack1lll11lll_opy_ in bstack1lll111ll_opy_ + [bstack11l1l1l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡒࡦࡳࡥࠨ।"), bstack11l1l1l_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶ࡛࡫ࡲࡴ࡫ࡲࡲࠬ॥")]:
    if bstack1lll11lll_opy_ in bstack11l1l1ll_opy_:
      bstack1ll111111_opy_[bstack1lll11lll_opy_] = bstack11l1l1ll_opy_[bstack1lll11lll_opy_]
      del (bstack11l1l1ll_opy_[bstack1lll11lll_opy_])
  if bstack1llll1l111_opy_(config):
    bstack11l1l1ll_opy_[bstack11l1l1l_opy_ (u"ࠬࡻࡳࡦ࡙࠶ࡇࠬ०")] = True
    caps.update(bstack1ll111111_opy_)
    caps[bstack11l1l1l_opy_ (u"࠭ࡢࡴࡶࡤࡧࡰࡀ࡯ࡱࡶ࡬ࡳࡳࡹࠧ१")] = bstack11l1l1ll_opy_
  else:
    bstack11l1l1ll_opy_[bstack11l1l1l_opy_ (u"ࠧࡶࡵࡨ࡛࠸ࡉࠧ२")] = False
    caps.update(bstack1ll111l1l_opy_(bstack11l1l1ll_opy_, bstack1ll111111_opy_))
    if bstack11l1l1l_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡐࡤࡱࡪ࠭३") in caps:
      caps[bstack11l1l1l_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࠪ४")] = caps[bstack11l1l1l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡒࡦࡳࡥࠨ५")]
      del (caps[bstack11l1l1l_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡓࡧ࡭ࡦࠩ६")])
    if bstack11l1l1l_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷ࡜ࡥࡳࡵ࡬ࡳࡳ࠭७") in caps:
      caps[bstack11l1l1l_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸ࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࠨ८")] = caps[bstack11l1l1l_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡗࡧࡵࡷ࡮ࡵ࡮ࠨ९")]
      del (caps[bstack11l1l1l_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡘࡨࡶࡸ࡯࡯࡯ࠩ॰")])
  return caps
def bstack11111llll_opy_():
  global bstack1lll1l111_opy_
  if bstack1ll1ll1l1_opy_() <= version.parse(bstack11l1l1l_opy_ (u"ࠩ࠶࠲࠶࠹࠮࠱ࠩॱ")):
    if bstack1lll1l111_opy_ != bstack11l1l1l_opy_ (u"ࠪࠫॲ"):
      return bstack11l1l1l_opy_ (u"ࠦ࡭ࡺࡴࡱ࠼࠲࠳ࠧॳ") + bstack1lll1l111_opy_ + bstack11l1l1l_opy_ (u"ࠧࡀ࠸࠱࠱ࡺࡨ࠴࡮ࡵࡣࠤॴ")
    return bstack111ll1l1l_opy_
  if bstack1lll1l111_opy_ != bstack11l1l1l_opy_ (u"࠭ࠧॵ"):
    return bstack11l1l1l_opy_ (u"ࠢࡩࡶࡷࡴࡸࡀ࠯࠰ࠤॶ") + bstack1lll1l111_opy_ + bstack11l1l1l_opy_ (u"ࠣ࠱ࡺࡨ࠴࡮ࡵࡣࠤॷ")
  return bstack111lll1l_opy_
def bstack11ll11l1l_opy_(options):
  return hasattr(options, bstack11l1l1l_opy_ (u"ࠩࡶࡩࡹࡥࡣࡢࡲࡤࡦ࡮ࡲࡩࡵࡻࠪॸ"))
def update(d, u):
  for k, v in u.items():
    if isinstance(v, collections.abc.Mapping):
      d[k] = update(d.get(k, {}), v)
    else:
      if isinstance(v, list):
        d[k] = d.get(k, []) + v
      else:
        d[k] = v
  return d
def bstack1ll1111ll_opy_(options, bstack1l1ll11l1_opy_):
  for bstack1l11111l1_opy_ in bstack1l1ll11l1_opy_:
    if bstack1l11111l1_opy_ in [bstack11l1l1l_opy_ (u"ࠪࡥࡷ࡭ࡳࠨॹ"), bstack11l1l1l_opy_ (u"ࠫࡪࡾࡴࡦࡰࡶ࡭ࡴࡴࡳࠨॺ")]:
      next
    if bstack1l11111l1_opy_ in options._experimental_options:
      options._experimental_options[bstack1l11111l1_opy_] = update(options._experimental_options[bstack1l11111l1_opy_],
                                                         bstack1l1ll11l1_opy_[bstack1l11111l1_opy_])
    else:
      options.add_experimental_option(bstack1l11111l1_opy_, bstack1l1ll11l1_opy_[bstack1l11111l1_opy_])
  if bstack11l1l1l_opy_ (u"ࠬࡧࡲࡨࡵࠪॻ") in bstack1l1ll11l1_opy_:
    for arg in bstack1l1ll11l1_opy_[bstack11l1l1l_opy_ (u"࠭ࡡࡳࡩࡶࠫॼ")]:
      options.add_argument(arg)
    del (bstack1l1ll11l1_opy_[bstack11l1l1l_opy_ (u"ࠧࡢࡴࡪࡷࠬॽ")])
  if bstack11l1l1l_opy_ (u"ࠨࡧࡻࡸࡪࡴࡳࡪࡱࡱࡷࠬॾ") in bstack1l1ll11l1_opy_:
    for ext in bstack1l1ll11l1_opy_[bstack11l1l1l_opy_ (u"ࠩࡨࡼࡹ࡫࡮ࡴ࡫ࡲࡲࡸ࠭ॿ")]:
      options.add_extension(ext)
    del (bstack1l1ll11l1_opy_[bstack11l1l1l_opy_ (u"ࠪࡩࡽࡺࡥ࡯ࡵ࡬ࡳࡳࡹࠧঀ")])
def bstack111ll11ll_opy_(options, bstack11ll1l1ll_opy_):
  if bstack11l1l1l_opy_ (u"ࠫࡵࡸࡥࡧࡵࠪঁ") in bstack11ll1l1ll_opy_:
    for bstack1ll1l1llll_opy_ in bstack11ll1l1ll_opy_[bstack11l1l1l_opy_ (u"ࠬࡶࡲࡦࡨࡶࠫং")]:
      if bstack1ll1l1llll_opy_ in options._preferences:
        options._preferences[bstack1ll1l1llll_opy_] = update(options._preferences[bstack1ll1l1llll_opy_], bstack11ll1l1ll_opy_[bstack11l1l1l_opy_ (u"࠭ࡰࡳࡧࡩࡷࠬঃ")][bstack1ll1l1llll_opy_])
      else:
        options.set_preference(bstack1ll1l1llll_opy_, bstack11ll1l1ll_opy_[bstack11l1l1l_opy_ (u"ࠧࡱࡴࡨࡪࡸ࠭঄")][bstack1ll1l1llll_opy_])
  if bstack11l1l1l_opy_ (u"ࠨࡣࡵ࡫ࡸ࠭অ") in bstack11ll1l1ll_opy_:
    for arg in bstack11ll1l1ll_opy_[bstack11l1l1l_opy_ (u"ࠩࡤࡶ࡬ࡹࠧআ")]:
      options.add_argument(arg)
def bstack11l11lll1_opy_(options, bstack1ll11llll1_opy_):
  if bstack11l1l1l_opy_ (u"ࠪࡻࡪࡨࡶࡪࡧࡺࠫই") in bstack1ll11llll1_opy_:
    options.use_webview(bool(bstack1ll11llll1_opy_[bstack11l1l1l_opy_ (u"ࠫࡼ࡫ࡢࡷ࡫ࡨࡻࠬঈ")]))
  bstack1ll1111ll_opy_(options, bstack1ll11llll1_opy_)
def bstack1l111lll1_opy_(options, bstack111ll1ll_opy_):
  for bstack1ll11llll_opy_ in bstack111ll1ll_opy_:
    if bstack1ll11llll_opy_ in [bstack11l1l1l_opy_ (u"ࠬࡺࡥࡤࡪࡱࡳࡱࡵࡧࡺࡒࡵࡩࡻ࡯ࡥࡸࠩউ"), bstack11l1l1l_opy_ (u"࠭ࡡࡳࡩࡶࠫঊ")]:
      next
    options.set_capability(bstack1ll11llll_opy_, bstack111ll1ll_opy_[bstack1ll11llll_opy_])
  if bstack11l1l1l_opy_ (u"ࠧࡢࡴࡪࡷࠬঋ") in bstack111ll1ll_opy_:
    for arg in bstack111ll1ll_opy_[bstack11l1l1l_opy_ (u"ࠨࡣࡵ࡫ࡸ࠭ঌ")]:
      options.add_argument(arg)
  if bstack11l1l1l_opy_ (u"ࠩࡷࡩࡨ࡮࡮ࡰ࡮ࡲ࡫ࡾࡖࡲࡦࡸ࡬ࡩࡼ࠭঍") in bstack111ll1ll_opy_:
    options.bstack1111llll1_opy_(bool(bstack111ll1ll_opy_[bstack11l1l1l_opy_ (u"ࠪࡸࡪࡩࡨ࡯ࡱ࡯ࡳ࡬ࡿࡐࡳࡧࡹ࡭ࡪࡽࠧ঎")]))
def bstack11l1ll111_opy_(options, bstack11l1ll1ll_opy_):
  for bstack1ll1l1l1ll_opy_ in bstack11l1ll1ll_opy_:
    if bstack1ll1l1l1ll_opy_ in [bstack11l1l1l_opy_ (u"ࠫࡦࡪࡤࡪࡶ࡬ࡳࡳࡧ࡬ࡐࡲࡷ࡭ࡴࡴࡳࠨএ"), bstack11l1l1l_opy_ (u"ࠬࡧࡲࡨࡵࠪঐ")]:
      next
    options._options[bstack1ll1l1l1ll_opy_] = bstack11l1ll1ll_opy_[bstack1ll1l1l1ll_opy_]
  if bstack11l1l1l_opy_ (u"࠭ࡡࡥࡦ࡬ࡸ࡮ࡵ࡮ࡢ࡮ࡒࡴࡹ࡯࡯࡯ࡵࠪ঑") in bstack11l1ll1ll_opy_:
    for bstack1l11l1l11_opy_ in bstack11l1ll1ll_opy_[bstack11l1l1l_opy_ (u"ࠧࡢࡦࡧ࡭ࡹ࡯࡯࡯ࡣ࡯ࡓࡵࡺࡩࡰࡰࡶࠫ঒")]:
      options.bstack1l1ll1l11_opy_(
        bstack1l11l1l11_opy_, bstack11l1ll1ll_opy_[bstack11l1l1l_opy_ (u"ࠨࡣࡧࡨ࡮ࡺࡩࡰࡰࡤࡰࡔࡶࡴࡪࡱࡱࡷࠬও")][bstack1l11l1l11_opy_])
  if bstack11l1l1l_opy_ (u"ࠩࡤࡶ࡬ࡹࠧঔ") in bstack11l1ll1ll_opy_:
    for arg in bstack11l1ll1ll_opy_[bstack11l1l1l_opy_ (u"ࠪࡥࡷ࡭ࡳࠨক")]:
      options.add_argument(arg)
def bstack1lllll1ll1_opy_(options, caps):
  if not hasattr(options, bstack11l1l1l_opy_ (u"ࠫࡐࡋ࡙ࠨখ")):
    return
  if options.KEY == bstack11l1l1l_opy_ (u"ࠬ࡭࡯ࡰࡩ࠽ࡧ࡭ࡸ࡯࡮ࡧࡒࡴࡹ࡯࡯࡯ࡵࠪগ") and options.KEY in caps:
    bstack1ll1111ll_opy_(options, caps[bstack11l1l1l_opy_ (u"࠭ࡧࡰࡱࡪ࠾ࡨ࡮ࡲࡰ࡯ࡨࡓࡵࡺࡩࡰࡰࡶࠫঘ")])
  elif options.KEY == bstack11l1l1l_opy_ (u"ࠧ࡮ࡱࡽ࠾࡫࡯ࡲࡦࡨࡲࡼࡔࡶࡴࡪࡱࡱࡷࠬঙ") and options.KEY in caps:
    bstack111ll11ll_opy_(options, caps[bstack11l1l1l_opy_ (u"ࠨ࡯ࡲࡾ࠿࡬ࡩࡳࡧࡩࡳࡽࡕࡰࡵ࡫ࡲࡲࡸ࠭চ")])
  elif options.KEY == bstack11l1l1l_opy_ (u"ࠩࡶࡥ࡫ࡧࡲࡪ࠰ࡲࡴࡹ࡯࡯࡯ࡵࠪছ") and options.KEY in caps:
    bstack1l111lll1_opy_(options, caps[bstack11l1l1l_opy_ (u"ࠪࡷࡦ࡬ࡡࡳ࡫࠱ࡳࡵࡺࡩࡰࡰࡶࠫজ")])
  elif options.KEY == bstack11l1l1l_opy_ (u"ࠫࡲࡹ࠺ࡦࡦࡪࡩࡔࡶࡴࡪࡱࡱࡷࠬঝ") and options.KEY in caps:
    bstack11l11lll1_opy_(options, caps[bstack11l1l1l_opy_ (u"ࠬࡳࡳ࠻ࡧࡧ࡫ࡪࡕࡰࡵ࡫ࡲࡲࡸ࠭ঞ")])
  elif options.KEY == bstack11l1l1l_opy_ (u"࠭ࡳࡦ࠼࡬ࡩࡔࡶࡴࡪࡱࡱࡷࠬট") and options.KEY in caps:
    bstack11l1ll111_opy_(options, caps[bstack11l1l1l_opy_ (u"ࠧࡴࡧ࠽࡭ࡪࡕࡰࡵ࡫ࡲࡲࡸ࠭ঠ")])
def bstack111llll11_opy_(caps):
  global bstack1ll11l11l_opy_
  if bstack1ll11l11l_opy_:
    if bstack11l1llll1_opy_() < version.parse(bstack11l1l1l_opy_ (u"ࠨ࠴࠱࠷࠳࠶ࠧড")):
      return None
    else:
      from appium.options.common.base import AppiumOptions
      options = AppiumOptions().load_capabilities(caps)
      return options
  else:
    browser = bstack11l1l1l_opy_ (u"ࠩࡦ࡬ࡷࡵ࡭ࡦࠩঢ")
    if bstack11l1l1l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡒࡦࡳࡥࠨণ") in caps:
      browser = caps[bstack11l1l1l_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡓࡧ࡭ࡦࠩত")]
    elif bstack11l1l1l_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷ࠭থ") in caps:
      browser = caps[bstack11l1l1l_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࠧদ")]
    browser = str(browser).lower()
    if browser == bstack11l1l1l_opy_ (u"ࠧࡪࡲ࡫ࡳࡳ࡫ࠧধ") or browser == bstack11l1l1l_opy_ (u"ࠨ࡫ࡳࡥࡩ࠭ন"):
      browser = bstack11l1l1l_opy_ (u"ࠩࡶࡥ࡫ࡧࡲࡪࠩ঩")
    if browser == bstack11l1l1l_opy_ (u"ࠪࡷࡦࡳࡳࡶࡰࡪࠫপ"):
      browser = bstack11l1l1l_opy_ (u"ࠫࡨ࡮ࡲࡰ࡯ࡨࠫফ")
    if browser not in [bstack11l1l1l_opy_ (u"ࠬࡩࡨࡳࡱࡰࡩࠬব"), bstack11l1l1l_opy_ (u"࠭ࡥࡥࡩࡨࠫভ"), bstack11l1l1l_opy_ (u"ࠧࡪࡧࠪম"), bstack11l1l1l_opy_ (u"ࠨࡵࡤࡪࡦࡸࡩࠨয"), bstack11l1l1l_opy_ (u"ࠩࡩ࡭ࡷ࡫ࡦࡰࡺࠪর")]:
      return None
    try:
      package = bstack11l1l1l_opy_ (u"ࠪࡷࡪࡲࡥ࡯࡫ࡸࡱ࠳ࡽࡥࡣࡦࡵ࡭ࡻ࡫ࡲ࠯ࡽࢀ࠲ࡴࡶࡴࡪࡱࡱࡷࠬ঱").format(browser)
      name = bstack11l1l1l_opy_ (u"ࠫࡔࡶࡴࡪࡱࡱࡷࠬল")
      browser_options = getattr(__import__(package, fromlist=[name]), name)
      options = browser_options()
      if not bstack11ll11l1l_opy_(options):
        return None
      for bstack1lll11lll_opy_ in caps.keys():
        options.set_capability(bstack1lll11lll_opy_, caps[bstack1lll11lll_opy_])
      bstack1lllll1ll1_opy_(options, caps)
      return options
    except Exception as e:
      logger.debug(str(e))
      return None
def bstack111ll1l1_opy_(options, bstack1ll1l1ll11_opy_):
  if not bstack11ll11l1l_opy_(options):
    return
  for bstack1lll11lll_opy_ in bstack1ll1l1ll11_opy_.keys():
    if bstack1lll11lll_opy_ in bstack1ll111lll_opy_:
      next
    if bstack1lll11lll_opy_ in options._caps and type(options._caps[bstack1lll11lll_opy_]) in [dict, list]:
      options._caps[bstack1lll11lll_opy_] = update(options._caps[bstack1lll11lll_opy_], bstack1ll1l1ll11_opy_[bstack1lll11lll_opy_])
    else:
      options.set_capability(bstack1lll11lll_opy_, bstack1ll1l1ll11_opy_[bstack1lll11lll_opy_])
  bstack1lllll1ll1_opy_(options, bstack1ll1l1ll11_opy_)
  if bstack11l1l1l_opy_ (u"ࠬࡳ࡯ࡻ࠼ࡧࡩࡧࡻࡧࡨࡧࡵࡅࡩࡪࡲࡦࡵࡶࠫ঳") in options._caps:
    if options._caps[bstack11l1l1l_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡎࡢ࡯ࡨࠫ঴")] and options._caps[bstack11l1l1l_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡏࡣࡰࡩࠬ঵")].lower() != bstack11l1l1l_opy_ (u"ࠨࡨ࡬ࡶࡪ࡬࡯ࡹࠩশ"):
      del options._caps[bstack11l1l1l_opy_ (u"ࠩࡰࡳࡿࡀࡤࡦࡤࡸ࡫࡬࡫ࡲࡂࡦࡧࡶࡪࡹࡳࠨষ")]
def bstack1ll11ll11_opy_(proxy_config):
  if bstack11l1l1l_opy_ (u"ࠪ࡬ࡹࡺࡰࡴࡒࡵࡳࡽࡿࠧস") in proxy_config:
    proxy_config[bstack11l1l1l_opy_ (u"ࠫࡸࡹ࡬ࡑࡴࡲࡼࡾ࠭হ")] = proxy_config[bstack11l1l1l_opy_ (u"ࠬ࡮ࡴࡵࡲࡶࡔࡷࡵࡸࡺࠩ঺")]
    del (proxy_config[bstack11l1l1l_opy_ (u"࠭ࡨࡵࡶࡳࡷࡕࡸ࡯ࡹࡻࠪ঻")])
  if bstack11l1l1l_opy_ (u"ࠧࡱࡴࡲࡼࡾ࡚ࡹࡱࡧ়ࠪ") in proxy_config and proxy_config[bstack11l1l1l_opy_ (u"ࠨࡲࡵࡳࡽࡿࡔࡺࡲࡨࠫঽ")].lower() != bstack11l1l1l_opy_ (u"ࠩࡧ࡭ࡷ࡫ࡣࡵࠩা"):
    proxy_config[bstack11l1l1l_opy_ (u"ࠪࡴࡷࡵࡸࡺࡖࡼࡴࡪ࠭ি")] = bstack11l1l1l_opy_ (u"ࠫࡲࡧ࡮ࡶࡣ࡯ࠫী")
  if bstack11l1l1l_opy_ (u"ࠬࡶࡲࡰࡺࡼࡅࡺࡺ࡯ࡤࡱࡱࡪ࡮࡭ࡕࡳ࡮ࠪু") in proxy_config:
    proxy_config[bstack11l1l1l_opy_ (u"࠭ࡰࡳࡱࡻࡽ࡙ࡿࡰࡦࠩূ")] = bstack11l1l1l_opy_ (u"ࠧࡱࡣࡦࠫৃ")
  return proxy_config
def bstack1l11ll111_opy_(config, proxy):
  from selenium.webdriver.common.proxy import Proxy
  if not bstack11l1l1l_opy_ (u"ࠨࡲࡵࡳࡽࡿࠧৄ") in config:
    return proxy
  config[bstack11l1l1l_opy_ (u"ࠩࡳࡶࡴࡾࡹࠨ৅")] = bstack1ll11ll11_opy_(config[bstack11l1l1l_opy_ (u"ࠪࡴࡷࡵࡸࡺࠩ৆")])
  if proxy == None:
    proxy = Proxy(config[bstack11l1l1l_opy_ (u"ࠫࡵࡸ࡯ࡹࡻࠪে")])
  return proxy
def bstack1l11l1111_opy_(self):
  global CONFIG
  global bstack11ll1111l_opy_
  try:
    proxy = bstack1l111l11l_opy_(CONFIG)
    if proxy:
      if proxy.endswith(bstack11l1l1l_opy_ (u"ࠬ࠴ࡰࡢࡥࠪৈ")):
        proxies = bstack11lll1ll1_opy_(proxy, bstack11111llll_opy_())
        if len(proxies) > 0:
          protocol, bstack111l11ll_opy_ = proxies.popitem()
          if bstack11l1l1l_opy_ (u"ࠨ࠺࠰࠱ࠥ৉") in bstack111l11ll_opy_:
            return bstack111l11ll_opy_
          else:
            return bstack11l1l1l_opy_ (u"ࠢࡩࡶࡷࡴ࠿࠵࠯ࠣ৊") + bstack111l11ll_opy_
      else:
        return proxy
  except Exception as e:
    logger.error(bstack11l1l1l_opy_ (u"ࠣࡇࡵࡶࡴࡸࠠࡪࡰࠣࡷࡪࡺࡴࡪࡰࡪࠤࡵࡸ࡯ࡹࡻࠣࡹࡷࡲࠠ࠻ࠢࡾࢁࠧো").format(str(e)))
  return bstack11ll1111l_opy_(self)
def bstack111111l1_opy_():
  global CONFIG
  return bstack1lll11l1l_opy_(CONFIG) and bstack1ll1ll1l1_opy_() >= version.parse(bstack1lll11ll1l_opy_)
def bstack1ll1ll11l1_opy_(config):
  bstack1llll1ll11_opy_ = {}
  if bstack11l1l1l_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡖࡸࡦࡩ࡫ࡍࡱࡦࡥࡱࡕࡰࡵ࡫ࡲࡲࡸ࠭ৌ") in config:
    bstack1llll1ll11_opy_ = config[bstack11l1l1l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡗࡹࡧࡣ࡬ࡎࡲࡧࡦࡲࡏࡱࡶ࡬ࡳࡳࡹ্ࠧ")]
  if bstack11l1l1l_opy_ (u"ࠫࡱࡵࡣࡢ࡮ࡒࡴࡹ࡯࡯࡯ࡵࠪৎ") in config:
    bstack1llll1ll11_opy_ = config[bstack11l1l1l_opy_ (u"ࠬࡲ࡯ࡤࡣ࡯ࡓࡵࡺࡩࡰࡰࡶࠫ৏")]
  proxy = bstack1l111l11l_opy_(config)
  if proxy:
    if proxy.endswith(bstack11l1l1l_opy_ (u"࠭࠮ࡱࡣࡦࠫ৐")) and os.path.isfile(proxy):
      bstack1llll1ll11_opy_[bstack11l1l1l_opy_ (u"ࠧ࠮ࡲࡤࡧ࠲࡬ࡩ࡭ࡧࠪ৑")] = proxy
    else:
      parsed_url = None
      if proxy.endswith(bstack11l1l1l_opy_ (u"ࠨ࠰ࡳࡥࡨ࠭৒")):
        proxies = bstack1111l1lll_opy_(config, bstack11111llll_opy_())
        if len(proxies) > 0:
          protocol, bstack111l11ll_opy_ = proxies.popitem()
          if bstack11l1l1l_opy_ (u"ࠤ࠽࠳࠴ࠨ৓") in bstack111l11ll_opy_:
            parsed_url = urlparse(bstack111l11ll_opy_)
          else:
            parsed_url = urlparse(protocol + bstack11l1l1l_opy_ (u"ࠥ࠾࠴࠵ࠢ৔") + bstack111l11ll_opy_)
      else:
        parsed_url = urlparse(proxy)
      if parsed_url and parsed_url.hostname: bstack1llll1ll11_opy_[bstack11l1l1l_opy_ (u"ࠫࡵࡸ࡯ࡹࡻࡋࡳࡸࡺࠧ৕")] = str(parsed_url.hostname)
      if parsed_url and parsed_url.port: bstack1llll1ll11_opy_[bstack11l1l1l_opy_ (u"ࠬࡶࡲࡰࡺࡼࡔࡴࡸࡴࠨ৖")] = str(parsed_url.port)
      if parsed_url and parsed_url.username: bstack1llll1ll11_opy_[bstack11l1l1l_opy_ (u"࠭ࡰࡳࡱࡻࡽ࡚ࡹࡥࡳࠩৗ")] = str(parsed_url.username)
      if parsed_url and parsed_url.password: bstack1llll1ll11_opy_[bstack11l1l1l_opy_ (u"ࠧࡱࡴࡲࡼࡾࡖࡡࡴࡵࠪ৘")] = str(parsed_url.password)
  return bstack1llll1ll11_opy_
def bstack1lll111lll_opy_(config):
  if bstack11l1l1l_opy_ (u"ࠨࡶࡨࡷࡹࡉ࡯࡯ࡶࡨࡼࡹࡕࡰࡵ࡫ࡲࡲࡸ࠭৙") in config:
    return config[bstack11l1l1l_opy_ (u"ࠩࡷࡩࡸࡺࡃࡰࡰࡷࡩࡽࡺࡏࡱࡶ࡬ࡳࡳࡹࠧ৚")]
  return {}
def bstack1lll11l1ll_opy_(caps):
  global bstack1l1111111_opy_
  if bstack11l1l1l_opy_ (u"ࠪࡦࡸࡺࡡࡤ࡭࠽ࡳࡵࡺࡩࡰࡰࡶࠫ৛") in caps:
    caps[bstack11l1l1l_opy_ (u"ࠫࡧࡹࡴࡢࡥ࡮࠾ࡴࡶࡴࡪࡱࡱࡷࠬড়")][bstack11l1l1l_opy_ (u"ࠬࡲ࡯ࡤࡣ࡯ࠫঢ়")] = True
    if bstack1l1111111_opy_:
      caps[bstack11l1l1l_opy_ (u"࠭ࡢࡴࡶࡤࡧࡰࡀ࡯ࡱࡶ࡬ࡳࡳࡹࠧ৞")][bstack11l1l1l_opy_ (u"ࠧ࡭ࡱࡦࡥࡱࡏࡤࡦࡰࡷ࡭࡫࡯ࡥࡳࠩয়")] = bstack1l1111111_opy_
  else:
    caps[bstack11l1l1l_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࠮࡭ࡱࡦࡥࡱ࠭ৠ")] = True
    if bstack1l1111111_opy_:
      caps[bstack11l1l1l_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫࠯࡮ࡲࡧࡦࡲࡉࡥࡧࡱࡸ࡮࡬ࡩࡦࡴࠪৡ")] = bstack1l1111111_opy_
def bstack111l1l111_opy_():
  global CONFIG
  if bstack11l1l1l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡎࡲࡧࡦࡲࠧৢ") in CONFIG and CONFIG[bstack11l1l1l_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡏࡳࡨࡧ࡬ࠨৣ")]:
    bstack1llll1ll11_opy_ = bstack1ll1ll11l1_opy_(CONFIG)
    bstack11l111l1l_opy_(CONFIG[bstack11l1l1l_opy_ (u"ࠬࡧࡣࡤࡧࡶࡷࡐ࡫ࡹࠨ৤")], bstack1llll1ll11_opy_)
def bstack11l111l1l_opy_(key, bstack1llll1ll11_opy_):
  global bstack1lll11l11l_opy_
  logger.info(bstack1lllllll11_opy_)
  try:
    bstack1lll11l11l_opy_ = Local()
    bstack11l1l1l11_opy_ = {bstack11l1l1l_opy_ (u"࠭࡫ࡦࡻࠪ৥"): key}
    bstack11l1l1l11_opy_.update(bstack1llll1ll11_opy_)
    logger.debug(bstack11111l11l_opy_.format(str(bstack11l1l1l11_opy_)))
    bstack1lll11l11l_opy_.start(**bstack11l1l1l11_opy_)
    if bstack1lll11l11l_opy_.isRunning():
      logger.info(bstack11l1lll11_opy_)
  except Exception as e:
    bstack11ll1l1l1_opy_(bstack1l1l111ll_opy_.format(str(e)))
def bstack111l1lll_opy_():
  global bstack1lll11l11l_opy_
  if bstack1lll11l11l_opy_.isRunning():
    logger.info(bstack11l11ll1l_opy_)
    bstack1lll11l11l_opy_.stop()
  bstack1lll11l11l_opy_ = None
def bstack1ll1lll111_opy_(bstack1l111llll_opy_=[]):
  global CONFIG
  bstack1l1l1lll1_opy_ = []
  bstack1l11111l_opy_ = [bstack11l1l1l_opy_ (u"ࠧࡰࡵࠪ০"), bstack11l1l1l_opy_ (u"ࠨࡱࡶ࡚ࡪࡸࡳࡪࡱࡱࠫ১"), bstack11l1l1l_opy_ (u"ࠩࡧࡩࡻ࡯ࡣࡦࡐࡤࡱࡪ࠭২"), bstack11l1l1l_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱ࡛࡫ࡲࡴ࡫ࡲࡲࠬ৩"), bstack11l1l1l_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡓࡧ࡭ࡦࠩ৪"), bstack11l1l1l_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷ࡜ࡥࡳࡵ࡬ࡳࡳ࠭৫")]
  try:
    for err in bstack1l111llll_opy_:
      bstack111l1111_opy_ = {}
      for k in bstack1l11111l_opy_:
        val = CONFIG[bstack11l1l1l_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩ৬")][int(err[bstack11l1l1l_opy_ (u"ࠧࡪࡰࡧࡩࡽ࠭৭")])].get(k)
        if val:
          bstack111l1111_opy_[k] = val
      bstack111l1111_opy_[bstack11l1l1l_opy_ (u"ࠨࡶࡨࡷࡹࡹࠧ৮")] = {
        err[bstack11l1l1l_opy_ (u"ࠩࡱࡥࡲ࡫ࠧ৯")]: err[bstack11l1l1l_opy_ (u"ࠪࡩࡷࡸ࡯ࡳࠩৰ")]
      }
      bstack1l1l1lll1_opy_.append(bstack111l1111_opy_)
  except Exception as e:
    logger.debug(bstack11l1l1l_opy_ (u"ࠫࡊࡸࡲࡰࡴࠣ࡭ࡳࠦࡦࡰࡴࡰࡥࡹࡺࡩ࡯ࡩࠣࡨࡦࡺࡡࠡࡨࡲࡶࠥ࡫ࡶࡦࡰࡷ࠾ࠥ࠭ৱ") + str(e))
  finally:
    return bstack1l1l1lll1_opy_
def bstack11l11llll_opy_():
  global bstack1l11l11l_opy_
  global bstack1ll1l111l1_opy_
  global bstack11llllll1_opy_
  if bstack1l11l11l_opy_:
    logger.warning(bstack1l11llll_opy_.format(str(bstack1l11l11l_opy_)))
  logger.info(bstack1111ll1l1_opy_)
  global bstack1lll11l11l_opy_
  if bstack1lll11l11l_opy_:
    bstack111l1lll_opy_()
  try:
    for driver in bstack1ll1l111l1_opy_:
      driver.quit()
  except Exception as e:
    pass
  logger.info(bstack1111111l_opy_)
  bstack1ll1lllll_opy_()
  if len(bstack11llllll1_opy_) > 0:
    message = bstack1ll1lll111_opy_(bstack11llllll1_opy_)
    bstack1ll1lllll_opy_(message)
  else:
    bstack1ll1lllll_opy_()
def bstack11ll111l_opy_(self, *args):
  logger.error(bstack1l1l1l11_opy_)
  bstack11l11llll_opy_()
  sys.exit(1)
def bstack11ll1l1l1_opy_(err):
  logger.critical(bstack1lll1lll1l_opy_.format(str(err)))
  bstack1ll1lllll_opy_(bstack1lll1lll1l_opy_.format(str(err)))
  atexit.unregister(bstack11l11llll_opy_)
  sys.exit(1)
def bstack11l1111l1_opy_(error, message):
  logger.critical(str(error))
  logger.critical(message)
  bstack1ll1lllll_opy_(message)
  atexit.unregister(bstack11l11llll_opy_)
  sys.exit(1)
def bstack1l1l11l1l_opy_():
  global CONFIG
  global bstack1ll11lll1l_opy_
  global bstack1lll1lll11_opy_
  global bstack1lllll11l1_opy_
  CONFIG = bstack1111l11l_opy_()
  bstack1l11l1ll_opy_()
  bstack1ll1l11l11_opy_()
  CONFIG = bstack1ll1l111ll_opy_(CONFIG)
  update(CONFIG, bstack1lll1lll11_opy_)
  update(CONFIG, bstack1ll11lll1l_opy_)
  CONFIG = bstack111ll111_opy_(CONFIG)
  bstack1lllll11l1_opy_ = bstack1ll1ll111l_opy_(CONFIG)
  bstack111111ll_opy_.set_property(bstack11l1l1l_opy_ (u"ࠬࡨࡳࡵࡣࡦ࡯ࡤࡹࡥࡴࡵ࡬ࡳࡳ࠭৲"), bstack1lllll11l1_opy_)
  if (bstack11l1l1l_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡓࡧ࡭ࡦࠩ৳") in CONFIG and bstack11l1l1l_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡔࡡ࡮ࡧࠪ৴") in bstack1ll11lll1l_opy_) or (
          bstack11l1l1l_opy_ (u"ࠨࡤࡸ࡭ࡱࡪࡎࡢ࡯ࡨࠫ৵") in CONFIG and bstack11l1l1l_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡏࡣࡰࡩࠬ৶") not in bstack1lll1lll11_opy_):
    if os.getenv(bstack11l1l1l_opy_ (u"ࠪࡆࡘ࡚ࡁࡄࡍࡢࡇࡔࡓࡂࡊࡐࡈࡈࡤࡈࡕࡊࡎࡇࡣࡎࡊࠧ৷")):
      CONFIG[bstack11l1l1l_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡌࡨࡪࡴࡴࡪࡨ࡬ࡩࡷ࠭৸")] = os.getenv(bstack11l1l1l_opy_ (u"ࠬࡈࡓࡕࡃࡆࡏࡤࡉࡏࡎࡄࡌࡒࡊࡊ࡟ࡃࡗࡌࡐࡉࡥࡉࡅࠩ৹"))
    else:
      bstack1l1l1l1l_opy_()
  elif (bstack11l1l1l_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡓࡧ࡭ࡦࠩ৺") not in CONFIG and bstack11l1l1l_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡏࡤࡦࡰࡷ࡭࡫࡯ࡥࡳࠩ৻") in CONFIG) or (
          bstack11l1l1l_opy_ (u"ࠨࡤࡸ࡭ࡱࡪࡎࡢ࡯ࡨࠫৼ") in bstack1lll1lll11_opy_ and bstack11l1l1l_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡏࡣࡰࡩࠬ৽") not in bstack1ll11lll1l_opy_):
    del (CONFIG[bstack11l1l1l_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡋࡧࡩࡳࡺࡩࡧ࡫ࡨࡶࠬ৾")])
  if bstack11ll11ll_opy_(CONFIG):
    bstack11ll1l1l1_opy_(bstack1lll1ll111_opy_)
  bstack111ll1ll1_opy_()
  bstack111l11l1_opy_()
  if bstack1ll11l11l_opy_:
    CONFIG[bstack11l1l1l_opy_ (u"ࠫࡦࡶࡰࠨ৿")] = bstack1111lllll_opy_(CONFIG)
    logger.info(bstack11111l1l1_opy_.format(CONFIG[bstack11l1l1l_opy_ (u"ࠬࡧࡰࡱࠩ਀")]))
def bstack111l11l1_opy_():
  global CONFIG
  global bstack1ll11l11l_opy_
  if bstack11l1l1l_opy_ (u"࠭ࡡࡱࡲࠪਁ") in CONFIG:
    try:
      from appium import version
    except Exception as e:
      bstack11l1111l1_opy_(e, bstack111l11lll_opy_)
    bstack1ll11l11l_opy_ = True
    bstack111111ll_opy_.set_property(bstack11l1l1l_opy_ (u"ࠧࡢࡲࡳࡣࡦࡻࡴࡰ࡯ࡤࡸࡪ࠭ਂ"), True)
def bstack1111lllll_opy_(config):
  bstack1lll1llll1_opy_ = bstack11l1l1l_opy_ (u"ࠨࠩਃ")
  app = config[bstack11l1l1l_opy_ (u"ࠩࡤࡴࡵ࠭਄")]
  if isinstance(app, str):
    if os.path.splitext(app)[1] in bstack11111111_opy_:
      if os.path.exists(app):
        bstack1lll1llll1_opy_ = bstack1l1l111l1_opy_(config, app)
      elif bstack111111lll_opy_(app):
        bstack1lll1llll1_opy_ = app
      else:
        bstack11ll1l1l1_opy_(bstack1l1111l11_opy_.format(app))
    else:
      if bstack111111lll_opy_(app):
        bstack1lll1llll1_opy_ = app
      elif os.path.exists(app):
        bstack1lll1llll1_opy_ = bstack1l1l111l1_opy_(app)
      else:
        bstack11ll1l1l1_opy_(bstack1111l1l11_opy_)
  else:
    if len(app) > 2:
      bstack11ll1l1l1_opy_(bstack1ll11l1l1_opy_)
    elif len(app) == 2:
      if bstack11l1l1l_opy_ (u"ࠪࡴࡦࡺࡨࠨਅ") in app and bstack11l1l1l_opy_ (u"ࠫࡨࡻࡳࡵࡱࡰࡣ࡮ࡪࠧਆ") in app:
        if os.path.exists(app[bstack11l1l1l_opy_ (u"ࠬࡶࡡࡵࡪࠪਇ")]):
          bstack1lll1llll1_opy_ = bstack1l1l111l1_opy_(config, app[bstack11l1l1l_opy_ (u"࠭ࡰࡢࡶ࡫ࠫਈ")], app[bstack11l1l1l_opy_ (u"ࠧࡤࡷࡶࡸࡴࡳ࡟ࡪࡦࠪਉ")])
        else:
          bstack11ll1l1l1_opy_(bstack1l1111l11_opy_.format(app))
      else:
        bstack11ll1l1l1_opy_(bstack1ll11l1l1_opy_)
    else:
      for key in app:
        if key in bstack1l1ll111l_opy_:
          if key == bstack11l1l1l_opy_ (u"ࠨࡲࡤࡸ࡭࠭ਊ"):
            if os.path.exists(app[key]):
              bstack1lll1llll1_opy_ = bstack1l1l111l1_opy_(config, app[key])
            else:
              bstack11ll1l1l1_opy_(bstack1l1111l11_opy_.format(app))
          else:
            bstack1lll1llll1_opy_ = app[key]
        else:
          bstack11ll1l1l1_opy_(bstack1l1llll1l_opy_)
  return bstack1lll1llll1_opy_
def bstack111111lll_opy_(bstack1lll1llll1_opy_):
  import re
  bstack1ll1lll1l_opy_ = re.compile(bstack11l1l1l_opy_ (u"ࡴࠥࡢࡠࡧ࠭ࡻࡃ࠰࡞࠵࠳࠹࡝ࡡ࠱ࡠ࠲ࡣࠪࠥࠤ਋"))
  bstack1lll111ll1_opy_ = re.compile(bstack11l1l1l_opy_ (u"ࡵࠦࡣࡡࡡ࠮ࡼࡄ࠱࡟࠶࠭࠺࡞ࡢ࠲ࡡ࠳࡝ࠫ࠱࡞ࡥ࠲ࢀࡁ࠮࡜࠳࠱࠾ࡢ࡟࠯࡞࠰ࡡ࠯ࠪࠢ਌"))
  if bstack11l1l1l_opy_ (u"ࠫࡧࡹ࠺࠰࠱ࠪ਍") in bstack1lll1llll1_opy_ or re.fullmatch(bstack1ll1lll1l_opy_, bstack1lll1llll1_opy_) or re.fullmatch(bstack1lll111ll1_opy_, bstack1lll1llll1_opy_):
    return True
  else:
    return False
def bstack1l1l111l1_opy_(config, path, bstack1l1l1111l_opy_=None):
  import requests
  from requests_toolbelt.multipart.encoder import MultipartEncoder
  import hashlib
  md5_hash = hashlib.md5(open(os.path.abspath(path), bstack11l1l1l_opy_ (u"ࠬࡸࡢࠨ਎")).read()).hexdigest()
  bstack1ll1l1l11l_opy_ = bstack1ll1l11111_opy_(md5_hash)
  bstack1lll1llll1_opy_ = None
  if bstack1ll1l1l11l_opy_:
    logger.info(bstack1l1l1ll1l_opy_.format(bstack1ll1l1l11l_opy_, md5_hash))
    return bstack1ll1l1l11l_opy_
  bstack1ll1llll1l_opy_ = MultipartEncoder(
    fields={
      bstack11l1l1l_opy_ (u"࠭ࡦࡪ࡮ࡨࠫਏ"): (os.path.basename(path), open(os.path.abspath(path), bstack11l1l1l_opy_ (u"ࠧࡳࡤࠪਐ")), bstack11l1l1l_opy_ (u"ࠨࡶࡨࡼࡹ࠵ࡰ࡭ࡣ࡬ࡲࠬ਑")),
      bstack11l1l1l_opy_ (u"ࠩࡦࡹࡸࡺ࡯࡮ࡡ࡬ࡨࠬ਒"): bstack1l1l1111l_opy_
    }
  )
  response = requests.post(bstack1lll1l11ll_opy_, data=bstack1ll1llll1l_opy_,
                           headers={bstack11l1l1l_opy_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩਓ"): bstack1ll1llll1l_opy_.content_type},
                           auth=(config[bstack11l1l1l_opy_ (u"ࠫࡺࡹࡥࡳࡐࡤࡱࡪ࠭ਔ")], config[bstack11l1l1l_opy_ (u"ࠬࡧࡣࡤࡧࡶࡷࡐ࡫ࡹࠨਕ")]))
  try:
    res = json.loads(response.text)
    bstack1lll1llll1_opy_ = res[bstack11l1l1l_opy_ (u"࠭ࡡࡱࡲࡢࡹࡷࡲࠧਖ")]
    logger.info(bstack11lllll1_opy_.format(bstack1lll1llll1_opy_))
    bstack1llllll11l_opy_(md5_hash, bstack1lll1llll1_opy_)
  except ValueError as err:
    bstack11ll1l1l1_opy_(bstack1llllll111_opy_.format(str(err)))
  return bstack1lll1llll1_opy_
def bstack111ll1ll1_opy_():
  global CONFIG
  global bstack1111lll1_opy_
  bstack11ll111ll_opy_ = 0
  bstack111llll1_opy_ = 1
  if bstack11l1l1l_opy_ (u"ࠧࡱࡣࡵࡥࡱࡲࡥ࡭ࡵࡓࡩࡷࡖ࡬ࡢࡶࡩࡳࡷࡳࠧਗ") in CONFIG:
    bstack111llll1_opy_ = CONFIG[bstack11l1l1l_opy_ (u"ࠨࡲࡤࡶࡦࡲ࡬ࡦ࡮ࡶࡔࡪࡸࡐ࡭ࡣࡷࡪࡴࡸ࡭ࠨਘ")]
  if bstack11l1l1l_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࡷࠬਙ") in CONFIG:
    bstack11ll111ll_opy_ = len(CONFIG[bstack11l1l1l_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱࡸ࠭ਚ")])
  bstack1111lll1_opy_ = int(bstack111llll1_opy_) * int(bstack11ll111ll_opy_)
def bstack1ll1l11111_opy_(md5_hash):
  bstack1l1l1l11l_opy_ = os.path.join(os.path.expanduser(bstack11l1l1l_opy_ (u"ࠫࢃ࠭ਛ")), bstack11l1l1l_opy_ (u"ࠬ࠴ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࠬਜ"), bstack11l1l1l_opy_ (u"࠭ࡡࡱࡲࡘࡴࡱࡵࡡࡥࡏࡇ࠹ࡍࡧࡳࡩ࠰࡭ࡷࡴࡴࠧਝ"))
  if os.path.exists(bstack1l1l1l11l_opy_):
    bstack111lll1l1_opy_ = json.load(open(bstack1l1l1l11l_opy_, bstack11l1l1l_opy_ (u"ࠧࡳࡤࠪਞ")))
    if md5_hash in bstack111lll1l1_opy_:
      bstack1l111l1ll_opy_ = bstack111lll1l1_opy_[md5_hash]
      bstack1ll1ll1ll_opy_ = datetime.datetime.now()
      bstack1llllll1ll_opy_ = datetime.datetime.strptime(bstack1l111l1ll_opy_[bstack11l1l1l_opy_ (u"ࠨࡶ࡬ࡱࡪࡹࡴࡢ࡯ࡳࠫਟ")], bstack11l1l1l_opy_ (u"ࠩࠨࡨ࠴ࠫ࡭࠰ࠧ࡜ࠤࠪࡎ࠺ࠦࡏ࠽ࠩࡘ࠭ਠ"))
      if (bstack1ll1ll1ll_opy_ - bstack1llllll1ll_opy_).days > 60:
        return None
      elif version.parse(str(__version__)) > version.parse(bstack1l111l1ll_opy_[bstack11l1l1l_opy_ (u"ࠪࡷࡩࡱ࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࠨਡ")]):
        return None
      return bstack1l111l1ll_opy_[bstack11l1l1l_opy_ (u"ࠫ࡮ࡪࠧਢ")]
  else:
    return None
def bstack1llllll11l_opy_(md5_hash, bstack1lll1llll1_opy_):
  bstack1ll1l1ll1_opy_ = os.path.join(os.path.expanduser(bstack11l1l1l_opy_ (u"ࠬࢄࠧਣ")), bstack11l1l1l_opy_ (u"࠭࠮ࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠭ਤ"))
  if not os.path.exists(bstack1ll1l1ll1_opy_):
    os.makedirs(bstack1ll1l1ll1_opy_)
  bstack1l1l1l11l_opy_ = os.path.join(os.path.expanduser(bstack11l1l1l_opy_ (u"ࠧࡿࠩਥ")), bstack11l1l1l_opy_ (u"ࠨ࠰ࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࠨਦ"), bstack11l1l1l_opy_ (u"ࠩࡤࡴࡵ࡛ࡰ࡭ࡱࡤࡨࡒࡊ࠵ࡉࡣࡶ࡬࠳ࡰࡳࡰࡰࠪਧ"))
  bstack1111ll1l_opy_ = {
    bstack11l1l1l_opy_ (u"ࠪ࡭ࡩ࠭ਨ"): bstack1lll1llll1_opy_,
    bstack11l1l1l_opy_ (u"ࠫࡹ࡯࡭ࡦࡵࡷࡥࡲࡶࠧ਩"): datetime.datetime.strftime(datetime.datetime.now(), bstack11l1l1l_opy_ (u"ࠬࠫࡤ࠰ࠧࡰ࠳ࠪ࡟ࠠࠦࡊ࠽ࠩࡒࡀࠥࡔࠩਪ")),
    bstack11l1l1l_opy_ (u"࠭ࡳࡥ࡭ࡢࡺࡪࡸࡳࡪࡱࡱࠫਫ"): str(__version__)
  }
  if os.path.exists(bstack1l1l1l11l_opy_):
    bstack111lll1l1_opy_ = json.load(open(bstack1l1l1l11l_opy_, bstack11l1l1l_opy_ (u"ࠧࡳࡤࠪਬ")))
  else:
    bstack111lll1l1_opy_ = {}
  bstack111lll1l1_opy_[md5_hash] = bstack1111ll1l_opy_
  with open(bstack1l1l1l11l_opy_, bstack11l1l1l_opy_ (u"ࠣࡹ࠮ࠦਭ")) as outfile:
    json.dump(bstack111lll1l1_opy_, outfile)
def bstack1l11ll1l1_opy_(self):
  return
def bstack1ll1lllll1_opy_(self):
  return
def bstack11l111ll1_opy_(self):
  from selenium.webdriver.remote.webdriver import WebDriver
  WebDriver.quit(self)
def bstack1llll11ll_opy_(self):
  global bstack1l11ll11_opy_
  global bstack11l1ll11l_opy_
  global bstack1ll111ll1_opy_
  try:
    if bstack11l1l1l_opy_ (u"ࠩࡳࡽࡹ࡫ࡳࡵࠩਮ") in bstack1l11ll11_opy_ and self.session_id != None:
      bstack1l1l11ll_opy_ = bstack11l1l1l_opy_ (u"ࠪࡴࡦࡹࡳࡦࡦࠪਯ") if len(threading.current_thread().bstackTestErrorMessages) == 0 else bstack11l1l1l_opy_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫਰ")
      bstack11l1l111_opy_ = bstack11l111l1_opy_(bstack11l1l1l_opy_ (u"ࠬࡹࡥࡵࡕࡨࡷࡸ࡯࡯࡯ࡕࡷࡥࡹࡻࡳࠨ਱"), bstack11l1l1l_opy_ (u"࠭ࠧਲ"), bstack1l1l11ll_opy_, bstack11l1l1l_opy_ (u"ࠧ࠭ࠢࠪਲ਼").join(
        threading.current_thread().bstackTestErrorMessages), bstack11l1l1l_opy_ (u"ࠨࠩ਴"), bstack11l1l1l_opy_ (u"ࠩࠪਵ"))
      if self != None:
        self.execute_script(bstack11l1l111_opy_)
  except Exception as e:
    logger.debug(bstack11l1l1l_opy_ (u"ࠥࡉࡷࡸ࡯ࡳࠢࡺ࡬࡮ࡲࡥࠡ࡯ࡤࡶࡰ࡯࡮ࡨࠢࡶࡸࡦࡺࡵࡴ࠼ࠣࠦਸ਼") + str(e))
  bstack1ll111ll1_opy_(self)
  self.session_id = None
def bstack11l1lll1l_opy_(self, *args, **kwargs):
  bstack1ll1ll1l1l_opy_ = bstack1l11ll1ll_opy_(self, *args, **kwargs)
  bstack1llll1ll1l_opy_.bstack11l11ll1_opy_(self)
  return bstack1ll1ll1l1l_opy_
def bstack1lll1lllll_opy_(self, command_executor,
             desired_capabilities=None, browser_profile=None, proxy=None,
             keep_alive=True, file_detector=None, options=None):
  global CONFIG
  global bstack11l1ll11l_opy_
  global bstack111111l11_opy_
  global bstack1111l1l1_opy_
  global bstack11l11l1ll_opy_
  global bstack11ll1l1l_opy_
  global bstack1l11ll11_opy_
  global bstack1l11ll1ll_opy_
  global bstack1ll1l111l1_opy_
  global bstack1l1111ll_opy_
  CONFIG[bstack11l1l1l_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡖࡈࡐ࠭਷")] = str(bstack1l11ll11_opy_) + str(__version__)
  command_executor = bstack11111llll_opy_()
  logger.debug(bstack11lll1ll_opy_.format(command_executor))
  proxy = bstack1l11ll111_opy_(CONFIG, proxy)
  bstack11l1lll1_opy_ = 0 if bstack111111l11_opy_ < 0 else bstack111111l11_opy_
  try:
    if bstack11l11l1ll_opy_ is True:
      bstack11l1lll1_opy_ = int(multiprocessing.current_process().name)
    elif bstack11ll1l1l_opy_ is True:
      bstack11l1lll1_opy_ = int(threading.current_thread().name)
  except:
    bstack11l1lll1_opy_ = 0
  bstack1ll1l1ll11_opy_ = bstack1ll11l1ll_opy_(CONFIG, bstack11l1lll1_opy_)
  logger.debug(bstack11l11l11l_opy_.format(str(bstack1ll1l1ll11_opy_)))
  if bstack11l1l1l_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡐࡴࡩࡡ࡭ࠩਸ") in CONFIG and CONFIG[bstack11l1l1l_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡑࡵࡣࡢ࡮ࠪਹ")]:
    bstack1lll11l1ll_opy_(bstack1ll1l1ll11_opy_)
  if desired_capabilities:
    bstack11l1l11ll_opy_ = bstack1ll1l111ll_opy_(desired_capabilities)
    bstack11l1l11ll_opy_[bstack11l1l1l_opy_ (u"ࠧࡶࡵࡨ࡛࠸ࡉࠧ਺")] = bstack1llll1l111_opy_(CONFIG)
    bstack1llll1l1ll_opy_ = bstack1ll11l1ll_opy_(bstack11l1l11ll_opy_)
    if bstack1llll1l1ll_opy_:
      bstack1ll1l1ll11_opy_ = update(bstack1llll1l1ll_opy_, bstack1ll1l1ll11_opy_)
    desired_capabilities = None
  if options:
    bstack111ll1l1_opy_(options, bstack1ll1l1ll11_opy_)
  if not options:
    options = bstack111llll11_opy_(bstack1ll1l1ll11_opy_)
  if proxy and bstack1ll1ll1l1_opy_() >= version.parse(bstack11l1l1l_opy_ (u"ࠨ࠶࠱࠵࠵࠴࠰ࠨ਻")):
    options.proxy(proxy)
  if options and bstack1ll1ll1l1_opy_() >= version.parse(bstack11l1l1l_opy_ (u"ࠩ࠶࠲࠽࠴࠰ࠨ਼")):
    desired_capabilities = None
  if (
          not options and not desired_capabilities
  ) or (
          bstack1ll1ll1l1_opy_() < version.parse(bstack11l1l1l_opy_ (u"ࠪ࠷࠳࠾࠮࠱ࠩ਽")) and not desired_capabilities
  ):
    desired_capabilities = {}
    desired_capabilities.update(bstack1ll1l1ll11_opy_)
  logger.info(bstack1111l111l_opy_)
  if bstack1ll1ll1l1_opy_() >= version.parse(bstack11l1l1l_opy_ (u"ࠫ࠹࠴࠱࠱࠰࠳ࠫਾ")):
    bstack1l11ll1ll_opy_(self, command_executor=command_executor,
              options=options, keep_alive=keep_alive, file_detector=file_detector)
  elif bstack1ll1ll1l1_opy_() >= version.parse(bstack11l1l1l_opy_ (u"ࠬ࠹࠮࠹࠰࠳ࠫਿ")):
    bstack1l11ll1ll_opy_(self, command_executor=command_executor,
              desired_capabilities=desired_capabilities, options=options,
              browser_profile=browser_profile, proxy=proxy,
              keep_alive=keep_alive, file_detector=file_detector)
  elif bstack1ll1ll1l1_opy_() >= version.parse(bstack11l1l1l_opy_ (u"࠭࠲࠯࠷࠶࠲࠵࠭ੀ")):
    bstack1l11ll1ll_opy_(self, command_executor=command_executor,
              desired_capabilities=desired_capabilities,
              browser_profile=browser_profile, proxy=proxy,
              keep_alive=keep_alive, file_detector=file_detector)
  else:
    bstack1l11ll1ll_opy_(self, command_executor=command_executor,
              desired_capabilities=desired_capabilities,
              browser_profile=browser_profile, proxy=proxy,
              keep_alive=keep_alive)
  try:
    bstack1llll1lll_opy_ = bstack11l1l1l_opy_ (u"ࠧࠨੁ")
    if bstack1ll1ll1l1_opy_() >= version.parse(bstack11l1l1l_opy_ (u"ࠨ࠶࠱࠴࠳࠶ࡢ࠲ࠩੂ")):
      bstack1llll1lll_opy_ = self.caps.get(bstack11l1l1l_opy_ (u"ࠤࡲࡴࡹ࡯࡭ࡢ࡮ࡋࡹࡧ࡛ࡲ࡭ࠤ੃"))
    else:
      bstack1llll1lll_opy_ = self.capabilities.get(bstack11l1l1l_opy_ (u"ࠥࡳࡵࡺࡩ࡮ࡣ࡯ࡌࡺࡨࡕࡳ࡮ࠥ੄"))
    if bstack1llll1lll_opy_:
      if bstack1ll1ll1l1_opy_() <= version.parse(bstack11l1l1l_opy_ (u"ࠫ࠸࠴࠱࠴࠰࠳ࠫ੅")):
        self.command_executor._url = bstack11l1l1l_opy_ (u"ࠧ࡮ࡴࡵࡲ࠽࠳࠴ࠨ੆") + bstack1lll1l111_opy_ + bstack11l1l1l_opy_ (u"ࠨ࠺࠹࠲࠲ࡻࡩ࠵ࡨࡶࡤࠥੇ")
      else:
        self.command_executor._url = bstack11l1l1l_opy_ (u"ࠢࡩࡶࡷࡴࡸࡀ࠯࠰ࠤੈ") + bstack1llll1lll_opy_ + bstack11l1l1l_opy_ (u"ࠣ࠱ࡺࡨ࠴࡮ࡵࡣࠤ੉")
      logger.debug(bstack11lll11l_opy_.format(bstack1llll1lll_opy_))
    else:
      logger.debug(bstack1l1l11111_opy_.format(bstack11l1l1l_opy_ (u"ࠤࡒࡴࡹ࡯࡭ࡢ࡮ࠣࡌࡺࡨࠠ࡯ࡱࡷࠤ࡫ࡵࡵ࡯ࡦࠥ੊")))
  except Exception as e:
    logger.debug(bstack1l1l11111_opy_.format(e))
  if bstack11l1l1l_opy_ (u"ࠪࡶࡴࡨ࡯ࡵࠩੋ") in bstack1l11ll11_opy_:
    bstack1lllll1l1_opy_(bstack111111l11_opy_, bstack1l1111ll_opy_)
  bstack11l1ll11l_opy_ = self.session_id
  if bstack11l1l1l_opy_ (u"ࠫࡵࡿࡴࡦࡵࡷࠫੌ") in bstack1l11ll11_opy_ or bstack11l1l1l_opy_ (u"ࠬࡨࡥࡩࡣࡹࡩ੍ࠬ") in bstack1l11ll11_opy_:
    threading.current_thread().bstack11l1ll1l1_opy_ = self.session_id
    threading.current_thread().bstackSessionDriver = self
    threading.current_thread().bstackTestErrorMessages = []
    bstack1llll1ll1l_opy_.bstack11l11ll1_opy_(self)
  bstack1ll1l111l1_opy_.append(self)
  if bstack11l1l1l_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩ੎") in CONFIG and bstack11l1l1l_opy_ (u"ࠧࡴࡧࡶࡷ࡮ࡵ࡮ࡏࡣࡰࡩࠬ੏") in CONFIG[bstack11l1l1l_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠫ੐")][bstack11l1lll1_opy_]:
    bstack1111l1l1_opy_ = CONFIG[bstack11l1l1l_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࡷࠬੑ")][bstack11l1lll1_opy_][bstack11l1l1l_opy_ (u"ࠪࡷࡪࡹࡳࡪࡱࡱࡒࡦࡳࡥࠨ੒")]
  logger.debug(bstack11111ll1l_opy_.format(bstack11l1ll11l_opy_))
try:
  try:
    import Browser
    from subprocess import Popen
    def bstack1l111ll1_opy_(self, args, bufsize=-1, executable=None,
              stdin=None, stdout=None, stderr=None,
              preexec_fn=None, close_fds=True,
              shell=False, cwd=None, env=None, universal_newlines=None,
              startupinfo=None, creationflags=0,
              restore_signals=True, start_new_session=False,
              pass_fds=(), *, user=None, group=None, extra_groups=None,
              encoding=None, errors=None, text=None, umask=-1, pipesize=-1):
      global CONFIG
      global bstack1l111l11_opy_
      if(bstack11l1l1l_opy_ (u"ࠦ࡮ࡴࡤࡦࡺ࠱࡮ࡸࠨ੓") in args[1]):
        with open(os.path.join(os.path.expanduser(bstack11l1l1l_opy_ (u"ࠬࢄࠧ੔")), bstack11l1l1l_opy_ (u"࠭࠮ࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠭੕"), bstack11l1l1l_opy_ (u"ࠧ࠯ࡵࡨࡷࡸ࡯࡯࡯࡫ࡧࡷ࠳ࡺࡸࡵࠩ੖")), bstack11l1l1l_opy_ (u"ࠨࡹࠪ੗")) as fp:
          fp.write(bstack11l1l1l_opy_ (u"ࠤࠥ੘"))
        if(not os.path.exists(os.path.join(os.path.dirname(args[1]), bstack11l1l1l_opy_ (u"ࠥ࡭ࡳࡪࡥࡹࡡࡥࡷࡹࡧࡣ࡬࠰࡭ࡷࠧਖ਼")))):
          with open(args[1], bstack11l1l1l_opy_ (u"ࠫࡷ࠭ਗ਼")) as f:
            lines = f.readlines()
            index = next((i for i, line in enumerate(lines) if bstack11l1l1l_opy_ (u"ࠬࡧࡳࡺࡰࡦࠤ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳࠦ࡟࡯ࡧࡺࡔࡦ࡭ࡥࠩࡥࡲࡲࡹ࡫ࡸࡵ࠮ࠣࡴࡦ࡭ࡥࠡ࠿ࠣࡺࡴ࡯ࡤࠡ࠲ࠬࠫਜ਼") in line), None)
            if index is not None:
                lines.insert(index+2, bstack1lll1ll1l1_opy_)
            lines.insert(1, bstack1lll111l1l_opy_)
            f.seek(0)
            with open(os.path.join(os.path.dirname(args[1]), bstack11l1l1l_opy_ (u"ࠨࡩ࡯ࡦࡨࡼࡤࡨࡳࡵࡣࡦ࡯࠳ࡰࡳࠣੜ")), bstack11l1l1l_opy_ (u"ࠧࡸࠩ੝")) as bstack1ll1l111l_opy_:
              bstack1ll1l111l_opy_.writelines(lines)
        CONFIG[bstack11l1l1l_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࡓࡅࡍࠪਫ਼")] = str(bstack1l11ll11_opy_) + str(__version__)
        bstack11l1lll1_opy_ = 0 if bstack111111l11_opy_ < 0 else bstack111111l11_opy_
        try:
          if bstack11l11l1ll_opy_ is True:
            bstack11l1lll1_opy_ = int(multiprocessing.current_process().name)
          elif bstack11ll1l1l_opy_ is True:
            bstack11l1lll1_opy_ = int(threading.current_thread().name)
        except:
          bstack11l1lll1_opy_ = 0
        CONFIG[bstack11l1l1l_opy_ (u"ࠤࡸࡷࡪ࡝࠳ࡄࠤ੟")] = False
        CONFIG[bstack11l1l1l_opy_ (u"ࠥ࡭ࡸࡖ࡬ࡢࡻࡺࡶ࡮࡭ࡨࡵࠤ੠")] = True
        bstack1ll1l1ll11_opy_ = bstack1ll11l1ll_opy_(CONFIG, bstack11l1lll1_opy_)
        logger.debug(bstack11l11l11l_opy_.format(str(bstack1ll1l1ll11_opy_)))
        if CONFIG[bstack11l1l1l_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡏࡳࡨࡧ࡬ࠨ੡")]:
          bstack1lll11l1ll_opy_(bstack1ll1l1ll11_opy_)
        if bstack11l1l1l_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡳࠨ੢") in CONFIG and bstack11l1l1l_opy_ (u"࠭ࡳࡦࡵࡶ࡭ࡴࡴࡎࡢ࡯ࡨࠫ੣") in CONFIG[bstack11l1l1l_opy_ (u"ࠧࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡵࠪ੤")][bstack11l1lll1_opy_]:
          bstack1111l1l1_opy_ = CONFIG[bstack11l1l1l_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠫ੥")][bstack11l1lll1_opy_][bstack11l1l1l_opy_ (u"ࠩࡶࡩࡸࡹࡩࡰࡰࡑࡥࡲ࡫ࠧ੦")]
        args.append(os.path.join(os.path.expanduser(bstack11l1l1l_opy_ (u"ࠪࢂࠬ੧")), bstack11l1l1l_opy_ (u"ࠫ࠳ࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࠫ੨"), bstack11l1l1l_opy_ (u"ࠬ࠴ࡳࡦࡵࡶ࡭ࡴࡴࡩࡥࡵ࠱ࡸࡽࡺࠧ੩")))
        args.append(str(threading.get_ident()))
        args.append(json.dumps(bstack1ll1l1ll11_opy_))
        args[1] = os.path.join(os.path.dirname(args[1]), bstack11l1l1l_opy_ (u"ࠨࡩ࡯ࡦࡨࡼࡤࡨࡳࡵࡣࡦ࡯࠳ࡰࡳࠣ੪"))
      bstack1l111l11_opy_ = True
      return bstack111l1l1l_opy_(self, args, bufsize=bufsize, executable=executable,
                    stdin=stdin, stdout=stdout, stderr=stderr,
                    preexec_fn=preexec_fn, close_fds=close_fds,
                    shell=shell, cwd=cwd, env=env, universal_newlines=universal_newlines,
                    startupinfo=startupinfo, creationflags=creationflags,
                    restore_signals=restore_signals, start_new_session=start_new_session,
                    pass_fds=pass_fds, user=user, group=group, extra_groups=extra_groups,
                    encoding=encoding, errors=errors, text=text, umask=umask, pipesize=pipesize)
  except Exception as e:
    pass
  import playwright._impl._api_structures
  import playwright._impl._helper
  def bstack111lll1ll_opy_(self,
        executablePath = None,
        channel = None,
        args = None,
        ignoreDefaultArgs = None,
        handleSIGINT = None,
        handleSIGTERM = None,
        handleSIGHUP = None,
        timeout = None,
        env = None,
        headless = None,
        devtools = None,
        proxy = None,
        downloadsPath = None,
        slowMo = None,
        tracesDir = None,
        chromiumSandbox = None,
        firefoxUserPrefs = None
        ):
    global CONFIG
    global bstack11l1ll11l_opy_
    global bstack111111l11_opy_
    global bstack1111l1l1_opy_
    global bstack11l11l1ll_opy_
    global bstack11ll1l1l_opy_
    global bstack1l11ll11_opy_
    global bstack1l11ll1ll_opy_
    CONFIG[bstack11l1l1l_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࡙ࡄࡌࠩ੫")] = str(bstack1l11ll11_opy_) + str(__version__)
    bstack11l1lll1_opy_ = 0 if bstack111111l11_opy_ < 0 else bstack111111l11_opy_
    try:
      if bstack11l11l1ll_opy_ is True:
        bstack11l1lll1_opy_ = int(multiprocessing.current_process().name)
      elif bstack11ll1l1l_opy_ is True:
        bstack11l1lll1_opy_ = int(threading.current_thread().name)
    except:
      bstack11l1lll1_opy_ = 0
    CONFIG[bstack11l1l1l_opy_ (u"ࠣ࡫ࡶࡔࡱࡧࡹࡸࡴ࡬࡫࡭ࡺࠢ੬")] = True
    bstack1ll1l1ll11_opy_ = bstack1ll11l1ll_opy_(CONFIG, bstack11l1lll1_opy_)
    logger.debug(bstack11l11l11l_opy_.format(str(bstack1ll1l1ll11_opy_)))
    if CONFIG[bstack11l1l1l_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡍࡱࡦࡥࡱ࠭੭")]:
      bstack1lll11l1ll_opy_(bstack1ll1l1ll11_opy_)
    if bstack11l1l1l_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱࡸ࠭੮") in CONFIG and bstack11l1l1l_opy_ (u"ࠫࡸ࡫ࡳࡴ࡫ࡲࡲࡓࡧ࡭ࡦࠩ੯") in CONFIG[bstack11l1l1l_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡳࠨੰ")][bstack11l1lll1_opy_]:
      bstack1111l1l1_opy_ = CONFIG[bstack11l1l1l_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩੱ")][bstack11l1lll1_opy_][bstack11l1l1l_opy_ (u"ࠧࡴࡧࡶࡷ࡮ࡵ࡮ࡏࡣࡰࡩࠬੲ")]
    import urllib
    import json
    bstack1111l1l1l_opy_ = bstack11l1l1l_opy_ (u"ࠨࡹࡶࡷ࠿࠵࠯ࡤࡦࡳ࠲ࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭࠱ࡧࡴࡳ࠯ࡱ࡮ࡤࡽࡼࡸࡩࡨࡪࡷࡃࡨࡧࡰࡴ࠿ࠪੳ") + urllib.parse.quote(json.dumps(bstack1ll1l1ll11_opy_))
    browser = self.connect(bstack1111l1l1l_opy_)
    return browser
except Exception as e:
    pass
def bstack11lll1l11_opy_():
    global bstack1l111l11_opy_
    try:
        from playwright._impl._browser_type import BrowserType
        BrowserType.launch = bstack111lll1ll_opy_
        bstack1l111l11_opy_ = True
    except Exception as e:
        pass
    try:
      import Browser
      from subprocess import Popen
      Popen.__init__ = bstack1l111ll1_opy_
      bstack1l111l11_opy_ = True
    except Exception as e:
      pass
def bstack11l111ll_opy_(context, bstack1lll1l11l1_opy_):
  try:
    context.page.evaluate(bstack11l1l1l_opy_ (u"ࠤࡢࠤࡂࡄࠠࡼࡿࠥੴ"), bstack11l1l1l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡡࡨࡼࡪࡩࡵࡵࡱࡵ࠾ࠥࢁࠢࡢࡥࡷ࡭ࡴࡴࠢ࠻ࠢࠥࡷࡪࡺࡓࡦࡵࡶ࡭ࡴࡴࡎࡢ࡯ࡨࠦ࠱ࠦࠢࡢࡴࡪࡹࡲ࡫࡮ࡵࡵࠥ࠾ࠥࢁࠢ࡯ࡣࡰࡩࠧࡀࠧੵ")+ json.dumps(bstack1lll1l11l1_opy_) + bstack11l1l1l_opy_ (u"ࠦࢂࢃࠢ੶"))
  except Exception as e:
    logger.debug(bstack11l1l1l_opy_ (u"ࠧ࡫ࡸࡤࡧࡳࡸ࡮ࡵ࡮ࠡ࡫ࡱࠤࡵࡲࡡࡺࡹࡵ࡭࡬࡮ࡴࠡࡵࡨࡷࡸ࡯࡯࡯ࠢࡱࡥࡲ࡫ࠠࡼࡿࠥ੷"), e)
def bstack111ll1111_opy_(context, message, level):
  try:
    context.page.evaluate(bstack11l1l1l_opy_ (u"ࠨ࡟ࠡ࠿ࡁࠤࢀࢃࠢ੸"), bstack11l1l1l_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡥࡥࡹࡧࡦࡹࡹࡵࡲ࠻ࠢࡾࠦࡦࡩࡴࡪࡱࡱࠦ࠿ࠦࠢࡢࡰࡱࡳࡹࡧࡴࡦࠤ࠯ࠤࠧࡧࡲࡨࡷࡰࡩࡳࡺࡳࠣ࠼ࠣࡿࠧࡪࡡࡵࡣࠥ࠾ࠬ੹") + json.dumps(message) + bstack11l1l1l_opy_ (u"ࠨ࠮ࠥࡰࡪࡼࡥ࡭ࠤ࠽ࠫ੺") + json.dumps(level) + bstack11l1l1l_opy_ (u"ࠩࢀࢁࠬ੻"))
  except Exception as e:
    logger.debug(bstack11l1l1l_opy_ (u"ࠥࡩࡽࡩࡥࡱࡶ࡬ࡳࡳࠦࡩ࡯ࠢࡳࡰࡦࡿࡷࡳ࡫ࡪ࡬ࡹࠦࡡ࡯ࡰࡲࡸࡦࡺࡩࡰࡰࠣࡿࢂࠨ੼"), e)
def bstack1llll1llll_opy_(context, status, message = bstack11l1l1l_opy_ (u"ࠦࠧ੽")):
  try:
    if(status == bstack11l1l1l_opy_ (u"ࠧ࡬ࡡࡪ࡮ࡨࡨࠧ੾")):
      context.page.evaluate(bstack11l1l1l_opy_ (u"ࠨ࡟ࠡ࠿ࡁࠤࢀࢃࠢ੿"), bstack11l1l1l_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡥࡥࡹࡧࡦࡹࡹࡵࡲ࠻ࠢࡾࠦࡦࡩࡴࡪࡱࡱࠦ࠿ࠦࠢࡴࡧࡷࡗࡪࡹࡳࡪࡱࡱࡗࡹࡧࡴࡶࡵࠥ࠰ࠥࠨࡡࡳࡩࡸࡱࡪࡴࡴࡴࠤ࠽ࠤࢀࠨࡲࡦࡣࡶࡳࡳࠨ࠺ࠨ઀") + json.dumps(bstack11l1l1l_opy_ (u"ࠣࡕࡦࡩࡳࡧࡲࡪࡱࠣࡪࡦ࡯࡬ࡦࡦࠣࡻ࡮ࡺࡨ࠻ࠢࠥઁ") + str(message)) + bstack11l1l1l_opy_ (u"ࠩ࠯ࠦࡸࡺࡡࡵࡷࡶࠦ࠿࠭ં") + json.dumps(status) + bstack11l1l1l_opy_ (u"ࠥࢁࢂࠨઃ"))
    else:
      context.page.evaluate(bstack11l1l1l_opy_ (u"ࠦࡤࠦ࠽࠿ࠢࡾࢁࠧ઄"), bstack11l1l1l_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡣࡪࡾࡥࡤࡷࡷࡳࡷࡀࠠࡼࠤࡤࡧࡹ࡯࡯࡯ࠤ࠽ࠤࠧࡹࡥࡵࡕࡨࡷࡸ࡯࡯࡯ࡕࡷࡥࡹࡻࡳࠣ࠮ࠣࠦࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠢ࠻ࠢࡾࠦࡸࡺࡡࡵࡷࡶࠦ࠿࠭અ") + json.dumps(status) + bstack11l1l1l_opy_ (u"ࠨࡽࡾࠤઆ"))
  except Exception as e:
    logger.debug(bstack11l1l1l_opy_ (u"ࠢࡦࡺࡦࡩࡵࡺࡩࡰࡰࠣ࡭ࡳࠦࡰ࡭ࡣࡼࡻࡷ࡯ࡧࡩࡶࠣࡷࡪࡺࠠࡴࡧࡶࡷ࡮ࡵ࡮ࠡࡵࡷࡥࡹࡻࡳࠡࡽࢀࠦઇ"), e)
def bstack111llllll_opy_(self, url):
  global bstack1ll1ll11ll_opy_
  try:
    bstack1ll11ll1l_opy_(url)
  except Exception as err:
    logger.debug(bstack1l1lllll1_opy_.format(str(err)))
  try:
    bstack1ll1ll11ll_opy_(self, url)
  except Exception as e:
    try:
      bstack1l1l1ll11_opy_ = str(e)
      if any(err_msg in bstack1l1l1ll11_opy_ for err_msg in bstack1l1l1llll_opy_):
        bstack1ll11ll1l_opy_(url, True)
    except Exception as err:
      logger.debug(bstack1l1lllll1_opy_.format(str(err)))
    raise e
def bstack1lll1ll1l_opy_(self):
  global bstack1lll11lll1_opy_
  bstack1lll11lll1_opy_ = self
  return
def bstack1lllll11ll_opy_(self):
  global bstack1l1l11lll_opy_
  bstack1l1l11lll_opy_ = self
  return
def bstack1l1l11l11_opy_(self, test):
  global CONFIG
  global bstack1l1l11lll_opy_
  global bstack1lll11lll1_opy_
  global bstack11l1ll11l_opy_
  global bstack1llll11l1l_opy_
  global bstack1111l1l1_opy_
  global bstack11l1l11l_opy_
  global bstack1l1lll1l1_opy_
  global bstack1l11lll11_opy_
  global bstack1ll1l111l1_opy_
  try:
    if not bstack11l1ll11l_opy_:
      with open(os.path.join(os.path.expanduser(bstack11l1l1l_opy_ (u"ࠨࢀࠪઈ")), bstack11l1l1l_opy_ (u"ࠩ࠱ࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࠩઉ"), bstack11l1l1l_opy_ (u"ࠪ࠲ࡸ࡫ࡳࡴ࡫ࡲࡲ࡮ࡪࡳ࠯ࡶࡻࡸࠬઊ"))) as f:
        bstack111l1lll1_opy_ = json.loads(bstack11l1l1l_opy_ (u"ࠦࢀࠨઋ") + f.read().strip() + bstack11l1l1l_opy_ (u"ࠬࠨࡸࠣ࠼ࠣࠦࡾࠨࠧઌ") + bstack11l1l1l_opy_ (u"ࠨࡽࠣઍ"))
        bstack11l1ll11l_opy_ = bstack111l1lll1_opy_[str(threading.get_ident())]
  except:
    pass
  if bstack1ll1l111l1_opy_:
    for driver in bstack1ll1l111l1_opy_:
      if bstack11l1ll11l_opy_ == driver.session_id:
        if test:
          bstack11l1l1lll_opy_ = str(test.data)
        if not bstack1lllllll1_opy_ and bstack11l1l1lll_opy_:
          bstack111l1ll1_opy_ = {
            bstack11l1l1l_opy_ (u"ࠧࡢࡥࡷ࡭ࡴࡴࠧ઎"): bstack11l1l1l_opy_ (u"ࠨࡵࡨࡸࡘ࡫ࡳࡴ࡫ࡲࡲࡓࡧ࡭ࡦࠩએ"),
            bstack11l1l1l_opy_ (u"ࠩࡤࡶ࡬ࡻ࡭ࡦࡰࡷࡷࠬઐ"): {
              bstack11l1l1l_opy_ (u"ࠪࡲࡦࡳࡥࠨઑ"): bstack11l1l1lll_opy_
            }
          }
          bstack111lll111_opy_ = bstack11l1l1l_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡢࡩࡽ࡫ࡣࡶࡶࡲࡶ࠿ࠦࡻࡾࠩ઒").format(json.dumps(bstack111l1ll1_opy_))
          driver.execute_script(bstack111lll111_opy_)
        if bstack1llll11l1l_opy_:
          bstack1l1l1l111_opy_ = {
            bstack11l1l1l_opy_ (u"ࠬࡧࡣࡵ࡫ࡲࡲࠬઓ"): bstack11l1l1l_opy_ (u"࠭ࡡ࡯ࡰࡲࡸࡦࡺࡥࠨઔ"),
            bstack11l1l1l_opy_ (u"ࠧࡢࡴࡪࡹࡲ࡫࡮ࡵࡵࠪક"): {
              bstack11l1l1l_opy_ (u"ࠨࡦࡤࡸࡦ࠭ખ"): bstack11l1l1lll_opy_ + bstack11l1l1l_opy_ (u"ࠩࠣࡴࡦࡹࡳࡦࡦࠤࠫગ"),
              bstack11l1l1l_opy_ (u"ࠪࡰࡪࡼࡥ࡭ࠩઘ"): bstack11l1l1l_opy_ (u"ࠫ࡮ࡴࡦࡰࠩઙ")
            }
          }
          bstack111l1ll1_opy_ = {
            bstack11l1l1l_opy_ (u"ࠬࡧࡣࡵ࡫ࡲࡲࠬચ"): bstack11l1l1l_opy_ (u"࠭ࡳࡦࡶࡖࡩࡸࡹࡩࡰࡰࡖࡸࡦࡺࡵࡴࠩછ"),
            bstack11l1l1l_opy_ (u"ࠧࡢࡴࡪࡹࡲ࡫࡮ࡵࡵࠪજ"): {
              bstack11l1l1l_opy_ (u"ࠨࡵࡷࡥࡹࡻࡳࠨઝ"): bstack11l1l1l_opy_ (u"ࠩࡳࡥࡸࡹࡥࡥࠩઞ")
            }
          }
          if bstack1llll11l1l_opy_.status == bstack11l1l1l_opy_ (u"ࠪࡔࡆ࡙ࡓࠨટ"):
            bstack1llll1111_opy_ = bstack11l1l1l_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡢࡩࡽ࡫ࡣࡶࡶࡲࡶ࠿ࠦࡻࡾࠩઠ").format(json.dumps(bstack1l1l1l111_opy_))
            driver.execute_script(bstack1llll1111_opy_)
            bstack111lll111_opy_ = bstack11l1l1l_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡣࡪࡾࡥࡤࡷࡷࡳࡷࡀࠠࡼࡿࠪડ").format(json.dumps(bstack111l1ll1_opy_))
            driver.execute_script(bstack111lll111_opy_)
          elif bstack1llll11l1l_opy_.status == bstack11l1l1l_opy_ (u"࠭ࡆࡂࡋࡏࠫઢ"):
            reason = bstack11l1l1l_opy_ (u"ࠢࠣણ")
            bstack1llllll1l1_opy_ = bstack11l1l1lll_opy_ + bstack11l1l1l_opy_ (u"ࠨࠢࡩࡥ࡮ࡲࡥࡥࠩત")
            if bstack1llll11l1l_opy_.message:
              reason = str(bstack1llll11l1l_opy_.message)
              bstack1llllll1l1_opy_ = bstack1llllll1l1_opy_ + bstack11l1l1l_opy_ (u"ࠩࠣࡻ࡮ࡺࡨࠡࡧࡵࡶࡴࡸ࠺ࠡࠩથ") + reason
            bstack1l1l1l111_opy_[bstack11l1l1l_opy_ (u"ࠪࡥࡷ࡭ࡵ࡮ࡧࡱࡸࡸ࠭દ")] = {
              bstack11l1l1l_opy_ (u"ࠫࡱ࡫ࡶࡦ࡮ࠪધ"): bstack11l1l1l_opy_ (u"ࠬ࡫ࡲࡳࡱࡵࠫન"),
              bstack11l1l1l_opy_ (u"࠭ࡤࡢࡶࡤࠫ઩"): bstack1llllll1l1_opy_
            }
            bstack111l1ll1_opy_[bstack11l1l1l_opy_ (u"ࠧࡢࡴࡪࡹࡲ࡫࡮ࡵࡵࠪપ")] = {
              bstack11l1l1l_opy_ (u"ࠨࡵࡷࡥࡹࡻࡳࠨફ"): bstack11l1l1l_opy_ (u"ࠩࡩࡥ࡮ࡲࡥࡥࠩબ"),
              bstack11l1l1l_opy_ (u"ࠪࡶࡪࡧࡳࡰࡰࠪભ"): reason
            }
            bstack1llll1111_opy_ = bstack11l1l1l_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡢࡩࡽ࡫ࡣࡶࡶࡲࡶ࠿ࠦࡻࡾࠩમ").format(json.dumps(bstack1l1l1l111_opy_))
            driver.execute_script(bstack1llll1111_opy_)
            bstack111lll111_opy_ = bstack11l1l1l_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡣࡪࡾࡥࡤࡷࡷࡳࡷࡀࠠࡼࡿࠪય").format(json.dumps(bstack111l1ll1_opy_))
            driver.execute_script(bstack111lll111_opy_)
  elif bstack11l1ll11l_opy_:
    try:
      data = {}
      bstack11l1l1lll_opy_ = None
      if test:
        bstack11l1l1lll_opy_ = str(test.data)
      if not bstack1lllllll1_opy_ and bstack11l1l1lll_opy_:
        data[bstack11l1l1l_opy_ (u"࠭࡮ࡢ࡯ࡨࠫર")] = bstack11l1l1lll_opy_
      if bstack1llll11l1l_opy_:
        if bstack1llll11l1l_opy_.status == bstack11l1l1l_opy_ (u"ࠧࡑࡃࡖࡗࠬ઱"):
          data[bstack11l1l1l_opy_ (u"ࠨࡵࡷࡥࡹࡻࡳࠨલ")] = bstack11l1l1l_opy_ (u"ࠩࡳࡥࡸࡹࡥࡥࠩળ")
        elif bstack1llll11l1l_opy_.status == bstack11l1l1l_opy_ (u"ࠪࡊࡆࡏࡌࠨ઴"):
          data[bstack11l1l1l_opy_ (u"ࠫࡸࡺࡡࡵࡷࡶࠫવ")] = bstack11l1l1l_opy_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬશ")
          if bstack1llll11l1l_opy_.message:
            data[bstack11l1l1l_opy_ (u"࠭ࡲࡦࡣࡶࡳࡳ࠭ષ")] = str(bstack1llll11l1l_opy_.message)
      user = CONFIG[bstack11l1l1l_opy_ (u"ࠧࡶࡵࡨࡶࡓࡧ࡭ࡦࠩસ")]
      key = CONFIG[bstack11l1l1l_opy_ (u"ࠨࡣࡦࡧࡪࡹࡳࡌࡧࡼࠫહ")]
      url = bstack11l1l1l_opy_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡿࢂࡀࡻࡾࡂࡤࡴ࡮࠴ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯࠳ࡩ࡯࡮࠱ࡤࡹࡹࡵ࡭ࡢࡶࡨ࠳ࡸ࡫ࡳࡴ࡫ࡲࡲࡸ࠵ࡻࡾ࠰࡭ࡷࡴࡴࠧ઺").format(user, key, bstack11l1ll11l_opy_)
      headers = {
        bstack11l1l1l_opy_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱ࡹࡿࡰࡦࠩ઻"): bstack11l1l1l_opy_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱࡭ࡷࡴࡴ઼ࠧ"),
      }
      if bool(data):
        requests.put(url, json=data, headers=headers)
    except Exception as e:
      logger.error(bstack1ll1l1lll_opy_.format(str(e)))
  if bstack1l1l11lll_opy_:
    bstack1l1lll1l1_opy_(bstack1l1l11lll_opy_)
  if bstack1lll11lll1_opy_:
    bstack1l11lll11_opy_(bstack1lll11lll1_opy_)
  bstack11l1l11l_opy_(self, test)
def bstack1111l11ll_opy_(self, parent, test, skip_on_failure=None, rpa=False):
  global bstack1llllll11_opy_
  bstack1llllll11_opy_(self, parent, test, skip_on_failure=skip_on_failure, rpa=rpa)
  global bstack1llll11l1l_opy_
  bstack1llll11l1l_opy_ = self._test
def bstack11l1111l_opy_():
  global bstack1lll1ll11l_opy_
  try:
    if os.path.exists(bstack1lll1ll11l_opy_):
      os.remove(bstack1lll1ll11l_opy_)
  except Exception as e:
    logger.debug(bstack11l1l1l_opy_ (u"ࠬࡋࡲࡳࡱࡵࠤ࡮ࡴࠠࡥࡧ࡯ࡩࡹ࡯࡮ࡨࠢࡵࡳࡧࡵࡴࠡࡴࡨࡴࡴࡸࡴࠡࡨ࡬ࡰࡪࡀࠠࠨઽ") + str(e))
def bstack11llll1l_opy_():
  global bstack1lll1ll11l_opy_
  bstack11l111l11_opy_ = {}
  try:
    if not os.path.isfile(bstack1lll1ll11l_opy_):
      with open(bstack1lll1ll11l_opy_, bstack11l1l1l_opy_ (u"࠭ࡷࠨા")):
        pass
      with open(bstack1lll1ll11l_opy_, bstack11l1l1l_opy_ (u"ࠢࡸ࠭ࠥિ")) as outfile:
        json.dump({}, outfile)
    if os.path.exists(bstack1lll1ll11l_opy_):
      bstack11l111l11_opy_ = json.load(open(bstack1lll1ll11l_opy_, bstack11l1l1l_opy_ (u"ࠨࡴࡥࠫી")))
  except Exception as e:
    logger.debug(bstack11l1l1l_opy_ (u"ࠩࡈࡶࡷࡵࡲࠡ࡫ࡱࠤࡷ࡫ࡡࡥ࡫ࡱ࡫ࠥࡸ࡯ࡣࡱࡷࠤࡷ࡫ࡰࡰࡴࡷࠤ࡫࡯࡬ࡦ࠼ࠣࠫુ") + str(e))
  finally:
    return bstack11l111l11_opy_
def bstack1lllll1l1_opy_(platform_index, item_index):
  global bstack1lll1ll11l_opy_
  try:
    bstack11l111l11_opy_ = bstack11llll1l_opy_()
    bstack11l111l11_opy_[item_index] = platform_index
    with open(bstack1lll1ll11l_opy_, bstack11l1l1l_opy_ (u"ࠥࡻ࠰ࠨૂ")) as outfile:
      json.dump(bstack11l111l11_opy_, outfile)
  except Exception as e:
    logger.debug(bstack11l1l1l_opy_ (u"ࠫࡊࡸࡲࡰࡴࠣ࡭ࡳࠦࡷࡳ࡫ࡷ࡭ࡳ࡭ࠠࡵࡱࠣࡶࡴࡨ࡯ࡵࠢࡵࡩࡵࡵࡲࡵࠢࡩ࡭ࡱ࡫࠺ࠡࠩૃ") + str(e))
def bstack1lllll111_opy_(bstack1l111l1l_opy_):
  global CONFIG
  bstack1lll1111l_opy_ = bstack11l1l1l_opy_ (u"ࠬ࠭ૄ")
  if not bstack11l1l1l_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩૅ") in CONFIG:
    logger.info(bstack11l1l1l_opy_ (u"ࠧࡏࡱࠣࡴࡱࡧࡴࡧࡱࡵࡱࡸࠦࡰࡢࡵࡶࡩࡩࠦࡵ࡯ࡣࡥࡰࡪࠦࡴࡰࠢࡪࡩࡳ࡫ࡲࡢࡶࡨࠤࡷ࡫ࡰࡰࡴࡷࠤ࡫ࡵࡲࠡࡔࡲࡦࡴࡺࠠࡳࡷࡱࠫ૆"))
  try:
    platform = CONFIG[bstack11l1l1l_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠫે")][bstack1l111l1l_opy_]
    if bstack11l1l1l_opy_ (u"ࠩࡲࡷࠬૈ") in platform:
      bstack1lll1111l_opy_ += str(platform[bstack11l1l1l_opy_ (u"ࠪࡳࡸ࠭ૉ")]) + bstack11l1l1l_opy_ (u"ࠫ࠱ࠦࠧ૊")
    if bstack11l1l1l_opy_ (u"ࠬࡵࡳࡗࡧࡵࡷ࡮ࡵ࡮ࠨો") in platform:
      bstack1lll1111l_opy_ += str(platform[bstack11l1l1l_opy_ (u"࠭࡯ࡴࡘࡨࡶࡸ࡯࡯࡯ࠩૌ")]) + bstack11l1l1l_opy_ (u"્ࠧ࠭ࠢࠪ")
    if bstack11l1l1l_opy_ (u"ࠨࡦࡨࡺ࡮ࡩࡥࡏࡣࡰࡩࠬ૎") in platform:
      bstack1lll1111l_opy_ += str(platform[bstack11l1l1l_opy_ (u"ࠩࡧࡩࡻ࡯ࡣࡦࡐࡤࡱࡪ࠭૏")]) + bstack11l1l1l_opy_ (u"ࠪ࠰ࠥ࠭ૐ")
    if bstack11l1l1l_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲ࡜ࡥࡳࡵ࡬ࡳࡳ࠭૑") in platform:
      bstack1lll1111l_opy_ += str(platform[bstack11l1l1l_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡖࡦࡴࡶ࡭ࡴࡴࠧ૒")]) + bstack11l1l1l_opy_ (u"࠭ࠬࠡࠩ૓")
    if bstack11l1l1l_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡏࡣࡰࡩࠬ૔") in platform:
      bstack1lll1111l_opy_ += str(platform[bstack11l1l1l_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡐࡤࡱࡪ࠭૕")]) + bstack11l1l1l_opy_ (u"ࠩ࠯ࠤࠬ૖")
    if bstack11l1l1l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵ࡚ࡪࡸࡳࡪࡱࡱࠫ૗") in platform:
      bstack1lll1111l_opy_ += str(platform[bstack11l1l1l_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶ࡛࡫ࡲࡴ࡫ࡲࡲࠬ૘")]) + bstack11l1l1l_opy_ (u"ࠬ࠲ࠠࠨ૙")
  except Exception as e:
    logger.debug(bstack11l1l1l_opy_ (u"࠭ࡓࡰ࡯ࡨࠤࡪࡸࡲࡰࡴࠣ࡭ࡳࠦࡧࡦࡰࡨࡶࡦࡺࡩ࡯ࡩࠣࡴࡱࡧࡴࡧࡱࡵࡱࠥࡹࡴࡳ࡫ࡱ࡫ࠥ࡬࡯ࡳࠢࡵࡩࡵࡵࡲࡵࠢࡪࡩࡳ࡫ࡲࡢࡶ࡬ࡳࡳ࠭૚") + str(e))
  finally:
    if bstack1lll1111l_opy_[len(bstack1lll1111l_opy_) - 2:] == bstack11l1l1l_opy_ (u"ࠧ࠭ࠢࠪ૛"):
      bstack1lll1111l_opy_ = bstack1lll1111l_opy_[:-2]
    return bstack1lll1111l_opy_
def bstack1l1ll1111_opy_(path, bstack1lll1111l_opy_):
  try:
    import xml.etree.ElementTree as ET
    bstack11llll11_opy_ = ET.parse(path)
    bstack111l11l1l_opy_ = bstack11llll11_opy_.getroot()
    bstack111111111_opy_ = None
    for suite in bstack111l11l1l_opy_.iter(bstack11l1l1l_opy_ (u"ࠨࡵࡸ࡭ࡹ࡫ࠧ૜")):
      if bstack11l1l1l_opy_ (u"ࠩࡶࡳࡺࡸࡣࡦࠩ૝") in suite.attrib:
        suite.attrib[bstack11l1l1l_opy_ (u"ࠪࡲࡦࡳࡥࠨ૞")] += bstack11l1l1l_opy_ (u"ࠫࠥ࠭૟") + bstack1lll1111l_opy_
        bstack111111111_opy_ = suite
    bstack11llll1l1_opy_ = None
    for robot in bstack111l11l1l_opy_.iter(bstack11l1l1l_opy_ (u"ࠬࡸ࡯ࡣࡱࡷࠫૠ")):
      bstack11llll1l1_opy_ = robot
    bstack1l1l11ll1_opy_ = len(bstack11llll1l1_opy_.findall(bstack11l1l1l_opy_ (u"࠭ࡳࡶ࡫ࡷࡩࠬૡ")))
    if bstack1l1l11ll1_opy_ == 1:
      bstack11llll1l1_opy_.remove(bstack11llll1l1_opy_.findall(bstack11l1l1l_opy_ (u"ࠧࡴࡷ࡬ࡸࡪ࠭ૢ"))[0])
      bstack11l11111l_opy_ = ET.Element(bstack11l1l1l_opy_ (u"ࠨࡵࡸ࡭ࡹ࡫ࠧૣ"), attrib={bstack11l1l1l_opy_ (u"ࠩࡱࡥࡲ࡫ࠧ૤"): bstack11l1l1l_opy_ (u"ࠪࡗࡺ࡯ࡴࡦࡵࠪ૥"), bstack11l1l1l_opy_ (u"ࠫ࡮ࡪࠧ૦"): bstack11l1l1l_opy_ (u"ࠬࡹ࠰ࠨ૧")})
      bstack11llll1l1_opy_.insert(1, bstack11l11111l_opy_)
      bstack1ll1l1ll1l_opy_ = None
      for suite in bstack11llll1l1_opy_.iter(bstack11l1l1l_opy_ (u"࠭ࡳࡶ࡫ࡷࡩࠬ૨")):
        bstack1ll1l1ll1l_opy_ = suite
      bstack1ll1l1ll1l_opy_.append(bstack111111111_opy_)
      bstack11lll11l1_opy_ = None
      for status in bstack111111111_opy_.iter(bstack11l1l1l_opy_ (u"ࠧࡴࡶࡤࡸࡺࡹࠧ૩")):
        bstack11lll11l1_opy_ = status
      bstack1ll1l1ll1l_opy_.append(bstack11lll11l1_opy_)
    bstack11llll11_opy_.write(path)
  except Exception as e:
    logger.debug(bstack11l1l1l_opy_ (u"ࠨࡇࡵࡶࡴࡸࠠࡪࡰࠣࡴࡦࡸࡳࡪࡰࡪࠤࡼ࡮ࡩ࡭ࡧࠣ࡫ࡪࡴࡥࡳࡣࡷ࡭ࡳ࡭ࠠࡳࡱࡥࡳࡹࠦࡲࡦࡲࡲࡶࡹ࠭૪") + str(e))
def bstack1ll1llllll_opy_(outs_dir, pabot_args, options, start_time_string, tests_root_name):
  global bstack1ll1lll1ll_opy_
  global CONFIG
  if bstack11l1l1l_opy_ (u"ࠤࡳࡽࡹ࡮࡯࡯ࡲࡤࡸ࡭ࠨ૫") in options:
    del options[bstack11l1l1l_opy_ (u"ࠥࡴࡾࡺࡨࡰࡰࡳࡥࡹ࡮ࠢ૬")]
  bstack1lll1ll1ll_opy_ = bstack11llll1l_opy_()
  for bstack11111lll1_opy_ in bstack1lll1ll1ll_opy_.keys():
    path = os.path.join(os.getcwd(), bstack11l1l1l_opy_ (u"ࠫࡵࡧࡢࡰࡶࡢࡶࡪࡹࡵ࡭ࡶࡶࠫ૭"), str(bstack11111lll1_opy_), bstack11l1l1l_opy_ (u"ࠬࡵࡵࡵࡲࡸࡸ࠳ࡾ࡭࡭ࠩ૮"))
    bstack1l1ll1111_opy_(path, bstack1lllll111_opy_(bstack1lll1ll1ll_opy_[bstack11111lll1_opy_]))
  bstack11l1111l_opy_()
  return bstack1ll1lll1ll_opy_(outs_dir, pabot_args, options, start_time_string, tests_root_name)
def bstack111l1l1l1_opy_(self, ff_profile_dir):
  global bstack1l1l1l1ll_opy_
  if not ff_profile_dir:
    return None
  return bstack1l1l1l1ll_opy_(self, ff_profile_dir)
def bstack111l1l11l_opy_(datasources, opts_for_run, outs_dir, pabot_args, suite_group):
  from pabot.pabot import QueueItem
  global CONFIG
  global bstack1l1111111_opy_
  bstack1l11llll1_opy_ = []
  if bstack11l1l1l_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩ૯") in CONFIG:
    bstack1l11llll1_opy_ = CONFIG[bstack11l1l1l_opy_ (u"ࠧࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡵࠪ૰")]
  return [
    QueueItem(
      datasources,
      outs_dir,
      opts_for_run,
      suite,
      pabot_args[bstack11l1l1l_opy_ (u"ࠣࡥࡲࡱࡲࡧ࡮ࡥࠤ૱")],
      pabot_args[bstack11l1l1l_opy_ (u"ࠤࡹࡩࡷࡨ࡯ࡴࡧࠥ૲")],
      argfile,
      pabot_args.get(bstack11l1l1l_opy_ (u"ࠥ࡬࡮ࡼࡥࠣ૳")),
      pabot_args[bstack11l1l1l_opy_ (u"ࠦࡵࡸ࡯ࡤࡧࡶࡷࡪࡹࠢ૴")],
      platform[0],
      bstack1l1111111_opy_
    )
    for suite in suite_group
    for argfile in pabot_args[bstack11l1l1l_opy_ (u"ࠧࡧࡲࡨࡷࡰࡩࡳࡺࡦࡪ࡮ࡨࡷࠧ૵")] or [(bstack11l1l1l_opy_ (u"ࠨࠢ૶"), None)]
    for platform in enumerate(bstack1l11llll1_opy_)
  ]
def bstack1ll1l11l1_opy_(self, datasources, outs_dir, options,
                        execution_item, command, verbose, argfile,
                        hive=None, processes=0, platform_index=0, bstack1lll1lll1_opy_=bstack11l1l1l_opy_ (u"ࠧࠨ૷")):
  global bstack1ll11lllll_opy_
  self.platform_index = platform_index
  self.bstack11l1lllll_opy_ = bstack1lll1lll1_opy_
  bstack1ll11lllll_opy_(self, datasources, outs_dir, options,
                      execution_item, command, verbose, argfile, hive, processes)
def bstack1lll11111l_opy_(caller_id, datasources, is_last, item, outs_dir):
  global bstack111ll1l11_opy_
  global bstack1ll1l11ll1_opy_
  if not bstack11l1l1l_opy_ (u"ࠨࡸࡤࡶ࡮ࡧࡢ࡭ࡧࠪ૸") in item.options:
    item.options[bstack11l1l1l_opy_ (u"ࠩࡹࡥࡷ࡯ࡡࡣ࡮ࡨࠫૹ")] = []
  for v in item.options[bstack11l1l1l_opy_ (u"ࠪࡺࡦࡸࡩࡢࡤ࡯ࡩࠬૺ")]:
    if bstack11l1l1l_opy_ (u"ࠫࡇ࡙ࡔࡂࡅࡎࡔࡑࡇࡔࡇࡑࡕࡑࡎࡔࡄࡆ࡚ࠪૻ") in v:
      item.options[bstack11l1l1l_opy_ (u"ࠬࡼࡡࡳ࡫ࡤࡦࡱ࡫ࠧૼ")].remove(v)
    if bstack11l1l1l_opy_ (u"࠭ࡂࡔࡖࡄࡇࡐࡉࡌࡊࡃࡕࡋࡘ࠭૽") in v:
      item.options[bstack11l1l1l_opy_ (u"ࠧࡷࡣࡵ࡭ࡦࡨ࡬ࡦࠩ૾")].remove(v)
  item.options[bstack11l1l1l_opy_ (u"ࠨࡸࡤࡶ࡮ࡧࡢ࡭ࡧࠪ૿")].insert(0, bstack11l1l1l_opy_ (u"ࠩࡅࡗ࡙ࡇࡃࡌࡒࡏࡅ࡙ࡌࡏࡓࡏࡌࡒࡉࡋࡘ࠻ࡽࢀࠫ଀").format(item.platform_index))
  item.options[bstack11l1l1l_opy_ (u"ࠪࡺࡦࡸࡩࡢࡤ࡯ࡩࠬଁ")].insert(0, bstack11l1l1l_opy_ (u"ࠫࡇ࡙ࡔࡂࡅࡎࡈࡊࡌࡌࡐࡅࡄࡐࡎࡊࡅࡏࡖࡌࡊࡎࡋࡒ࠻ࡽࢀࠫଂ").format(item.bstack11l1lllll_opy_))
  if bstack1ll1l11ll1_opy_:
    item.options[bstack11l1l1l_opy_ (u"ࠬࡼࡡࡳ࡫ࡤࡦࡱ࡫ࠧଃ")].insert(0, bstack11l1l1l_opy_ (u"࠭ࡂࡔࡖࡄࡇࡐࡉࡌࡊࡃࡕࡋࡘࡀࡻࡾࠩ଄").format(bstack1ll1l11ll1_opy_))
  return bstack111ll1l11_opy_(caller_id, datasources, is_last, item, outs_dir)
def bstack1lll1llll_opy_(command, item_index):
  global bstack1ll1l11ll1_opy_
  if bstack1ll1l11ll1_opy_:
    command[0] = command[0].replace(bstack11l1l1l_opy_ (u"ࠧࡳࡱࡥࡳࡹ࠭ଅ"), bstack11l1l1l_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࠭ࡴࡦ࡮ࠤࡷࡵࡢࡰࡶ࠰࡭ࡳࡺࡥࡳࡰࡤࡰࠥ࠳࠭ࡣࡵࡷࡥࡨࡱ࡟ࡪࡶࡨࡱࡤ࡯࡮ࡥࡧࡻࠤࠬଆ") + str(
      item_index) + bstack11l1l1l_opy_ (u"ࠩࠣࠫଇ") + bstack1ll1l11ll1_opy_, 1)
  else:
    command[0] = command[0].replace(bstack11l1l1l_opy_ (u"ࠪࡶࡴࡨ࡯ࡵࠩଈ"),
                                    bstack11l1l1l_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭࠰ࡷࡩࡱࠠࡳࡱࡥࡳࡹ࠳ࡩ࡯ࡶࡨࡶࡳࡧ࡬ࠡ࠯࠰ࡦࡸࡺࡡࡤ࡭ࡢ࡭ࡹ࡫࡭ࡠ࡫ࡱࡨࡪࡾࠠࠨଉ") + str(item_index), 1)
def bstack1ll1lll1l1_opy_(command, stderr, stdout, item_name, verbose, pool_id, item_index):
  global bstack11lllllll_opy_
  bstack1lll1llll_opy_(command, item_index)
  return bstack11lllllll_opy_(command, stderr, stdout, item_name, verbose, pool_id, item_index)
def bstack111l11111_opy_(command, stderr, stdout, item_name, verbose, pool_id, item_index, outs_dir):
  global bstack11lllllll_opy_
  bstack1lll1llll_opy_(command, item_index)
  return bstack11lllllll_opy_(command, stderr, stdout, item_name, verbose, pool_id, item_index, outs_dir)
def bstack1111l11l1_opy_(command, stderr, stdout, item_name, verbose, pool_id, item_index, outs_dir, process_timeout):
  global bstack11lllllll_opy_
  bstack1lll1llll_opy_(command, item_index)
  return bstack11lllllll_opy_(command, stderr, stdout, item_name, verbose, pool_id, item_index, outs_dir, process_timeout)
def bstack11l1ll1l_opy_(self, runner, quiet=False, capture=True):
  global bstack1lll1l1ll1_opy_
  bstack111llll1l_opy_ = bstack1lll1l1ll1_opy_(self, runner, quiet=False, capture=True)
  if self.exception:
    if not hasattr(runner, bstack11l1l1l_opy_ (u"ࠬ࡫ࡸࡤࡧࡳࡸ࡮ࡵ࡮ࡠࡣࡵࡶࠬଊ")):
      runner.exception_arr = []
    if not hasattr(runner, bstack11l1l1l_opy_ (u"࠭ࡥࡹࡥࡢࡸࡷࡧࡣࡦࡤࡤࡧࡰࡥࡡࡳࡴࠪଋ")):
      runner.exc_traceback_arr = []
    runner.exception = self.exception
    runner.exc_traceback = self.exc_traceback
    runner.exception_arr.append(self.exception)
    runner.exc_traceback_arr.append(self.exc_traceback)
  return bstack111llll1l_opy_
def bstack111l11l11_opy_(self, name, context, *args):
  global bstack1111ll11l_opy_
  if name == bstack11l1l1l_opy_ (u"ࠧࡣࡧࡩࡳࡷ࡫࡟ࡧࡧࡤࡸࡺࡸࡥࠨଌ"):
    bstack1111ll11l_opy_(self, name, context, *args)
    try:
      if not bstack1lllllll1_opy_:
        bstack1ll1llll11_opy_ = threading.current_thread().bstackSessionDriver if bstack11lll111_opy_(bstack11l1l1l_opy_ (u"ࠨࡤࡶࡸࡦࡩ࡫ࡔࡧࡶࡷ࡮ࡵ࡮ࡅࡴ࡬ࡺࡪࡸࠧ଍")) else context.browser
        bstack1lll1l11l1_opy_ = str(self.feature.name)
        bstack11l111ll_opy_(context, bstack1lll1l11l1_opy_)
        bstack1ll1llll11_opy_.execute_script(bstack11l1l1l_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡠࡧࡻࡩࡨࡻࡴࡰࡴ࠽ࠤࢀࠨࡡࡤࡶ࡬ࡳࡳࠨ࠺ࠡࠤࡶࡩࡹ࡙ࡥࡴࡵ࡬ࡳࡳࡔࡡ࡮ࡧࠥ࠰ࠥࠨࡡࡳࡩࡸࡱࡪࡴࡴࡴࠤ࠽ࠤࢀࠨ࡮ࡢ࡯ࡨࠦ࠿ࠦࠧ଎") + json.dumps(bstack1lll1l11l1_opy_) + bstack11l1l1l_opy_ (u"ࠪࢁࢂ࠭ଏ"))
      self.driver_before_scenario = False
    except Exception as e:
      logger.debug(bstack11l1l1l_opy_ (u"ࠫࡋࡧࡩ࡭ࡧࡧࠤࡹࡵࠠࡴࡧࡷࠤࡸ࡫ࡳࡴ࡫ࡲࡲࠥࡴࡡ࡮ࡧࠣ࡭ࡳࠦࡢࡦࡨࡲࡶࡪࠦࡦࡦࡣࡷࡹࡷ࡫࠺ࠡࡽࢀࠫଐ").format(str(e)))
  elif name == bstack11l1l1l_opy_ (u"ࠬࡨࡥࡧࡱࡵࡩࡤࡹࡣࡦࡰࡤࡶ࡮ࡵࠧ଑"):
    bstack1111ll11l_opy_(self, name, context, *args)
    try:
      if not hasattr(self, bstack11l1l1l_opy_ (u"࠭ࡤࡳ࡫ࡹࡩࡷࡥࡢࡦࡨࡲࡶࡪࡥࡳࡤࡧࡱࡥࡷ࡯࡯ࠨ଒")):
        self.driver_before_scenario = True
      if (not bstack1lllllll1_opy_):
        scenario_name = args[0].name
        feature_name = bstack1lll1l11l1_opy_ = str(self.feature.name)
        bstack1lll1l11l1_opy_ = feature_name + bstack11l1l1l_opy_ (u"ࠧࠡ࠯ࠣࠫଓ") + scenario_name
        bstack1ll1llll11_opy_ = threading.current_thread().bstackSessionDriver if bstack11lll111_opy_(bstack11l1l1l_opy_ (u"ࠨࡤࡶࡸࡦࡩ࡫ࡔࡧࡶࡷ࡮ࡵ࡮ࡅࡴ࡬ࡺࡪࡸࠧଔ")) else context.browser
        if self.driver_before_scenario:
          bstack11l111ll_opy_(context, bstack1lll1l11l1_opy_)
          bstack1ll1llll11_opy_.execute_script(bstack11l1l1l_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡠࡧࡻࡩࡨࡻࡴࡰࡴ࠽ࠤࢀࠨࡡࡤࡶ࡬ࡳࡳࠨ࠺ࠡࠤࡶࡩࡹ࡙ࡥࡴࡵ࡬ࡳࡳࡔࡡ࡮ࡧࠥ࠰ࠥࠨࡡࡳࡩࡸࡱࡪࡴࡴࡴࠤ࠽ࠤࢀࠨ࡮ࡢ࡯ࡨࠦ࠿ࠦࠧକ") + json.dumps(bstack1lll1l11l1_opy_) + bstack11l1l1l_opy_ (u"ࠪࢁࢂ࠭ଖ"))
    except Exception as e:
      logger.debug(bstack11l1l1l_opy_ (u"ࠫࡋࡧࡩ࡭ࡧࡧࠤࡹࡵࠠࡴࡧࡷࠤࡸ࡫ࡳࡴ࡫ࡲࡲࠥࡴࡡ࡮ࡧࠣ࡭ࡳࠦࡢࡦࡨࡲࡶࡪࠦࡳࡤࡧࡱࡥࡷ࡯࡯࠻ࠢࡾࢁࠬଗ").format(str(e)))
  elif name == bstack11l1l1l_opy_ (u"ࠬࡧࡦࡵࡧࡵࡣࡸࡩࡥ࡯ࡣࡵ࡭ࡴ࠭ଘ"):
    try:
      bstack1111l1ll_opy_ = args[0].status.name
      bstack1ll1llll11_opy_ = threading.current_thread().bstackSessionDriver if bstack11l1l1l_opy_ (u"࠭ࡢࡴࡶࡤࡧࡰ࡙ࡥࡴࡵ࡬ࡳࡳࡊࡲࡪࡸࡨࡶࠬଙ") in threading.current_thread().__dict__.keys() else context.browser
      if str(bstack1111l1ll_opy_).lower() == bstack11l1l1l_opy_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧଚ"):
        bstack1llllllll1_opy_ = bstack11l1l1l_opy_ (u"ࠨࠩଛ")
        bstack1llll1l11_opy_ = bstack11l1l1l_opy_ (u"ࠩࠪଜ")
        bstack111lllll1_opy_ = bstack11l1l1l_opy_ (u"ࠪࠫଝ")
        try:
          import traceback
          bstack1llllllll1_opy_ = self.exception.__class__.__name__
          bstack1lllll1lll_opy_ = traceback.format_tb(self.exc_traceback)
          bstack1llll1l11_opy_ = bstack11l1l1l_opy_ (u"ࠫࠥ࠭ଞ").join(bstack1lllll1lll_opy_)
          bstack111lllll1_opy_ = bstack1lllll1lll_opy_[-1]
        except Exception as e:
          logger.debug(bstack1l1lll111_opy_.format(str(e)))
        bstack1llllllll1_opy_ += bstack111lllll1_opy_
        bstack111ll1111_opy_(context, json.dumps(str(args[0].name) + bstack11l1l1l_opy_ (u"ࠧࠦ࠭ࠡࡈࡤ࡭ࡱ࡫ࡤࠢ࡞ࡱࠦଟ") + str(bstack1llll1l11_opy_)),
                            bstack11l1l1l_opy_ (u"ࠨࡥࡳࡴࡲࡶࠧଠ"))
        if self.driver_before_scenario:
          bstack1llll1llll_opy_(context, bstack11l1l1l_opy_ (u"ࠢࡧࡣ࡬ࡰࡪࡪࠢଡ"), bstack1llllllll1_opy_)
          bstack1ll1llll11_opy_.execute_script(bstack11l1l1l_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࡟ࡦࡺࡨࡧࡺࡺ࡯ࡳ࠼ࠣࡿࠧࡧࡣࡵ࡫ࡲࡲࠧࡀࠠࠣࡣࡱࡲࡴࡺࡡࡵࡧࠥ࠰ࠥࠨࡡࡳࡩࡸࡱࡪࡴࡴࡴࠤ࠽ࠤࢀࠨࡤࡢࡶࡤࠦ࠿࠭ଢ") + json.dumps(str(args[0].name) + bstack11l1l1l_opy_ (u"ࠤࠣ࠱ࠥࡌࡡࡪ࡮ࡨࡨࠦࡢ࡮ࠣଣ") + str(bstack1llll1l11_opy_)) + bstack11l1l1l_opy_ (u"ࠪ࠰ࠥࠨ࡬ࡦࡸࡨࡰࠧࡀࠠࠣࡧࡵࡶࡴࡸࠢࡾࡿࠪତ"))
        if self.driver_before_scenario:
          bstack1ll1llll11_opy_.execute_script(bstack11l1l1l_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡢࡩࡽ࡫ࡣࡶࡶࡲࡶ࠿ࠦࡻࠣࡣࡦࡸ࡮ࡵ࡮ࠣ࠼ࠣࠦࡸ࡫ࡴࡔࡧࡶࡷ࡮ࡵ࡮ࡔࡶࡤࡸࡺࡹࠢ࠭ࠢࠥࡥࡷ࡭ࡵ࡮ࡧࡱࡸࡸࠨ࠺ࠡࡽࠥࡷࡹࡧࡴࡶࡵࠥ࠾ࠧ࡬ࡡࡪ࡮ࡨࡨࠧ࠲ࠠࠣࡴࡨࡥࡸࡵ࡮ࠣ࠼ࠣࠫଥ") + json.dumps(bstack11l1l1l_opy_ (u"࡙ࠧࡣࡦࡰࡤࡶ࡮ࡵࠠࡧࡣ࡬ࡰࡪࡪࠠࡸ࡫ࡷ࡬࠿ࠦ࡜࡯ࠤଦ") + str(bstack1llllllll1_opy_)) + bstack11l1l1l_opy_ (u"࠭ࡽࡾࠩଧ"))
      else:
        bstack111ll1111_opy_(context, bstack11l1l1l_opy_ (u"ࠢࡑࡣࡶࡷࡪࡪࠡࠣନ"), bstack11l1l1l_opy_ (u"ࠣ࡫ࡱࡪࡴࠨ଩"))
        if self.driver_before_scenario:
          bstack1llll1llll_opy_(context, bstack11l1l1l_opy_ (u"ࠤࡳࡥࡸࡹࡥࡥࠤପ"))
        bstack1ll1llll11_opy_.execute_script(bstack11l1l1l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡡࡨࡼࡪࡩࡵࡵࡱࡵ࠾ࠥࢁࠢࡢࡥࡷ࡭ࡴࡴࠢ࠻ࠢࠥࡥࡳࡴ࡯ࡵࡣࡷࡩࠧ࠲ࠠࠣࡣࡵ࡫ࡺࡳࡥ࡯ࡶࡶࠦ࠿ࠦࡻࠣࡦࡤࡸࡦࠨ࠺ࠨଫ") + json.dumps(str(args[0].name) + bstack11l1l1l_opy_ (u"ࠦࠥ࠳ࠠࡑࡣࡶࡷࡪࡪࠡࠣବ")) + bstack11l1l1l_opy_ (u"ࠬ࠲ࠠࠣ࡮ࡨࡺࡪࡲࠢ࠻ࠢࠥ࡭ࡳ࡬࡯ࠣࡿࢀࠫଭ"))
        if self.driver_before_scenario:
          bstack1ll1llll11_opy_.execute_script(bstack11l1l1l_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡤ࡫ࡸࡦࡥࡸࡸࡴࡸ࠺ࠡࡽࠥࡥࡨࡺࡩࡰࡰࠥ࠾ࠥࠨࡳࡦࡶࡖࡩࡸࡹࡩࡰࡰࡖࡸࡦࡺࡵࡴࠤ࠯ࠤࠧࡧࡲࡨࡷࡰࡩࡳࡺࡳࠣ࠼ࠣࡿࠧࡹࡴࡢࡶࡸࡷࠧࡀࠢࡱࡣࡶࡷࡪࡪࠢࡾࡿࠪମ"))
    except Exception as e:
      logger.debug(bstack11l1l1l_opy_ (u"ࠧࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡱࡦࡸ࡫ࠡࡵࡨࡷࡸ࡯࡯࡯ࠢࡶࡸࡦࡺࡵࡴࠢ࡬ࡲࠥࡧࡦࡵࡧࡵࠤ࡫࡫ࡡࡵࡷࡵࡩ࠿ࠦࡻࡾࠩଯ").format(str(e)))
  elif name == bstack11l1l1l_opy_ (u"ࠨࡣࡩࡸࡪࡸ࡟ࡧࡧࡤࡸࡺࡸࡥࠨର"):
    try:
      bstack1ll1llll11_opy_ = threading.current_thread().bstackSessionDriver if bstack11lll111_opy_(bstack11l1l1l_opy_ (u"ࠩࡥࡷࡹࡧࡣ࡬ࡕࡨࡷࡸ࡯࡯࡯ࡆࡵ࡭ࡻ࡫ࡲࠨ଱")) else context.browser
      if context.failed is True:
        bstack1l111lll_opy_ = []
        bstack11ll1l11l_opy_ = []
        bstack1l1llll11_opy_ = []
        bstack1ll1ll111_opy_ = bstack11l1l1l_opy_ (u"ࠪࠫଲ")
        try:
          import traceback
          for exc in self.exception_arr:
            bstack1l111lll_opy_.append(exc.__class__.__name__)
          for exc_tb in self.exc_traceback_arr:
            bstack1lllll1lll_opy_ = traceback.format_tb(exc_tb)
            bstack1lll111111_opy_ = bstack11l1l1l_opy_ (u"ࠫࠥ࠭ଳ").join(bstack1lllll1lll_opy_)
            bstack11ll1l11l_opy_.append(bstack1lll111111_opy_)
            bstack1l1llll11_opy_.append(bstack1lllll1lll_opy_[-1])
        except Exception as e:
          logger.debug(bstack1l1lll111_opy_.format(str(e)))
        bstack1llllllll1_opy_ = bstack11l1l1l_opy_ (u"ࠬ࠭଴")
        for i in range(len(bstack1l111lll_opy_)):
          bstack1llllllll1_opy_ += bstack1l111lll_opy_[i] + bstack1l1llll11_opy_[i] + bstack11l1l1l_opy_ (u"࠭࡜࡯ࠩଵ")
        bstack1ll1ll111_opy_ = bstack11l1l1l_opy_ (u"ࠧࠡࠩଶ").join(bstack11ll1l11l_opy_)
        if not self.driver_before_scenario:
          bstack111ll1111_opy_(context, bstack1ll1ll111_opy_, bstack11l1l1l_opy_ (u"ࠣࡧࡵࡶࡴࡸࠢଷ"))
          bstack1llll1llll_opy_(context, bstack11l1l1l_opy_ (u"ࠤࡩࡥ࡮ࡲࡥࡥࠤସ"), bstack1llllllll1_opy_)
          bstack1ll1llll11_opy_.execute_script(bstack11l1l1l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡡࡨࡼࡪࡩࡵࡵࡱࡵ࠾ࠥࢁࠢࡢࡥࡷ࡭ࡴࡴࠢ࠻ࠢࠥࡥࡳࡴ࡯ࡵࡣࡷࡩࠧ࠲ࠠࠣࡣࡵ࡫ࡺࡳࡥ࡯ࡶࡶࠦ࠿ࠦࡻࠣࡦࡤࡸࡦࠨ࠺ࠨହ") + json.dumps(bstack1ll1ll111_opy_) + bstack11l1l1l_opy_ (u"ࠫ࠱ࠦࠢ࡭ࡧࡹࡩࡱࠨ࠺ࠡࠤࡨࡶࡷࡵࡲࠣࡿࢀࠫ଺"))
          bstack1ll1llll11_opy_.execute_script(bstack11l1l1l_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡣࡪࡾࡥࡤࡷࡷࡳࡷࡀࠠࡼࠤࡤࡧࡹ࡯࡯࡯ࠤ࠽ࠤࠧࡹࡥࡵࡕࡨࡷࡸ࡯࡯࡯ࡕࡷࡥࡹࡻࡳࠣ࠮ࠣࠦࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠢ࠻ࠢࡾࠦࡸࡺࡡࡵࡷࡶࠦ࠿ࠨࡦࡢ࡫࡯ࡩࡩࠨࠬࠡࠤࡵࡩࡦࡹ࡯࡯ࠤ࠽ࠤࠬ଻") + json.dumps(bstack11l1l1l_opy_ (u"ࠨࡓࡰ࡯ࡨࠤࡸࡩࡥ࡯ࡣࡵ࡭ࡴࡹࠠࡧࡣ࡬ࡰࡪࡪ࠺ࠡ࡞ࡱ଼ࠦ") + str(bstack1llllllll1_opy_)) + bstack11l1l1l_opy_ (u"ࠧࡾࡿࠪଽ"))
      else:
        if not self.driver_before_scenario:
          bstack111ll1111_opy_(context, bstack11l1l1l_opy_ (u"ࠣࡈࡨࡥࡹࡻࡲࡦ࠼ࠣࠦା") + str(self.feature.name) + bstack11l1l1l_opy_ (u"ࠤࠣࡴࡦࡹࡳࡦࡦࠤࠦି"), bstack11l1l1l_opy_ (u"ࠥ࡭ࡳ࡬࡯ࠣୀ"))
          bstack1llll1llll_opy_(context, bstack11l1l1l_opy_ (u"ࠦࡵࡧࡳࡴࡧࡧࠦୁ"))
          bstack1ll1llll11_opy_.execute_script(bstack11l1l1l_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡣࡪࡾࡥࡤࡷࡷࡳࡷࡀࠠࡼࠤࡤࡧࡹ࡯࡯࡯ࠤ࠽ࠤࠧࡧ࡮࡯ࡱࡷࡥࡹ࡫ࠢ࠭ࠢࠥࡥࡷ࡭ࡵ࡮ࡧࡱࡸࡸࠨ࠺ࠡࡽࠥࡨࡦࡺࡡࠣ࠼ࠪୂ") + json.dumps(bstack11l1l1l_opy_ (u"ࠨࡆࡦࡣࡷࡹࡷ࡫࠺ࠡࠤୃ") + str(self.feature.name) + bstack11l1l1l_opy_ (u"ࠢࠡࡲࡤࡷࡸ࡫ࡤࠢࠤୄ")) + bstack11l1l1l_opy_ (u"ࠨ࠮ࠣࠦࡱ࡫ࡶࡦ࡮ࠥ࠾ࠥࠨࡩ࡯ࡨࡲࠦࢂࢃࠧ୅"))
          bstack1ll1llll11_opy_.execute_script(bstack11l1l1l_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡠࡧࡻࡩࡨࡻࡴࡰࡴ࠽ࠤࢀࠨࡡࡤࡶ࡬ࡳࡳࠨ࠺ࠡࠤࡶࡩࡹ࡙ࡥࡴࡵ࡬ࡳࡳ࡙ࡴࡢࡶࡸࡷࠧ࠲ࠠࠣࡣࡵ࡫ࡺࡳࡥ࡯ࡶࡶࠦ࠿ࠦࡻࠣࡵࡷࡥࡹࡻࡳࠣ࠼ࠥࡴࡦࡹࡳࡦࡦࠥࢁࢂ࠭୆"))
    except Exception as e:
      logger.debug(bstack11l1l1l_opy_ (u"ࠪࡊࡦ࡯࡬ࡦࡦࠣࡸࡴࠦ࡭ࡢࡴ࡮ࠤࡸ࡫ࡳࡴ࡫ࡲࡲࠥࡹࡴࡢࡶࡸࡷࠥ࡯࡮ࠡࡣࡩࡸࡪࡸࠠࡧࡧࡤࡸࡺࡸࡥ࠻ࠢࡾࢁࠬେ").format(str(e)))
  else:
    bstack1111ll11l_opy_(self, name, context, *args)
  if name in [bstack11l1l1l_opy_ (u"ࠫࡦ࡬ࡴࡦࡴࡢࡪࡪࡧࡴࡶࡴࡨࠫୈ"), bstack11l1l1l_opy_ (u"ࠬࡧࡦࡵࡧࡵࡣࡸࡩࡥ࡯ࡣࡵ࡭ࡴ࠭୉")]:
    bstack1111ll11l_opy_(self, name, context, *args)
    if (name == bstack11l1l1l_opy_ (u"࠭ࡡࡧࡶࡨࡶࡤࡹࡣࡦࡰࡤࡶ࡮ࡵࠧ୊") and self.driver_before_scenario) or (
            name == bstack11l1l1l_opy_ (u"ࠧࡢࡨࡷࡩࡷࡥࡦࡦࡣࡷࡹࡷ࡫ࠧୋ") and not self.driver_before_scenario):
      try:
        bstack1ll1llll11_opy_ = threading.current_thread().bstackSessionDriver if bstack11lll111_opy_(bstack11l1l1l_opy_ (u"ࠨࡤࡶࡸࡦࡩ࡫ࡔࡧࡶࡷ࡮ࡵ࡮ࡅࡴ࡬ࡺࡪࡸࠧୌ")) else context.browser
        bstack1ll1llll11_opy_.quit()
      except Exception:
        pass
def bstack1l111l111_opy_(config, startdir):
  return bstack11l1l1l_opy_ (u"ࠤࡧࡶ࡮ࡼࡥࡳ࠼ࠣࡿ࠵ࢃ୍ࠢ").format(bstack11l1l1l_opy_ (u"ࠥࡆࡷࡵࡷࡴࡧࡵࡗࡹࡧࡣ࡬ࠤ୎"))
class Notset:
  def __repr__(self):
    return bstack11l1l1l_opy_ (u"ࠦࡁࡔࡏࡕࡕࡈࡘࡃࠨ୏")
notset = Notset()
def bstack11lllll11_opy_(self, name: str, default=notset, skip: bool = False):
  global bstack1lll1ll11_opy_
  if str(name).lower() == bstack11l1l1l_opy_ (u"ࠬࡪࡲࡪࡸࡨࡶࠬ୐"):
    return bstack11l1l1l_opy_ (u"ࠨࡂࡳࡱࡺࡷࡪࡸࡓࡵࡣࡦ࡯ࠧ୑")
  else:
    return bstack1lll1ll11_opy_(self, name, default, skip)
def bstack111lllll_opy_(item, when):
  global bstack1llll111ll_opy_
  try:
    bstack1llll111ll_opy_(item, when)
  except Exception as e:
    pass
def bstack1lll1l11l_opy_():
  return
def bstack11l111l1_opy_(type, name, status, reason, bstack1ll1l1lll1_opy_, bstack1111l1111_opy_):
  bstack111l1ll1_opy_ = {
    bstack11l1l1l_opy_ (u"ࠧࡢࡥࡷ࡭ࡴࡴࠧ୒"): type,
    bstack11l1l1l_opy_ (u"ࠨࡣࡵ࡫ࡺࡳࡥ࡯ࡶࡶࠫ୓"): {}
  }
  if type == bstack11l1l1l_opy_ (u"ࠩࡤࡲࡳࡵࡴࡢࡶࡨࠫ୔"):
    bstack111l1ll1_opy_[bstack11l1l1l_opy_ (u"ࠪࡥࡷ࡭ࡵ࡮ࡧࡱࡸࡸ࠭୕")][bstack11l1l1l_opy_ (u"ࠫࡱ࡫ࡶࡦ࡮ࠪୖ")] = bstack1ll1l1lll1_opy_
    bstack111l1ll1_opy_[bstack11l1l1l_opy_ (u"ࠬࡧࡲࡨࡷࡰࡩࡳࡺࡳࠨୗ")][bstack11l1l1l_opy_ (u"࠭ࡤࡢࡶࡤࠫ୘")] = json.dumps(str(bstack1111l1111_opy_))
  if type == bstack11l1l1l_opy_ (u"ࠧࡴࡧࡷࡗࡪࡹࡳࡪࡱࡱࡒࡦࡳࡥࠨ୙"):
    bstack111l1ll1_opy_[bstack11l1l1l_opy_ (u"ࠨࡣࡵ࡫ࡺࡳࡥ࡯ࡶࡶࠫ୚")][bstack11l1l1l_opy_ (u"ࠩࡱࡥࡲ࡫ࠧ୛")] = name
  if type == bstack11l1l1l_opy_ (u"ࠪࡷࡪࡺࡓࡦࡵࡶ࡭ࡴࡴࡓࡵࡣࡷࡹࡸ࠭ଡ଼"):
    bstack111l1ll1_opy_[bstack11l1l1l_opy_ (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧଢ଼")][bstack11l1l1l_opy_ (u"ࠬࡹࡴࡢࡶࡸࡷࠬ୞")] = status
    if status == bstack11l1l1l_opy_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭ୟ"):
      bstack111l1ll1_opy_[bstack11l1l1l_opy_ (u"ࠧࡢࡴࡪࡹࡲ࡫࡮ࡵࡵࠪୠ")][bstack11l1l1l_opy_ (u"ࠨࡴࡨࡥࡸࡵ࡮ࠨୡ")] = json.dumps(str(reason))
  bstack111lll111_opy_ = bstack11l1l1l_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡠࡧࡻࡩࡨࡻࡴࡰࡴ࠽ࠤࢀࢃࠧୢ").format(json.dumps(bstack111l1ll1_opy_))
  return bstack111lll111_opy_
def bstack1lll1l1l11_opy_(item, call, rep):
  global bstack1ll1l1111_opy_
  global bstack1ll1l111l1_opy_
  global bstack1lllllll1_opy_
  name = bstack11l1l1l_opy_ (u"ࠪࠫୣ")
  try:
    if rep.when == bstack11l1l1l_opy_ (u"ࠫࡨࡧ࡬࡭ࠩ୤"):
      bstack11l1ll11l_opy_ = threading.current_thread().bstack11l1ll1l1_opy_
      try:
        if not bstack1lllllll1_opy_:
          name = str(rep.nodeid)
          bstack11l1l111_opy_ = bstack11l111l1_opy_(bstack11l1l1l_opy_ (u"ࠬࡹࡥࡵࡕࡨࡷࡸ࡯࡯࡯ࡐࡤࡱࡪ࠭୥"), name, bstack11l1l1l_opy_ (u"࠭ࠧ୦"), bstack11l1l1l_opy_ (u"ࠧࠨ୧"), bstack11l1l1l_opy_ (u"ࠨࠩ୨"), bstack11l1l1l_opy_ (u"ࠩࠪ୩"))
          for driver in bstack1ll1l111l1_opy_:
            if bstack11l1ll11l_opy_ == driver.session_id:
              driver.execute_script(bstack11l1l111_opy_)
      except Exception as e:
        logger.debug(bstack11l1l1l_opy_ (u"ࠪࡉࡷࡸ࡯ࡳࠢ࡬ࡲࠥࡹࡥࡵࡶ࡬ࡲ࡬ࠦࡳࡦࡵࡶ࡭ࡴࡴࡎࡢ࡯ࡨࠤ࡫ࡵࡲࠡࡲࡼࡸࡪࡹࡴ࠮ࡤࡧࡨࠥࡹࡥࡴࡵ࡬ࡳࡳࡀࠠࡼࡿࠪ୪").format(str(e)))
      try:
        status = bstack11l1l1l_opy_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫ୫") if rep.outcome.lower() == bstack11l1l1l_opy_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ୬") else bstack11l1l1l_opy_ (u"࠭ࡰࡢࡵࡶࡩࡩ࠭୭")
        reason = bstack11l1l1l_opy_ (u"ࠧࠨ୮")
        if (reason != bstack11l1l1l_opy_ (u"ࠣࠤ୯")):
          try:
            if (threading.current_thread().bstackTestErrorMessages == None):
              threading.current_thread().bstackTestErrorMessages = []
          except Exception as e:
            threading.current_thread().bstackTestErrorMessages = []
          threading.current_thread().bstackTestErrorMessages.append(str(reason))
        if status == bstack11l1l1l_opy_ (u"ࠩࡩࡥ࡮ࡲࡥࡥࠩ୰"):
          reason = rep.longrepr.reprcrash.message
          if (not threading.current_thread().bstackTestErrorMessages):
            threading.current_thread().bstackTestErrorMessages = []
          threading.current_thread().bstackTestErrorMessages.append(reason)
        level = bstack11l1l1l_opy_ (u"ࠪ࡭ࡳ࡬࡯ࠨୱ") if status == bstack11l1l1l_opy_ (u"ࠫࡵࡧࡳࡴࡧࡧࠫ୲") else bstack11l1l1l_opy_ (u"ࠬ࡫ࡲࡳࡱࡵࠫ୳")
        data = name + bstack11l1l1l_opy_ (u"࠭ࠠࡱࡣࡶࡷࡪࡪࠡࠨ୴") if status == bstack11l1l1l_opy_ (u"ࠧࡱࡣࡶࡷࡪࡪࠧ୵") else name + bstack11l1l1l_opy_ (u"ࠨࠢࡩࡥ࡮ࡲࡥࡥࠣࠣࠫ୶") + reason
        bstack1l111ll1l_opy_ = bstack11l111l1_opy_(bstack11l1l1l_opy_ (u"ࠩࡤࡲࡳࡵࡴࡢࡶࡨࠫ୷"), bstack11l1l1l_opy_ (u"ࠪࠫ୸"), bstack11l1l1l_opy_ (u"ࠫࠬ୹"), bstack11l1l1l_opy_ (u"ࠬ࠭୺"), level, data)
        for driver in bstack1ll1l111l1_opy_:
          if bstack11l1ll11l_opy_ == driver.session_id:
            driver.execute_script(bstack1l111ll1l_opy_)
      except Exception as e:
        logger.debug(bstack11l1l1l_opy_ (u"࠭ࡅࡳࡴࡲࡶࠥ࡯࡮ࠡࡵࡨࡸࡹ࡯࡮ࡨࠢࡶࡩࡸࡹࡩࡰࡰࠣࡧࡴࡴࡴࡦࡺࡷࠤ࡫ࡵࡲࠡࡲࡼࡸࡪࡹࡴ࠮ࡤࡧࡨࠥࡹࡥࡴࡵ࡬ࡳࡳࡀࠠࡼࡿࠪ୻").format(str(e)))
  except Exception as e:
    logger.debug(bstack11l1l1l_opy_ (u"ࠧࡆࡴࡵࡳࡷࠦࡩ࡯ࠢࡪࡩࡹࡺࡩ࡯ࡩࠣࡷࡹࡧࡴࡦࠢ࡬ࡲࠥࡶࡹࡵࡧࡶࡸ࠲ࡨࡤࡥࠢࡷࡩࡸࡺࠠࡴࡶࡤࡸࡺࡹ࠺ࠡࡽࢀࠫ୼").format(str(e)))
  bstack1ll1l1111_opy_(item, call, rep)
def bstack1ll1llll1_opy_(framework_name):
  global bstack1l11ll11_opy_
  global bstack1l111l11_opy_
  global bstack11lll1l1_opy_
  bstack1l11ll11_opy_ = framework_name
  logger.info(bstack11l111lll_opy_.format(bstack1l11ll11_opy_.split(bstack11l1l1l_opy_ (u"ࠨ࠯ࠪ୽"))[0]))
  try:
    from selenium import webdriver
    from selenium.webdriver.common.service import Service
    from selenium.webdriver.remote.webdriver import WebDriver
    if bstack1lllll11l1_opy_:
      Service.start = bstack1l11ll1l1_opy_
      Service.stop = bstack1ll1lllll1_opy_
      webdriver.Remote.get = bstack111llllll_opy_
      WebDriver.close = bstack11l111ll1_opy_
      WebDriver.quit = bstack1llll11ll_opy_
      webdriver.Remote.__init__ = bstack1lll1lllll_opy_
    if not bstack1lllll11l1_opy_ and bstack1llll1ll1l_opy_.on():
      webdriver.Remote.__init__ = bstack11l1lll1l_opy_
    bstack1l111l11_opy_ = True
  except Exception as e:
    pass
  bstack11lll1l11_opy_()
  if not bstack1l111l11_opy_:
    bstack11l1111l1_opy_(bstack11l1l1l_opy_ (u"ࠤࡓࡥࡨࡱࡡࡨࡧࡶࠤࡳࡵࡴࠡ࡫ࡱࡷࡹࡧ࡬࡭ࡧࡧࠦ୾"), bstack1lll11llll_opy_)
  if bstack111111l1_opy_():
    try:
      from selenium.webdriver.remote.remote_connection import RemoteConnection
      RemoteConnection._get_proxy_url = bstack1l11l1111_opy_
    except Exception as e:
      logger.error(bstack1lll1111l1_opy_.format(str(e)))
  if (bstack11l1l1l_opy_ (u"ࠪࡶࡴࡨ࡯ࡵࠩ୿") in str(framework_name).lower()):
    try:
      from robot import run_cli
      from robot.output import Output
      from robot.running.status import TestStatus
      from pabot.pabot import QueueItem
      from pabot import pabot
      try:
        from SeleniumLibrary.keywords.webdrivertools.webdrivertools import WebDriverCreator
        WebDriverCreator._get_ff_profile = bstack111l1l1l1_opy_
        from SeleniumLibrary.keywords.webdrivertools.webdrivertools import WebDriverCache
        WebDriverCache.close = bstack1lllll11ll_opy_
      except Exception as e:
        logger.warn(bstack11l1l11l1_opy_ + str(e))
      try:
        from AppiumLibrary.utils.applicationcache import ApplicationCache
        ApplicationCache.close = bstack1lll1ll1l_opy_
      except Exception as e:
        logger.debug(bstack11l1111ll_opy_ + str(e))
    except Exception as e:
      bstack11l1111l1_opy_(e, bstack11l1l11l1_opy_)
    Output.end_test = bstack1l1l11l11_opy_
    TestStatus.__init__ = bstack1111l11ll_opy_
    QueueItem.__init__ = bstack1ll1l11l1_opy_
    pabot._create_items = bstack111l1l11l_opy_
    try:
      from pabot import __version__ as bstack111l1ll11_opy_
      if version.parse(bstack111l1ll11_opy_) >= version.parse(bstack11l1l1l_opy_ (u"ࠫ࠷࠴࠱࠶࠰࠳ࠫ஀")):
        pabot._run = bstack1111l11l1_opy_
      elif version.parse(bstack111l1ll11_opy_) >= version.parse(bstack11l1l1l_opy_ (u"ࠬ࠸࠮࠲࠵࠱࠴ࠬ஁")):
        pabot._run = bstack111l11111_opy_
      else:
        pabot._run = bstack1ll1lll1l1_opy_
    except Exception as e:
      pabot._run = bstack1ll1lll1l1_opy_
    pabot._create_command_for_execution = bstack1lll11111l_opy_
    pabot._report_results = bstack1ll1llllll_opy_
  if bstack11l1l1l_opy_ (u"࠭ࡢࡦࡪࡤࡺࡪ࠭ஂ") in str(framework_name).lower():
    try:
      from behave.runner import Runner
      from behave.model import Step
    except Exception as e:
      bstack11l1111l1_opy_(e, bstack1ll1l11ll_opy_)
    Runner.run_hook = bstack111l11l11_opy_
    Step.run = bstack11l1ll1l_opy_
  if bstack11l1l1l_opy_ (u"ࠧࡱࡻࡷࡩࡸࡺࠧஃ") in str(framework_name).lower():
    if not bstack1lllll11l1_opy_:
      return
    try:
      from pytest_selenium import pytest_selenium
      from _pytest.config import Config
      pytest_selenium.pytest_report_header = bstack1l111l111_opy_
      from pytest_selenium.drivers import browserstack
      browserstack.pytest_selenium_runtest_makereport = bstack1lll1l11l_opy_
      Config.getoption = bstack11lllll11_opy_
    except Exception as e:
      pass
    try:
      from _pytest import runner
      runner._update_current_test_var = bstack111lllll_opy_
    except Exception as e:
      pass
    try:
      from pytest_bdd import reporting
      reporting.runtest_makereport = bstack1lll1l1l11_opy_
    except Exception as e:
      pass
def bstack11l1l111l_opy_():
  global CONFIG
  if bstack11l1l1l_opy_ (u"ࠨࡲࡤࡶࡦࡲ࡬ࡦ࡮ࡶࡔࡪࡸࡐ࡭ࡣࡷࡪࡴࡸ࡭ࠨ஄") in CONFIG and int(CONFIG[bstack11l1l1l_opy_ (u"ࠩࡳࡥࡷࡧ࡬࡭ࡧ࡯ࡷࡕ࡫ࡲࡑ࡮ࡤࡸ࡫ࡵࡲ࡮ࠩஅ")]) > 1:
    logger.warn(bstack1ll1l1l111_opy_)
def bstack1l11l1ll1_opy_(arg):
  bstack1ll1llll1_opy_(bstack111l1l11_opy_)
  from behave.__main__ import main as bstack11111l1ll_opy_
  bstack11111l1ll_opy_(arg)
def bstack11llllll_opy_():
  logger.info(bstack1l1ll1ll1_opy_)
  import argparse
  parser = argparse.ArgumentParser()
  parser.add_argument(bstack11l1l1l_opy_ (u"ࠪࡷࡪࡺࡵࡱࠩஆ"), help=bstack11l1l1l_opy_ (u"ࠫࡌ࡫࡮ࡦࡴࡤࡸࡪࠦࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࠥࡩ࡯࡯ࡨ࡬࡫ࠬஇ"))
  parser.add_argument(bstack11l1l1l_opy_ (u"ࠬ࠳ࡵࠨஈ"), bstack11l1l1l_opy_ (u"࠭࠭࠮ࡷࡶࡩࡷࡴࡡ࡮ࡧࠪஉ"), help=bstack11l1l1l_opy_ (u"࡚ࠧࡱࡸࡶࠥࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࠤࡺࡹࡥࡳࡰࡤࡱࡪ࠭ஊ"))
  parser.add_argument(bstack11l1l1l_opy_ (u"ࠨ࠯࡮ࠫ஋"), bstack11l1l1l_opy_ (u"ࠩ࠰࠱ࡰ࡫ࡹࠨ஌"), help=bstack11l1l1l_opy_ (u"ࠪ࡝ࡴࡻࡲࠡࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࠠࡢࡥࡦࡩࡸࡹࠠ࡬ࡧࡼࠫ஍"))
  parser.add_argument(bstack11l1l1l_opy_ (u"ࠫ࠲࡬ࠧஎ"), bstack11l1l1l_opy_ (u"ࠬ࠳࠭ࡧࡴࡤࡱࡪࡽ࡯ࡳ࡭ࠪஏ"), help=bstack11l1l1l_opy_ (u"࡙࠭ࡰࡷࡵࠤࡹ࡫ࡳࡵࠢࡩࡶࡦࡳࡥࡸࡱࡵ࡯ࠬஐ"))
  bstack111111l1l_opy_ = parser.parse_args()
  try:
    bstack11l11l1l_opy_ = bstack11l1l1l_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠴ࡧࡦࡰࡨࡶ࡮ࡩ࠮ࡺ࡯࡯࠲ࡸࡧ࡭ࡱ࡮ࡨࠫ஑")
    if bstack111111l1l_opy_.framework and bstack111111l1l_opy_.framework not in (bstack11l1l1l_opy_ (u"ࠨࡲࡼࡸ࡭ࡵ࡮ࠨஒ"), bstack11l1l1l_opy_ (u"ࠩࡳࡽࡹ࡮࡯࡯࠵ࠪஓ")):
      bstack11l11l1l_opy_ = bstack11l1l1l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬࠰ࡩࡶࡦࡳࡥࡸࡱࡵ࡯࠳ࡿ࡭࡭࠰ࡶࡥࡲࡶ࡬ࡦࠩஔ")
    bstack11l11lll_opy_ = os.path.join(os.path.dirname(os.path.realpath(__file__)), bstack11l11l1l_opy_)
    bstack1llll1l1l_opy_ = open(bstack11l11lll_opy_, bstack11l1l1l_opy_ (u"ࠫࡷ࠭க"))
    bstack11lllll1l_opy_ = bstack1llll1l1l_opy_.read()
    bstack1llll1l1l_opy_.close()
    if bstack111111l1l_opy_.username:
      bstack11lllll1l_opy_ = bstack11lllll1l_opy_.replace(bstack11l1l1l_opy_ (u"ࠬ࡟ࡏࡖࡔࡢ࡙ࡘࡋࡒࡏࡃࡐࡉࠬ஖"), bstack111111l1l_opy_.username)
    if bstack111111l1l_opy_.key:
      bstack11lllll1l_opy_ = bstack11lllll1l_opy_.replace(bstack11l1l1l_opy_ (u"࡙࠭ࡐࡗࡕࡣࡆࡉࡃࡆࡕࡖࡣࡐࡋ࡙ࠨ஗"), bstack111111l1l_opy_.key)
    if bstack111111l1l_opy_.framework:
      bstack11lllll1l_opy_ = bstack11lllll1l_opy_.replace(bstack11l1l1l_opy_ (u"࡚ࠧࡑࡘࡖࡤࡌࡒࡂࡏࡈ࡛ࡔࡘࡋࠨ஘"), bstack111111l1l_opy_.framework)
    file_name = bstack11l1l1l_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࠮ࡺ࡯࡯ࠫங")
    file_path = os.path.abspath(file_name)
    bstack1llll1l1l1_opy_ = open(file_path, bstack11l1l1l_opy_ (u"ࠩࡺࠫச"))
    bstack1llll1l1l1_opy_.write(bstack11lllll1l_opy_)
    bstack1llll1l1l1_opy_.close()
    logger.info(bstack1l11l1l1l_opy_)
    try:
      os.environ[bstack11l1l1l_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡉࡖࡆࡓࡅࡘࡑࡕࡏࠬ஛")] = bstack111111l1l_opy_.framework if bstack111111l1l_opy_.framework != None else bstack11l1l1l_opy_ (u"ࠦࠧஜ")
      config = yaml.safe_load(bstack11lllll1l_opy_)
      config[bstack11l1l1l_opy_ (u"ࠬࡹ࡯ࡶࡴࡦࡩࠬ஝")] = bstack11l1l1l_opy_ (u"࠭ࡰࡺࡶ࡫ࡳࡳ࠳ࡳࡦࡶࡸࡴࠬஞ")
      bstack1ll1l11lll_opy_(bstack1llll11ll1_opy_, config)
    except Exception as e:
      logger.debug(bstack1l1l1l1l1_opy_.format(str(e)))
  except Exception as e:
    logger.error(bstack1l1lll11l_opy_.format(str(e)))
def bstack1ll1l11lll_opy_(bstack1l111ll11_opy_, config, bstack11ll1l111_opy_={}):
  global bstack1lllll11l1_opy_
  if not config:
    return
  bstack1l11l111_opy_ = bstack1lll11l111_opy_ if not bstack1lllll11l1_opy_ else (
    bstack1llll11l1_opy_ if bstack11l1l1l_opy_ (u"ࠧࡢࡲࡳࠫட") in config else bstack1l1111ll1_opy_)
  data = {
    bstack11l1l1l_opy_ (u"ࠨࡷࡶࡩࡷࡔࡡ࡮ࡧࠪ஠"): config[bstack11l1l1l_opy_ (u"ࠩࡸࡷࡪࡸࡎࡢ࡯ࡨࠫ஡")],
    bstack11l1l1l_opy_ (u"ࠪࡥࡨࡩࡥࡴࡵࡎࡩࡾ࠭஢"): config[bstack11l1l1l_opy_ (u"ࠫࡦࡩࡣࡦࡵࡶࡏࡪࡿࠧண")],
    bstack11l1l1l_opy_ (u"ࠬ࡫ࡶࡦࡰࡷࡣࡹࡿࡰࡦࠩத"): bstack1l111ll11_opy_,
    bstack11l1l1l_opy_ (u"࠭ࡥࡷࡧࡱࡸࡤࡶࡲࡰࡲࡨࡶࡹ࡯ࡥࡴࠩ஥"): {
      bstack11l1l1l_opy_ (u"ࠧ࡭ࡣࡱ࡫ࡺࡧࡧࡦࡡࡩࡶࡦࡳࡥࡸࡱࡵ࡯ࠬ஦"): str(config[bstack11l1l1l_opy_ (u"ࠨࡵࡲࡹࡷࡩࡥࠨ஧")]) if bstack11l1l1l_opy_ (u"ࠩࡶࡳࡺࡸࡣࡦࠩந") in config else bstack11l1l1l_opy_ (u"ࠥࡹࡳࡱ࡮ࡰࡹࡱࠦன"),
      bstack11l1l1l_opy_ (u"ࠫࡷ࡫ࡦࡦࡴࡵࡩࡷ࠭ப"): bstack11ll1llll_opy_(os.getenv(bstack11l1l1l_opy_ (u"ࠧࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣࡋࡘࡁࡎࡇ࡚ࡓࡗࡑࠢ஫"), bstack11l1l1l_opy_ (u"ࠨࠢ஬"))),
      bstack11l1l1l_opy_ (u"ࠧ࡭ࡣࡱ࡫ࡺࡧࡧࡦࠩ஭"): bstack11l1l1l_opy_ (u"ࠨࡲࡼࡸ࡭ࡵ࡮ࠨம"),
      bstack11l1l1l_opy_ (u"ࠩࡳࡶࡴࡪࡵࡤࡶࠪய"): bstack1l11l111_opy_,
      bstack11l1l1l_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡐࡤࡱࡪ࠭ர"): config[bstack11l1l1l_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡑࡥࡲ࡫ࠧற")] if config[bstack11l1l1l_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡒࡦࡳࡥࠨல")] else bstack11l1l1l_opy_ (u"ࠨࡵ࡯࡭ࡱࡳࡼࡴࠢள"),
      bstack11l1l1l_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡏࡤࡦࡰࡷ࡭࡫࡯ࡥࡳࠩழ"): str(config[bstack11l1l1l_opy_ (u"ࠨࡤࡸ࡭ࡱࡪࡉࡥࡧࡱࡸ࡮࡬ࡩࡦࡴࠪவ")]) if bstack11l1l1l_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡊࡦࡨࡲࡹ࡯ࡦࡪࡧࡵࠫஶ") in config else bstack11l1l1l_opy_ (u"ࠥࡹࡳࡱ࡮ࡰࡹࡱࠦஷ"),
      bstack11l1l1l_opy_ (u"ࠫࡴࡹࠧஸ"): sys.platform,
      bstack11l1l1l_opy_ (u"ࠬ࡮࡯ࡴࡶࡱࡥࡲ࡫ࠧஹ"): socket.gethostname()
    }
  }
  update(data[bstack11l1l1l_opy_ (u"࠭ࡥࡷࡧࡱࡸࡤࡶࡲࡰࡲࡨࡶࡹ࡯ࡥࡴࠩ஺")], bstack11ll1l111_opy_)
  try:
    response = bstack11llll11l_opy_(bstack11l1l1l_opy_ (u"ࠧࡑࡑࡖࡘࠬ஻"), bstack1llll111l1_opy_(bstack11ll1ll1l_opy_), data, {
      bstack11l1l1l_opy_ (u"ࠨࡣࡸࡸ࡭࠭஼"): (config[bstack11l1l1l_opy_ (u"ࠩࡸࡷࡪࡸࡎࡢ࡯ࡨࠫ஽")], config[bstack11l1l1l_opy_ (u"ࠪࡥࡨࡩࡥࡴࡵࡎࡩࡾ࠭ா")])
    })
    if response:
      logger.debug(bstack1ll1ll1l11_opy_.format(bstack1l111ll11_opy_, str(response.json())))
  except Exception as e:
    logger.debug(bstack1lll1l1111_opy_.format(str(e)))
def bstack11ll1llll_opy_(framework):
  return bstack11l1l1l_opy_ (u"ࠦࢀࢃ࠭ࡱࡻࡷ࡬ࡴࡴࡡࡨࡧࡱࡸ࠴ࢁࡽࠣி").format(str(framework), __version__) if framework else bstack11l1l1l_opy_ (u"ࠧࡶࡹࡵࡪࡲࡲࡦ࡭ࡥ࡯ࡶ࠲ࡿࢂࠨீ").format(
    __version__)
def bstack1lll11111_opy_():
  global CONFIG
  if bool(CONFIG):
    return
  try:
    bstack1l1l11l1l_opy_()
    logger.debug(bstack11l1l1l1l_opy_.format(str(CONFIG)))
    bstack11lll1l1l_opy_()
    bstack11l1llll_opy_()
  except Exception as e:
    logger.error(bstack11l1l1l_opy_ (u"ࠨࡆࡢ࡫࡯ࡩࡩࠦࡴࡰࠢࡶࡩࡹࡻࡰ࠭ࠢࡨࡶࡷࡵࡲ࠻ࠢࠥு") + str(e))
    sys.exit(1)
  sys.excepthook = bstack1llll11l11_opy_
  atexit.register(bstack11l11llll_opy_)
  signal.signal(signal.SIGINT, bstack11ll111l_opy_)
  signal.signal(signal.SIGTERM, bstack11ll111l_opy_)
def bstack1llll11l11_opy_(exctype, value, traceback):
  global bstack1ll1l111l1_opy_
  try:
    for driver in bstack1ll1l111l1_opy_:
      driver.execute_script(
        bstack11l1l1l_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡥࡥࡹࡧࡦࡹࡹࡵࡲ࠻ࠢࡾࠦࡦࡩࡴࡪࡱࡱࠦ࠿ࠦࠢࡴࡧࡷࡗࡪࡹࡳࡪࡱࡱࡗࡹࡧࡴࡶࡵࠥ࠰ࠥࠨࡡࡳࡩࡸࡱࡪࡴࡴࡴࠤ࠽ࠤࢀࠨࡳࡵࡣࡷࡹࡸࠨ࠺ࠣࡨࡤ࡭ࡱ࡫ࡤࠣ࠮ࠣࠦࡷ࡫ࡡࡴࡱࡱࠦ࠿ࠦࠧூ") + json.dumps(
          bstack11l1l1l_opy_ (u"ࠣࡕࡨࡷࡸ࡯࡯࡯ࠢࡩࡥ࡮ࡲࡥࡥࠢࡺ࡭ࡹ࡮࠺ࠡ࡞ࡱࠦ௃") + str(value)) + bstack11l1l1l_opy_ (u"ࠩࢀࢁࠬ௄"))
  except Exception:
    pass
  bstack1ll1lllll_opy_(value)
  sys.__excepthook__(exctype, value, traceback)
  sys.exit(1)
def bstack1ll1lllll_opy_(message=bstack11l1l1l_opy_ (u"ࠪࠫ௅")):
  global CONFIG
  try:
    if message:
      bstack11ll1l111_opy_ = {
        bstack11l1l1l_opy_ (u"ࠫࡪࡸࡲࡰࡴࠪெ"): str(message)
      }
      bstack1ll1l11lll_opy_(bstack1l111111_opy_, CONFIG, bstack11ll1l111_opy_)
    else:
      bstack1ll1l11lll_opy_(bstack1l111111_opy_, CONFIG)
  except Exception as e:
    logger.debug(bstack1lll1l1l1_opy_.format(str(e)))
def bstack1ll1111l_opy_(bstack1ll11l111_opy_, size):
  bstack1l11lll1l_opy_ = []
  while len(bstack1ll11l111_opy_) > size:
    bstack1l1l111l_opy_ = bstack1ll11l111_opy_[:size]
    bstack1l11lll1l_opy_.append(bstack1l1l111l_opy_)
    bstack1ll11l111_opy_ = bstack1ll11l111_opy_[size:]
  bstack1l11lll1l_opy_.append(bstack1ll11l111_opy_)
  return bstack1l11lll1l_opy_
def bstack1l1111lll_opy_(args):
  if bstack11l1l1l_opy_ (u"ࠬ࠳࡭ࠨே") in args and bstack11l1l1l_opy_ (u"࠭ࡰࡥࡤࠪை") in args:
    return True
  return False
def run_on_browserstack(bstack11111l11_opy_=None, bstack1lllll1l1l_opy_=None, bstack1lll11l11_opy_=False):
  global CONFIG
  global bstack1lll1l111_opy_
  global bstack1ll11l11l_opy_
  bstack1ll1lll11_opy_ = bstack11l1l1l_opy_ (u"ࠧࠨ௉")
  if bstack11111l11_opy_ and isinstance(bstack11111l11_opy_, str):
    bstack11111l11_opy_ = eval(bstack11111l11_opy_)
  if bstack11111l11_opy_:
    CONFIG = bstack11111l11_opy_[bstack11l1l1l_opy_ (u"ࠨࡅࡒࡒࡋࡏࡇࠨொ")]
    bstack1lll1l111_opy_ = bstack11111l11_opy_[bstack11l1l1l_opy_ (u"ࠩࡋ࡙ࡇࡥࡕࡓࡎࠪோ")]
    bstack1ll11l11l_opy_ = bstack11111l11_opy_[bstack11l1l1l_opy_ (u"ࠪࡍࡘࡥࡁࡑࡒࡢࡅ࡚࡚ࡏࡎࡃࡗࡉࠬௌ")]
    bstack111111ll_opy_.set_property(bstack11l1l1l_opy_ (u"ࠫࡎ࡙࡟ࡂࡒࡓࡣࡆ࡛ࡔࡐࡏࡄࡘࡊ்࠭"), bstack1ll11l11l_opy_)
    bstack1ll1lll11_opy_ = bstack11l1l1l_opy_ (u"ࠬࡶࡹࡵࡪࡲࡲࠬ௎")
  if not bstack1lll11l11_opy_:
    if len(sys.argv) <= 1:
      logger.critical(bstack1ll1111l1_opy_)
      return
    if sys.argv[1] == bstack11l1l1l_opy_ (u"࠭࠭࠮ࡸࡨࡶࡸ࡯࡯࡯ࠩ௏") or sys.argv[1] == bstack11l1l1l_opy_ (u"ࠧ࠮ࡸࠪௐ"):
      logger.info(bstack11l1l1l_opy_ (u"ࠨࡄࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࠠࡑࡻࡷ࡬ࡴࡴࠠࡔࡆࡎࠤࡻࢁࡽࠨ௑").format(__version__))
      return
    if sys.argv[1] == bstack11l1l1l_opy_ (u"ࠩࡶࡩࡹࡻࡰࠨ௒"):
      bstack11llllll_opy_()
      return
  args = sys.argv
  bstack1lll11111_opy_()
  global bstack1111lll1_opy_
  global bstack11l11l1ll_opy_
  global bstack11ll1l1l_opy_
  global bstack111111l11_opy_
  global bstack1l1111111_opy_
  global bstack1ll1l11ll1_opy_
  global bstack11llllll1_opy_
  global bstack11lll1l1_opy_
  if not bstack1ll1lll11_opy_:
    if args[1] == bstack11l1l1l_opy_ (u"ࠪࡴࡾࡺࡨࡰࡰࠪ௓") or args[1] == bstack11l1l1l_opy_ (u"ࠫࡵࡿࡴࡩࡱࡱ࠷ࠬ௔"):
      bstack1ll1lll11_opy_ = bstack11l1l1l_opy_ (u"ࠬࡶࡹࡵࡪࡲࡲࠬ௕")
      args = args[2:]
    elif args[1] == bstack11l1l1l_opy_ (u"࠭ࡲࡰࡤࡲࡸࠬ௖"):
      bstack1ll1lll11_opy_ = bstack11l1l1l_opy_ (u"ࠧࡳࡱࡥࡳࡹ࠭ௗ")
      args = args[2:]
    elif args[1] == bstack11l1l1l_opy_ (u"ࠨࡲࡤࡦࡴࡺࠧ௘"):
      bstack1ll1lll11_opy_ = bstack11l1l1l_opy_ (u"ࠩࡳࡥࡧࡵࡴࠨ௙")
      args = args[2:]
    elif args[1] == bstack11l1l1l_opy_ (u"ࠪࡶࡴࡨ࡯ࡵ࠯࡬ࡲࡹ࡫ࡲ࡯ࡣ࡯ࠫ௚"):
      bstack1ll1lll11_opy_ = bstack11l1l1l_opy_ (u"ࠫࡷࡵࡢࡰࡶ࠰࡭ࡳࡺࡥࡳࡰࡤࡰࠬ௛")
      args = args[2:]
    elif args[1] == bstack11l1l1l_opy_ (u"ࠬࡶࡹࡵࡧࡶࡸࠬ௜"):
      bstack1ll1lll11_opy_ = bstack11l1l1l_opy_ (u"࠭ࡰࡺࡶࡨࡷࡹ࠭௝")
      args = args[2:]
    elif args[1] == bstack11l1l1l_opy_ (u"ࠧࡣࡧ࡫ࡥࡻ࡫ࠧ௞"):
      bstack1ll1lll11_opy_ = bstack11l1l1l_opy_ (u"ࠨࡤࡨ࡬ࡦࡼࡥࠨ௟")
      args = args[2:]
    else:
      if not bstack11l1l1l_opy_ (u"ࠩࡩࡶࡦࡳࡥࡸࡱࡵ࡯ࠬ௠") in CONFIG or str(CONFIG[bstack11l1l1l_opy_ (u"ࠪࡪࡷࡧ࡭ࡦࡹࡲࡶࡰ࠭௡")]).lower() in [bstack11l1l1l_opy_ (u"ࠫࡵࡿࡴࡩࡱࡱࠫ௢"), bstack11l1l1l_opy_ (u"ࠬࡶࡹࡵࡪࡲࡲ࠸࠭௣")]:
        bstack1ll1lll11_opy_ = bstack11l1l1l_opy_ (u"࠭ࡰࡺࡶ࡫ࡳࡳ࠭௤")
        args = args[1:]
      elif str(CONFIG[bstack11l1l1l_opy_ (u"ࠧࡧࡴࡤࡱࡪࡽ࡯ࡳ࡭ࠪ௥")]).lower() == bstack11l1l1l_opy_ (u"ࠨࡴࡲࡦࡴࡺࠧ௦"):
        bstack1ll1lll11_opy_ = bstack11l1l1l_opy_ (u"ࠩࡵࡳࡧࡵࡴࠨ௧")
        args = args[1:]
      elif str(CONFIG[bstack11l1l1l_opy_ (u"ࠪࡪࡷࡧ࡭ࡦࡹࡲࡶࡰ࠭௨")]).lower() == bstack11l1l1l_opy_ (u"ࠫࡵࡧࡢࡰࡶࠪ௩"):
        bstack1ll1lll11_opy_ = bstack11l1l1l_opy_ (u"ࠬࡶࡡࡣࡱࡷࠫ௪")
        args = args[1:]
      elif str(CONFIG[bstack11l1l1l_opy_ (u"࠭ࡦࡳࡣࡰࡩࡼࡵࡲ࡬ࠩ௫")]).lower() == bstack11l1l1l_opy_ (u"ࠧࡱࡻࡷࡩࡸࡺࠧ௬"):
        bstack1ll1lll11_opy_ = bstack11l1l1l_opy_ (u"ࠨࡲࡼࡸࡪࡹࡴࠨ௭")
        args = args[1:]
      elif str(CONFIG[bstack11l1l1l_opy_ (u"ࠩࡩࡶࡦࡳࡥࡸࡱࡵ࡯ࠬ௮")]).lower() == bstack11l1l1l_opy_ (u"ࠪࡦࡪ࡮ࡡࡷࡧࠪ௯"):
        bstack1ll1lll11_opy_ = bstack11l1l1l_opy_ (u"ࠫࡧ࡫ࡨࡢࡸࡨࠫ௰")
        args = args[1:]
      else:
        os.environ[bstack11l1l1l_opy_ (u"ࠬࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣࡋࡘࡁࡎࡇ࡚ࡓࡗࡑࠧ௱")] = bstack1ll1lll11_opy_
        bstack11ll1l1l1_opy_(bstack1l11ll1l_opy_)
  global bstack111l1l1l_opy_
  if bstack11111l11_opy_:
    try:
      os.environ[bstack11l1l1l_opy_ (u"࠭ࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤࡌࡒࡂࡏࡈ࡛ࡔࡘࡋࠨ௲")] = bstack1ll1lll11_opy_
      bstack1ll1l11lll_opy_(bstack1l11l111l_opy_, CONFIG)
    except Exception as e:
      logger.debug(bstack1lll1l1l1_opy_.format(str(e)))
  global bstack1l11ll1ll_opy_
  global bstack1ll111ll1_opy_
  global bstack11l1l11l_opy_
  global bstack1l11lll11_opy_
  global bstack1l1lll1l1_opy_
  global bstack1llllll11_opy_
  global bstack1l1l1l1ll_opy_
  global bstack11lllllll_opy_
  global bstack1ll11lllll_opy_
  global bstack111ll1l11_opy_
  global bstack1l1lll1ll_opy_
  global bstack1111ll11l_opy_
  global bstack1lll1l1ll1_opy_
  global bstack1ll1ll11ll_opy_
  global bstack11ll1111l_opy_
  global bstack1lll1ll11_opy_
  global bstack1llll111ll_opy_
  global bstack1ll1lll1ll_opy_
  global bstack1ll1l1111_opy_
  try:
    from selenium import webdriver
    from selenium.webdriver.remote.webdriver import WebDriver
    bstack1l11ll1ll_opy_ = webdriver.Remote.__init__
    bstack1ll111ll1_opy_ = WebDriver.quit
    bstack1l1lll1ll_opy_ = WebDriver.close
    bstack1ll1ll11ll_opy_ = WebDriver.get
  except Exception as e:
    pass
  try:
    import Browser
    from subprocess import Popen
    bstack111l1l1l_opy_ = Popen.__init__
  except Exception as e:
    pass
  if bstack1lll11l1l_opy_(CONFIG):
    if bstack1ll1ll1l1_opy_() < version.parse(bstack1lll11ll1l_opy_):
      logger.error(bstack11ll111l1_opy_.format(bstack1ll1ll1l1_opy_()))
    else:
      try:
        from selenium.webdriver.remote.remote_connection import RemoteConnection
        bstack11ll1111l_opy_ = RemoteConnection._get_proxy_url
      except Exception as e:
        logger.error(bstack1lll1111l1_opy_.format(str(e)))
  if bstack1ll1lll11_opy_ != bstack11l1l1l_opy_ (u"ࠧࡱࡻࡷ࡬ࡴࡴࠧ௳") or (bstack1ll1lll11_opy_ == bstack11l1l1l_opy_ (u"ࠨࡲࡼࡸ࡭ࡵ࡮ࠨ௴") and not bstack11111l11_opy_):
    bstack1111111ll_opy_()
  if (bstack1ll1lll11_opy_ in [bstack11l1l1l_opy_ (u"ࠩࡳࡥࡧࡵࡴࠨ௵"), bstack11l1l1l_opy_ (u"ࠪࡶࡴࡨ࡯ࡵࠩ௶"), bstack11l1l1l_opy_ (u"ࠫࡷࡵࡢࡰࡶ࠰࡭ࡳࡺࡥࡳࡰࡤࡰࠬ௷")]):
    try:
      from robot import run_cli
      from robot.output import Output
      from robot.running.status import TestStatus
      from pabot.pabot import QueueItem
      from pabot import pabot
      try:
        from SeleniumLibrary.keywords.webdrivertools.webdrivertools import WebDriverCreator
        from SeleniumLibrary.keywords.webdrivertools.webdrivertools import WebDriverCache
        WebDriverCreator._get_ff_profile = bstack111l1l1l1_opy_
        bstack1l1lll1l1_opy_ = WebDriverCache.close
      except Exception as e:
        logger.warn(bstack11l1l11l1_opy_ + str(e))
      try:
        from AppiumLibrary.utils.applicationcache import ApplicationCache
        bstack1l11lll11_opy_ = ApplicationCache.close
      except Exception as e:
        logger.debug(bstack11l1111ll_opy_ + str(e))
    except Exception as e:
      bstack11l1111l1_opy_(e, bstack11l1l11l1_opy_)
    if bstack1ll1lll11_opy_ != bstack11l1l1l_opy_ (u"ࠬࡸ࡯ࡣࡱࡷ࠱࡮ࡴࡴࡦࡴࡱࡥࡱ࠭௸"):
      bstack11l1111l_opy_()
    bstack11l1l11l_opy_ = Output.end_test
    bstack1llllll11_opy_ = TestStatus.__init__
    bstack11lllllll_opy_ = pabot._run
    bstack1ll11lllll_opy_ = QueueItem.__init__
    bstack111ll1l11_opy_ = pabot._create_command_for_execution
    bstack1ll1lll1ll_opy_ = pabot._report_results
  if bstack1ll1lll11_opy_ == bstack11l1l1l_opy_ (u"࠭ࡢࡦࡪࡤࡺࡪ࠭௹"):
    try:
      from behave.runner import Runner
      from behave.model import Step
    except Exception as e:
      bstack11l1111l1_opy_(e, bstack1ll1l11ll_opy_)
    bstack1111ll11l_opy_ = Runner.run_hook
    bstack1lll1l1ll1_opy_ = Step.run
  if bstack1ll1lll11_opy_ == bstack11l1l1l_opy_ (u"ࠧࡱࡻࡷࡩࡸࡺࠧ௺"):
    try:
      bstack1llll1ll1l_opy_.launch(CONFIG, {
        bstack11l1l1l_opy_ (u"ࠨࡨࡵࡥࡲ࡫ࡷࡰࡴ࡮ࡣࡳࡧ࡭ࡦࠩ௻"): bstack11l1l1l_opy_ (u"ࠩࡓࡽࡹ࡫ࡳࡵࠩ௼"),
        bstack11l1l1l_opy_ (u"ࠪࡪࡷࡧ࡭ࡦࡹࡲࡶࡰࡥࡶࡦࡴࡶ࡭ࡴࡴࠧ௽"): bstack1lll11l1_opy_.version(),
        bstack11l1l1l_opy_ (u"ࠫࡸࡪ࡫ࡠࡸࡨࡶࡸ࡯࡯࡯ࠩ௾"): __version__
      })
      from _pytest.config import Config
      bstack1lll1ll11_opy_ = Config.getoption
      from _pytest import runner
      bstack1llll111ll_opy_ = runner._update_current_test_var
    except Exception as e:
      logger.warn(e, bstack1l1lll11_opy_)
    try:
      from pytest_bdd import reporting
      bstack1ll1l1111_opy_ = reporting.runtest_makereport
    except Exception as e:
      logger.debug(bstack11l1l1l_opy_ (u"ࠬࡖ࡬ࡦࡣࡶࡩࠥ࡯࡮ࡴࡶࡤࡰࡱࠦࡰࡺࡶࡨࡷࡹ࠳ࡢࡥࡦࠣࡸࡴࠦࡲࡶࡰࠣࡴࡾࡺࡥࡴࡶ࠰ࡦࡩࡪࠠࡵࡧࡶࡸࡸ࠭௿"))
  if bstack1ll1lll11_opy_ == bstack11l1l1l_opy_ (u"࠭ࡰࡺࡶ࡫ࡳࡳ࠭ఀ"):
    bstack11l11l1ll_opy_ = True
    if bstack11111l11_opy_ and bstack1lll11l11_opy_:
      bstack1l1111111_opy_ = CONFIG.get(bstack11l1l1l_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡔࡶࡤࡧࡰࡒ࡯ࡤࡣ࡯ࡓࡵࡺࡩࡰࡰࡶࠫఁ"), {}).get(bstack11l1l1l_opy_ (u"ࠨ࡮ࡲࡧࡦࡲࡉࡥࡧࡱࡸ࡮࡬ࡩࡦࡴࠪం"))
      bstack1ll1llll1_opy_(bstack11ll1ll1_opy_)
    elif bstack11111l11_opy_:
      bstack1l1111111_opy_ = CONFIG.get(bstack11l1l1l_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡖࡸࡦࡩ࡫ࡍࡱࡦࡥࡱࡕࡰࡵ࡫ࡲࡲࡸ࠭ః"), {}).get(bstack11l1l1l_opy_ (u"ࠪࡰࡴࡩࡡ࡭ࡋࡧࡩࡳࡺࡩࡧ࡫ࡨࡶࠬఄ"))
      global bstack1ll1l111l1_opy_
      try:
        if bstack1l1111lll_opy_(bstack11111l11_opy_[bstack11l1l1l_opy_ (u"ࠫ࡫࡯࡬ࡦࡡࡱࡥࡲ࡫ࠧఅ")]) and multiprocessing.current_process().name == bstack11l1l1l_opy_ (u"ࠬ࠶ࠧఆ"):
          bstack11111l11_opy_[bstack11l1l1l_opy_ (u"࠭ࡦࡪ࡮ࡨࡣࡳࡧ࡭ࡦࠩఇ")].remove(bstack11l1l1l_opy_ (u"ࠧ࠮࡯ࠪఈ"))
          bstack11111l11_opy_[bstack11l1l1l_opy_ (u"ࠨࡨ࡬ࡰࡪࡥ࡮ࡢ࡯ࡨࠫఉ")].remove(bstack11l1l1l_opy_ (u"ࠩࡳࡨࡧ࠭ఊ"))
          bstack11111l11_opy_[bstack11l1l1l_opy_ (u"ࠪࡪ࡮ࡲࡥࡠࡰࡤࡱࡪ࠭ఋ")] = bstack11111l11_opy_[bstack11l1l1l_opy_ (u"ࠫ࡫࡯࡬ࡦࡡࡱࡥࡲ࡫ࠧఌ")][0]
          with open(bstack11111l11_opy_[bstack11l1l1l_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡢࡲࡦࡳࡥࠨ఍")], bstack11l1l1l_opy_ (u"࠭ࡲࠨఎ")) as f:
            bstack1lllll11l_opy_ = f.read()
          bstack1ll1ll1111_opy_ = bstack11l1l1l_opy_ (u"ࠢࠣࠤࡩࡶࡴࡳࠠࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡥࡳࡥ࡭ࠣ࡭ࡲࡶ࡯ࡳࡶࠣࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡡ࡬ࡲ࡮ࡺࡩࡢ࡮࡬ࡾࡪࡁࠠࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡥࡩ࡯࡫ࡷ࡭ࡦࡲࡩࡻࡧࠫࡿࢂ࠯࠻ࠡࡨࡵࡳࡲࠦࡰࡥࡤࠣ࡭ࡲࡶ࡯ࡳࡶࠣࡔࡩࡨ࠻ࠡࡱࡪࡣࡩࡨࠠ࠾ࠢࡓࡨࡧ࠴ࡤࡰࡡࡥࡶࡪࡧ࡫࠼ࠌࡧࡩ࡫ࠦ࡭ࡰࡦࡢࡦࡷ࡫ࡡ࡬ࠪࡶࡩࡱ࡬ࠬࠡࡣࡵ࡫࠱ࠦࡴࡦ࡯ࡳࡳࡷࡧࡲࡺࠢࡀࠤ࠵࠯࠺ࠋࠢࠣࡸࡷࡿ࠺ࠋࠢࠣࠤࠥࡧࡲࡨࠢࡀࠤࡸࡺࡲࠩ࡫ࡱࡸ࠭ࡧࡲࡨࠫ࠮࠵࠵࠯ࠊࠡࠢࡨࡼࡨ࡫ࡰࡵࠢࡈࡼࡨ࡫ࡰࡵ࡫ࡲࡲࠥࡧࡳࠡࡧ࠽ࠎࠥࠦࠠࠡࡲࡤࡷࡸࠐࠠࠡࡱࡪࡣࡩࡨࠨࡴࡧ࡯ࡪ࠱ࡧࡲࡨ࠮ࡷࡩࡲࡶ࡯ࡳࡣࡵࡽ࠮ࠐࡐࡥࡤ࠱ࡨࡴࡥࡢࠡ࠿ࠣࡱࡴࡪ࡟ࡣࡴࡨࡥࡰࠐࡐࡥࡤ࠱ࡨࡴࡥࡢࡳࡧࡤ࡯ࠥࡃࠠ࡮ࡱࡧࡣࡧࡸࡥࡢ࡭ࠍࡔࡩࡨࠨࠪ࠰ࡶࡩࡹࡥࡴࡳࡣࡦࡩ࠭࠯࡜࡯ࠤࠥࠦఏ").format(str(bstack11111l11_opy_))
          bstack11llll111_opy_ = bstack1ll1ll1111_opy_ + bstack1lllll11l_opy_
          bstack111l11ll1_opy_ = bstack11111l11_opy_[bstack11l1l1l_opy_ (u"ࠨࡨ࡬ࡰࡪࡥ࡮ࡢ࡯ࡨࠫఐ")] + bstack11l1l1l_opy_ (u"ࠩࡢࡦࡸࡺࡡࡤ࡭ࡢࡸࡪࡳࡰ࠯ࡲࡼࠫ఑")
          with open(bstack111l11ll1_opy_, bstack11l1l1l_opy_ (u"ࠪࡻࠬఒ")):
            pass
          with open(bstack111l11ll1_opy_, bstack11l1l1l_opy_ (u"ࠦࡼ࠱ࠢఓ")) as f:
            f.write(bstack11llll111_opy_)
          import subprocess
          process_data = subprocess.run([bstack11l1l1l_opy_ (u"ࠧࡶࡹࡵࡪࡲࡲࠧఔ"), bstack111l11ll1_opy_])
          if os.path.exists(bstack111l11ll1_opy_):
            os.unlink(bstack111l11ll1_opy_)
          os._exit(process_data.returncode)
        else:
          if bstack1l1111lll_opy_(bstack11111l11_opy_[bstack11l1l1l_opy_ (u"࠭ࡦࡪ࡮ࡨࡣࡳࡧ࡭ࡦࠩక")]):
            bstack11111l11_opy_[bstack11l1l1l_opy_ (u"ࠧࡧ࡫࡯ࡩࡤࡴࡡ࡮ࡧࠪఖ")].remove(bstack11l1l1l_opy_ (u"ࠨ࠯ࡰࠫగ"))
            bstack11111l11_opy_[bstack11l1l1l_opy_ (u"ࠩࡩ࡭ࡱ࡫࡟࡯ࡣࡰࡩࠬఘ")].remove(bstack11l1l1l_opy_ (u"ࠪࡴࡩࡨࠧఙ"))
            bstack11111l11_opy_[bstack11l1l1l_opy_ (u"ࠫ࡫࡯࡬ࡦࡡࡱࡥࡲ࡫ࠧచ")] = bstack11111l11_opy_[bstack11l1l1l_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡢࡲࡦࡳࡥࠨఛ")][0]
          bstack1ll1llll1_opy_(bstack11ll1ll1_opy_)
          sys.path.append(os.path.dirname(os.path.abspath(bstack11111l11_opy_[bstack11l1l1l_opy_ (u"࠭ࡦࡪ࡮ࡨࡣࡳࡧ࡭ࡦࠩజ")])))
          sys.argv = sys.argv[2:]
          mod_globals = globals()
          mod_globals[bstack11l1l1l_opy_ (u"ࠧࡠࡡࡱࡥࡲ࡫࡟ࡠࠩఝ")] = bstack11l1l1l_opy_ (u"ࠨࡡࡢࡱࡦ࡯࡮ࡠࡡࠪఞ")
          mod_globals[bstack11l1l1l_opy_ (u"ࠩࡢࡣ࡫࡯࡬ࡦࡡࡢࠫట")] = os.path.abspath(bstack11111l11_opy_[bstack11l1l1l_opy_ (u"ࠪࡪ࡮ࡲࡥࡠࡰࡤࡱࡪ࠭ఠ")])
          exec(open(bstack11111l11_opy_[bstack11l1l1l_opy_ (u"ࠫ࡫࡯࡬ࡦࡡࡱࡥࡲ࡫ࠧడ")]).read(), mod_globals)
      except BaseException as e:
        try:
          traceback.print_exc()
          logger.error(bstack11l1l1l_opy_ (u"ࠬࡉࡡࡶࡩ࡫ࡸࠥࡋࡸࡤࡧࡳࡸ࡮ࡵ࡮࠻ࠢࡾࢁࠬఢ").format(str(e)))
          for driver in bstack1ll1l111l1_opy_:
            bstack1lllll1l1l_opy_.append({
              bstack11l1l1l_opy_ (u"࠭࡮ࡢ࡯ࡨࠫణ"): bstack11111l11_opy_[bstack11l1l1l_opy_ (u"ࠧࡧ࡫࡯ࡩࡤࡴࡡ࡮ࡧࠪత")],
              bstack11l1l1l_opy_ (u"ࠨࡧࡵࡶࡴࡸࠧథ"): str(e),
              bstack11l1l1l_opy_ (u"ࠩ࡬ࡲࡩ࡫ࡸࠨద"): multiprocessing.current_process().name
            })
            driver.execute_script(
              bstack11l1l1l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡡࡨࡼࡪࡩࡵࡵࡱࡵ࠾ࠥࢁࠢࡢࡥࡷ࡭ࡴࡴࠢ࠻ࠢࠥࡷࡪࡺࡓࡦࡵࡶ࡭ࡴࡴࡓࡵࡣࡷࡹࡸࠨࠬࠡࠤࡤࡶ࡬ࡻ࡭ࡦࡰࡷࡷࠧࡀࠠࡼࠤࡶࡸࡦࡺࡵࡴࠤ࠽ࠦ࡫ࡧࡩ࡭ࡧࡧࠦ࠱ࠦࠢࡳࡧࡤࡷࡴࡴࠢ࠻ࠢࠪధ") + json.dumps(
                bstack11l1l1l_opy_ (u"ࠦࡘ࡫ࡳࡴ࡫ࡲࡲࠥ࡬ࡡࡪ࡮ࡨࡨࠥࡽࡩࡵࡪ࠽ࠤࡡࡴࠢన") + str(e)) + bstack11l1l1l_opy_ (u"ࠬࢃࡽࠨ఩"))
        except Exception:
          pass
      finally:
        try:
          for driver in bstack1ll1l111l1_opy_:
            driver.quit()
        except Exception as e:
          pass
    else:
      bstack111l1l111_opy_()
      bstack11l1l111l_opy_()
      bstack1lll1lll_opy_ = {
        bstack11l1l1l_opy_ (u"࠭ࡦࡪ࡮ࡨࡣࡳࡧ࡭ࡦࠩప"): args[0],
        bstack11l1l1l_opy_ (u"ࠧࡄࡑࡑࡊࡎࡍࠧఫ"): CONFIG,
        bstack11l1l1l_opy_ (u"ࠨࡊࡘࡆࡤ࡛ࡒࡍࠩబ"): bstack1lll1l111_opy_,
        bstack11l1l1l_opy_ (u"ࠩࡌࡗࡤࡇࡐࡑࡡࡄ࡙࡙ࡕࡍࡂࡖࡈࠫభ"): bstack1ll11l11l_opy_
      }
      if bstack11l1l1l_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱࡸ࠭మ") in CONFIG:
        bstack1ll1l1ll_opy_ = []
        manager = multiprocessing.Manager()
        bstack1lllllllll_opy_ = manager.list()
        if bstack1l1111lll_opy_(args):
          for index, platform in enumerate(CONFIG[bstack11l1l1l_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡹࠧయ")]):
            if index == 0:
              bstack1lll1lll_opy_[bstack11l1l1l_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡢࡲࡦࡳࡥࠨర")] = args
            bstack1ll1l1ll_opy_.append(multiprocessing.Process(name=str(index),
                                                       target=run_on_browserstack,
                                                       args=(bstack1lll1lll_opy_, bstack1lllllllll_opy_)))
        else:
          for index, platform in enumerate(CONFIG[bstack11l1l1l_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩఱ")]):
            bstack1ll1l1ll_opy_.append(multiprocessing.Process(name=str(index),
                                                       target=run_on_browserstack,
                                                       args=(bstack1lll1lll_opy_, bstack1lllllllll_opy_)))
        for t in bstack1ll1l1ll_opy_:
          t.start()
        for t in bstack1ll1l1ll_opy_:
          t.join()
        bstack11llllll1_opy_ = list(bstack1lllllllll_opy_)
      else:
        if bstack1l1111lll_opy_(args):
          bstack1lll1lll_opy_[bstack11l1l1l_opy_ (u"ࠧࡧ࡫࡯ࡩࡤࡴࡡ࡮ࡧࠪల")] = args
          test = multiprocessing.Process(name=str(0),
                                         target=run_on_browserstack, args=(bstack1lll1lll_opy_,))
          test.start()
          test.join()
        else:
          bstack1ll1llll1_opy_(bstack11ll1ll1_opy_)
          sys.path.append(os.path.dirname(os.path.abspath(args[0])))
          mod_globals = globals()
          mod_globals[bstack11l1l1l_opy_ (u"ࠨࡡࡢࡲࡦࡳࡥࡠࡡࠪళ")] = bstack11l1l1l_opy_ (u"ࠩࡢࡣࡲࡧࡩ࡯ࡡࡢࠫఴ")
          mod_globals[bstack11l1l1l_opy_ (u"ࠪࡣࡤ࡬ࡩ࡭ࡧࡢࡣࠬవ")] = os.path.abspath(args[0])
          sys.argv = sys.argv[2:]
          exec(open(args[0]).read(), mod_globals)
  elif bstack1ll1lll11_opy_ == bstack11l1l1l_opy_ (u"ࠫࡵࡧࡢࡰࡶࠪశ") or bstack1ll1lll11_opy_ == bstack11l1l1l_opy_ (u"ࠬࡸ࡯ࡣࡱࡷࠫష"):
    try:
      from pabot import pabot
    except Exception as e:
      bstack11l1111l1_opy_(e, bstack11l1l11l1_opy_)
    bstack111l1l111_opy_()
    bstack1ll1llll1_opy_(bstack11ll1111_opy_)
    if bstack11l1l1l_opy_ (u"࠭࠭࠮ࡲࡵࡳࡨ࡫ࡳࡴࡧࡶࠫస") in args:
      i = args.index(bstack11l1l1l_opy_ (u"ࠧ࠮࠯ࡳࡶࡴࡩࡥࡴࡵࡨࡷࠬహ"))
      args.pop(i)
      args.pop(i)
    args.insert(0, str(bstack1111lll1_opy_))
    args.insert(0, str(bstack11l1l1l_opy_ (u"ࠨ࠯࠰ࡴࡷࡵࡣࡦࡵࡶࡩࡸ࠭఺")))
    pabot.main(args)
  elif bstack1ll1lll11_opy_ == bstack11l1l1l_opy_ (u"ࠩࡵࡳࡧࡵࡴ࠮࡫ࡱࡸࡪࡸ࡮ࡢ࡮ࠪ఻"):
    try:
      from robot import run_cli
    except Exception as e:
      bstack11l1111l1_opy_(e, bstack11l1l11l1_opy_)
    for a in args:
      if bstack11l1l1l_opy_ (u"ࠪࡆࡘ࡚ࡁࡄࡍࡓࡐࡆ࡚ࡆࡐࡔࡐࡍࡓࡊࡅ఼࡙ࠩ") in a:
        bstack111111l11_opy_ = int(a.split(bstack11l1l1l_opy_ (u"ࠫ࠿࠭ఽ"))[1])
      if bstack11l1l1l_opy_ (u"ࠬࡈࡓࡕࡃࡆࡏࡉࡋࡆࡍࡑࡆࡅࡑࡏࡄࡆࡐࡗࡍࡋࡏࡅࡓࠩా") in a:
        bstack1l1111111_opy_ = str(a.split(bstack11l1l1l_opy_ (u"࠭࠺ࠨి"))[1])
      if bstack11l1l1l_opy_ (u"ࠧࡃࡕࡗࡅࡈࡑࡃࡍࡋࡄࡖࡌ࡙ࠧీ") in a:
        bstack1ll1l11ll1_opy_ = str(a.split(bstack11l1l1l_opy_ (u"ࠨ࠼ࠪు"))[1])
    bstack1l11lll1_opy_ = None
    if bstack11l1l1l_opy_ (u"ࠩ࠰࠱ࡧࡹࡴࡢࡥ࡮ࡣ࡮ࡺࡥ࡮ࡡ࡬ࡲࡩ࡫ࡸࠨూ") in args:
      i = args.index(bstack11l1l1l_opy_ (u"ࠪ࠱࠲ࡨࡳࡵࡣࡦ࡯ࡤ࡯ࡴࡦ࡯ࡢ࡭ࡳࡪࡥࡹࠩృ"))
      args.pop(i)
      bstack1l11lll1_opy_ = args.pop(i)
    if bstack1l11lll1_opy_ is not None:
      global bstack1l1111ll_opy_
      bstack1l1111ll_opy_ = bstack1l11lll1_opy_
    bstack1ll1llll1_opy_(bstack11ll1111_opy_)
    run_cli(args)
  elif bstack1ll1lll11_opy_ == bstack11l1l1l_opy_ (u"ࠫࡵࡿࡴࡦࡵࡷࠫౄ"):
    bstack1lll11ll1_opy_ = bstack1lll11l1_opy_(args, logger, CONFIG, bstack1lllll11l1_opy_)
    bstack1lll11ll1_opy_.bstack1lll1111_opy_()
    bstack111l1l111_opy_()
    bstack11lll1l1_opy_ = bstack1lll11ll1_opy_.bstack1lll1l1l_opy_()
    bstack1lll11ll1_opy_.bstack1lll1lll_opy_(bstack1lllllll1_opy_)
    bstack11ll1l1l_opy_ = True
    bstack1llll1l1_opy_ = bstack1lll11ll1_opy_.bstack1ll1ll11_opy_()
    bstack1lll11ll1_opy_.bstack1ll11l1l_opy_(bstack1llll1l1_opy_, bstack1ll1llll1_opy_)
  elif bstack1ll1lll11_opy_ == bstack11l1l1l_opy_ (u"ࠬࡨࡥࡩࡣࡹࡩࠬ౅"):
    try:
      from behave.__main__ import main as bstack11111l1ll_opy_
      from behave.configuration import Configuration
    except Exception as e:
      bstack11l1111l1_opy_(e, bstack1ll1l11ll_opy_)
    bstack111l1l111_opy_()
    bstack11ll1l1l_opy_ = True
    bstack1l1ll1l1_opy_ = 1
    if bstack11l1l1l_opy_ (u"࠭ࡰࡢࡴࡤࡰࡱ࡫࡬ࡴࡒࡨࡶࡕࡲࡡࡵࡨࡲࡶࡲ࠭ె") in CONFIG:
      bstack1l1ll1l1_opy_ = CONFIG[bstack11l1l1l_opy_ (u"ࠧࡱࡣࡵࡥࡱࡲࡥ࡭ࡵࡓࡩࡷࡖ࡬ࡢࡶࡩࡳࡷࡳࠧే")]
    bstack1ll1ll1l_opy_ = int(bstack1l1ll1l1_opy_) * int(len(CONFIG[bstack11l1l1l_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠫై")]))
    config = Configuration(args)
    bstack11l11l1l1_opy_ = config.paths
    if len(bstack11l11l1l1_opy_) == 0:
      import glob
      pattern = bstack11l1l1l_opy_ (u"ࠩ࠭࠮࠴࠰࠮ࡧࡧࡤࡸࡺࡸࡥࠨ౉")
      bstack1llll1ll1_opy_ = glob.glob(pattern, recursive=True)
      args.extend(bstack1llll1ll1_opy_)
      config = Configuration(args)
      bstack11l11l1l1_opy_ = config.paths
    bstack1lll11ll_opy_ = [os.path.normpath(item) for item in bstack11l11l1l1_opy_]
    bstack1111lll1l_opy_ = [os.path.normpath(item) for item in args]
    bstack1lll11l1l1_opy_ = [item for item in bstack1111lll1l_opy_ if item not in bstack1lll11ll_opy_]
    import platform as pf
    if pf.system().lower() == bstack11l1l1l_opy_ (u"ࠪࡻ࡮ࡴࡤࡰࡹࡶࠫొ"):
      from pathlib import PureWindowsPath, PurePosixPath
      bstack1lll11ll_opy_ = [str(PurePosixPath(PureWindowsPath(bstack1ll111l1_opy_)))
                    for bstack1ll111l1_opy_ in bstack1lll11ll_opy_]
    bstack1ll11111_opy_ = []
    for spec in bstack1lll11ll_opy_:
      bstack1llll111_opy_ = []
      bstack1llll111_opy_ += bstack1lll11l1l1_opy_
      bstack1llll111_opy_.append(spec)
      bstack1ll11111_opy_.append(bstack1llll111_opy_)
    execution_items = []
    for bstack1llll111_opy_ in bstack1ll11111_opy_:
      for index, _ in enumerate(CONFIG[bstack11l1l1l_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡹࠧో")]):
        item = {}
        item[bstack11l1l1l_opy_ (u"ࠬࡧࡲࡨࠩౌ")] = bstack11l1l1l_opy_ (u"࠭ࠠࠨ్").join(bstack1llll111_opy_)
        item[bstack11l1l1l_opy_ (u"ࠧࡪࡰࡧࡩࡽ࠭౎")] = index
        execution_items.append(item)
    bstack1llll1l1_opy_ = bstack1ll1111l_opy_(execution_items, bstack1ll1ll1l_opy_)
    for execution_item in bstack1llll1l1_opy_:
      bstack1ll1l1ll_opy_ = []
      for item in execution_item:
        bstack1ll1l1ll_opy_.append(bstack1ll1l11l_opy_(name=str(item[bstack11l1l1l_opy_ (u"ࠨ࡫ࡱࡨࡪࡾࠧ౏")]),
                                             target=bstack1l11l1ll1_opy_,
                                             args=(item[bstack11l1l1l_opy_ (u"ࠩࡤࡶ࡬࠭౐")],)))
      for t in bstack1ll1l1ll_opy_:
        t.start()
      for t in bstack1ll1l1ll_opy_:
        t.join()
  else:
    bstack11ll1l1l1_opy_(bstack1l11ll1l_opy_)
  if not bstack11111l11_opy_:
    bstack1ll1ll1ll1_opy_()
def browserstack_initialize(bstack1llll11lll_opy_=None):
  run_on_browserstack(bstack1llll11lll_opy_, None, True)
def bstack1ll1ll1ll1_opy_():
  bstack1llll1ll1l_opy_.stop()
  bstack1llll1ll1l_opy_.bstack11ll1lll1_opy_()
  [bstack11l11l11_opy_, bstack1l1ll1lll_opy_] = bstack1llll1lll1_opy_()
  if bstack11l11l11_opy_ is not None and bstack1llll11111_opy_() != -1:
    sessions = bstack11lll111l_opy_(bstack11l11l11_opy_)
    bstack1ll111l11_opy_(sessions, bstack1l1ll1lll_opy_)
def bstack1l1ll1l1l_opy_(bstack11111ll11_opy_):
  if bstack11111ll11_opy_:
    return bstack11111ll11_opy_.capitalize()
  else:
    return bstack11111ll11_opy_
def bstack11111l111_opy_(bstack111l1llll_opy_):
  if bstack11l1l1l_opy_ (u"ࠪࡲࡦࡳࡥࠨ౑") in bstack111l1llll_opy_ and bstack111l1llll_opy_[bstack11l1l1l_opy_ (u"ࠫࡳࡧ࡭ࡦࠩ౒")] != bstack11l1l1l_opy_ (u"ࠬ࠭౓"):
    return bstack111l1llll_opy_[bstack11l1l1l_opy_ (u"࠭࡮ࡢ࡯ࡨࠫ౔")]
  else:
    bstack11l1l1lll_opy_ = bstack11l1l1l_opy_ (u"ౕࠢࠣ")
    if bstack11l1l1l_opy_ (u"ࠨࡦࡨࡺ࡮ࡩࡥࠨౖ") in bstack111l1llll_opy_ and bstack111l1llll_opy_[bstack11l1l1l_opy_ (u"ࠩࡧࡩࡻ࡯ࡣࡦࠩ౗")] != None:
      bstack11l1l1lll_opy_ += bstack111l1llll_opy_[bstack11l1l1l_opy_ (u"ࠪࡨࡪࡼࡩࡤࡧࠪౘ")] + bstack11l1l1l_opy_ (u"ࠦ࠱ࠦࠢౙ")
      if bstack111l1llll_opy_[bstack11l1l1l_opy_ (u"ࠬࡵࡳࠨౚ")] == bstack11l1l1l_opy_ (u"ࠨࡩࡰࡵࠥ౛"):
        bstack11l1l1lll_opy_ += bstack11l1l1l_opy_ (u"ࠢࡪࡑࡖࠤࠧ౜")
      bstack11l1l1lll_opy_ += (bstack111l1llll_opy_[bstack11l1l1l_opy_ (u"ࠨࡱࡶࡣࡻ࡫ࡲࡴ࡫ࡲࡲࠬౝ")] or bstack11l1l1l_opy_ (u"ࠩࠪ౞"))
      return bstack11l1l1lll_opy_
    else:
      bstack11l1l1lll_opy_ += bstack1l1ll1l1l_opy_(bstack111l1llll_opy_[bstack11l1l1l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࠫ౟")]) + bstack11l1l1l_opy_ (u"ࠦࠥࠨౠ") + (
              bstack111l1llll_opy_[bstack11l1l1l_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡥࡶࡦࡴࡶ࡭ࡴࡴࠧౡ")] or bstack11l1l1l_opy_ (u"࠭ࠧౢ")) + bstack11l1l1l_opy_ (u"ࠢ࠭ࠢࠥౣ")
      if bstack111l1llll_opy_[bstack11l1l1l_opy_ (u"ࠨࡱࡶࠫ౤")] == bstack11l1l1l_opy_ (u"ࠤ࡚࡭ࡳࡪ࡯ࡸࡵࠥ౥"):
        bstack11l1l1lll_opy_ += bstack11l1l1l_opy_ (u"࡛ࠥ࡮ࡴࠠࠣ౦")
      bstack11l1l1lll_opy_ += bstack111l1llll_opy_[bstack11l1l1l_opy_ (u"ࠫࡴࡹ࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࠨ౧")] or bstack11l1l1l_opy_ (u"ࠬ࠭౨")
      return bstack11l1l1lll_opy_
def bstack1ll11lll1_opy_(bstack111ll1lll_opy_):
  if bstack111ll1lll_opy_ == bstack11l1l1l_opy_ (u"ࠨࡤࡰࡰࡨࠦ౩"):
    return bstack11l1l1l_opy_ (u"ࠧ࠽ࡶࡧࠤࡨࡲࡡࡴࡵࡀࠦࡧࡹࡴࡢࡥ࡮࠱ࡩࡧࡴࡢࠤࠣࡷࡹࡿ࡬ࡦ࠿ࠥࡧࡴࡲ࡯ࡳ࠼ࡪࡶࡪ࡫࡮࠼ࠤࡁࡀ࡫ࡵ࡮ࡵࠢࡦࡳࡱࡵࡲ࠾ࠤࡪࡶࡪ࡫࡮ࠣࡀࡆࡳࡲࡶ࡬ࡦࡶࡨࡨࡁ࠵ࡦࡰࡰࡷࡂࡁ࠵ࡴࡥࡀࠪ౪")
  elif bstack111ll1lll_opy_ == bstack11l1l1l_opy_ (u"ࠣࡨࡤ࡭ࡱ࡫ࡤࠣ౫"):
    return bstack11l1l1l_opy_ (u"ࠩ࠿ࡸࡩࠦࡣ࡭ࡣࡶࡷࡂࠨࡢࡴࡶࡤࡧࡰ࠳ࡤࡢࡶࡤࠦࠥࡹࡴࡺ࡮ࡨࡁࠧࡩ࡯࡭ࡱࡵ࠾ࡷ࡫ࡤ࠼ࠤࡁࡀ࡫ࡵ࡮ࡵࠢࡦࡳࡱࡵࡲ࠾ࠤࡵࡩࡩࠨ࠾ࡇࡣ࡬ࡰࡪࡪ࠼࠰ࡨࡲࡲࡹࡄ࠼࠰ࡶࡧࡂࠬ౬")
  elif bstack111ll1lll_opy_ == bstack11l1l1l_opy_ (u"ࠥࡴࡦࡹࡳࡦࡦࠥ౭"):
    return bstack11l1l1l_opy_ (u"ࠫࡁࡺࡤࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡤࡶࡸࡦࡩ࡫࠮ࡦࡤࡸࡦࠨࠠࡴࡶࡼࡰࡪࡃࠢࡤࡱ࡯ࡳࡷࡀࡧࡳࡧࡨࡲࡀࠨ࠾࠽ࡨࡲࡲࡹࠦࡣࡰ࡮ࡲࡶࡂࠨࡧࡳࡧࡨࡲࠧࡄࡐࡢࡵࡶࡩࡩࡂ࠯ࡧࡱࡱࡸࡃࡂ࠯ࡵࡦࡁࠫ౮")
  elif bstack111ll1lll_opy_ == bstack11l1l1l_opy_ (u"ࠧ࡫ࡲࡳࡱࡵࠦ౯"):
    return bstack11l1l1l_opy_ (u"࠭࠼ࡵࡦࠣࡧࡱࡧࡳࡴ࠿ࠥࡦࡸࡺࡡࡤ࡭࠰ࡨࡦࡺࡡࠣࠢࡶࡸࡾࡲࡥ࠾ࠤࡦࡳࡱࡵࡲ࠻ࡴࡨࡨࡀࠨ࠾࠽ࡨࡲࡲࡹࠦࡣࡰ࡮ࡲࡶࡂࠨࡲࡦࡦࠥࡂࡊࡸࡲࡰࡴ࠿࠳࡫ࡵ࡮ࡵࡀ࠿࠳ࡹࡪ࠾ࠨ౰")
  elif bstack111ll1lll_opy_ == bstack11l1l1l_opy_ (u"ࠢࡵ࡫ࡰࡩࡴࡻࡴࠣ౱"):
    return bstack11l1l1l_opy_ (u"ࠨ࠾ࡷࡨࠥࡩ࡬ࡢࡵࡶࡁࠧࡨࡳࡵࡣࡦ࡯࠲ࡪࡡࡵࡣࠥࠤࡸࡺࡹ࡭ࡧࡀࠦࡨࡵ࡬ࡰࡴ࠽ࠧࡪ࡫ࡡ࠴࠴࠹࠿ࠧࡄ࠼ࡧࡱࡱࡸࠥࡩ࡯࡭ࡱࡵࡁࠧࠩࡥࡦࡣ࠶࠶࠻ࠨ࠾ࡕ࡫ࡰࡩࡴࡻࡴ࠽࠱ࡩࡳࡳࡺ࠾࠽࠱ࡷࡨࡃ࠭౲")
  elif bstack111ll1lll_opy_ == bstack11l1l1l_opy_ (u"ࠤࡵࡹࡳࡴࡩ࡯ࡩࠥ౳"):
    return bstack11l1l1l_opy_ (u"ࠪࡀࡹࡪࠠࡤ࡮ࡤࡷࡸࡃࠢࡣࡵࡷࡥࡨࡱ࠭ࡥࡣࡷࡥࠧࠦࡳࡵࡻ࡯ࡩࡂࠨࡣࡰ࡮ࡲࡶ࠿ࡨ࡬ࡢࡥ࡮࠿ࠧࡄ࠼ࡧࡱࡱࡸࠥࡩ࡯࡭ࡱࡵࡁࠧࡨ࡬ࡢࡥ࡮ࠦࡃࡘࡵ࡯ࡰ࡬ࡲ࡬ࡂ࠯ࡧࡱࡱࡸࡃࡂ࠯ࡵࡦࡁࠫ౴")
  else:
    return bstack11l1l1l_opy_ (u"ࠫࡁࡺࡤࠡࡣ࡯࡭࡬ࡴ࠽ࠣࡥࡨࡲࡹ࡫ࡲࠣࠢࡦࡰࡦࡹࡳ࠾ࠤࡥࡷࡹࡧࡣ࡬࠯ࡧࡥࡹࡧࠢࠡࡵࡷࡽࡱ࡫࠽ࠣࡥࡲࡰࡴࡸ࠺ࡣ࡮ࡤࡧࡰࡁࠢ࠿࠾ࡩࡳࡳࡺࠠࡤࡱ࡯ࡳࡷࡃࠢࡣ࡮ࡤࡧࡰࠨ࠾ࠨ౵") + bstack1l1ll1l1l_opy_(
      bstack111ll1lll_opy_) + bstack11l1l1l_opy_ (u"ࠬࡂ࠯ࡧࡱࡱࡸࡃࡂ࠯ࡵࡦࡁࠫ౶")
def bstack111l111ll_opy_(session):
  return bstack11l1l1l_opy_ (u"࠭࠼ࡵࡴࠣࡧࡱࡧࡳࡴ࠿ࠥࡦࡸࡺࡡࡤ࡭࠰ࡶࡴࡽࠢ࠿࠾ࡷࡨࠥࡩ࡬ࡢࡵࡶࡁࠧࡨࡳࡵࡣࡦ࡯࠲ࡪࡡࡵࡣࠣࡷࡪࡹࡳࡪࡱࡱ࠱ࡳࡧ࡭ࡦࠤࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧࢁࡽࠣࠢࡷࡥࡷ࡭ࡥࡵ࠿ࠥࡣࡧࡲࡡ࡯࡭ࠥࡂࢀࢃ࠼࠰ࡣࡁࡀ࠴ࡺࡤ࠿ࡽࢀࡿࢂࡂࡴࡥࠢࡤࡰ࡮࡭࡮࠾ࠤࡦࡩࡳࡺࡥࡳࠤࠣࡧࡱࡧࡳࡴ࠿ࠥࡦࡸࡺࡡࡤ࡭࠰ࡨࡦࡺࡡࠣࡀࡾࢁࡁ࠵ࡴࡥࡀ࠿ࡸࡩࠦࡡ࡭࡫ࡪࡲࡂࠨࡣࡦࡰࡷࡩࡷࠨࠠࡤ࡮ࡤࡷࡸࡃࠢࡣࡵࡷࡥࡨࡱ࠭ࡥࡣࡷࡥࠧࡄࡻࡾ࠾࠲ࡸࡩࡄ࠼ࡵࡦࠣࡥࡱ࡯ࡧ࡯࠿ࠥࡧࡪࡴࡴࡦࡴࠥࠤࡨࡲࡡࡴࡵࡀࠦࡧࡹࡴࡢࡥ࡮࠱ࡩࡧࡴࡢࠤࡁࡿࢂࡂ࠯ࡵࡦࡁࡀࡹࡪࠠࡢ࡮࡬࡫ࡳࡃࠢࡤࡧࡱࡸࡪࡸࠢࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡤࡶࡸࡦࡩ࡫࠮ࡦࡤࡸࡦࠨ࠾ࡼࡿ࠿࠳ࡹࡪ࠾࠽࠱ࡷࡶࡃ࠭౷").format(
    session[bstack11l1l1l_opy_ (u"ࠧࡱࡷࡥࡰ࡮ࡩ࡟ࡶࡴ࡯ࠫ౸")], bstack11111l111_opy_(session), bstack1ll11lll1_opy_(session[bstack11l1l1l_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࡟ࡴࡶࡤࡸࡺࡹࠧ౹")]),
    bstack1ll11lll1_opy_(session[bstack11l1l1l_opy_ (u"ࠩࡶࡸࡦࡺࡵࡴࠩ౺")]),
    bstack1l1ll1l1l_opy_(session[bstack11l1l1l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࠫ౻")] or session[bstack11l1l1l_opy_ (u"ࠫࡩ࡫ࡶࡪࡥࡨࠫ౼")] or bstack11l1l1l_opy_ (u"ࠬ࠭౽")) + bstack11l1l1l_opy_ (u"ࠨࠠࠣ౾") + (session[bstack11l1l1l_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡠࡸࡨࡶࡸ࡯࡯࡯ࠩ౿")] or bstack11l1l1l_opy_ (u"ࠨࠩಀ")),
    session[bstack11l1l1l_opy_ (u"ࠩࡲࡷࠬಁ")] + bstack11l1l1l_opy_ (u"ࠥࠤࠧಂ") + session[bstack11l1l1l_opy_ (u"ࠫࡴࡹ࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࠨಃ")], session[bstack11l1l1l_opy_ (u"ࠬࡪࡵࡳࡣࡷ࡭ࡴࡴࠧ಄")] or bstack11l1l1l_opy_ (u"࠭ࠧಅ"),
    session[bstack11l1l1l_opy_ (u"ࠧࡤࡴࡨࡥࡹ࡫ࡤࡠࡣࡷࠫಆ")] if session[bstack11l1l1l_opy_ (u"ࠨࡥࡵࡩࡦࡺࡥࡥࡡࡤࡸࠬಇ")] else bstack11l1l1l_opy_ (u"ࠩࠪಈ"))
def bstack1ll111l11_opy_(sessions, bstack1l1ll1lll_opy_):
  try:
    bstack1llll1111l_opy_ = bstack11l1l1l_opy_ (u"ࠥࠦಉ")
    if not os.path.exists(bstack11ll11l1_opy_):
      os.mkdir(bstack11ll11l1_opy_)
    with open(os.path.join(os.path.dirname(os.path.realpath(__file__)), bstack11l1l1l_opy_ (u"ࠫࡦࡹࡳࡦࡶࡶ࠳ࡷ࡫ࡰࡰࡴࡷ࠲࡭ࡺ࡭࡭ࠩಊ")), bstack11l1l1l_opy_ (u"ࠬࡸࠧಋ")) as f:
      bstack1llll1111l_opy_ = f.read()
    bstack1llll1111l_opy_ = bstack1llll1111l_opy_.replace(bstack11l1l1l_opy_ (u"࠭ࡻࠦࡔࡈࡗ࡚ࡒࡔࡔࡡࡆࡓ࡚ࡔࡔࠦࡿࠪಌ"), str(len(sessions)))
    bstack1llll1111l_opy_ = bstack1llll1111l_opy_.replace(bstack11l1l1l_opy_ (u"ࠧࡼࠧࡅ࡙ࡎࡒࡄࡠࡗࡕࡐࠪࢃࠧ಍"), bstack1l1ll1lll_opy_)
    bstack1llll1111l_opy_ = bstack1llll1111l_opy_.replace(bstack11l1l1l_opy_ (u"ࠨࡽࠨࡆ࡚ࡏࡌࡅࡡࡑࡅࡒࡋࠥࡾࠩಎ"),
                                              sessions[0].get(bstack11l1l1l_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡠࡰࡤࡱࡪ࠭ಏ")) if sessions[0] else bstack11l1l1l_opy_ (u"ࠪࠫಐ"))
    with open(os.path.join(bstack11ll11l1_opy_, bstack11l1l1l_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭࠰ࡶࡪࡶ࡯ࡳࡶ࠱࡬ࡹࡳ࡬ࠨ಑")), bstack11l1l1l_opy_ (u"ࠬࡽࠧಒ")) as stream:
      stream.write(bstack1llll1111l_opy_.split(bstack11l1l1l_opy_ (u"࠭ࡻࠦࡕࡈࡗࡘࡏࡏࡏࡕࡢࡈࡆ࡚ࡁࠦࡿࠪಓ"))[0])
      for session in sessions:
        stream.write(bstack111l111ll_opy_(session))
      stream.write(bstack1llll1111l_opy_.split(bstack11l1l1l_opy_ (u"ࠧࡼࠧࡖࡉࡘ࡙ࡉࡐࡐࡖࡣࡉࡇࡔࡂࠧࢀࠫಔ"))[1])
    logger.info(bstack11l1l1l_opy_ (u"ࠨࡉࡨࡲࡪࡸࡡࡵࡧࡧࠤࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࠣࡦࡺ࡯࡬ࡥࠢࡤࡶࡹ࡯ࡦࡢࡥࡷࡷࠥࡧࡴࠡࡽࢀࠫಕ").format(bstack11ll11l1_opy_));
  except Exception as e:
    logger.debug(bstack1lllll1111_opy_.format(str(e)))
def bstack11lll111l_opy_(bstack11l11l11_opy_):
  global CONFIG
  try:
    host = bstack11l1l1l_opy_ (u"ࠩࡤࡴ࡮࠳ࡣ࡭ࡱࡸࡨࠬಖ") if bstack11l1l1l_opy_ (u"ࠪࡥࡵࡶࠧಗ") in CONFIG else bstack11l1l1l_opy_ (u"ࠫࡦࡶࡩࠨಘ")
    user = CONFIG[bstack11l1l1l_opy_ (u"ࠬࡻࡳࡦࡴࡑࡥࡲ࡫ࠧಙ")]
    key = CONFIG[bstack11l1l1l_opy_ (u"࠭ࡡࡤࡥࡨࡷࡸࡑࡥࡺࠩಚ")]
    bstack1ll1l1l1l1_opy_ = bstack11l1l1l_opy_ (u"ࠧࡢࡲࡳ࠱ࡦࡻࡴࡰ࡯ࡤࡸࡪ࠭ಛ") if bstack11l1l1l_opy_ (u"ࠨࡣࡳࡴࠬಜ") in CONFIG else bstack11l1l1l_opy_ (u"ࠩࡤࡹࡹࡵ࡭ࡢࡶࡨࠫಝ")
    url = bstack11l1l1l_opy_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࢀࢃ࠺ࡼࡿࡃࡿࢂ࠴ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯࠳ࡩ࡯࡮࠱ࡾࢁ࠴ࡨࡵࡪ࡮ࡧࡷ࠴ࢁࡽ࠰ࡵࡨࡷࡸ࡯࡯࡯ࡵ࠱࡮ࡸࡵ࡮ࠨಞ").format(user, key, host, bstack1ll1l1l1l1_opy_,
                                                                                bstack11l11l11_opy_)
    headers = {
      bstack11l1l1l_opy_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲ࡺࡹࡱࡧࠪಟ"): bstack11l1l1l_opy_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲࡮ࡸࡵ࡮ࠨಠ"),
    }
    proxies = bstack1111l1lll_opy_(CONFIG, url)
    response = requests.get(url, headers=headers, proxies=proxies)
    if response.json():
      return list(map(lambda session: session[bstack11l1l1l_opy_ (u"࠭ࡡࡶࡶࡲࡱࡦࡺࡩࡰࡰࡢࡷࡪࡹࡳࡪࡱࡱࠫಡ")], response.json()))
  except Exception as e:
    logger.debug(bstack1111ll111_opy_.format(str(e)))
def bstack1llll1lll1_opy_():
  global CONFIG
  try:
    if bstack11l1l1l_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡔࡡ࡮ࡧࠪಢ") in CONFIG:
      host = bstack11l1l1l_opy_ (u"ࠨࡣࡳ࡭࠲ࡩ࡬ࡰࡷࡧࠫಣ") if bstack11l1l1l_opy_ (u"ࠩࡤࡴࡵ࠭ತ") in CONFIG else bstack11l1l1l_opy_ (u"ࠪࡥࡵ࡯ࠧಥ")
      user = CONFIG[bstack11l1l1l_opy_ (u"ࠫࡺࡹࡥࡳࡐࡤࡱࡪ࠭ದ")]
      key = CONFIG[bstack11l1l1l_opy_ (u"ࠬࡧࡣࡤࡧࡶࡷࡐ࡫ࡹࠨಧ")]
      bstack1ll1l1l1l1_opy_ = bstack11l1l1l_opy_ (u"࠭ࡡࡱࡲ࠰ࡥࡺࡺ࡯࡮ࡣࡷࡩࠬನ") if bstack11l1l1l_opy_ (u"ࠧࡢࡲࡳࠫ಩") in CONFIG else bstack11l1l1l_opy_ (u"ࠨࡣࡸࡸࡴࡳࡡࡵࡧࠪಪ")
      url = bstack11l1l1l_opy_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡿࢂࡀࡻࡾࡂࡾࢁ࠳ࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮࠲ࡨࡵ࡭࠰ࡽࢀ࠳ࡧࡻࡩ࡭ࡦࡶ࠲࡯ࡹ࡯࡯ࠩಫ").format(user, key, host, bstack1ll1l1l1l1_opy_)
      headers = {
        bstack11l1l1l_opy_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱ࡹࡿࡰࡦࠩಬ"): bstack11l1l1l_opy_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱࡭ࡷࡴࡴࠧಭ"),
      }
      if bstack11l1l1l_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡍࡩ࡫࡮ࡵ࡫ࡩ࡭ࡪࡸࠧಮ") in CONFIG:
        params = {bstack11l1l1l_opy_ (u"࠭࡮ࡢ࡯ࡨࠫಯ"): CONFIG[bstack11l1l1l_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡔࡡ࡮ࡧࠪರ")], bstack11l1l1l_opy_ (u"ࠨࡤࡸ࡭ࡱࡪ࡟ࡪࡦࡨࡲࡹ࡯ࡦࡪࡧࡵࠫಱ"): CONFIG[bstack11l1l1l_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡊࡦࡨࡲࡹ࡯ࡦࡪࡧࡵࠫಲ")]}
      else:
        params = {bstack11l1l1l_opy_ (u"ࠪࡲࡦࡳࡥࠨಳ"): CONFIG[bstack11l1l1l_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡑࡥࡲ࡫ࠧ಴")]}
      proxies = bstack1111l1lll_opy_(CONFIG, url)
      response = requests.get(url, params=params, headers=headers, proxies=proxies)
      if response.json():
        bstack1111lll11_opy_ = response.json()[0][bstack11l1l1l_opy_ (u"ࠬࡧࡵࡵࡱࡰࡥࡹ࡯࡯࡯ࡡࡥࡹ࡮ࡲࡤࠨವ")]
        if bstack1111lll11_opy_:
          bstack1l1ll1lll_opy_ = bstack1111lll11_opy_[bstack11l1l1l_opy_ (u"࠭ࡰࡶࡤ࡯࡭ࡨࡥࡵࡳ࡮ࠪಶ")].split(bstack11l1l1l_opy_ (u"ࠧࡱࡷࡥࡰ࡮ࡩ࠭ࡣࡷ࡬ࡰࡩ࠭ಷ"))[0] + bstack11l1l1l_opy_ (u"ࠨࡤࡸ࡭ࡱࡪࡳ࠰ࠩಸ") + bstack1111lll11_opy_[
            bstack11l1l1l_opy_ (u"ࠩ࡫ࡥࡸ࡮ࡥࡥࡡ࡬ࡨࠬಹ")]
          logger.info(bstack1l11111ll_opy_.format(bstack1l1ll1lll_opy_))
          bstack111ll11l_opy_ = CONFIG[bstack11l1l1l_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡐࡤࡱࡪ࠭಺")]
          if bstack11l1l1l_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡌࡨࡪࡴࡴࡪࡨ࡬ࡩࡷ࠭಻") in CONFIG:
            bstack111ll11l_opy_ += bstack11l1l1l_opy_ (u"಼ࠬࠦࠧ") + CONFIG[bstack11l1l1l_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡎࡪࡥ࡯ࡶ࡬ࡪ࡮࡫ࡲࠨಽ")]
          if bstack111ll11l_opy_ != bstack1111lll11_opy_[bstack11l1l1l_opy_ (u"ࠧ࡯ࡣࡰࡩࠬಾ")]:
            logger.debug(bstack11l11ll11_opy_.format(bstack1111lll11_opy_[bstack11l1l1l_opy_ (u"ࠨࡰࡤࡱࡪ࠭ಿ")], bstack111ll11l_opy_))
          return [bstack1111lll11_opy_[bstack11l1l1l_opy_ (u"ࠩ࡫ࡥࡸ࡮ࡥࡥࡡ࡬ࡨࠬೀ")], bstack1l1ll1lll_opy_]
    else:
      logger.warn(bstack1ll1l1l1l_opy_)
  except Exception as e:
    logger.debug(bstack1l11l1l1_opy_.format(str(e)))
  return [None, None]
def bstack1ll11ll1l_opy_(url, bstack11l1l1l1_opy_=False):
  global CONFIG
  global bstack1l11l11l_opy_
  if not bstack1l11l11l_opy_:
    hostname = bstack1l1l1ll1_opy_(url)
    is_private = bstack1llll1l11l_opy_(hostname)
    if (bstack11l1l1l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡎࡲࡧࡦࡲࠧು") in CONFIG and not CONFIG[bstack11l1l1l_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡏࡳࡨࡧ࡬ࠨೂ")]) and (is_private or bstack11l1l1l1_opy_):
      bstack1l11l11l_opy_ = hostname
def bstack1l1l1ll1_opy_(url):
  return urlparse(url).hostname
def bstack1llll1l11l_opy_(hostname):
  for bstack1111ll11_opy_ in bstack1l11l11l1_opy_:
    regex = re.compile(bstack1111ll11_opy_)
    if regex.match(hostname):
      return True
  return False
def bstack11lll111_opy_(key_name):
  return True if key_name in threading.current_thread().__dict__.keys() else False