# coding: UTF-8
import sys
bstack1111l1l_opy_ = sys.version_info [0] == 2
bstack1l111l_opy_ = 2048
bstack1lllll1l_opy_ = 7
def bstack11l1l1l_opy_ (bstack111l1l_opy_):
    global bstack1ll111_opy_
    bstack1111111_opy_ = ord (bstack111l1l_opy_ [-1])
    bstack1l1111_opy_ = bstack111l1l_opy_ [:-1]
    bstack1lll111_opy_ = bstack1111111_opy_ % len (bstack1l1111_opy_)
    bstack11ll1l_opy_ = bstack1l1111_opy_ [:bstack1lll111_opy_] + bstack1l1111_opy_ [bstack1lll111_opy_:]
    if bstack1111l1l_opy_:
        bstack11111l1_opy_ = unicode () .join ([unichr (ord (char) - bstack1l111l_opy_ - (bstack1l1lll_opy_ + bstack1111111_opy_) % bstack1lllll1l_opy_) for bstack1l1lll_opy_, char in enumerate (bstack11ll1l_opy_)])
    else:
        bstack11111l1_opy_ = str () .join ([chr (ord (char) - bstack1l111l_opy_ - (bstack1l1lll_opy_ + bstack1111111_opy_) % bstack1lllll1l_opy_) for bstack1l1lll_opy_, char in enumerate (bstack11ll1l_opy_)])
    return eval (bstack11111l1_opy_)
import os
from browserstack_sdk.bstack1ll11l11_opy_ import *
from bstack_utils.helper import bstack1ll1111l_opy_
from bstack_utils.messages import bstack1l1lll11_opy_
from bstack_utils.constants import bstack1l1ll1ll_opy_
class bstack1lll11l1_opy_:
    def __init__(self, args, logger, bstack1llll1ll_opy_, bstack1lll1ll1_opy_):
        self.args = args
        self.logger = logger
        self.bstack1llll1ll_opy_ = bstack1llll1ll_opy_
        self.bstack1lll1ll1_opy_ = bstack1lll1ll1_opy_
        self._prepareconfig = None
        self.Config = None
        self.runner = None
        self.bstack1lll11ll_opy_ = []
        self.bstack1l1lll1l_opy_ = None
        self.bstack1ll11111_opy_ = []
        self.bstack1ll1l111_opy_ = self.bstack1lll1l1l_opy_()
    def start(self):
        self.bstack1lll1111_opy_()
        self.parse_args()
        self.bstack1lll1l11_opy_()
    def bstack1lll1lll_opy_(self, bstack1lll111l_opy_):
        self.parse_args()
        self.bstack1lll1l11_opy_()
        self.bstack1l1l1lll_opy_(bstack1lll111l_opy_)
        self.bstack1l1ll11l_opy_()
    @staticmethod
    def version():
        import pytest
        return pytest.__version__
    def bstack1ll1lll1_opy_(self, arg):
        if arg in self.args:
            i = self.args.index(arg)
            self.args.pop(i + 1)
            self.args.pop(i)
    def parse_args(self):
        try:
            bstack1l1ll111_opy_ = [bstack11l1l1l_opy_ (u"ࠩ࠰࠱ࡦࡸࡧࡴࠩࡵ"), bstack11l1l1l_opy_ (u"ࠪ࠱࠲ࡪࡲࡪࡸࡨࡶࠬࡶ"), bstack11l1l1l_opy_ (u"ࠫ࠲࠳ࡰ࡭ࡷࡪ࡭ࡳࡹࠧࡷ"), bstack11l1l1l_opy_ (u"ࠬ࠳ࡰࠨࡸ"), bstack11l1l1l_opy_ (u"࠭࠭࠮ࡰࡸࡱࡵࡸ࡯ࡤࡧࡶࡷࡪࡹࠧࡹ"), bstack11l1l1l_opy_ (u"ࠧ࠮ࡰࠪࡺ")]
            for arg in bstack1l1ll111_opy_:
                self.bstack1ll1lll1_opy_(arg)
        except Exception as exc:
            self.logger.error(str(exc))
    def bstack1lllll11_opy_(self, bstack1lll11ll_opy_):
        try:
            if os.environ.get(bstack11l1l1l_opy_ (u"ࠣࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡓࡇࡕ࡙ࡓࠨࡻ"), None) == bstack11l1l1l_opy_ (u"ࠤࡷࡶࡺ࡫ࠢࡼ"):
                tests = os.environ.get(bstack11l1l1l_opy_ (u"ࠥࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡕࡉࡗ࡛ࡎࡠࡖࡈࡗ࡙࡙ࠢࡽ"), None)
                if bstack11l1l1l_opy_ (u"ࠦࡷ࡫ࡲࡶࡰࡗࡩࡸࡺࡳࠣࡾ") in self.bstack1llll1ll_opy_:
                    del self.bstack1llll1ll_opy_[bstack11l1l1l_opy_ (u"ࠧࡸࡥࡳࡷࡱࡘࡪࡹࡴࡴࠤࡿ")]
                if tests is None or tests == bstack11l1l1l_opy_ (u"ࠨ࡮ࡶ࡮࡯ࠦࢀ"):
                    return bstack1lll11ll_opy_
                bstack1lll11ll_opy_ = tests.split(bstack11l1l1l_opy_ (u"ࠧ࠭ࠩࢁ"))
                return bstack1lll11ll_opy_
        except Exception as exc:
            self.logger.error(str(exc))
        return bstack1lll11ll_opy_
    def get_args(self):
        return self.args
    def bstack1lll1l11_opy_(self):
        config = self._prepareconfig(self.args)
        bstack1lll11ll_opy_ = config.args
        bstack1llll11l_opy_ = config.invocation_params.args
        bstack1llll11l_opy_ = list(bstack1llll11l_opy_)
        bstack1l1llll1_opy_ = [os.path.normpath(item) for item in bstack1lll11ll_opy_]
        bstack1ll1l1l1_opy_ = [os.path.normpath(item) for item in bstack1llll11l_opy_]
        bstack1l1lll1l_opy_ = [item for item in bstack1ll1l1l1_opy_ if item not in bstack1l1llll1_opy_]
        import platform as pf
        if pf.system().lower() == bstack11l1l1l_opy_ (u"ࠨࡹ࡬ࡲࡩࡵࡷࡴࠩࢂ"):
            from pathlib import PureWindowsPath, PurePosixPath
            bstack1lll11ll_opy_ = [str(PurePosixPath(PureWindowsPath(bstack1ll111l1_opy_)))
                          for bstack1ll111l1_opy_ in bstack1lll11ll_opy_]
        bstack1lll11ll_opy_ = self.bstack1lllll11_opy_(bstack1lll11ll_opy_)
        self.bstack1lll11ll_opy_ = bstack1lll11ll_opy_
        self.bstack1l1lll1l_opy_ = bstack1l1lll1l_opy_
        return bstack1l1lll1l_opy_
    def bstack1lll1111_opy_(self):
        try:
            from _pytest.config import _prepareconfig
            from _pytest.config import Config
            from _pytest import runner
            import importlib
            bstack1ll111ll_opy_ = importlib.find_loader(bstack11l1l1l_opy_ (u"ࠩࡳࡽࡹ࡫ࡳࡵࡡࡶࡩࡱ࡫࡮ࡪࡷࡰࠫࢃ"))
            self._prepareconfig = _prepareconfig
            self.Config = Config
            self.runner = runner
        except Exception as e:
            self.logger.warn(e, bstack1l1lll11_opy_)
    def bstack1l1l1lll_opy_(self, bstack1lll111l_opy_):
        if bstack11l1l1l_opy_ (u"ࠪ࠱࠲ࡩࡡࡤࡪࡨ࠱ࡨࡲࡥࡢࡴࠪࢄ") not in self.bstack1l1lll1l_opy_:
            self.bstack1l1lll1l_opy_.append(bstack11l1l1l_opy_ (u"ࠫ࠲࠳ࡣࡢࡥ࡫ࡩ࠲ࡩ࡬ࡦࡣࡵࠫࢅ"))
        if bstack1lll111l_opy_:
            self.bstack1l1lll1l_opy_.append(bstack11l1l1l_opy_ (u"ࠬ࠳࠭ࡴ࡭࡬ࡴࡘ࡫ࡳࡴ࡫ࡲࡲࡓࡧ࡭ࡦࠩࢆ"))
            self.bstack1l1lll1l_opy_.append(bstack11l1l1l_opy_ (u"࠭ࡔࡳࡷࡨࠫࢇ"))
        if not self.bstack1ll1l111_opy_:
            self.bstack1l1lll1l_opy_.append(bstack11l1l1l_opy_ (u"ࠧ࠮ࡲࠪ࢈"))
            self.bstack1l1lll1l_opy_.append(bstack11l1l1l_opy_ (u"ࠨࡲࡼࡸࡪࡹࡴࡠࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࡰ࡭ࡷࡪ࡭ࡳ࠭ࢉ"))
        self.bstack1l1lll1l_opy_.append(bstack11l1l1l_opy_ (u"ࠩ࠰࠱ࡩࡸࡩࡷࡧࡵࠫࢊ"))
        self.bstack1l1lll1l_opy_.append(bstack11l1l1l_opy_ (u"ࠪࡧ࡭ࡸ࡯࡮ࡧࠪࢋ"))
    def bstack1l1ll11l_opy_(self):
        bstack1ll11111_opy_ = []
        for spec in self.bstack1lll11ll_opy_:
            bstack1llll111_opy_ = [spec]
            bstack1llll111_opy_ += self.bstack1l1lll1l_opy_
            bstack1ll11111_opy_.append(bstack1llll111_opy_)
        self.bstack1ll11111_opy_ = bstack1ll11111_opy_
        return bstack1ll11111_opy_
    def bstack1lll1l1l_opy_(self):
        try:
            from pytest_bdd import reporting
            self.bstack1ll1l111_opy_ = True
            return True
        except Exception as e:
            self.bstack1ll1l111_opy_ = False
        return self.bstack1ll1l111_opy_
    def bstack1ll1ll11_opy_(self):
        bstack1l1ll1l1_opy_ = 1
        if bstack11l1l1l_opy_ (u"ࠫࡵࡧࡲࡢ࡮࡯ࡩࡱࡹࡐࡦࡴࡓࡰࡦࡺࡦࡰࡴࡰࠫࢌ") in self.bstack1llll1ll_opy_:
            bstack1l1ll1l1_opy_ = self.bstack1llll1ll_opy_[bstack11l1l1l_opy_ (u"ࠬࡶࡡࡳࡣ࡯ࡰࡪࡲࡳࡑࡧࡵࡔࡱࡧࡴࡧࡱࡵࡱࠬࢍ")]
        bstack1ll1ll1l_opy_ = int(bstack1l1ll1l1_opy_) * int(len(self.bstack1llll1ll_opy_[bstack11l1l1l_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩࢎ")]))
        execution_items = []
        for bstack1llll111_opy_ in self.bstack1ll11111_opy_:
            for index, _ in enumerate(self.bstack1llll1ll_opy_[bstack11l1l1l_opy_ (u"ࠧࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡵࠪ࢏")]):
                item = {}
                item[bstack11l1l1l_opy_ (u"ࠨࡣࡵ࡫ࠬ࢐")] = bstack1llll111_opy_
                item[bstack11l1l1l_opy_ (u"ࠩ࡬ࡲࡩ࡫ࡸࠨ࢑")] = index
                execution_items.append(item)
        bstack1llll1l1_opy_ = bstack1ll1111l_opy_(execution_items, bstack1ll1ll1l_opy_)
        return bstack1llll1l1_opy_
    def bstack1ll11l1l_opy_(self, bstack1llll1l1_opy_, bstack1ll1llll_opy_):
        for execution_item in bstack1llll1l1_opy_:
            bstack1ll1l1ll_opy_ = []
            for item in execution_item:
                bstack1ll1l1ll_opy_.append(bstack1ll1l11l_opy_(name=str(item[bstack11l1l1l_opy_ (u"ࠪ࡭ࡳࡪࡥࡹࠩ࢒")]),
                                                     target=self.bstack1ll11lll_opy_,
                                                     args=(item[bstack11l1l1l_opy_ (u"ࠫࡦࡸࡧࠨ࢓")], bstack1ll1llll_opy_)))
            for t in bstack1ll1l1ll_opy_:
                t.start()
            for t in bstack1ll1l1ll_opy_:
                t.join()
    def bstack1ll11lll_opy_(self, arg, bstack1ll1llll_opy_):
        arg.append(bstack11l1l1l_opy_ (u"ࠧ࠳࠭ࡪ࡯ࡳࡳࡷࡺ࠭࡮ࡱࡧࡩࡂ࡯࡭ࡱࡱࡵࡸࡱ࡯ࡢࠣ࢔"))
        arg.append(bstack11l1l1l_opy_ (u"ࠨ࠭ࡘࠤ࢕"))
        arg.append(bstack11l1l1l_opy_ (u"ࠢࡪࡩࡱࡳࡷ࡫࠺ࡎࡱࡧࡹࡱ࡫ࠠࡢ࡮ࡵࡩࡦࡪࡹࠡ࡫ࡰࡴࡴࡸࡴࡦࡦ࠽ࡴࡾࡺࡥࡴࡶ࠱ࡔࡾࡺࡥࡴࡶ࡚ࡥࡷࡴࡩ࡯ࡩࠥ࢖"))
        arg.append(bstack11l1l1l_opy_ (u"ࠣ࠯࡚ࠦࢗ"))
        arg.append(bstack11l1l1l_opy_ (u"ࠤ࡬࡫ࡳࡵࡲࡦ࠼ࡗ࡬ࡪࠦࡨࡰࡱ࡮࡭ࡲࡶ࡬ࠣ࢘"))
        bstack1ll1llll_opy_(bstack1l1ll1ll_opy_)
        if self.bstack1lll1ll1_opy_:
            os.environ[bstack11l1l1l_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡘࡗࡊࡘࡎࡂࡏࡈ࢙ࠫ")] = self.bstack1llll1ll_opy_[bstack11l1l1l_opy_ (u"ࠫࡺࡹࡥࡳࡐࡤࡱࡪ࢚࠭")]
            os.environ[bstack11l1l1l_opy_ (u"ࠬࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣࡆࡉࡃࡆࡕࡖࡣࡐࡋ࡙ࠨ࢛")] = self.bstack1llll1ll_opy_[bstack11l1l1l_opy_ (u"࠭ࡡࡤࡥࡨࡷࡸࡑࡥࡺࠩ࢜")]
        os.environ[bstack11l1l1l_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡁࡖࡖࡒࡑࡆ࡚ࡉࡐࡐࠪ࢝")] = self.bstack1lll1ll1_opy_.__str__()
        from _pytest.config import main as bstack1l1lllll_opy_
        bstack1l1lllll_opy_(arg)