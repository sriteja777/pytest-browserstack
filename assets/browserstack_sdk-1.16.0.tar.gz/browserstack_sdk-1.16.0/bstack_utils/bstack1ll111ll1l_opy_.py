# coding: UTF-8
import sys
bstack1111l1l_opy_ = sys.version_info [0] == 2
bstack1l111l_opy_ = 2048
bstack1lllll1l_opy_ = 7
def bstack11l1l1l_opy_ (bstack111l1l_opy_):
    global bstack1ll111_opy_
    bstack1111111_opy_ = ord (bstack111l1l_opy_ [-1])
    bstack1l1111_opy_ = bstack111l1l_opy_ [:-1]
    bstack1lll111_opy_ = bstack1111111_opy_ % len (bstack1l1111_opy_)
    bstack11ll1l_opy_ = bstack1l1111_opy_ [:bstack1lll111_opy_] + bstack1l1111_opy_ [bstack1lll111_opy_:]
    if bstack1111l1l_opy_:
        bstack11111l1_opy_ = unicode () .join ([unichr (ord (char) - bstack1l111l_opy_ - (bstack1l1lll_opy_ + bstack1111111_opy_) % bstack1lllll1l_opy_) for bstack1l1lll_opy_, char in enumerate (bstack11ll1l_opy_)])
    else:
        bstack11111l1_opy_ = str () .join ([chr (ord (char) - bstack1l111l_opy_ - (bstack1l1lll_opy_ + bstack1111111_opy_) % bstack1lllll1l_opy_) for bstack1l1lll_opy_, char in enumerate (bstack11ll1l_opy_)])
    return eval (bstack11111l1_opy_)
class bstack1ll111l1ll_opy_:
    def __init__(self, handler):
        self._1ll111l111_opy_ = None
        self.handler = handler
        self._1ll111ll11_opy_ = self.bstack1ll111l11l_opy_()
        self.patch()
    def patch(self):
        self._1ll111l111_opy_ = self._1ll111ll11_opy_.execute
        self._1ll111ll11_opy_.execute = self.bstack1ll111l1l1_opy_()
    def bstack1ll111l1l1_opy_(self):
        def execute(this, driver_command, *args, **kwargs):
            response = self._1ll111l111_opy_(this, driver_command, *args, **kwargs)
            self.handler(driver_command, response)
            return response
        return execute
    def reset(self):
        self._1ll111ll11_opy_.execute = self._1ll111l111_opy_
    @staticmethod
    def bstack1ll111l11l_opy_():
        from selenium.webdriver.remote.webdriver import WebDriver
        return WebDriver