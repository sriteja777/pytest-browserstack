# coding: UTF-8
import sys
bstack1111l1l_opy_ = sys.version_info [0] == 2
bstack1l111l_opy_ = 2048
bstack1lllll1l_opy_ = 7
def bstack11l1l1l_opy_ (bstack111l1l_opy_):
    global bstack1ll111_opy_
    bstack1111111_opy_ = ord (bstack111l1l_opy_ [-1])
    bstack1l1111_opy_ = bstack111l1l_opy_ [:-1]
    bstack1lll111_opy_ = bstack1111111_opy_ % len (bstack1l1111_opy_)
    bstack11ll1l_opy_ = bstack1l1111_opy_ [:bstack1lll111_opy_] + bstack1l1111_opy_ [bstack1lll111_opy_:]
    if bstack1111l1l_opy_:
        bstack11111l1_opy_ = unicode () .join ([unichr (ord (char) - bstack1l111l_opy_ - (bstack1l1lll_opy_ + bstack1111111_opy_) % bstack1lllll1l_opy_) for bstack1l1lll_opy_, char in enumerate (bstack11ll1l_opy_)])
    else:
        bstack11111l1_opy_ = str () .join ([chr (ord (char) - bstack1l111l_opy_ - (bstack1l1lll_opy_ + bstack1111111_opy_) % bstack1lllll1l_opy_) for bstack1l1lll_opy_, char in enumerate (bstack11ll1l_opy_)])
    return eval (bstack11111l1_opy_)
import datetime
import os
import re
import subprocess
import git
import requests
from bstack_utils.config import Config
from bstack_utils.constants import bstack1ll111llll_opy_
from bstack_utils.proxy import bstack1111l1lll_opy_
bstack111111ll_opy_ = Config.get_instance()
def bstack1l1l1llll1_opy_(config):
    return config[bstack11l1l1l_opy_ (u"ࠩࡸࡷࡪࡸࡎࡢ࡯ࡨࠫ࿗")]
def bstack1ll111111l_opy_(config):
    return config[bstack11l1l1l_opy_ (u"ࠪࡥࡨࡩࡥࡴࡵࡎࡩࡾ࠭࿘")]
def bstack1l1l1111ll_opy_(obj):
    values = []
    bstack1l1l11l1l1_opy_ = re.compile(bstack11l1l1l_opy_ (u"ࡶࠧࡤࡃࡖࡕࡗࡓࡒࡥࡔࡂࡉࡢࡠࡩ࠱ࠤࠣ࿙"), re.I)
    for key in obj.keys():
        if bstack1l1l11l1l1_opy_.match(key):
            values.append(obj[key])
    return values
def bstack1ll1111111_opy_(config):
    tags = []
    tag = config.get(bstack11l1l1l_opy_ (u"ࠧࡩࡵࡴࡶࡲࡱ࡙ࡧࡧࠣ࿚")) or os.environ.get(bstack11l1l1l_opy_ (u"ࠨࡃࡖࡕࡗࡓࡒࡥࡔࡂࡉࠥ࿛"))
    if tag:
        tags.append(tag)
    tags.extend(bstack1l1l1111ll_opy_(os.environ))
    tags.extend(bstack1l1l1111ll_opy_(config))
    return tags
def bstack1l1l111111_opy_(markers):
    tags = []
    for marker in markers:
        tags.append(marker.name)
    return tags
def bstack1l11lllll1_opy_(bstack1l1l1111l1_opy_):
    if not bstack1l1l1111l1_opy_:
        return bstack11l1l1l_opy_ (u"ࠧࠨ࿜")
    return bstack11l1l1l_opy_ (u"ࠣࡽࢀࠤ࠭ࢁࡽࠪࠤ࿝").format(bstack1l1l1111l1_opy_.name, bstack1l1l1111l1_opy_.email)
def bstack1l1ll1l11l_opy_():
    try:
        repo = git.Repo(search_parent_directories=True)
        bstack1l1l11l111_opy_ = repo.common_dir
        info = {
            bstack11l1l1l_opy_ (u"ࠤࡶ࡬ࡦࠨ࿞"): repo.head.commit.hexsha,
            bstack11l1l1l_opy_ (u"ࠥࡷ࡭ࡵࡲࡵࡡࡶ࡬ࡦࠨ࿟"): repo.git.rev_parse(repo.head.commit, short=True),
            bstack11l1l1l_opy_ (u"ࠦࡧࡸࡡ࡯ࡥ࡫ࠦ࿠"): repo.active_branch.name,
            bstack11l1l1l_opy_ (u"ࠧࡺࡡࡨࠤ࿡"): repo.git.describe(all=True, tags=True, exact_match=True),
            bstack11l1l1l_opy_ (u"ࠨࡣࡰ࡯ࡰ࡭ࡹࡺࡥࡳࠤ࿢"): bstack1l11lllll1_opy_(repo.head.commit.committer),
            bstack11l1l1l_opy_ (u"ࠢࡤࡱࡰࡱ࡮ࡺࡴࡦࡴࡢࡨࡦࡺࡥࠣ࿣"): repo.head.commit.committed_datetime.isoformat(),
            bstack11l1l1l_opy_ (u"ࠣࡣࡸࡸ࡭ࡵࡲࠣ࿤"): bstack1l11lllll1_opy_(repo.head.commit.author),
            bstack11l1l1l_opy_ (u"ࠤࡤࡹࡹ࡮࡯ࡳࡡࡧࡥࡹ࡫ࠢ࿥"): repo.head.commit.authored_datetime.isoformat(),
            bstack11l1l1l_opy_ (u"ࠥࡧࡴࡳ࡭ࡪࡶࡢࡱࡪࡹࡳࡢࡩࡨࠦ࿦"): repo.head.commit.message,
            bstack11l1l1l_opy_ (u"ࠦࡷࡵ࡯ࡵࠤ࿧"): repo.git.rev_parse(bstack11l1l1l_opy_ (u"ࠧ࠳࠭ࡴࡪࡲࡻ࠲ࡺ࡯ࡱ࡮ࡨࡺࡪࡲࠢ࿨")),
            bstack11l1l1l_opy_ (u"ࠨࡣࡰ࡯ࡰࡳࡳࡥࡧࡪࡶࡢࡨ࡮ࡸࠢ࿩"): bstack1l1l11l111_opy_,
            bstack11l1l1l_opy_ (u"ࠢࡸࡱࡵ࡯ࡹࡸࡥࡦࡡࡪ࡭ࡹࡥࡤࡪࡴࠥ࿪"): subprocess.check_output([bstack11l1l1l_opy_ (u"ࠣࡩ࡬ࡸࠧ࿫"), bstack11l1l1l_opy_ (u"ࠤࡵࡩࡻ࠳ࡰࡢࡴࡶࡩࠧ࿬"), bstack11l1l1l_opy_ (u"ࠥ࠱࠲࡭ࡩࡵ࠯ࡦࡳࡲࡳ࡯࡯࠯ࡧ࡭ࡷࠨ࿭")]).strip().decode(
                bstack11l1l1l_opy_ (u"ࠫࡺࡺࡦ࠮࠺ࠪ࿮")),
            bstack11l1l1l_opy_ (u"ࠧࡲࡡࡴࡶࡢࡸࡦ࡭ࠢ࿯"): repo.git.describe(tags=True, abbrev=0, always=True),
            bstack11l1l1l_opy_ (u"ࠨࡣࡰ࡯ࡰ࡭ࡹࡹ࡟ࡴ࡫ࡱࡧࡪࡥ࡬ࡢࡵࡷࡣࡹࡧࡧࠣ࿰"): repo.git.rev_list(
                bstack11l1l1l_opy_ (u"ࠢࡼࡿ࠱࠲ࢀࢃࠢ࿱").format(repo.head.commit, repo.git.describe(tags=True, abbrev=0, always=True)), count=True)
        }
        remotes = repo.remotes
        bstack1l1l11l1ll_opy_ = []
        for remote in remotes:
            bstack1l11llll1l_opy_ = {
                bstack11l1l1l_opy_ (u"ࠣࡰࡤࡱࡪࠨ࿲"): remote.name,
                bstack11l1l1l_opy_ (u"ࠤࡸࡶࡱࠨ࿳"): remote.url,
            }
            bstack1l1l11l1ll_opy_.append(bstack1l11llll1l_opy_)
        return {
            bstack11l1l1l_opy_ (u"ࠥࡲࡦࡳࡥࠣ࿴"): bstack11l1l1l_opy_ (u"ࠦ࡬࡯ࡴࠣ࿵"),
            **info,
            bstack11l1l1l_opy_ (u"ࠧࡸࡥ࡮ࡱࡷࡩࡸࠨ࿶"): bstack1l1l11l1ll_opy_
        }
    except Exception as err:
        print(bstack11l1l1l_opy_ (u"ࠨࡅࡹࡥࡨࡴࡹ࡯࡯࡯ࠢ࡬ࡲࠥࡶ࡯ࡱࡷ࡯ࡥࡹ࡯࡮ࡨࠢࡊ࡭ࡹࠦ࡭ࡦࡶࡤࡨࡦࡺࡡࠡࡹ࡬ࡸ࡭ࠦࡥࡳࡴࡲࡶ࠿ࠦࡻࡾࠤ࿷").format(err))
        return {}
def bstack1l1lll1lll_opy_():
    env = os.environ
    if (bstack11l1l1l_opy_ (u"ࠢࡋࡇࡑࡏࡎࡔࡓࡠࡗࡕࡐࠧ࿸") in env and len(env[bstack11l1l1l_opy_ (u"ࠣࡌࡈࡒࡐࡏࡎࡔࡡࡘࡖࡑࠨ࿹")]) > 0) or (
            bstack11l1l1l_opy_ (u"ࠤࡍࡉࡓࡑࡉࡏࡕࡢࡌࡔࡓࡅࠣ࿺") in env and len(env[bstack11l1l1l_opy_ (u"ࠥࡎࡊࡔࡋࡊࡐࡖࡣࡍࡕࡍࡆࠤ࿻")]) > 0):
        return {
            bstack11l1l1l_opy_ (u"ࠦࡳࡧ࡭ࡦࠤ࿼"): bstack11l1l1l_opy_ (u"ࠧࡐࡥ࡯࡭࡬ࡲࡸࠨ࿽"),
            bstack11l1l1l_opy_ (u"ࠨࡢࡶ࡫࡯ࡨࡤࡻࡲ࡭ࠤ࿾"): env.get(bstack11l1l1l_opy_ (u"ࠢࡃࡗࡌࡐࡉࡥࡕࡓࡎࠥ࿿")),
            bstack11l1l1l_opy_ (u"ࠣ࡬ࡲࡦࡤࡴࡡ࡮ࡧࠥက"): env.get(bstack11l1l1l_opy_ (u"ࠤࡍࡓࡇࡥࡎࡂࡏࡈࠦခ")),
            bstack11l1l1l_opy_ (u"ࠥࡦࡺ࡯࡬ࡥࡡࡱࡹࡲࡨࡥࡳࠤဂ"): env.get(bstack11l1l1l_opy_ (u"ࠦࡇ࡛ࡉࡍࡆࡢࡒ࡚ࡓࡂࡆࡔࠥဃ"))
        }
    if env.get(bstack11l1l1l_opy_ (u"ࠧࡉࡉࠣင")) == bstack11l1l1l_opy_ (u"ࠨࡴࡳࡷࡨࠦစ") and env.get(bstack11l1l1l_opy_ (u"ࠢࡄࡋࡕࡇࡑࡋࡃࡊࠤဆ")) == bstack11l1l1l_opy_ (u"ࠣࡶࡵࡹࡪࠨဇ"):
        return {
            bstack11l1l1l_opy_ (u"ࠤࡱࡥࡲ࡫ࠢဈ"): bstack11l1l1l_opy_ (u"ࠥࡇ࡮ࡸࡣ࡭ࡧࡆࡍࠧဉ"),
            bstack11l1l1l_opy_ (u"ࠦࡧࡻࡩ࡭ࡦࡢࡹࡷࡲࠢည"): env.get(bstack11l1l1l_opy_ (u"ࠧࡉࡉࡓࡅࡏࡉࡤࡈࡕࡊࡎࡇࡣ࡚ࡘࡌࠣဋ")),
            bstack11l1l1l_opy_ (u"ࠨࡪࡰࡤࡢࡲࡦࡳࡥࠣဌ"): env.get(bstack11l1l1l_opy_ (u"ࠢࡄࡋࡕࡇࡑࡋ࡟ࡋࡑࡅࠦဍ")),
            bstack11l1l1l_opy_ (u"ࠣࡤࡸ࡭ࡱࡪ࡟࡯ࡷࡰࡦࡪࡸࠢဎ"): env.get(bstack11l1l1l_opy_ (u"ࠤࡆࡍࡗࡉࡌࡆࡡࡅ࡙ࡎࡒࡄࡠࡐࡘࡑࠧဏ"))
        }
    if env.get(bstack11l1l1l_opy_ (u"ࠥࡇࡎࠨတ")) == bstack11l1l1l_opy_ (u"ࠦࡹࡸࡵࡦࠤထ") and env.get(bstack11l1l1l_opy_ (u"࡚ࠧࡒࡂࡘࡌࡗࠧဒ")) == bstack11l1l1l_opy_ (u"ࠨࡴࡳࡷࡨࠦဓ"):
        return {
            bstack11l1l1l_opy_ (u"ࠢ࡯ࡣࡰࡩࠧန"): bstack11l1l1l_opy_ (u"ࠣࡖࡵࡥࡻ࡯ࡳࠡࡅࡌࠦပ"),
            bstack11l1l1l_opy_ (u"ࠤࡥࡹ࡮ࡲࡤࡠࡷࡵࡰࠧဖ"): env.get(bstack11l1l1l_opy_ (u"ࠥࡘࡗࡇࡖࡊࡕࡢࡆ࡚ࡏࡌࡅࡡ࡚ࡉࡇࡥࡕࡓࡎࠥဗ")),
            bstack11l1l1l_opy_ (u"ࠦ࡯ࡵࡢࡠࡰࡤࡱࡪࠨဘ"): env.get(bstack11l1l1l_opy_ (u"࡚ࠧࡒࡂࡘࡌࡗࡤࡐࡏࡃࡡࡑࡅࡒࡋࠢမ")),
            bstack11l1l1l_opy_ (u"ࠨࡢࡶ࡫࡯ࡨࡤࡴࡵ࡮ࡤࡨࡶࠧယ"): env.get(bstack11l1l1l_opy_ (u"ࠢࡕࡔࡄ࡚ࡎ࡙࡟ࡃࡗࡌࡐࡉࡥࡎࡖࡏࡅࡉࡗࠨရ"))
        }
    if env.get(bstack11l1l1l_opy_ (u"ࠣࡅࡌࠦလ")) == bstack11l1l1l_opy_ (u"ࠤࡷࡶࡺ࡫ࠢဝ") and env.get(bstack11l1l1l_opy_ (u"ࠥࡇࡎࡥࡎࡂࡏࡈࠦသ")) == bstack11l1l1l_opy_ (u"ࠦࡨࡵࡤࡦࡵ࡫࡭ࡵࠨဟ"):
        return {
            bstack11l1l1l_opy_ (u"ࠧࡴࡡ࡮ࡧࠥဠ"): bstack11l1l1l_opy_ (u"ࠨࡃࡰࡦࡨࡷ࡭࡯ࡰࠣအ"),
            bstack11l1l1l_opy_ (u"ࠢࡣࡷ࡬ࡰࡩࡥࡵࡳ࡮ࠥဢ"): None,
            bstack11l1l1l_opy_ (u"ࠣ࡬ࡲࡦࡤࡴࡡ࡮ࡧࠥဣ"): None,
            bstack11l1l1l_opy_ (u"ࠤࡥࡹ࡮ࡲࡤࡠࡰࡸࡱࡧ࡫ࡲࠣဤ"): None
        }
    if env.get(bstack11l1l1l_opy_ (u"ࠥࡆࡎ࡚ࡂࡖࡅࡎࡉ࡙ࡥࡂࡓࡃࡑࡇࡍࠨဥ")) and env.get(bstack11l1l1l_opy_ (u"ࠦࡇࡏࡔࡃࡗࡆࡏࡊ࡚࡟ࡄࡑࡐࡑࡎ࡚ࠢဦ")):
        return {
            bstack11l1l1l_opy_ (u"ࠧࡴࡡ࡮ࡧࠥဧ"): bstack11l1l1l_opy_ (u"ࠨࡂࡪࡶࡥࡹࡨࡱࡥࡵࠤဨ"),
            bstack11l1l1l_opy_ (u"ࠢࡣࡷ࡬ࡰࡩࡥࡵࡳ࡮ࠥဩ"): env.get(bstack11l1l1l_opy_ (u"ࠣࡄࡌࡘࡇ࡛ࡃࡌࡇࡗࡣࡌࡏࡔࡠࡊࡗࡘࡕࡥࡏࡓࡋࡊࡍࡓࠨဪ")),
            bstack11l1l1l_opy_ (u"ࠤ࡭ࡳࡧࡥ࡮ࡢ࡯ࡨࠦါ"): None,
            bstack11l1l1l_opy_ (u"ࠥࡦࡺ࡯࡬ࡥࡡࡱࡹࡲࡨࡥࡳࠤာ"): env.get(bstack11l1l1l_opy_ (u"ࠦࡇࡏࡔࡃࡗࡆࡏࡊ࡚࡟ࡃࡗࡌࡐࡉࡥࡎࡖࡏࡅࡉࡗࠨိ"))
        }
    if env.get(bstack11l1l1l_opy_ (u"ࠧࡉࡉࠣီ")) == bstack11l1l1l_opy_ (u"ࠨࡴࡳࡷࡨࠦု") and env.get(bstack11l1l1l_opy_ (u"ࠢࡅࡔࡒࡒࡊࠨူ")) == bstack11l1l1l_opy_ (u"ࠣࡶࡵࡹࡪࠨေ"):
        return {
            bstack11l1l1l_opy_ (u"ࠤࡱࡥࡲ࡫ࠢဲ"): bstack11l1l1l_opy_ (u"ࠥࡈࡷࡵ࡮ࡦࠤဳ"),
            bstack11l1l1l_opy_ (u"ࠦࡧࡻࡩ࡭ࡦࡢࡹࡷࡲࠢဴ"): env.get(bstack11l1l1l_opy_ (u"ࠧࡊࡒࡐࡐࡈࡣࡇ࡛ࡉࡍࡆࡢࡐࡎࡔࡋࠣဵ")),
            bstack11l1l1l_opy_ (u"ࠨࡪࡰࡤࡢࡲࡦࡳࡥࠣံ"): None,
            bstack11l1l1l_opy_ (u"ࠢࡣࡷ࡬ࡰࡩࡥ࡮ࡶ࡯ࡥࡩࡷࠨ့"): env.get(bstack11l1l1l_opy_ (u"ࠣࡆࡕࡓࡓࡋ࡟ࡃࡗࡌࡐࡉࡥࡎࡖࡏࡅࡉࡗࠨး"))
        }
    if env.get(bstack11l1l1l_opy_ (u"ࠤࡆࡍ္ࠧ")) == bstack11l1l1l_opy_ (u"ࠥࡸࡷࡻࡥ်ࠣ") and env.get(bstack11l1l1l_opy_ (u"ࠦࡘࡋࡍࡂࡒࡋࡓࡗࡋࠢျ")) == bstack11l1l1l_opy_ (u"ࠧࡺࡲࡶࡧࠥြ"):
        return {
            bstack11l1l1l_opy_ (u"ࠨ࡮ࡢ࡯ࡨࠦွ"): bstack11l1l1l_opy_ (u"ࠢࡔࡧࡰࡥࡵ࡮࡯ࡳࡧࠥှ"),
            bstack11l1l1l_opy_ (u"ࠣࡤࡸ࡭ࡱࡪ࡟ࡶࡴ࡯ࠦဿ"): env.get(bstack11l1l1l_opy_ (u"ࠤࡖࡉࡒࡇࡐࡉࡑࡕࡉࡤࡕࡒࡈࡃࡑࡍ࡟ࡇࡔࡊࡑࡑࡣ࡚ࡘࡌࠣ၀")),
            bstack11l1l1l_opy_ (u"ࠥ࡮ࡴࡨ࡟࡯ࡣࡰࡩࠧ၁"): env.get(bstack11l1l1l_opy_ (u"ࠦࡘࡋࡍࡂࡒࡋࡓࡗࡋ࡟ࡋࡑࡅࡣࡓࡇࡍࡆࠤ၂")),
            bstack11l1l1l_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡳࡻ࡭ࡣࡧࡵࠦ၃"): env.get(bstack11l1l1l_opy_ (u"ࠨࡓࡆࡏࡄࡔࡍࡕࡒࡆࡡࡍࡓࡇࡥࡉࡅࠤ၄"))
        }
    if env.get(bstack11l1l1l_opy_ (u"ࠢࡄࡋࠥ၅")) == bstack11l1l1l_opy_ (u"ࠣࡶࡵࡹࡪࠨ၆") and env.get(bstack11l1l1l_opy_ (u"ࠤࡊࡍ࡙ࡒࡁࡃࡡࡆࡍࠧ၇")) == bstack11l1l1l_opy_ (u"ࠥࡸࡷࡻࡥࠣ၈"):
        return {
            bstack11l1l1l_opy_ (u"ࠦࡳࡧ࡭ࡦࠤ၉"): bstack11l1l1l_opy_ (u"ࠧࡍࡩࡵࡎࡤࡦࠧ၊"),
            bstack11l1l1l_opy_ (u"ࠨࡢࡶ࡫࡯ࡨࡤࡻࡲ࡭ࠤ။"): env.get(bstack11l1l1l_opy_ (u"ࠢࡄࡋࡢࡎࡔࡈ࡟ࡖࡔࡏࠦ၌")),
            bstack11l1l1l_opy_ (u"ࠣ࡬ࡲࡦࡤࡴࡡ࡮ࡧࠥ၍"): env.get(bstack11l1l1l_opy_ (u"ࠤࡆࡍࡤࡐࡏࡃࡡࡑࡅࡒࡋࠢ၎")),
            bstack11l1l1l_opy_ (u"ࠥࡦࡺ࡯࡬ࡥࡡࡱࡹࡲࡨࡥࡳࠤ၏"): env.get(bstack11l1l1l_opy_ (u"ࠦࡈࡏ࡟ࡋࡑࡅࡣࡎࡊࠢၐ"))
        }
    if env.get(bstack11l1l1l_opy_ (u"ࠧࡉࡉࠣၑ")) == bstack11l1l1l_opy_ (u"ࠨࡴࡳࡷࡨࠦၒ") and env.get(bstack11l1l1l_opy_ (u"ࠢࡃࡗࡌࡐࡉࡑࡉࡕࡇࠥၓ")) == bstack11l1l1l_opy_ (u"ࠣࡶࡵࡹࡪࠨၔ"):
        return {
            bstack11l1l1l_opy_ (u"ࠤࡱࡥࡲ࡫ࠢၕ"): bstack11l1l1l_opy_ (u"ࠥࡆࡺ࡯࡬ࡥ࡭࡬ࡸࡪࠨၖ"),
            bstack11l1l1l_opy_ (u"ࠦࡧࡻࡩ࡭ࡦࡢࡹࡷࡲࠢၗ"): env.get(bstack11l1l1l_opy_ (u"ࠧࡈࡕࡊࡎࡇࡏࡎ࡚ࡅࡠࡄࡘࡍࡑࡊ࡟ࡖࡔࡏࠦၘ")),
            bstack11l1l1l_opy_ (u"ࠨࡪࡰࡤࡢࡲࡦࡳࡥࠣၙ"): env.get(bstack11l1l1l_opy_ (u"ࠢࡃࡗࡌࡐࡉࡑࡉࡕࡇࡢࡐࡆࡈࡅࡍࠤၚ")) or env.get(bstack11l1l1l_opy_ (u"ࠣࡄࡘࡍࡑࡊࡋࡊࡖࡈࡣࡕࡏࡐࡆࡎࡌࡒࡊࡥࡎࡂࡏࡈࠦၛ")),
            bstack11l1l1l_opy_ (u"ࠤࡥࡹ࡮ࡲࡤࡠࡰࡸࡱࡧ࡫ࡲࠣၜ"): env.get(bstack11l1l1l_opy_ (u"ࠥࡆ࡚ࡏࡌࡅࡍࡌࡘࡊࡥࡂࡖࡋࡏࡈࡤࡔࡕࡎࡄࡈࡖࠧၝ"))
        }
    if env.get(bstack11l1l1l_opy_ (u"࡙ࠦࡌ࡟ࡃࡗࡌࡐࡉࠨၞ")) == bstack11l1l1l_opy_ (u"࡚ࠧࡲࡶࡧࠥၟ"):
        return {
            bstack11l1l1l_opy_ (u"ࠨ࡮ࡢ࡯ࡨࠦၠ"): bstack11l1l1l_opy_ (u"ࠢࡗ࡫ࡶࡹࡦࡲࠠࡔࡶࡸࡨ࡮ࡵࠠࡕࡧࡤࡱ࡙ࠥࡥࡳࡸ࡬ࡧࡪࡹࠢၡ"),
            bstack11l1l1l_opy_ (u"ࠣࡤࡸ࡭ࡱࡪ࡟ࡶࡴ࡯ࠦၢ"): bstack1l1l1lllll_opy_ (u"ࠤࡾࡩࡳࡼ࠮ࡨࡧࡷ࡙࡙ࠬࠬࡔࡖࡈࡑࡤ࡚ࡅࡂࡏࡉࡓ࡚ࡔࡄࡂࡖࡌࡓࡓ࡙ࡅࡓࡘࡈࡖ࡚ࡘࡉࠨࠫࢀࡿࡪࡴࡶ࠯ࡩࡨࡸ࠭࠭ࡓ࡚ࡕࡗࡉࡒࡥࡔࡆࡃࡐࡔࡗࡕࡊࡆࡅࡗࡍࡉ࠭ࠩࡾࠤၣ"),
            bstack11l1l1l_opy_ (u"ࠥ࡮ࡴࡨ࡟࡯ࡣࡰࡩࠧၤ"): env.get(bstack11l1l1l_opy_ (u"ࠦࡘ࡟ࡓࡕࡇࡐࡣࡉࡋࡆࡊࡐࡌࡘࡎࡕࡎࡊࡆࠥၥ")),
            bstack11l1l1l_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡳࡻ࡭ࡣࡧࡵࠦၦ"): env.get(bstack11l1l1l_opy_ (u"ࠨࡂࡖࡋࡏࡈࡤࡈࡕࡊࡎࡇࡍࡉࠨၧ"))
        }
    return {bstack11l1l1l_opy_ (u"ࠢࡣࡷ࡬ࡰࡩࡥ࡮ࡶ࡯ࡥࡩࡷࠨၨ"): None}
def get_host_info():
    uname = os.uname()
    return {
        bstack11l1l1l_opy_ (u"ࠣࡪࡲࡷࡹࡴࡡ࡮ࡧࠥၩ"): uname.nodename,
        bstack11l1l1l_opy_ (u"ࠤࡳࡰࡦࡺࡦࡰࡴࡰࠦၪ"): uname.sysname,
        bstack11l1l1l_opy_ (u"ࠥࡸࡾࡶࡥࠣၫ"): uname.machine,
        bstack11l1l1l_opy_ (u"ࠦࡻ࡫ࡲࡴ࡫ࡲࡲࠧၬ"): uname.version,
        bstack11l1l1l_opy_ (u"ࠧࡧࡲࡤࡪࠥၭ"): uname.machine
    }
def bstack1l11llllll_opy_():
    try:
        import selenium
        return True
    except ImportError:
        return False
def bstack1ll11111l1_opy_():
    if bstack111111ll_opy_.get_property(bstack11l1l1l_opy_ (u"࠭ࡢࡴࡶࡤࡧࡰࡥࡳࡦࡵࡶ࡭ࡴࡴࠧၮ")):
        return bstack11l1l1l_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠭ၯ")
    return bstack11l1l1l_opy_ (u"ࠨࡷࡱ࡯ࡳࡵࡷ࡯ࡡࡪࡶ࡮ࡪࠧၰ")
def bstack1l1llll11l_opy_(driver):
    info = {
        bstack11l1l1l_opy_ (u"ࠩࡦࡥࡵࡧࡢࡪ࡮࡬ࡸ࡮࡫ࡳࠨၱ"): driver.capabilities,
        bstack11l1l1l_opy_ (u"ࠪࡷࡪࡹࡳࡪࡱࡱࡣ࡮ࡪࠧၲ"): driver.session_id,
        bstack11l1l1l_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࠬၳ"): driver.capabilities[bstack11l1l1l_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡔࡡ࡮ࡧࠪၴ")],
        bstack11l1l1l_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸ࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࠨၵ"): driver.capabilities[bstack11l1l1l_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡗࡧࡵࡷ࡮ࡵ࡮ࠨၶ")],
        bstack11l1l1l_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࠪၷ"): driver.capabilities[bstack11l1l1l_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࡒࡦࡳࡥࠨၸ")],
    }
    if bstack1ll11111l1_opy_() == bstack11l1l1l_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࠩၹ"):
        info[bstack11l1l1l_opy_ (u"ࠫࡵࡸ࡯ࡥࡷࡦࡸࠬၺ")] = bstack11l1l1l_opy_ (u"ࠬࡧࡰࡱ࠯ࡤࡹࡹࡵ࡭ࡢࡶࡨࠫၻ") if bstack111111ll_opy_.get_property(bstack11l1l1l_opy_ (u"࠭ࡡࡱࡲࡢࡥࡺࡺ࡯࡮ࡣࡷࡩࠬၼ")) else bstack11l1l1l_opy_ (u"ࠧࡢࡷࡷࡳࡲࡧࡴࡦࠩၽ")
    return info
def bstack11llll11l_opy_(bstack1l1l11ll11_opy_, url, data, config):
    headers = config[bstack11l1l1l_opy_ (u"ࠨࡪࡨࡥࡩ࡫ࡲࡴࠩၾ")]
    proxies = bstack1111l1lll_opy_(config, url)
    auth = config.get(bstack11l1l1l_opy_ (u"ࠩࡤࡹࡹ࡮ࠧၿ"), None)
    response = requests.request(
        bstack1l1l11ll11_opy_,
        url=url,
        headers=headers,
        auth=auth,
        json=data,
        proxies=proxies
    )
    return response
def bstack1ll1111l_opy_(bstack1ll11l111_opy_, size):
    bstack1l11lll1l_opy_ = []
    while len(bstack1ll11l111_opy_) > size:
        bstack1l1l111l_opy_ = bstack1ll11l111_opy_[:size]
        bstack1l11lll1l_opy_.append(bstack1l1l111l_opy_)
        bstack1ll11l111_opy_ = bstack1ll11l111_opy_[size:]
    bstack1l11lll1l_opy_.append(bstack1ll11l111_opy_)
    return bstack1l11lll1l_opy_
def bstack1l1lll1l1l_opy_(message):
    os.write(1, bytes(message, bstack11l1l1l_opy_ (u"ࠪࡹࡹ࡬࠭࠹ࠩႀ")))
    os.write(1, bytes(bstack11l1l1l_opy_ (u"ࠫࡡࡴࠧႁ"), bstack11l1l1l_opy_ (u"ࠬࡻࡴࡧ࠯࠻ࠫႂ")))
def bstack1l1l111l1l_opy_():
    return os.environ[bstack11l1l1l_opy_ (u"࠭ࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤࡇࡕࡕࡑࡐࡅ࡙ࡏࡏࡏࠩႃ")].lower() == bstack11l1l1l_opy_ (u"ࠧࡵࡴࡸࡩࠬႄ")
def bstack1llll111l1_opy_(bstack1l1lll11ll_opy_):
    return bstack1l1l1lllll_opy_ (u"ࠨࡽࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡃࡓࡍࡤ࡛ࡒࡍࡿ࠲ࡿࡪࡴࡤࡱࡱ࡬ࡲࡹࢃࠧႅ")
def bstack11llll1ll_opy_():
    return datetime.datetime.utcnow().isoformat() + bstack11l1l1l_opy_ (u"ࠩ࡝ࠫႆ")
def bstack1l1l111ll1_opy_(outcome):
    _, exception, _ = outcome.excinfo or (None, None, None)
    if exception:
        return bstack11l1l1l_opy_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪႇ")
    else:
        return bstack11l1l1l_opy_ (u"ࠫࡵࡧࡳࡴࡧࡧࠫႈ")
def bstack1l1llllll1_opy_(val):
    return val.__str__().lower() == bstack11l1l1l_opy_ (u"ࠬࡺࡲࡶࡧࠪႉ")
def bstack1l1l11111l_opy_(val):
    return val.__str__().lower() == bstack11l1l1l_opy_ (u"࠭ࡦࡢ࡮ࡶࡩࠬႊ")
def bstack1ll1111lll_opy_(bstack1l1l111lll_opy_=Exception, bstack1l1lllll11_opy_=False, default_value=None):
    def decorator(func):
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except bstack1l1l111lll_opy_ as e:
                print(bstack11l1l1l_opy_ (u"ࠢࡆࡺࡦࡩࡵࡺࡩࡰࡰࠣ࡭ࡳࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠡࡽࢀࠤ࠲ࡄࠠࡼࡿ࠽ࠤࢀࢃࠢႋ").format(func.__name__, bstack1l1l111lll_opy_.__name__, str(e)))
                return default_value
        return wrapper
    def bstack1l1l11l11l_opy_(bstack1l1l111l11_opy_):
        def wrapped(cls, *args, **kwargs):
            try:
                return bstack1l1l111l11_opy_(cls, *args, **kwargs)
            except bstack1l1l111lll_opy_ as e:
                print(bstack11l1l1l_opy_ (u"ࠣࡇࡻࡧࡪࡶࡴࡪࡱࡱࠤ࡮ࡴࠠࡧࡷࡱࡧࡹ࡯࡯࡯ࠢࡾࢁࠥ࠳࠾ࠡࡽࢀ࠾ࠥࢁࡽࠣႌ").format(bstack1l1l111l11_opy_.__name__, bstack1l1l111lll_opy_.__name__, str(e)))
                return default_value
        return wrapped
    if bstack1l1lllll11_opy_:
        return bstack1l1l11l11l_opy_
    else:
        return decorator
def bstack1ll1ll111l_opy_(bstack1llll1ll_opy_):
    if bstack11l1l1l_opy_ (u"ࠩࡤࡹࡹࡵ࡭ࡢࡶ࡬ࡳࡳႍ࠭") in bstack1llll1ll_opy_ and bstack1l1l11111l_opy_(bstack1llll1ll_opy_[bstack11l1l1l_opy_ (u"ࠪࡥࡺࡺ࡯࡮ࡣࡷ࡭ࡴࡴࠧႎ")]):
        return False
    if bstack11l1l1l_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡄࡹࡹࡵ࡭ࡢࡶ࡬ࡳࡳ࠭ႏ") in bstack1llll1ll_opy_ and bstack1l1l11111l_opy_(bstack1llll1ll_opy_[bstack11l1l1l_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡅࡺࡺ࡯࡮ࡣࡷ࡭ࡴࡴࠧ႐")]):
        return False
    return True