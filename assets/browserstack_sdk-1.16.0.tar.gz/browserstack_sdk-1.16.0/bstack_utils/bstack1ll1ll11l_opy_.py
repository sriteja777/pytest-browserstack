# coding: UTF-8
import sys
bstack1111l1l_opy_ = sys.version_info [0] == 2
bstack1l111l_opy_ = 2048
bstack1lllll1l_opy_ = 7
def bstack11l1l1l_opy_ (bstack111l1l_opy_):
    global bstack1ll111_opy_
    bstack1111111_opy_ = ord (bstack111l1l_opy_ [-1])
    bstack1l1111_opy_ = bstack111l1l_opy_ [:-1]
    bstack1lll111_opy_ = bstack1111111_opy_ % len (bstack1l1111_opy_)
    bstack11ll1l_opy_ = bstack1l1111_opy_ [:bstack1lll111_opy_] + bstack1l1111_opy_ [bstack1lll111_opy_:]
    if bstack1111l1l_opy_:
        bstack11111l1_opy_ = unicode () .join ([unichr (ord (char) - bstack1l111l_opy_ - (bstack1l1lll_opy_ + bstack1111111_opy_) % bstack1lllll1l_opy_) for bstack1l1lll_opy_, char in enumerate (bstack11ll1l_opy_)])
    else:
        bstack11111l1_opy_ = str () .join ([chr (ord (char) - bstack1l111l_opy_ - (bstack1l1lll_opy_ + bstack1111111_opy_) % bstack1lllll1l_opy_) for bstack1l1lll_opy_, char in enumerate (bstack11ll1l_opy_)])
    return eval (bstack11111l1_opy_)
import datetime
import json
import logging
import os
import threading
from bstack_utils.helper import bstack1l1ll1l11l_opy_, bstack1l1lll1lll_opy_, get_host_info, bstack1l1l1llll1_opy_, bstack1ll111111l_opy_, bstack1ll1111111_opy_, \
    bstack1l1llll11l_opy_, bstack1ll11111l1_opy_, bstack11llll11l_opy_, bstack1l1lll1l1l_opy_, bstack1l1llllll1_opy_, bstack1ll1111lll_opy_
from bstack_utils.bstack1l1ll11lll_opy_ import bstack1l1lll1l11_opy_
bstack1l1ll1ll11_opy_ = [
    bstack11l1l1l_opy_ (u"࠭ࡌࡰࡩࡆࡶࡪࡧࡴࡦࡦࠪ༗"), bstack11l1l1l_opy_ (u"ࠧࡄࡄࡗࡗࡪࡹࡳࡪࡱࡱࡇࡷ࡫ࡡࡵࡧࡧ༘ࠫ"), bstack11l1l1l_opy_ (u"ࠨࡖࡨࡷࡹࡘࡵ࡯ࡈ࡬ࡲ࡮ࡹࡨࡦࡦ༙ࠪ"), bstack11l1l1l_opy_ (u"ࠩࡗࡩࡸࡺࡒࡶࡰࡖ࡯࡮ࡶࡰࡦࡦࠪ༚"),
    bstack11l1l1l_opy_ (u"ࠪࡌࡴࡵ࡫ࡓࡷࡱࡊ࡮ࡴࡩࡴࡪࡨࡨࠬ༛"), bstack11l1l1l_opy_ (u"࡙ࠫ࡫ࡳࡵࡔࡸࡲࡘࡺࡡࡳࡶࡨࡨࠬ༜"), bstack11l1l1l_opy_ (u"ࠬࡎ࡯ࡰ࡭ࡕࡹࡳ࡙ࡴࡢࡴࡷࡩࡩ࠭༝")
]
bstack1l1ll11ll1_opy_ = bstack11l1l1l_opy_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡤࡱ࡯ࡰࡪࡩࡴࡰࡴ࠰ࡳࡧࡹࡥࡳࡸࡤࡦ࡮ࡲࡩࡵࡻ࠱ࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬࠰ࡦࡳࡲ࠭༞")
logger = logging.getLogger(__name__)
class bstack1llll1ll1l_opy_:
    bstack1l1ll11lll_opy_ = None
    bs_config = None
    @classmethod
    @bstack1ll1111lll_opy_(bstack1l1lllll11_opy_=True)
    def launch(cls, bs_config, bstack1l1ll1l1ll_opy_):
        cls.bs_config = bs_config
        if not cls.bstack1l1ll1111l_opy_():
            return
        cls.bstack1l1ll11lll_opy_ = bstack1l1lll1l11_opy_(cls.bstack1ll11111ll_opy_)
        cls.bstack1l1ll11lll_opy_.start()
        bstack1l1ll1l1l1_opy_ = bstack1l1l1llll1_opy_(bs_config)
        bstack1ll1111l1l_opy_ = bstack1ll111111l_opy_(bs_config)
        data = {
            bstack11l1l1l_opy_ (u"ࠧࡧࡱࡵࡱࡦࡺࠧ༟"): bstack11l1l1l_opy_ (u"ࠨ࡬ࡶࡳࡳ࠭༠"),
            bstack11l1l1l_opy_ (u"ࠩࡳࡶࡴࡰࡥࡤࡶࡢࡲࡦࡳࡥࠨ༡"): bs_config.get(bstack11l1l1l_opy_ (u"ࠪࡴࡷࡵࡪࡦࡥࡷࡒࡦࡳࡥࠨ༢"), bstack11l1l1l_opy_ (u"ࠫࠬ༣")),
            bstack11l1l1l_opy_ (u"ࠬࡴࡡ࡮ࡧࠪ༤"): bs_config.get(bstack11l1l1l_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡓࡧ࡭ࡦࠩ༥"), os.path.basename(os.path.abspath(os.getcwd()))),
            bstack11l1l1l_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡥࡩࡥࡧࡱࡸ࡮࡬ࡩࡦࡴࠪ༦"): bs_config.get(bstack11l1l1l_opy_ (u"ࠨࡤࡸ࡭ࡱࡪࡉࡥࡧࡱࡸ࡮࡬ࡩࡦࡴࠪ༧")),
            bstack11l1l1l_opy_ (u"ࠩࡧࡩࡸࡩࡲࡪࡲࡷ࡭ࡴࡴࠧ༨"): bs_config.get(bstack11l1l1l_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭༩"), bstack11l1l1l_opy_ (u"ࠫࠬ༪")),
            bstack11l1l1l_opy_ (u"ࠬࡹࡴࡢࡴࡷࡣࡹ࡯࡭ࡦࠩ༫"): datetime.datetime.now().isoformat(),
            bstack11l1l1l_opy_ (u"࠭ࡴࡢࡩࡶࠫ༬"): bstack1ll1111111_opy_(bs_config),
            bstack11l1l1l_opy_ (u"ࠧࡩࡱࡶࡸࡤ࡯࡮ࡧࡱࠪ༭"): get_host_info(),
            bstack11l1l1l_opy_ (u"ࠨࡥ࡬ࡣ࡮ࡴࡦࡰࠩ༮"): bstack1l1lll1lll_opy_(),
            bstack11l1l1l_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡠࡴࡸࡲࡤ࡯ࡤࡦࡰࡷ࡭࡫࡯ࡥࡳࠩ༯"): os.environ.get(bstack11l1l1l_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡅ࡙ࡎࡒࡄࡠࡔࡘࡒࡤࡏࡄࡆࡐࡗࡍࡋࡏࡅࡓࠩ༰")),
            bstack11l1l1l_opy_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࡣࡹ࡫ࡳࡵࡵࡢࡶࡪࡸࡵ࡯ࠩ༱"): os.environ.get(bstack11l1l1l_opy_ (u"ࠬࡈࡒࡐ࡙ࡖࡉࡗ࡙ࡔࡂࡅࡎࡣࡗࡋࡒࡖࡐࠪ༲"), False),
            bstack11l1l1l_opy_ (u"࠭ࡶࡦࡴࡶ࡭ࡴࡴ࡟ࡤࡱࡱࡸࡷࡵ࡬ࠨ༳"): bstack1l1ll1l11l_opy_(),
            bstack11l1l1l_opy_ (u"ࠧࡰࡤࡶࡩࡷࡼࡡࡣ࡫࡯࡭ࡹࡿ࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࠨ༴"): {
                bstack11l1l1l_opy_ (u"ࠨࡨࡵࡥࡲ࡫ࡷࡰࡴ࡮ࡒࡦࡳࡥࠨ༵"): bstack1l1ll1l1ll_opy_.get(bstack11l1l1l_opy_ (u"ࠩࡩࡶࡦࡳࡥࡸࡱࡵ࡯ࡤࡴࡡ࡮ࡧࠪ༶"), bstack11l1l1l_opy_ (u"ࠪࡔࡾࡺࡥࡴࡶ༷ࠪ")),
                bstack11l1l1l_opy_ (u"ࠫ࡫ࡸࡡ࡮ࡧࡺࡳࡷࡱࡖࡦࡴࡶ࡭ࡴࡴࠧ༸"): bstack1l1ll1l1ll_opy_.get(bstack11l1l1l_opy_ (u"ࠬ࡬ࡲࡢ࡯ࡨࡻࡴࡸ࡫ࡠࡸࡨࡶࡸ࡯࡯࡯༹ࠩ")),
                bstack11l1l1l_opy_ (u"࠭ࡳࡥ࡭࡙ࡩࡷࡹࡩࡰࡰࠪ༺"): bstack1l1ll1l1ll_opy_.get(bstack11l1l1l_opy_ (u"ࠧࡴࡦ࡮ࡣࡻ࡫ࡲࡴ࡫ࡲࡲࠬ༻"))
            }
        }
        config = {
            bstack11l1l1l_opy_ (u"ࠨࡣࡸࡸ࡭࠭༼"): (bstack1l1ll1l1l1_opy_, bstack1ll1111l1l_opy_),
            bstack11l1l1l_opy_ (u"ࠩ࡫ࡩࡦࡪࡥࡳࡵࠪ༽"): cls.default_headers()
        }
        response = bstack11llll11l_opy_(bstack11l1l1l_opy_ (u"ࠪࡔࡔ࡙ࡔࠨ༾"), cls.request_url(bstack11l1l1l_opy_ (u"ࠫࡦࡶࡩ࠰ࡸ࠴࠳ࡧࡻࡩ࡭ࡦࡶࠫ༿")), data, config)
        if response.status_code != 200:
            os.environ[bstack11l1l1l_opy_ (u"ࠬࡈࡓࡠࡖࡈࡗ࡙ࡕࡐࡔࡡࡅ࡙ࡎࡒࡄࡠࡅࡒࡑࡕࡒࡅࡕࡇࡇࠫཀ")] = bstack11l1l1l_opy_ (u"࠭ࡦࡢ࡮ࡶࡩࠬཁ")
            os.environ[bstack11l1l1l_opy_ (u"ࠧࡃࡕࡢࡘࡊ࡙ࡔࡐࡒࡖࡣࡏ࡝ࡔࠨག")] = bstack11l1l1l_opy_ (u"ࠨࡰࡸࡰࡱ࠭གྷ")
            os.environ[bstack11l1l1l_opy_ (u"ࠩࡅࡗࡤ࡚ࡅࡔࡖࡒࡔࡘࡥࡂࡖࡋࡏࡈࡤࡎࡁࡔࡊࡈࡈࡤࡏࡄࠨང")] = bstack11l1l1l_opy_ (u"ࠥࡲࡺࡲ࡬ࠣཅ")
            os.environ[bstack11l1l1l_opy_ (u"ࠫࡇ࡙࡟ࡕࡇࡖࡘࡔࡖࡓࡠࡃࡏࡐࡔ࡝࡟ࡔࡅࡕࡉࡊࡔࡓࡉࡑࡗࡗࠬཆ")] = bstack11l1l1l_opy_ (u"ࠧࡴࡵ࡭࡮ࠥཇ")
            bstack1l1lll1111_opy_ = response.json()
            if bstack1l1lll1111_opy_ and bstack1l1lll1111_opy_[bstack11l1l1l_opy_ (u"࠭࡭ࡦࡵࡶࡥ࡬࡫ࠧ཈")]:
                error_message = bstack1l1lll1111_opy_[bstack11l1l1l_opy_ (u"ࠧ࡮ࡧࡶࡷࡦ࡭ࡥࠨཉ")]
                if bstack1l1lll1111_opy_[bstack11l1l1l_opy_ (u"ࠨࡧࡵࡶࡴࡸࡔࡺࡲࡨࠫཊ")] == bstack11l1l1l_opy_ (u"ࠩࡈࡖࡗࡕࡒࡠࡋࡑ࡚ࡆࡒࡉࡅࡡࡆࡖࡊࡊࡅࡏࡖࡌࡅࡑ࡙ࠧཋ"):
                    logger.error(error_message)
                elif bstack1l1lll1111_opy_[bstack11l1l1l_opy_ (u"ࠪࡩࡷࡸ࡯ࡳࡖࡼࡴࡪ࠭ཌ")] == bstack11l1l1l_opy_ (u"ࠫࡊࡘࡒࡐࡔࡢࡅࡈࡉࡅࡔࡕࡢࡈࡊࡔࡉࡆࡆࠪཌྷ"):
                    logger.info(error_message)
                elif bstack1l1lll1111_opy_[bstack11l1l1l_opy_ (u"ࠬ࡫ࡲࡳࡱࡵࡘࡾࡶࡥࠨཎ")] == bstack11l1l1l_opy_ (u"࠭ࡅࡓࡔࡒࡖࡤ࡙ࡄࡌࡡࡇࡉࡕࡘࡅࡄࡃࡗࡉࡉ࠭ཏ"):
                    logger.error(error_message)
                else:
                    logger.error(error_message)
            else:
                logger.error(bstack1l1l1lllll_opy_ (u"ࠢࡅࡣࡷࡥࠥࡻࡰ࡭ࡱࡤࡨࠥࡺ࡯ࠡࡄࡵࡳࡼࡹࡥࡳࡕࡷࡥࡨࡱࠠࡕࡧࡶࡸࠥࡕࡢࡴࡧࡵࡺࡦࡨࡩ࡭࡫ࡷࡽࠥ࡬ࡡࡪ࡮ࡨࡨࠥࡪࡵࡦࠢࡷࡳࠥࡹ࡯࡮ࡧࠣࡩࡷࡸ࡯ࡳࠤཐ"))
            return [None, None, None]
        os.environ[bstack11l1l1l_opy_ (u"ࠨࡄࡖࡣ࡙ࡋࡓࡕࡑࡓࡗࡤࡈࡕࡊࡎࡇࡣࡈࡕࡍࡑࡎࡈࡘࡊࡊࠧད")] = bstack11l1l1l_opy_ (u"ࠩࡷࡶࡺ࡫ࠧདྷ")
        bstack1l1lll1111_opy_ = response.json()
        if bstack1l1lll1111_opy_.get(bstack11l1l1l_opy_ (u"ࠪ࡮ࡼࡺࠧན")):
            os.environ[bstack11l1l1l_opy_ (u"ࠫࡇ࡙࡟ࡕࡇࡖࡘࡔࡖࡓࡠࡌ࡚ࡘࠬཔ")] = bstack1l1lll1111_opy_[bstack11l1l1l_opy_ (u"ࠬࡰࡷࡵࠩཕ")]
            os.environ[bstack11l1l1l_opy_ (u"࠭ࡃࡓࡇࡇࡉࡓ࡚ࡉࡂࡎࡖࡣࡋࡕࡒࡠࡅࡕࡅࡘࡎ࡟ࡓࡇࡓࡓࡗ࡚ࡉࡏࡉࠪབ")] = json.dumps({
                bstack11l1l1l_opy_ (u"ࠧࡶࡵࡨࡶࡳࡧ࡭ࡦࠩབྷ"): bstack1l1ll1l1l1_opy_,
                bstack11l1l1l_opy_ (u"ࠨࡲࡤࡷࡸࡽ࡯ࡳࡦࠪམ"): bstack1ll1111l1l_opy_
            })
        if bstack1l1lll1111_opy_.get(bstack11l1l1l_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡠࡪࡤࡷ࡭࡫ࡤࡠ࡫ࡧࠫཙ")):
            os.environ[bstack11l1l1l_opy_ (u"ࠪࡆࡘࡥࡔࡆࡕࡗࡓࡕ࡙࡟ࡃࡗࡌࡐࡉࡥࡈࡂࡕࡋࡉࡉࡥࡉࡅࠩཚ")] = bstack1l1lll1111_opy_[bstack11l1l1l_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡢ࡬ࡦࡹࡨࡦࡦࡢ࡭ࡩ࠭ཛ")]
        if bstack1l1lll1111_opy_.get(bstack11l1l1l_opy_ (u"ࠬࡧ࡬࡭ࡱࡺࡣࡸࡩࡲࡦࡧࡱࡷ࡭ࡵࡴࡴࠩཛྷ")):
            os.environ[bstack11l1l1l_opy_ (u"࠭ࡂࡔࡡࡗࡉࡘ࡚ࡏࡑࡕࡢࡅࡑࡒࡏࡘࡡࡖࡇࡗࡋࡅࡏࡕࡋࡓ࡙࡙ࠧཝ")] = str(bstack1l1lll1111_opy_[bstack11l1l1l_opy_ (u"ࠧࡢ࡮࡯ࡳࡼࡥࡳࡤࡴࡨࡩࡳࡹࡨࡰࡶࡶࠫཞ")])
        return [bstack1l1lll1111_opy_[bstack11l1l1l_opy_ (u"ࠨ࡬ࡺࡸࠬཟ")], bstack1l1lll1111_opy_[bstack11l1l1l_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡠࡪࡤࡷ࡭࡫ࡤࡠ࡫ࡧࠫའ")], bstack1l1lll1111_opy_[bstack11l1l1l_opy_ (u"ࠪࡥࡱࡲ࡯ࡸࡡࡶࡧࡷ࡫ࡥ࡯ࡵ࡫ࡳࡹࡹࠧཡ")]]
    @classmethod
    @bstack1ll1111lll_opy_(bstack1l1lllll11_opy_=True)
    def stop(cls):
        if not cls.on():
            return
        if os.environ[bstack11l1l1l_opy_ (u"ࠫࡇ࡙࡟ࡕࡇࡖࡘࡔࡖࡓࡠࡌ࡚ࡘࠬར")] == bstack11l1l1l_opy_ (u"ࠧࡴࡵ࡭࡮ࠥལ") or os.environ[bstack11l1l1l_opy_ (u"࠭ࡂࡔࡡࡗࡉࡘ࡚ࡏࡑࡕࡢࡆ࡚ࡏࡌࡅࡡࡋࡅࡘࡎࡅࡅࡡࡌࡈࠬཤ")] == bstack11l1l1l_opy_ (u"ࠢ࡯ࡷ࡯ࡰࠧཥ"):
            print(bstack11l1l1l_opy_ (u"ࠨࡇ࡛ࡇࡊࡖࡔࡊࡑࡑࠤࡎࡔࠠࡴࡶࡲࡴࡇࡻࡩ࡭ࡦࡘࡴࡸࡺࡲࡦࡣࡰࠤࡗࡋࡑࡖࡇࡖࡘ࡚ࠥࡏࠡࡖࡈࡗ࡙ࠦࡏࡃࡕࡈࡖ࡛ࡇࡂࡊࡎࡌࡘ࡞ࠦ࠺ࠡࡏ࡬ࡷࡸ࡯࡮ࡨࠢࡤࡹࡹ࡮ࡥ࡯ࡶ࡬ࡧࡦࡺࡩࡰࡰࠣࡸࡴࡱࡥ࡯ࠩས"))
            return {
                bstack11l1l1l_opy_ (u"ࠩࡶࡸࡦࡺࡵࡴࠩཧ"): bstack11l1l1l_opy_ (u"ࠪࡩࡷࡸ࡯ࡳࠩཨ"),
                bstack11l1l1l_opy_ (u"ࠫࡲ࡫ࡳࡴࡣࡪࡩࠬཀྵ"): bstack11l1l1l_opy_ (u"࡚ࠬ࡯࡬ࡧࡱ࠳ࡧࡻࡩ࡭ࡦࡌࡈࠥ࡯ࡳࠡࡷࡱࡨࡪ࡬ࡩ࡯ࡧࡧ࠰ࠥࡨࡵࡪ࡮ࡧࠤࡨࡸࡥࡢࡶ࡬ࡳࡳࠦ࡭ࡪࡩ࡫ࡸࠥ࡮ࡡࡷࡧࠣࡪࡦ࡯࡬ࡦࡦࠪཪ")
            }
        else:
            cls.bstack1l1ll11lll_opy_.shutdown()
            data = {
                bstack11l1l1l_opy_ (u"࠭ࡳࡵࡱࡳࡣࡹ࡯࡭ࡦࠩཫ"): datetime.datetime.now().isoformat()
            }
            config = {
                bstack11l1l1l_opy_ (u"ࠧࡩࡧࡤࡨࡪࡸࡳࠨཬ"): cls.default_headers()
            }
            bstack1l1lll11ll_opy_ = bstack11l1l1l_opy_ (u"ࠨࡣࡳ࡭࠴ࡼ࠱࠰ࡤࡸ࡭ࡱࡪࡳ࠰ࡽࢀ࠳ࡸࡺ࡯ࡱࠩ཭").format(os.environ[bstack11l1l1l_opy_ (u"ࠤࡅࡗࡤ࡚ࡅࡔࡖࡒࡔࡘࡥࡂࡖࡋࡏࡈࡤࡎࡁࡔࡊࡈࡈࡤࡏࡄࠣ཮")])
            bstack1l1ll1lll1_opy_ = cls.request_url(bstack1l1lll11ll_opy_)
            response = bstack11llll11l_opy_(bstack11l1l1l_opy_ (u"ࠪࡔ࡚࡚ࠧ཯"), bstack1l1ll1lll1_opy_, data, config)
            if not response.ok:
                raise Exception(bstack11l1l1l_opy_ (u"ࠦࡘࡺ࡯ࡱࠢࡵࡩࡶࡻࡥࡴࡶࠣࡲࡴࡺࠠࡰ࡭ࠥ཰"))
    @classmethod
    def bstack11ll1lll1_opy_(cls):
        if cls.on():
            print(
                bstack11l1l1l_opy_ (u"ࠬ࡜ࡩࡴ࡫ࡷࠤ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡵࡢࡴࡧࡵࡺࡦࡨࡩ࡭࡫ࡷࡽ࠳ࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮࠲ࡨࡵ࡭࠰ࡤࡸ࡭ࡱࡪࡳ࠰ࡽࢀࠤࡹࡵࠠࡷ࡫ࡨࡻࠥࡨࡵࡪ࡮ࡧࠤࡷ࡫ࡰࡰࡴࡷ࠰ࠥ࡯࡮ࡴ࡫ࡪ࡬ࡹࡹࠬࠡࡣࡱࡨࠥࡳࡡ࡯ࡻࠣࡱࡴࡸࡥࠡࡦࡨࡦࡺ࡭ࡧࡪࡰࡪࠤ࡮ࡴࡦࡰࡴࡰࡥࡹ࡯࡯࡯ࠢࡤࡰࡱࠦࡡࡵࠢࡲࡲࡪࠦࡰ࡭ࡣࡦࡩࠦࡢ࡮ࠨཱ").format(os.environ[bstack11l1l1l_opy_ (u"ࠨࡂࡔࡡࡗࡉࡘ࡚ࡏࡑࡕࡢࡆ࡚ࡏࡌࡅࡡࡋࡅࡘࡎࡅࡅࡡࡌࡈིࠧ")]))
    @classmethod
    def bstack1l1ll11l11_opy_(cls, bstack1l1llll1l1_opy_, bstack1l1l1lll11_opy_=bstack11l1l1l_opy_ (u"ࠧࡢࡲ࡬࠳ࡻ࠷࠯ࡣࡣࡷࡧ࡭ཱི࠭")):
        if not cls.on():
            return
        bstack1l111ll11_opy_ = bstack1l1llll1l1_opy_[bstack11l1l1l_opy_ (u"ࠨࡧࡹࡩࡳࡺ࡟ࡵࡻࡳࡩུࠬ")]
        bstack1l1lllllll_opy_ = {
            bstack11l1l1l_opy_ (u"ࠩࡗࡩࡸࡺࡒࡶࡰࡖࡸࡦࡸࡴࡦࡦཱུࠪ"): bstack11l1l1l_opy_ (u"ࠪࡘࡪࡹࡴࡠࡕࡷࡥࡷࡺ࡟ࡖࡲ࡯ࡳࡦࡪࠧྲྀ"),
            bstack11l1l1l_opy_ (u"࡙ࠫ࡫ࡳࡵࡔࡸࡲࡋ࡯࡮ࡪࡵ࡫ࡩࡩ࠭ཷ"): bstack11l1l1l_opy_ (u"࡚ࠬࡥࡴࡶࡢࡉࡳࡪ࡟ࡖࡲ࡯ࡳࡦࡪࠧླྀ"),
            bstack11l1l1l_opy_ (u"࠭ࡔࡦࡵࡷࡖࡺࡴࡓ࡬࡫ࡳࡴࡪࡪࠧཹ"): bstack11l1l1l_opy_ (u"ࠧࡕࡧࡶࡸࡤ࡙࡫ࡪࡲࡳࡩࡩࡥࡕࡱ࡮ࡲࡥࡩེ࠭"),
            bstack11l1l1l_opy_ (u"ࠨࡎࡲ࡫ࡈࡸࡥࡢࡶࡨࡨཻࠬ"): bstack11l1l1l_opy_ (u"ࠩࡏࡳ࡬ࡥࡕࡱ࡮ࡲࡥࡩོ࠭"),
            bstack11l1l1l_opy_ (u"ࠪࡌࡴࡵ࡫ࡓࡷࡱࡗࡹࡧࡲࡵࡧࡧཽࠫ"): bstack11l1l1l_opy_ (u"ࠫࡍࡵ࡯࡬ࡡࡖࡸࡦࡸࡴࡠࡗࡳࡰࡴࡧࡤࠨཾ"),
            bstack11l1l1l_opy_ (u"ࠬࡎ࡯ࡰ࡭ࡕࡹࡳࡌࡩ࡯࡫ࡶ࡬ࡪࡪࠧཿ"): bstack11l1l1l_opy_ (u"࠭ࡈࡰࡱ࡮ࡣࡊࡴࡤࡠࡗࡳࡰࡴࡧࡤࠨྀ"),
            bstack11l1l1l_opy_ (u"ࠧࡄࡄࡗࡗࡪࡹࡳࡪࡱࡱࡇࡷ࡫ࡡࡵࡧࡧཱྀࠫ"): bstack11l1l1l_opy_ (u"ࠨࡅࡅࡘࡤ࡛ࡰ࡭ࡱࡤࡨࠬྂ")
        }.get(bstack1l111ll11_opy_)
        if bstack1l1l1lll11_opy_ == bstack11l1l1l_opy_ (u"ࠩࡤࡴ࡮࠵ࡶ࠲࠱ࡥࡥࡹࡩࡨࠨྃ"):
            cls.bstack1l1ll11lll_opy_.add(bstack1l1llll1l1_opy_)
        elif bstack1l1l1lll11_opy_ == bstack11l1l1l_opy_ (u"ࠪࡥࡵ࡯࠯ࡷ࠳࠲ࡷࡨࡸࡥࡦࡰࡶ࡬ࡴࡺࡳࠨ྄"):
            cls.bstack1ll11111ll_opy_([bstack1l1llll1l1_opy_], bstack1l1l1lll11_opy_)
    @classmethod
    @bstack1ll1111lll_opy_(bstack1l1lllll11_opy_=True)
    def bstack1ll11111ll_opy_(cls, bstack1l1llll1l1_opy_, bstack1l1l1lll11_opy_=bstack11l1l1l_opy_ (u"ࠫࡦࡶࡩ࠰ࡸ࠴࠳ࡧࡧࡴࡤࡪࠪ྅")):
        config = {
            bstack11l1l1l_opy_ (u"ࠬ࡮ࡥࡢࡦࡨࡶࡸ࠭྆"): cls.default_headers()
        }
        response = bstack11llll11l_opy_(bstack11l1l1l_opy_ (u"࠭ࡐࡐࡕࡗࠫ྇"), cls.request_url(bstack1l1l1lll11_opy_), bstack1l1llll1l1_opy_, config)
        bstack1l1lll11l1_opy_ = response.json()
    @classmethod
    @bstack1ll1111lll_opy_(bstack1l1lllll11_opy_=True)
    def bstack1l1ll1ll1l_opy_(cls, bstack1l1llll111_opy_):
        bstack1l1ll111ll_opy_ = []
        for log in bstack1l1llll111_opy_:
            bstack1l1ll111ll_opy_.append({
                bstack11l1l1l_opy_ (u"ࠧ࡬࡫ࡱࡨࠬྈ"): bstack11l1l1l_opy_ (u"ࠨࡖࡈࡗ࡙ࡥࡌࡐࡉࠪྉ"),
                bstack11l1l1l_opy_ (u"ࠩ࡯ࡩࡻ࡫࡬ࠨྊ"): log[bstack11l1l1l_opy_ (u"ࠪࡰࡪࡼࡥ࡭ࠩྋ")],
                bstack11l1l1l_opy_ (u"ࠫࡹ࡯࡭ࡦࡵࡷࡥࡲࡶࠧྌ"): log[bstack11l1l1l_opy_ (u"ࠬࡺࡩ࡮ࡧࡶࡸࡦࡳࡰࠨྍ")],
                bstack11l1l1l_opy_ (u"࠭ࡨࡵࡶࡳࡣࡷ࡫ࡳࡱࡱࡱࡷࡪ࠭ྎ"): {},
                bstack11l1l1l_opy_ (u"ࠧ࡮ࡧࡶࡷࡦ࡭ࡥࠨྏ"): log[bstack11l1l1l_opy_ (u"ࠨ࡯ࡨࡷࡸࡧࡧࡦࠩྐ")],
                bstack11l1l1l_opy_ (u"ࠩࡷࡩࡸࡺ࡟ࡳࡷࡱࡣࡺࡻࡩࡥࠩྑ"): log[bstack11l1l1l_opy_ (u"ࠪࡸࡪࡹࡴࡠࡴࡸࡲࡤࡻࡵࡪࡦࠪྒ")]
            })
        cls.bstack1l1ll11l11_opy_({
            bstack11l1l1l_opy_ (u"ࠫࡪࡼࡥ࡯ࡶࡢࡸࡾࡶࡥࠨྒྷ"): bstack11l1l1l_opy_ (u"ࠬࡒ࡯ࡨࡅࡵࡩࡦࡺࡥࡥࠩྔ"),
            bstack11l1l1l_opy_ (u"࠭࡬ࡰࡩࡶࠫྕ"): bstack1l1ll111ll_opy_
        })
    @classmethod
    @bstack1ll1111lll_opy_(bstack1l1lllll11_opy_=True)
    def bstack1l1ll1llll_opy_(cls, steps):
        bstack1ll1111ll1_opy_ = []
        for step in steps:
            bstack1l1ll11111_opy_ = {
                bstack11l1l1l_opy_ (u"ࠧ࡬࡫ࡱࡨࠬྖ"): bstack11l1l1l_opy_ (u"ࠨࡖࡈࡗ࡙ࡥࡓࡕࡇࡓࠫྗ"),
                bstack11l1l1l_opy_ (u"ࠩ࡯ࡩࡻ࡫࡬ࠨ྘"): step[bstack11l1l1l_opy_ (u"ࠪࡰࡪࡼࡥ࡭ࠩྙ")],
                bstack11l1l1l_opy_ (u"ࠫࡹ࡯࡭ࡦࡵࡷࡥࡲࡶࠧྚ"): step[bstack11l1l1l_opy_ (u"ࠬࡺࡩ࡮ࡧࡶࡸࡦࡳࡰࠨྛ")],
                bstack11l1l1l_opy_ (u"࠭࡭ࡦࡵࡶࡥ࡬࡫ࠧྜ"): step[bstack11l1l1l_opy_ (u"ࠧ࡮ࡧࡶࡷࡦ࡭ࡥࠨྜྷ")],
                bstack11l1l1l_opy_ (u"ࠨࡦࡸࡶࡦࡺࡩࡰࡰࠪྞ"): step[bstack11l1l1l_opy_ (u"ࠩࡧࡹࡷࡧࡴࡪࡱࡱࠫྟ")]
            }
            if bstack11l1l1l_opy_ (u"ࠪࡸࡪࡹࡴࡠࡴࡸࡲࡤࡻࡵࡪࡦࠪྠ") in step:
                bstack1l1ll11111_opy_[bstack11l1l1l_opy_ (u"ࠫࡹ࡫ࡳࡵࡡࡵࡹࡳࡥࡵࡶ࡫ࡧࠫྡ")] = step[bstack11l1l1l_opy_ (u"ࠬࡺࡥࡴࡶࡢࡶࡺࡴ࡟ࡶࡷ࡬ࡨࠬྡྷ")]
            elif bstack11l1l1l_opy_ (u"࠭ࡨࡰࡱ࡮ࡣࡷࡻ࡮ࡠࡷࡸ࡭ࡩ࠭ྣ") in step:
                bstack1l1ll11111_opy_[bstack11l1l1l_opy_ (u"ࠧࡩࡱࡲ࡯ࡤࡸࡵ࡯ࡡࡸࡹ࡮ࡪࠧྤ")] = step[bstack11l1l1l_opy_ (u"ࠨࡪࡲࡳࡰࡥࡲࡶࡰࡢࡹࡺ࡯ࡤࠨྥ")]
            bstack1ll1111ll1_opy_.append(bstack1l1ll11111_opy_)
        cls.bstack1l1ll11l11_opy_({
            bstack11l1l1l_opy_ (u"ࠩࡨࡺࡪࡴࡴࡠࡶࡼࡴࡪ࠭ྦ"): bstack11l1l1l_opy_ (u"ࠪࡐࡴ࡭ࡃࡳࡧࡤࡸࡪࡪࠧྦྷ"),
            bstack11l1l1l_opy_ (u"ࠫࡱࡵࡧࡴࠩྨ"): bstack1ll1111ll1_opy_
        })
    @classmethod
    @bstack1ll1111lll_opy_(bstack1l1lllll11_opy_=True)
    def bstack1l1llll1ll_opy_(cls, screenshot):
        cls.bstack1l1ll11l11_opy_({
            bstack11l1l1l_opy_ (u"ࠬ࡫ࡶࡦࡰࡷࡣࡹࡿࡰࡦࠩྩ"): bstack11l1l1l_opy_ (u"࠭ࡌࡰࡩࡆࡶࡪࡧࡴࡦࡦࠪྪ"),
            bstack11l1l1l_opy_ (u"ࠧ࡭ࡱࡪࡷࠬྫ"): [{
                bstack11l1l1l_opy_ (u"ࠨ࡭࡬ࡲࡩ࠭ྫྷ"): bstack11l1l1l_opy_ (u"ࠩࡗࡉࡘ࡚࡟ࡔࡅࡕࡉࡊࡔࡓࡉࡑࡗࠫྭ"),
                bstack11l1l1l_opy_ (u"ࠪࡸ࡮ࡳࡥࡴࡶࡤࡱࡵ࠭ྮ"): datetime.datetime.utcnow().isoformat() + bstack11l1l1l_opy_ (u"ࠫ࡟࠭ྯ"),
                bstack11l1l1l_opy_ (u"ࠬࡳࡥࡴࡵࡤ࡫ࡪ࠭ྰ"): screenshot[bstack11l1l1l_opy_ (u"࠭ࡩ࡮ࡣࡪࡩࠬྱ")],
                bstack11l1l1l_opy_ (u"ࠧࡵࡧࡶࡸࡤࡸࡵ࡯ࡡࡸࡹ࡮ࡪࠧྲ"): screenshot[bstack11l1l1l_opy_ (u"ࠨࡶࡨࡷࡹࡥࡲࡶࡰࡢࡹࡺ࡯ࡤࠨླ")]
            }]
        }, bstack1l1l1lll11_opy_=bstack11l1l1l_opy_ (u"ࠩࡤࡴ࡮࠵ࡶ࠲࠱ࡶࡧࡷ࡫ࡥ࡯ࡵ࡫ࡳࡹࡹࠧྴ"))
    @classmethod
    @bstack1ll1111lll_opy_(bstack1l1lllll11_opy_=True)
    def bstack11l11ll1_opy_(cls, driver):
        bstack1l1l1lll1l_opy_ = cls.bstack1l1l1lll1l_opy_()
        if not bstack1l1l1lll1l_opy_:
            return
        cls.bstack1l1ll11l11_opy_({
            bstack11l1l1l_opy_ (u"ࠪࡩࡻ࡫࡮ࡵࡡࡷࡽࡵ࡫ࠧྵ"): bstack11l1l1l_opy_ (u"ࠫࡈࡈࡔࡔࡧࡶࡷ࡮ࡵ࡮ࡄࡴࡨࡥࡹ࡫ࡤࠨྶ"),
            bstack11l1l1l_opy_ (u"ࠬࡺࡥࡴࡶࡢࡶࡺࡴࠧྷ"): {
                bstack11l1l1l_opy_ (u"ࠨࡵࡶ࡫ࡧࠦྸ"): cls.bstack1l1l1lll1l_opy_(),
                bstack11l1l1l_opy_ (u"ࠢࡪࡰࡷࡩ࡬ࡸࡡࡵ࡫ࡲࡲࡸࠨྐྵ"): cls.bstack1l1lll1ll1_opy_(driver)
            }
        })
    @classmethod
    def on(cls):
        if not getattr(cls, bstack11l1l1l_opy_ (u"ࠨࡤࡶࡣࡨࡵ࡮ࡧ࡫ࡪࠫྺ"), None):
            return False
        if not cls.bstack1l1ll1111l_opy_():
            return False
        if os.environ.get(bstack11l1l1l_opy_ (u"ࠩࡅࡗࡤ࡚ࡅࡔࡖࡒࡔࡘࡥࡊࡘࡖࠪྻ"), None) is None or os.environ[bstack11l1l1l_opy_ (u"ࠪࡆࡘࡥࡔࡆࡕࡗࡓࡕ࡙࡟ࡋ࡙ࡗࠫྼ")] == bstack11l1l1l_opy_ (u"ࠦࡳࡻ࡬࡭ࠤ྽"):
            return False
        return True
    @classmethod
    def bstack1l1ll1111l_opy_(cls):
        return bstack1l1llllll1_opy_(cls.bs_config.get(bstack11l1l1l_opy_ (u"ࠬࡺࡥࡴࡶࡒࡦࡸ࡫ࡲࡷࡣࡥ࡭ࡱ࡯ࡴࡺࠩ྾"), False))
    @staticmethod
    def request_url(url):
        return bstack11l1l1l_opy_ (u"࠭ࡻࡾ࠱ࡾࢁࠬ྿").format(bstack1l1ll11ll1_opy_, url)
    @staticmethod
    def default_headers():
        headers = {
            bstack11l1l1l_opy_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭࿀"): bstack11l1l1l_opy_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡪࡴࡱࡱࠫ࿁"),
            bstack11l1l1l_opy_ (u"࡛ࠩ࠱ࡇ࡙ࡔࡂࡅࡎ࠱࡙ࡋࡓࡕࡑࡓࡗࠬ࿂"): bstack11l1l1l_opy_ (u"ࠪࡸࡷࡻࡥࠨ࿃")
        }
        if os.environ.get(bstack11l1l1l_opy_ (u"ࠫࡇ࡙࡟ࡕࡇࡖࡘࡔࡖࡓࡠࡌ࡚ࡘࠬ࿄"), None):
            headers[bstack11l1l1l_opy_ (u"ࠬࡇࡵࡵࡪࡲࡶ࡮ࢀࡡࡵ࡫ࡲࡲࠬ࿅")] = bstack11l1l1l_opy_ (u"࠭ࡂࡦࡣࡵࡩࡷࠦࡻࡾ࿆ࠩ").format(os.environ[bstack11l1l1l_opy_ (u"ࠢࡃࡕࡢࡘࡊ࡙ࡔࡐࡒࡖࡣࡏ࡝ࡔࠣ࿇")])
        return headers
    @staticmethod
    def bstack1l1l1lll1l_opy_():
        return getattr(threading.current_thread(), bstack11l1l1l_opy_ (u"ࠨࡥࡸࡶࡷ࡫࡮ࡵࡡࡷࡩࡸࡺ࡟ࡶࡷ࡬ࡨࠬ࿈"), None)
    @staticmethod
    def bstack1l1lll1ll1_opy_(driver):
        return {
            bstack1ll11111l1_opy_(): bstack1l1llll11l_opy_(driver)
        }
    @staticmethod
    def bstack1l1ll1l111_opy_(exception_info, report):
        return [{bstack11l1l1l_opy_ (u"ࠩࡥࡥࡨࡱࡴࡳࡣࡦࡩࠬ࿉"): [exception_info.exconly(), report.longreprtext]}]
    @staticmethod
    def bstack1ll1111l11_opy_(typename):
        if bstack11l1l1l_opy_ (u"ࠥࡅࡸࡹࡥࡳࡶ࡬ࡳࡳࠨ࿊") in typename:
            return bstack11l1l1l_opy_ (u"ࠦࡆࡹࡳࡦࡴࡷ࡭ࡴࡴࡅࡳࡴࡲࡶࠧ࿋")
        return bstack11l1l1l_opy_ (u"࡛ࠧ࡮ࡩࡣࡱࡨࡱ࡫ࡤࡆࡴࡵࡳࡷࠨ࿌")
    @staticmethod
    def bstack1l1lll111l_opy_(func):
        def wrap(*args, **kwargs):
            if bstack1llll1ll1l_opy_.on():
                return func(*args, **kwargs)
            return
        return wrap
    @staticmethod
    def bstack1l1ll111l1_opy_(test):
        bstack1l1ll11l1l_opy_ = test.parent
        scope = []
        while bstack1l1ll11l1l_opy_ is not None:
            scope.append(bstack1l1ll11l1l_opy_.name)
            bstack1l1ll11l1l_opy_ = bstack1l1ll11l1l_opy_.parent
        scope.reverse()
        return scope[2:]
    @staticmethod
    def bstack1l1lllll1l_opy_(hook_type):
        if hook_type == bstack11l1l1l_opy_ (u"ࠨࡂࡆࡈࡒࡖࡊࡥࡅࡂࡅࡋࠦ࿍"):
            return bstack11l1l1l_opy_ (u"ࠢࡔࡧࡷࡹࡵࠦࡨࡰࡱ࡮ࠦ࿎")
        elif hook_type == bstack11l1l1l_opy_ (u"ࠣࡃࡉࡘࡊࡘ࡟ࡆࡃࡆࡌࠧ࿏"):
            return bstack11l1l1l_opy_ (u"ࠤࡗࡩࡦࡸࡤࡰࡹࡱࠤ࡭ࡵ࡯࡬ࠤ࿐")