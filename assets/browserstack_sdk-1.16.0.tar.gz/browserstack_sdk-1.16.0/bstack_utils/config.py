# coding: UTF-8
import sys
bstack1111l1l_opy_ = sys.version_info [0] == 2
bstack1l111l_opy_ = 2048
bstack1lllll1l_opy_ = 7
def bstack11l1l1l_opy_ (bstack111l1l_opy_):
    global bstack1ll111_opy_
    bstack1111111_opy_ = ord (bstack111l1l_opy_ [-1])
    bstack1l1111_opy_ = bstack111l1l_opy_ [:-1]
    bstack1lll111_opy_ = bstack1111111_opy_ % len (bstack1l1111_opy_)
    bstack11ll1l_opy_ = bstack1l1111_opy_ [:bstack1lll111_opy_] + bstack1l1111_opy_ [bstack1lll111_opy_:]
    if bstack1111l1l_opy_:
        bstack11111l1_opy_ = unicode () .join ([unichr (ord (char) - bstack1l111l_opy_ - (bstack1l1lll_opy_ + bstack1111111_opy_) % bstack1lllll1l_opy_) for bstack1l1lll_opy_, char in enumerate (bstack11ll1l_opy_)])
    else:
        bstack11111l1_opy_ = str () .join ([chr (ord (char) - bstack1l111l_opy_ - (bstack1l1lll_opy_ + bstack1111111_opy_) % bstack1lllll1l_opy_) for bstack1l1lll_opy_, char in enumerate (bstack11ll1l_opy_)])
    return eval (bstack11111l1_opy_)
conf = {
    bstack11l1l1l_opy_ (u"ࠬࡧࡰࡱࡡࡤࡹࡹࡵ࡭ࡢࡶࡨࠫೃ"): False,
    bstack11l1l1l_opy_ (u"࠭ࡢࡴࡶࡤࡧࡰࡥࡳࡦࡵࡶ࡭ࡴࡴࠧೄ"): True,
}
class Config(object):
    instance = None
    def __init__(self):
        self._1ll11lll11_opy_ = conf
    @classmethod
    def get_instance(cls):
        if cls.instance:
            return cls.instance
        return Config()
    def get_property(self, property_name):
        return self._1ll11lll11_opy_.get(property_name, None)
    def set_property(self, property_name, bstack1ll11ll1ll_opy_):
        self._1ll11lll11_opy_[property_name] = bstack1ll11ll1ll_opy_