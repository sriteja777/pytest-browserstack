# coding: UTF-8
import sys
bstack1111l1l_opy_ = sys.version_info [0] == 2
bstack1l111l_opy_ = 2048
bstack1lllll1l_opy_ = 7
def bstack11l1l1l_opy_ (bstack111l1l_opy_):
    global bstack1ll111_opy_
    bstack1111111_opy_ = ord (bstack111l1l_opy_ [-1])
    bstack1l1111_opy_ = bstack111l1l_opy_ [:-1]
    bstack1lll111_opy_ = bstack1111111_opy_ % len (bstack1l1111_opy_)
    bstack11ll1l_opy_ = bstack1l1111_opy_ [:bstack1lll111_opy_] + bstack1l1111_opy_ [bstack1lll111_opy_:]
    if bstack1111l1l_opy_:
        bstack11111l1_opy_ = unicode () .join ([unichr (ord (char) - bstack1l111l_opy_ - (bstack1l1lll_opy_ + bstack1111111_opy_) % bstack1lllll1l_opy_) for bstack1l1lll_opy_, char in enumerate (bstack11ll1l_opy_)])
    else:
        bstack11111l1_opy_ = str () .join ([chr (ord (char) - bstack1l111l_opy_ - (bstack1l1lll_opy_ + bstack1111111_opy_) % bstack1lllll1l_opy_) for bstack1l1lll_opy_, char in enumerate (bstack11ll1l_opy_)])
    return eval (bstack11111l1_opy_)
import os
from urllib.parse import urlparse
from bstack_utils.messages import bstack1ll11l1lll_opy_
def bstack1ll11l11ll_opy_(url):
    try:
        result = urlparse(url)
        return all([result.scheme, result.netloc])
    except:
        return False
def bstack1ll11ll11l_opy_(bstack1ll11ll1l1_opy_, bstack1ll11l1l11_opy_):
    from pypac import get_pac
    from pypac import PACSession
    from pypac.parser import PACFile
    import socket
    if os.path.isfile(bstack1ll11ll1l1_opy_):
        with open(bstack1ll11ll1l1_opy_) as f:
            pac = PACFile(f.read())
    elif bstack1ll11l11ll_opy_(bstack1ll11ll1l1_opy_):
        pac = get_pac(url=bstack1ll11ll1l1_opy_)
    else:
        raise Exception(bstack11l1l1l_opy_ (u"ࠧࡑࡣࡦࠤ࡫࡯࡬ࡦࠢࡧࡳࡪࡹࠠ࡯ࡱࡷࠤࡪࡾࡩࡴࡶ࠽ࠤࢀࢃࠧ೅").format(bstack1ll11ll1l1_opy_))
    session = PACSession(pac)
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect((bstack11l1l1l_opy_ (u"ࠣ࠺࠱࠼࠳࠾࠮࠹ࠤೆ"), 80))
        bstack1ll11ll111_opy_ = s.getsockname()[0]
        s.close()
    except:
        bstack1ll11ll111_opy_ = bstack11l1l1l_opy_ (u"ࠩ࠳࠲࠵࠴࠰࠯࠲ࠪೇ")
    proxy_url = session.get_pac().find_proxy_for_url(bstack1ll11l1l11_opy_, bstack1ll11ll111_opy_)
    return proxy_url
def bstack1lll11l1l_opy_(config):
    return bstack11l1l1l_opy_ (u"ࠪ࡬ࡹࡺࡰࡑࡴࡲࡼࡾ࠭ೈ") in config or bstack11l1l1l_opy_ (u"ࠫ࡭ࡺࡴࡱࡵࡓࡶࡴࡾࡹࠨ೉") in config
def bstack1l111l11l_opy_(config):
    if not bstack1lll11l1l_opy_(config):
        return
    if config.get(bstack11l1l1l_opy_ (u"ࠬ࡮ࡴࡵࡲࡓࡶࡴࡾࡹࠨೊ")):
        return config.get(bstack11l1l1l_opy_ (u"࠭ࡨࡵࡶࡳࡔࡷࡵࡸࡺࠩೋ"))
    if config.get(bstack11l1l1l_opy_ (u"ࠧࡩࡶࡷࡴࡸࡖࡲࡰࡺࡼࠫೌ")):
        return config.get(bstack11l1l1l_opy_ (u"ࠨࡪࡷࡸࡵࡹࡐࡳࡱࡻࡽ್ࠬ"))
def bstack1111l1lll_opy_(config, bstack1ll11l1l11_opy_):
    proxy = bstack1l111l11l_opy_(config)
    proxies = {}
    if config.get(bstack11l1l1l_opy_ (u"ࠩ࡫ࡸࡹࡶࡐࡳࡱࡻࡽࠬ೎")) or config.get(bstack11l1l1l_opy_ (u"ࠪ࡬ࡹࡺࡰࡴࡒࡵࡳࡽࡿࠧ೏")):
        if proxy.endswith(bstack11l1l1l_opy_ (u"ࠫ࠳ࡶࡡࡤࠩ೐")):
            proxies = bstack11lll1ll1_opy_(proxy, bstack1ll11l1l11_opy_)
        else:
            proxies = {
                bstack11l1l1l_opy_ (u"ࠬ࡮ࡴࡵࡲࡶࠫ೑"): proxy
            }
    return proxies
def bstack11lll1ll1_opy_(bstack1ll11ll1l1_opy_, bstack1ll11l1l11_opy_):
    proxies = {}
    global bstack1ll11l1ll1_opy_
    if bstack11l1l1l_opy_ (u"࠭ࡐࡂࡅࡢࡔࡗࡕࡘ࡚ࠩ೒") in globals():
        return bstack1ll11l1ll1_opy_
    try:
        proxy = bstack1ll11ll11l_opy_(bstack1ll11ll1l1_opy_, bstack1ll11l1l11_opy_)
        if bstack11l1l1l_opy_ (u"ࠢࡅࡋࡕࡉࡈ࡚ࠢ೓") in proxy:
            proxies = {}
        elif bstack11l1l1l_opy_ (u"ࠣࡊࡗࡘࡕࠨ೔") in proxy or bstack11l1l1l_opy_ (u"ࠤࡋࡘ࡙ࡖࡓࠣೕ") in proxy or bstack11l1l1l_opy_ (u"ࠥࡗࡔࡉࡋࡔࠤೖ") in proxy:
            bstack1ll11l1l1l_opy_ = proxy.split(bstack11l1l1l_opy_ (u"ࠦࠥࠨ೗"))
            if bstack11l1l1l_opy_ (u"ࠧࡀ࠯࠰ࠤ೘") in bstack11l1l1l_opy_ (u"ࠨࠢ೙").join(bstack1ll11l1l1l_opy_[1:]):
                proxies = {
                    bstack11l1l1l_opy_ (u"ࠧࡩࡶࡷࡴࡸ࠭೚"): bstack11l1l1l_opy_ (u"ࠣࠤ೛").join(bstack1ll11l1l1l_opy_[1:])
                }
            else:
                proxies = {
                    bstack11l1l1l_opy_ (u"ࠩ࡫ࡸࡹࡶࡳࠨ೜"): str(bstack1ll11l1l1l_opy_[0]).lower() + bstack11l1l1l_opy_ (u"ࠥ࠾࠴࠵ࠢೝ") + bstack11l1l1l_opy_ (u"ࠦࠧೞ").join(bstack1ll11l1l1l_opy_[1:])
                }
        elif bstack11l1l1l_opy_ (u"ࠧࡖࡒࡐ࡚࡜ࠦ೟") in proxy:
            bstack1ll11l1l1l_opy_ = proxy.split(bstack11l1l1l_opy_ (u"ࠨࠠࠣೠ"))
            if bstack11l1l1l_opy_ (u"ࠢ࠻࠱࠲ࠦೡ") in bstack11l1l1l_opy_ (u"ࠣࠤೢ").join(bstack1ll11l1l1l_opy_[1:]):
                proxies = {
                    bstack11l1l1l_opy_ (u"ࠩ࡫ࡸࡹࡶࡳࠨೣ"): bstack11l1l1l_opy_ (u"ࠥࠦ೤").join(bstack1ll11l1l1l_opy_[1:])
                }
            else:
                proxies = {
                    bstack11l1l1l_opy_ (u"ࠫ࡭ࡺࡴࡱࡵࠪ೥"): bstack11l1l1l_opy_ (u"ࠧ࡮ࡴࡵࡲ࠽࠳࠴ࠨ೦") + bstack11l1l1l_opy_ (u"ࠨࠢ೧").join(bstack1ll11l1l1l_opy_[1:])
                }
        else:
            proxies = {
                bstack11l1l1l_opy_ (u"ࠧࡩࡶࡷࡴࡸ࠭೨"): proxy
            }
    except Exception as e:
        print(bstack11l1l1l_opy_ (u"ࠣࡵࡲࡱࡪࠦࡥࡳࡴࡲࡶࠧ೩"), bstack1ll11l1lll_opy_.format(bstack1ll11ll1l1_opy_, str(e)))
    bstack1ll11l1ll1_opy_ = proxies
    return proxies