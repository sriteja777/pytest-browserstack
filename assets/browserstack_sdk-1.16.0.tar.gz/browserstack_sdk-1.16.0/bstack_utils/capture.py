# coding: UTF-8
import sys
bstack1111l1l_opy_ = sys.version_info [0] == 2
bstack1l111l_opy_ = 2048
bstack1lllll1l_opy_ = 7
def bstack11l1l1l_opy_ (bstack111l1l_opy_):
    global bstack1ll111_opy_
    bstack1111111_opy_ = ord (bstack111l1l_opy_ [-1])
    bstack1l1111_opy_ = bstack111l1l_opy_ [:-1]
    bstack1lll111_opy_ = bstack1111111_opy_ % len (bstack1l1111_opy_)
    bstack11ll1l_opy_ = bstack1l1111_opy_ [:bstack1lll111_opy_] + bstack1l1111_opy_ [bstack1lll111_opy_:]
    if bstack1111l1l_opy_:
        bstack11111l1_opy_ = unicode () .join ([unichr (ord (char) - bstack1l111l_opy_ - (bstack1l1lll_opy_ + bstack1111111_opy_) % bstack1lllll1l_opy_) for bstack1l1lll_opy_, char in enumerate (bstack11ll1l_opy_)])
    else:
        bstack11111l1_opy_ = str () .join ([chr (ord (char) - bstack1l111l_opy_ - (bstack1l1lll_opy_ + bstack1111111_opy_) % bstack1lllll1l_opy_) for bstack1l1lll_opy_, char in enumerate (bstack11ll1l_opy_)])
    return eval (bstack11111l1_opy_)
import sys
class bstack1l1l1ll11l_opy_:
    def __init__(self, handler):
        self._1l1l1l1lll_opy_ = sys.stdout.write
        self._1l1l1ll111_opy_ = sys.stderr.write
        self.handler = handler
        self._started = False
    def start(self):
        if self._started:
            return
        self._started = True
        sys.stdout.write = self.bstack1l1l1ll1l1_opy_
        sys.stdout.error = self.bstack1l1l1ll1ll_opy_
    def bstack1l1l1ll1l1_opy_(self, _str):
        self._1l1l1l1lll_opy_(_str)
        if self.handler:
            self.handler({bstack11l1l1l_opy_ (u"ࠪࡰࡪࡼࡥ࡭ࠩ࿑"): bstack11l1l1l_opy_ (u"ࠫࡎࡔࡆࡐࠩ࿒"), bstack11l1l1l_opy_ (u"ࠬࡳࡥࡴࡵࡤ࡫ࡪ࠭࿓"): _str})
    def bstack1l1l1ll1ll_opy_(self, _str):
        self._1l1l1ll111_opy_(_str)
        if self.handler:
            self.handler({bstack11l1l1l_opy_ (u"࠭࡬ࡦࡸࡨࡰࠬ࿔"): bstack11l1l1l_opy_ (u"ࠧࡆࡔࡕࡓࡗ࠭࿕"), bstack11l1l1l_opy_ (u"ࠨ࡯ࡨࡷࡸࡧࡧࡦࠩ࿖"): _str})
    def reset(self):
        if not self._started:
            return
        self._started = False
        sys.stdout.write = self._1l1l1l1lll_opy_
        sys.stderr.write = self._1l1l1ll111_opy_